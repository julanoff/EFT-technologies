/*                                                              
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;


/*
 * 26-Feb-2012. JR  Fix the try/catch so we create the event log if it doesn't exist yet.
 * 
 *                  On 2nd thought, yes and no. In windows 7 you can't create the Simulator
 *                  source from in here, programatically, even if your id had admin
 *                  rights. Some game that Microsoft is playing - even if you're an admin,
 *                  you really aren't, all the way. The only option you have is to write a
 *                  program that creates the Simulator source and run that program as
 *                  an admin - right-click the executable and you can 'run as admin'. Geez.
 *                  
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 
 * 04-Jun-17    JR  BBT install exposed the fact that if you jump in here and look for a
 *                  particular event log, and it doesn't exist (yet), AND you're NOT an admin
 *                  you'll throw a security exception because the system won't let you look
 *                  at all the existing event logs. Fuck !
 * 
 */


namespace Simulator.EventLogger
{
    public class SimulatorLog : EventLog
    {
        /// as can't tell if there is an error or how to return it 
        /// set up a simple error reporting system

        private string strError;
        private bool bError = false;
        private string eventLogSource;
        /// <summary>
        /// get or set the error string
        /// </summary>
        public string Error
        {
            get { return strError; }
            set { strError = value; IsError = true; }
        }

        /// <summary>
        /// check if there has been an error
        /// </summary>
        public bool IsError
        {
            get { return bError; }
            set { bError = value; }
        }

        public SimulatorLog(string eventLogName)
        {
            eventLogSource = eventLogName;
            /*
             * This next piece of code will croak if you're not an Admin and the event
             * log doesn't exist. Pain in the ass ... What to do ? Catch it, write to
             * the application event log and throw an exception.
             */
            try
            {
                if (EventLog.SourceExists(eventLogName) == false)
                {
                    try						/// create the event log on the current computer
                    {
                        EventLog.CreateEventSource(eventLogName, eventLogName);
                    }
                    catch (ArgumentException)
                    {
                        Error = "The string passed to CreateEventSource is null";
                    }
                    catch (Exception)
                    {
                        Error = "The system could not open the registry key for " + eventLogName;
                    }
                }
                else
                {
                    Source = eventLogSource;
                }
            }
            catch
            {
                string msg = string.Format("Fatal - Simulator log {0} doesn't exist. Run ServerSetup as admin.",
                    eventLogName);
                EventLog.WriteEntry("Application", msg, EventLogEntryType.Error);
                throw new System.SystemException(msg);
            }
        }


        /// <summary>
        /// Write an entry into the log
        /// </summary>
        /// <param name="entry">Text to be written to the log</param>
        /// <returns>false on error</returns>
        private bool MakeEntry(string entry, EventLogEntryType eventType)
        {
            IsError = false;
            try
            {
                Process CurrentProc = Process.GetCurrentProcess();
                string pName = CurrentProc.ProcessName;

                if (pName.Contains("."))
                {
                    pName = pName.Substring(0, pName.IndexOf('.'));
                }
                string curEvent = pName + ": " + entry;
                WriteEntry(curEvent, eventType);
            }
            catch (ArgumentException argExp)
            {
                Error = "Argument exception is " + argExp.Message;
            }
            catch (InvalidOperationException)
            {
                Error = "You do not have write permission for the event log";
            }
            //catch (Win32Exception winExp)
            //{
            //    Error = "Win32Exception is " + winExp.Message;
            //}
            catch (SystemException)
            {
                Error = "The event log could not be notified to start receiving events";
            }
            catch (Exception)
            {
                Error = "The registry entry for the log could not be opened on the remote computer";
            }

            if (IsError == true)
                return false;
            return true;
        }
        /// <param name="information">Information to be written to the event log</param>
        /// <returns>true if written to the event log</returns>
        public bool InformationalMsg(string information)
        {
            return MakeEntry(information, EventLogEntryType.Information);
        }

        /// <summary>
        /// Write a warning to the current event log
        /// </summary>
        /// <param name="warning">warning to be written to the event log</param>
        /// <returns>true on success</returns>
        public bool WarningMsg(string warning)
        {
            return MakeEntry(warning, EventLogEntryType.Warning);
        }

        /// <summary>
        /// Write an error to the current event log
        /// </summary>
        /// <param name="error">error to be written to the event log</param>
        /// <returns>true on success</returns>
        public bool FatalMsg(string error)
        {
            return MakeEntry(error, EventLogEntryType.Error);
        }

        public bool ErrorMsg(string error)
        {
            /*
             * Kinda dumb since this is exactly the same thing as FatalMsg above
             * but I want to have this for a little more clarity for the humans
             * reading the code so they don't get confused by the word 'Fatal'.
             */ 
            return MakeEntry(error, EventLogEntryType.Error);
        }

        /// <summary>
        /// clear all the data out of the current event log
        /// </summary>
        /// <returns>false on error </returns>
        public bool ClearEventLog()
        {
            IsError = false;
            try
            {
                Clear();
            }
            //catch (Win32Exception winExp)
            //{
            //    IsError = true;
            //    Error = "Win 32 Exception " + winExp.Message;
            //}
            catch (ArgumentException)
            {
                IsError = true;
                Error = "The log name is empty";
            }
            catch (Exception)
            {
                IsError = true;
                Error = "The log could not be opened";
            }

            if (IsError == true)
                return false;
            else
                return true;
        }


        /// <summary>
        /// Remove the current event log and source from the system
        /// </summary>
        /// <param name="eventLogName">Name of the event log to be deleted</param>
        /// <returns>false if error</returns>
        public bool DeleteEventLog()
        {
            IsError = false;

            try
            {
                EventLog.Delete(Source);
            }

            catch (ArgumentException)
            {
                IsError = true;
                Error = "Event Log Name is null";
            }

            catch (SystemException sysExp)
            {
                IsError = true;
                Error = "System Exception " + sysExp;
            }

            if (IsError == true)
                return false;
            else
                return true;
        }
    }

}
