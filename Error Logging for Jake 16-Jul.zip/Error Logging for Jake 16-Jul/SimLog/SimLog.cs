/*                                                              
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
 * 
 * 
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 
 * 23-May-17    JR  BBT wants the Simulator to live on the D: drive
 *                  so we can't arbitrarily hard-wire the drive name in here. Sigh.
 *                  
 * 15-Jul-17    JR  Let's do a console.writeline as well as writing to the log file. That
 *                  way, if we're running code in a command window, we'll be able to see
 *                  the info, too.
 * 
 * 
*/
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.DBLibrary;

namespace Simulator.SimLog
{
    public class log
    {
        public static void eventLog(string area, string info)
        {
           /*
            * Most vanilla entry point will write 'info' messages.
            */ 
            eventLog(area, info, 0);
        }

        public static void eventLog(string area, string info, int severity)
        {
            /*
             * Let's write out this message to the console, log it to the Simulator event
             * log and put it in the area's event table. One-stop shopping ...
             */ 
            write(area, info, false);
            try
            {
                SimulatorLog eventLog = new SimulatorLog("Simulator");
                switch (severity)
                {
                    case 0:
                        eventLog.InformationalMsg(info);
                        break;
                    case 1:
                    case 2:
                    case 3:
                        eventLog.ErrorMsg(info);
                        break;
                    default:
                        eventLog.FatalMsg(info);
                        break;
                }
            }
            catch (Exception re)
            {
                write(area, "SimLog threw exception in RecordException: " + re.Message);
                write(area, "SimLog was trying to record this exception: " + info);
            }
            SimEventLog( area,  info,  severity);
        }


        public static void SimEventLog(string area, string info)
        {
            SimEventLog( area,  info, 0);
        }

        public static void SimEventLog(string area, string info, int severity)
        {
            DBAccess dbconn = new DBAccess();
            try
            {
                Process myProcess = Process.GetCurrentProcess();
                string pName = myProcess.ProcessName;
                if (pName.Contains("."))
                {
                    pName = pName.Substring(0, pName.IndexOf('.'));
                }
                info = info.Replace("'", "''");
                dbconn.Connect(true, area);
                string cmd = string.Format("insert into SimulatorEvents (Eventtime, severity,Who,Event) values ('{0}','{1}','{2}','{3}')",
                    DateTime.Now, severity, pName, info);
                dbconn.Execute(cmd, true);
            }
            catch (Exception ex)
            {
                SimLog.log.write(area, "DbAccess record event threw exception: " + ex.Message);

            }
            finally
            {
                dbconn.DisConnect();
            }
        }


        public static void write(string area, string info)
        {
            write(area, info, false);
        }
        public static void write(string area, string info, bool indent)
        {
            int tries = 5;
            int cnt = 0;
            BackEndSubs util = new BackEndSubs();
            string simDrive = util.GetAreaRoot(area);
            simDrive = simDrive.Substring(0, simDrive.IndexOf(":") + 1);
            string fName = string.Format(simDrive + "\\Simulator\\{0}\\{0}_log.txt", area);
            FileStream logFile;
            while (true)
            {
                try
                {
                    logFile = new FileStream(fName, FileMode.Append, FileAccess.Write);
                    break;
                }
                catch (Exception ex)
                {
                    cnt++;
                    if (ex.Message.IndexOf("The process cannot access the file") != -1)
                    {
                        System.Threading.Thread.Sleep(1000); //wait 1 sec
                    }
                    if (cnt > tries)
                    {
                        Console.WriteLine("file is busy. wait.. Error - " + ex.Message);
                        return;
                    }
                }

            }
            StreamWriter swriter = new StreamWriter(logFile);
            string now = DateTime.Now.ToString("dd-MMM-yyy HH:mm:ss") + " ";

            string myIndent;
            if (indent)
            {
                myIndent = "     ";
            }
            else
            {
                myIndent = "";
            }
            swriter.WriteLine(now + myIndent + info);
            swriter.Flush();
            swriter.Close();
            Console.WriteLine(info);
        }
    }
}
