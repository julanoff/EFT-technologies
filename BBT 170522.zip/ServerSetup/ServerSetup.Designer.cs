namespace ServerSetup
{
    partial class ServerSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateDB_button = new System.Windows.Forms.Button();
            this.Area_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.UserName_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Message_textBox = new System.Windows.Forms.TextBox();
            this.LoadAreaTables_button = new System.Windows.Forms.Button();
            this.CreateMDRtables_button = new System.Windows.Forms.Button();
            this.InitArea_button = new System.Windows.Forms.Button();
            this.LoadCompareKeys_button = new System.Windows.Forms.Button();
            this.LoadErrorCode_button = new System.Windows.Forms.Button();
            this.LoadEditTables_button = new System.Windows.Forms.Button();
            this.LoadXML_button = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.simVersion_textBox = new System.Windows.Forms.TextBox();
            this.simVersionLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.updateSimVersion_button = new System.Windows.Forms.Button();
            this.purgeQbl_button = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.UpdateRgwLoadTablesButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CreateDB_button
            // 
            this.CreateDB_button.Location = new System.Drawing.Point(23, 118);
            this.CreateDB_button.Name = "CreateDB_button";
            this.CreateDB_button.Size = new System.Drawing.Size(146, 23);
            this.CreateDB_button.TabIndex = 0;
            this.CreateDB_button.Text = "Create Database";
            this.CreateDB_button.UseVisualStyleBackColor = true;
            this.CreateDB_button.Click += new System.EventHandler(this.CreateDB_button_Click);
            // 
            // Area_textBox
            // 
            this.Area_textBox.Location = new System.Drawing.Point(116, 31);
            this.Area_textBox.Name = "Area_textBox";
            this.Area_textBox.Size = new System.Drawing.Size(130, 20);
            this.Area_textBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Specify the Area";
            // 
            // UserName_textBox
            // 
            this.UserName_textBox.Location = new System.Drawing.Point(344, 31);
            this.UserName_textBox.Name = "UserName_textBox";
            this.UserName_textBox.Size = new System.Drawing.Size(100, 20);
            this.UserName_textBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(257, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Specify the User";
            // 
            // Message_textBox
            // 
            this.Message_textBox.Location = new System.Drawing.Point(23, 430);
            this.Message_textBox.Name = "Message_textBox";
            this.Message_textBox.Size = new System.Drawing.Size(429, 20);
            this.Message_textBox.TabIndex = 5;
            // 
            // LoadAreaTables_button
            // 
            this.LoadAreaTables_button.Location = new System.Drawing.Point(69, 237);
            this.LoadAreaTables_button.Name = "LoadAreaTables_button";
            this.LoadAreaTables_button.Size = new System.Drawing.Size(146, 23);
            this.LoadAreaTables_button.TabIndex = 6;
            this.LoadAreaTables_button.Text = "Load Area Tables";
            this.LoadAreaTables_button.UseVisualStyleBackColor = true;
            this.LoadAreaTables_button.Click += new System.EventHandler(this.LoadAreaTables_button_Click);
            // 
            // CreateMDRtables_button
            // 
            this.CreateMDRtables_button.Location = new System.Drawing.Point(23, 156);
            this.CreateMDRtables_button.Name = "CreateMDRtables_button";
            this.CreateMDRtables_button.Size = new System.Drawing.Size(146, 23);
            this.CreateMDRtables_button.TabIndex = 7;
            this.CreateMDRtables_button.Text = "Create MDR Tables";
            this.CreateMDRtables_button.UseVisualStyleBackColor = true;
            this.CreateMDRtables_button.Click += new System.EventHandler(this.CreateMDRtables_button_Click);
            // 
            // InitArea_button
            // 
            this.InitArea_button.Location = new System.Drawing.Point(23, 194);
            this.InitArea_button.Name = "InitArea_button";
            this.InitArea_button.Size = new System.Drawing.Size(146, 23);
            this.InitArea_button.TabIndex = 8;
            this.InitArea_button.Text = "Initialize an Area";
            this.InitArea_button.UseVisualStyleBackColor = true;
            this.InitArea_button.Click += new System.EventHandler(this.InitArea_button_Click);
            // 
            // LoadCompareKeys_button
            // 
            this.LoadCompareKeys_button.Location = new System.Drawing.Point(69, 266);
            this.LoadCompareKeys_button.Name = "LoadCompareKeys_button";
            this.LoadCompareKeys_button.Size = new System.Drawing.Size(146, 23);
            this.LoadCompareKeys_button.TabIndex = 9;
            this.LoadCompareKeys_button.Text = "Load Compare Keys";
            this.LoadCompareKeys_button.UseVisualStyleBackColor = true;
            this.LoadCompareKeys_button.Click += new System.EventHandler(this.LoadCompareKeys_button_Click);
            // 
            // LoadErrorCode_button
            // 
            this.LoadErrorCode_button.Location = new System.Drawing.Point(69, 295);
            this.LoadErrorCode_button.Name = "LoadErrorCode_button";
            this.LoadErrorCode_button.Size = new System.Drawing.Size(146, 23);
            this.LoadErrorCode_button.TabIndex = 10;
            this.LoadErrorCode_button.Text = "Load Error Codes";
            this.LoadErrorCode_button.UseVisualStyleBackColor = true;
            this.LoadErrorCode_button.Click += new System.EventHandler(this.LoadErrorCode_button_Click);
            // 
            // LoadEditTables_button
            // 
            this.LoadEditTables_button.Location = new System.Drawing.Point(69, 324);
            this.LoadEditTables_button.Name = "LoadEditTables_button";
            this.LoadEditTables_button.Size = new System.Drawing.Size(146, 23);
            this.LoadEditTables_button.TabIndex = 11;
            this.LoadEditTables_button.Text = "Load Edit Tables";
            this.LoadEditTables_button.UseVisualStyleBackColor = true;
            this.LoadEditTables_button.Click += new System.EventHandler(this.LoadEditTables_button_Click);
            // 
            // LoadXML_button
            // 
            this.LoadXML_button.Location = new System.Drawing.Point(69, 353);
            this.LoadXML_button.Name = "LoadXML_button";
            this.LoadXML_button.Size = new System.Drawing.Size(146, 23);
            this.LoadXML_button.TabIndex = 12;
            this.LoadXML_button.Text = "Load XML Configuration";
            this.LoadXML_button.UseVisualStyleBackColor = true;
            this.LoadXML_button.Click += new System.EventHandler(this.LoadXML_button_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(274, 118);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Dump Configuration";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.DumpConfiguration);
            // 
            // simVersion_textBox
            // 
            this.simVersion_textBox.Location = new System.Drawing.Point(344, 68);
            this.simVersion_textBox.Name = "simVersion_textBox";
            this.simVersion_textBox.Size = new System.Drawing.Size(100, 20);
            this.simVersion_textBox.TabIndex = 14;
            // 
            // simVersionLabel
            // 
            this.simVersionLabel.AutoSize = true;
            this.simVersionLabel.Location = new System.Drawing.Point(257, 75);
            this.simVersionLabel.Name = "simVersionLabel";
            this.simVersionLabel.Size = new System.Drawing.Size(62, 13);
            this.simVersionLabel.TabIndex = 15;
            this.simVersionLabel.Text = "Sim Version";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(283, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Housekeeping";
            // 
            // updateSimVersion_button
            // 
            this.updateSimVersion_button.Location = new System.Drawing.Point(274, 236);
            this.updateSimVersion_button.Name = "updateSimVersion_button";
            this.updateSimVersion_button.Size = new System.Drawing.Size(117, 23);
            this.updateSimVersion_button.TabIndex = 17;
            this.updateSimVersion_button.Text = "Update Sim Version";
            this.updateSimVersion_button.UseVisualStyleBackColor = true;
            this.updateSimVersion_button.Click += new System.EventHandler(this.updateSimVersion_button_Click);
            // 
            // purgeQbl_button
            // 
            this.purgeQbl_button.Location = new System.Drawing.Point(274, 322);
            this.purgeQbl_button.Name = "purgeQbl_button";
            this.purgeQbl_button.Size = new System.Drawing.Size(117, 23);
            this.purgeQbl_button.TabIndex = 18;
            this.purgeQbl_button.Text = "Purge QBL table";
            this.purgeQbl_button.UseVisualStyleBackColor = true;
            this.purgeQbl_button.Click += new System.EventHandler(this.purgeQbl_button_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(274, 353);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(124, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "Create FT keys flat file";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.FTKeys_button_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(69, 399);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(146, 23);
            this.button3.TabIndex = 20;
            this.button3.Text = "Add Outbound Tables";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.AddOutboundTables_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(274, 156);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(150, 23);
            this.button4.TabIndex = 21;
            this.button4.Text = "Create Simulator Event log";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.CreateEventLogs_Click);
            // 
            // UpdateRgwLoadTablesButton
            // 
            this.UpdateRgwLoadTablesButton.Location = new System.Drawing.Point(274, 265);
            this.UpdateRgwLoadTablesButton.Name = "UpdateRgwLoadTablesButton";
            this.UpdateRgwLoadTablesButton.Size = new System.Drawing.Size(170, 23);
            this.UpdateRgwLoadTablesButton.TabIndex = 22;
            this.UpdateRgwLoadTablesButton.Text = "Update RGW Message Tables";
            this.UpdateRgwLoadTablesButton.UseVisualStyleBackColor = true;
            this.UpdateRgwLoadTablesButton.Click += new System.EventHandler(this.UpdateRgwLoadTables_button_click);
            this.UpdateRgwLoadTablesButton.MouseHover += new System.EventHandler(this.UpdateRgwLoadTables_mouse_hover);
            // 
            // ServerSetup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 586);
            this.Controls.Add(this.UpdateRgwLoadTablesButton);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.purgeQbl_button);
            this.Controls.Add(this.updateSimVersion_button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.simVersionLabel);
            this.Controls.Add(this.simVersion_textBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.LoadXML_button);
            this.Controls.Add(this.LoadEditTables_button);
            this.Controls.Add(this.LoadErrorCode_button);
            this.Controls.Add(this.LoadCompareKeys_button);
            this.Controls.Add(this.InitArea_button);
            this.Controls.Add(this.CreateMDRtables_button);
            this.Controls.Add(this.LoadAreaTables_button);
            this.Controls.Add(this.Message_textBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.UserName_textBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Area_textBox);
            this.Controls.Add(this.CreateDB_button);
            this.Name = "ServerSetup";
            this.Text = "Simulator Server Setup";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CreateDB_button;
        private System.Windows.Forms.TextBox Area_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox UserName_textBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Message_textBox;
        private System.Windows.Forms.Button LoadAreaTables_button;
        private System.Windows.Forms.Button CreateMDRtables_button;
        private System.Windows.Forms.Button InitArea_button;
        private System.Windows.Forms.Button LoadCompareKeys_button;
        private System.Windows.Forms.Button LoadErrorCode_button;
        private System.Windows.Forms.Button LoadEditTables_button;
        private System.Windows.Forms.Button LoadXML_button;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox simVersion_textBox;
        private System.Windows.Forms.Label simVersionLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button updateSimVersion_button;
        private System.Windows.Forms.Button purgeQbl_button;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button UpdateRgwLoadTablesButton;
    }
}

