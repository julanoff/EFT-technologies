/*                                                              
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Simulator.BackEndSubLib;
using Simulator.dataDefs;
using Simulator.DBLibrary;
using System.IO;
using Simulator.SimLog;
using System.Reflection;
using System.Configuration;
using System.Diagnostics;
/*
 * 13-Jun-15    Add a button to create the windows Simulator event log if needed.
 * 
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 
 * 05-Mar-16    JR  When creating event logs, also create ACIFeeder event log.
 * 
 */

namespace ServerSetup
{
    public partial class ServerSetup : Form
    {
        public ServerSetup()
        {
            InitializeComponent();
            simVersion_textBox.Text = "5.0";
        }

        private void CreateDB_button_Click(object sender, EventArgs e)
        {

            string area = Area_textBox.Text.Trim();
            if (area.Length > 0)
            {
                int status = 0;
                CreateDatabase createDB = new CreateDatabase();
                string user = UserName_textBox.Text.Trim();
                if (user.Length > 0)
                {
                    status = createDB.newDB(area, user);
                }
                else
                {
                    status = createDB.newDB(area);
                }
                if (status > 0)
                    Message_textBox.Text = string.Format("New Database created: 'Simulator_{0}'",
                        area);
                return;
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }

        }

        //private void x()
        //{
        //    string xyz = "";
        //    string Area;
        //    switch (xyz)
        //    {

        //        //case "MDR":
        //        //    /*
        //        //     * Create just the message tables. 
        //        //     */
        //        //    rgwDef_v1 rgwDef_v1 = new rgwDef_v1();
        //        //    rgwDef_v1.initMessageRepository(Area);
        //        //    util.logInfo(Area, "LoadConfig", "Created Message Tables");
        //        //    break;

        //        //case "COMPAREKEYS":
        //        //case "MASTERCOMPAREKEYS":
        //        //    baseCfg.LoadCompareKeys(dbWrt, Area);
        //        //    baseCfg.LoadRGWCompareKeys(dbWrt, Area);
        //        //    util.logInfo(Area, "LoadConfig", "Loaded Compare Keys");
        //        //    break;

        //        //case "ERRORCODES":
        //        //    baseCfg.LoadErrorCodes(dbWrt, Area);
        //        //    baseCfg.LoadChpTags(dbWrt, Area);
        //        //    util.logInfo(Area, "LoadConfig", "Loaded Error Codes");
        //        //    break;

        //        //case "EDITS":
        //        //    baseCfg.doEditTables(dbWrt, Area);
        //        //    util.logInfo(Area, "LoadConfig", "Loaded s");
        //        //    break;

        //        //case "CONTROL":
        //        //    LoadXMLConfig(dbWrt, "c:\\Simulator\\" + Area + "_Config.xml");
        //        //    util.logInfo(Area, "LoadConfig", "Loaded just the xml configuration");
        //        //    break;

        //        case "NEWLINE":
        //            //LoadXMLConfig(dbWrt, "c:\\Simulator\\" + Arg2);
        //            //util.logInfo(Area, "LoadConfig", "Loaded new line info from: " + Arg2);
        //            break;


        //    }
        //}

        private void LoadAreaTables_button_Click(object sender, EventArgs e)
        {
            string area = Area_textBox.Text.Trim();
            if (area.Length > 0)
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                BackEndSubs util = new BackEndSubs();
                BaselineConfig baseCfg = new BaselineConfig();
                baseCfg.LoadAreaTables(dbWrt, area);
                baseCfg.dumpConfiguration(area);
                util.logInfo(area, "LoadConfig", "Loaded Area Tables");
                Message_textBox.Text = string.Format("Area tables for Area {0} loaded.", area);
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }

        }

        private void CreateMDRtables_button_Click(object sender, EventArgs e)
        {
            BackEndSubs util = new BackEndSubs();
            string area = Area_textBox.Text.Trim();
            string rgwVersion = simVersion_textBox.Text.Trim();
            CreateMDRTables(area, rgwVersion);
        }

        private void CreateMDRTables(string area, string rgwVersion)
        {
            BackEndSubs util = new BackEndSubs();
            string version = "";
            try
            {
                if (area.Length > 0)
                {
                    LoadConfig lcfg = new LoadConfig(area);
                    string rgwMainVersion = rgwVersion.Substring(0, rgwVersion.IndexOf("."));
                    switch (rgwMainVersion)
                    {
                        case "5":
                            {
                                dataDefs.rgwDef_v5 rgwDef = new dataDefs.rgwDef_v5();
                                rgwDef.initMessageRepository(area);
                                version = "MTS 5.0";
                                break;
                            }
                        case "4":
                            {
                                dataDefs.rgwDef_v4 rgwDef = new dataDefs.rgwDef_v4();
                                rgwDef.initMessageRepository(area);
                                version = "MTS 4.0";
                                break;
                            }
                        case "3":
                            {
                                rgwDef_v3 rgwDef = new rgwDef_v3();
                                rgwDef.initMessageRepository(area);
                                version = "MTS 3.0";
                                break;
                            }
                        default:
                            {
                                Message_textBox.Text = string.Format("Unknown RGW/MTS version.");           
                                break;
                            }

                    }

                    util.logInfo(area, "LoadConfig", "Created Message Tables");
                    Message_textBox.Text = string.Format("Message tables for Area {0} created. RGW table version {1}", area, version);
                }
                else
                {
                    Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
                }
            }
            catch (Exception createMdrExc)
            {
                Message_textBox.Text = string.Format("Area {0} Update exception {1}", area,
                    createMdrExc.Message.ToString());
            }
        }

        private void InitArea_button_Click(object sender, EventArgs e)
        {

            string area = Area_textBox.Text.Trim();
            string rgwVersion = simVersion_textBox.Text.Trim();

            //SimLog.log.write(area, "Sever Setup - initialize area " + area + " rgw version " + rgwVersion);
            //string version = "";
            if (area.Length > 0)
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                BaselineConfig baseCfg = new BaselineConfig();
                BackEndSubs util = new BackEndSubs();
                CreateMDRTables(area, rgwVersion);
                LoadConfig lcfg = new LoadConfig(area);
                lcfg.InitMasters(area);
                try
                {
                    util.CreateDirectories("c:\\Simulator\\", area);
                    baseCfg.SimulatorInit(dbWrt, area, "ACI");
                    baseCfg.LoadAreaTables(dbWrt, area);

                    baseCfg.LoadErrorCodes(dbWrt, area);
                    baseCfg.LoadChpTags(dbWrt, area);
                    baseCfg.doEditTables(dbWrt, area);

                    lcfg.LoadXMLConfig(dbWrt, "c:\\Simulator\\" + area + "_Config.xml");
                    baseCfg.LoadCompareKeys(dbWrt, area);
                    baseCfg.LoadRGWCompareKeys(dbWrt, area);
                }
                catch
                {

                }
                util.logInfo(area, "LoadConfig", "Initialized everything");
                Message_textBox.Text = string.Format("Area {0} initialized. RGW table format is {1}", area, rgwVersion);
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }
        }

        private void FTKeys_button_Click(object sender, EventArgs e)
        {
            StreamWriter swriter;
            FileStream out_file;
            string area = Area_textBox.Text.Trim();
            DBAccess dbWrt = new DBAccess();
            dbWrt.Connect(true, area);
            BaselineConfig baseCfg = new BaselineConfig();
            BackEndSubs util = new BackEndSubs();

            string FTKeysFile = "c:\\Simulator\\ftkeys.txt";

            bool createFile = true;

            if (createFile)
            {
                string cmd = "select top 1 * from mif";
                DataTable mif = dbWrt.getDataSet(cmd).Tables[0];
                cmd = "select top 1 * from mtf1000";
                DataTable mtf1000 = dbWrt.getDataSet(cmd).Tables[0];
                cmd = "select top 1 * from msg_rule_log";
                DataTable msgRule = dbWrt.getDataSet(cmd).Tables[0];


                out_file = new FileStream(FTKeysFile, FileMode.OpenOrCreate, FileAccess.Write);
                swriter = new StreamWriter(out_file);
                char dblQuote = '"';
                string xmlHeader = "<?xml version=" + dblQuote + "1.0" + dblQuote;
                xmlHeader = xmlHeader + " standalone =" + dblQuote + "yes" + dblQuote + "?>";
                swriter.WriteLine(xmlHeader);
                swriter.Flush();
                swriter.WriteLine("<FundTechKeys>");
                swriter.Flush();

                for (int i = 0; i < mif.Columns.Count; i++)
                {
                    DataColumn dc = mif.Columns[i];
                    string name = dc.ColumnName;
                    string type = dc.DataType.ToString();
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<MIF>\n");
                    sb.Append(string.Format("  <IdiKey>{0}</IdiKey>\n", name));
                    sb.Append(string.Format("  <CmpKey>{0}</CmpKey>\n", name));
                    sb.Append(string.Format("  <XmlSet>MIF</XmlSet>\n"));
                    sb.Append(string.Format("  <compExpression>=</compExpression>\n"));
                    sb.Append(string.Format("  <Include>Y</Include>\n"));
                    sb.Append(string.Format("  <OrdinalType>none</OrdinalType>\n"));
                    sb.Append("</MIF>");
                    swriter.WriteLine(sb.ToString());
                    swriter.Flush();
                }
                for (int i = 0; i < mtf1000.Columns.Count; i++)
                {
                    DataColumn dc = mtf1000.Columns[i];
                    string name = dc.ColumnName;
                    string type = dc.DataType.ToString();
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<mtf1000>\n");
                    sb.Append(string.Format("  <IdiKey>{0}</IdiKey>\n", name));
                    sb.Append(string.Format("  <CmpKey>{0}</CmpKey>\n", name));
                    sb.Append(string.Format("  <XmlSet>mtf1000</XmlSet>\n"));
                    sb.Append(string.Format("  <compExpression>=</compExpression>\n"));
                    sb.Append(string.Format("  <Include>Y</Include>\n"));
                    sb.Append(string.Format("  <OrdinalType>none</OrdinalType>\n"));
                    sb.Append("</mtf1000>");
                    swriter.WriteLine(sb.ToString());
                    swriter.Flush();
                }

                StringBuilder sb1 = new StringBuilder();
                sb1.Append("<history>\n");
                sb1.Append(string.Format("  <IdiKey>Status</IdiKey>\n"));
                sb1.Append(string.Format("  <CmpKey>status</CmpKey>\n"));
                sb1.Append(string.Format("  <XmlSet>mtf1000</XmlSet>\n"));
                sb1.Append(string.Format("  <compExpression>=</compExpression>\n"));
                sb1.Append(string.Format("  <Include>Y</Include>\n"));
                sb1.Append(string.Format("  <OrdinalType>none</OrdinalType>\n"));
                sb1.Append("</history>\n");


                sb1.Append("<msg_rule_log>\n");
                sb1.Append(string.Format("  <IdiKey>Description</IdiKey>\n"));
                sb1.Append(string.Format("  <CmpKey>Description</CmpKey>\n"));
                sb1.Append(string.Format("  <XmlSet>mtf1000</XmlSet>\n"));
                sb1.Append(string.Format("  <compExpression>=</compExpression>\n"));
                sb1.Append(string.Format("  <Include>Y</Include>\n"));
                sb1.Append(string.Format("  <OrdinalType>none</OrdinalType>\n"));
                sb1.Append("</msg_rule_log>");
                swriter.WriteLine(sb1.ToString());
                swriter.Flush();

                swriter.WriteLine("</FundTechKeys>");
                swriter.Flush();
            }
            else
            {
                baseCfg.loadFundTechCompareKeys(area);
                /*
                util.MakeNewTable("MasterFundTechCompareKeys", "CompareKeys", dbWrt, area, false);
                util.UpdateTableDescription("MasterFundTechCompareKeys", "Master FT Compare Key List", dbWrt);
                util.MakeNewTable("FundTechTestKeys", "CompareKeys", dbWrt, area, false);
                util.UpdateTableDescription("FundTechTestKeys", "FT Test Compare Key List", dbWrt);
           
                DataSet ds = new DataSet();
                ds.ReadXml(FTKeysFile);
                int nTables = ds.Tables.Count;
                for (int i = 0; i < nTables; i++)
                {
                    DataTable dt = ds.Tables[i];
                    for (int rCount = 0; rCount < dt.Rows.Count; rCount++)
                    {
                        DataRow dr = dt.Rows[rCount];
                        string cmd = string.Format("insert into {0} (idikey, cmpkey, xmlset, compExpression, "+
                            "include, ordinalType) values ('{1}', '{2}', '{3}', '{4}', '{5}', '{6}')" ,
                        "MasterFundTechCompareKeys",
                        dr[0].ToString(),
                        dr[1].ToString(),
                        dr[2].ToString(),
                        dr[3].ToString(),
                        dr[4].ToString(),
                        dr[5].ToString());
                        dbWrt.Execute(cmd, true);

                        cmd = cmd.Replace("MasterFundTechCompareKeys", "FundTechTestKeys");
                        dbWrt.Execute(cmd, true);
                    }
                }
                */
            }
        }

        private void LoadCompareKeys_button_Click(object sender, EventArgs e)
        {
            string area = Area_textBox.Text.Trim();
            if (area.Length > 0)
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                BaselineConfig baseCfg = new BaselineConfig();
                BackEndSubs util = new BackEndSubs();
                baseCfg.LoadCompareKeys(dbWrt, area);
                baseCfg.LoadRGWCompareKeys(dbWrt, area);
                baseCfg.loadFundTechCompareKeys(area);
                util.logInfo(area, "LoadConfig", "Loaded Compare Keys");
                Message_textBox.Text = string.Format("Compare keys for Area {0} loaded.", area);
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }
        }

        private void LoadErrorCode_button_Click(object sender, EventArgs e)
        {
            string area = Area_textBox.Text.Trim();
            if (area.Length > 0)
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                BaselineConfig baseCfg = new BaselineConfig();
                BackEndSubs util = new BackEndSubs();
                baseCfg.LoadErrorCodes(dbWrt, area);
                baseCfg.LoadChpTags(dbWrt, area);
                util.logInfo(area, "LoadConfig", "Loaded Error Codes");
                Message_textBox.Text = string.Format("Error codes for Area {0} loaded.", area);
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }
        }

        private void LoadEditTables_button_Click(object sender, EventArgs e)
        {
            string area = Area_textBox.Text.Trim();
            if (area.Length > 0)
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                BaselineConfig baseCfg = new BaselineConfig();
                BackEndSubs util = new BackEndSubs();
                baseCfg.doEditTables(dbWrt, area);
                util.logInfo(area, "LoadConfig", "Loaded edit tables");
                Message_textBox.Text = string.Format("Edit tables for Area {0} loaded.", area);
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }

        }

        private void LoadXML_button_Click(object sender, EventArgs e)
        {
            string area = Area_textBox.Text.Trim();
            if (area.Length > 0)
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                BaselineConfig baseCfg = new BaselineConfig();
                BackEndSubs util = new BackEndSubs();
                LoadConfig lcfg = new LoadConfig(area);
                lcfg.SetVendor("ACI");

                lcfg.LoadXMLConfig(dbWrt, "c:\\Simulator\\" + area + "_Config.xml");
                util.logInfo(area, "LoadConfig", "Loaded just the xml configuration");
                Message_textBox.Text = string.Format("Configuration (XML) for Area {0} loaded.", area);
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }

        }

        private void DumpConfiguration(object sender, EventArgs e)
        {
            string area = Area_textBox.Text.Trim();
            if (area.Length > 0)
            {
                BaselineConfig basecfg = new BaselineConfig();
                basecfg.dumpConfiguration(area);
                Message_textBox.Text = string.Format("Dumped configuration for area {0}", area);
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }
        }

        private void DeleteRgwTables_button_Click(object sender, EventArgs e)
        {
            string area = Area_textBox.Text.Trim();
            if (area.Length > 0)
            {
                BaselineConfig basecfg = new BaselineConfig();
                basecfg.dumpConfiguration(area);
                Message_textBox.Text = string.Format("Dumped configuration for area {0}", area);
            }
            else
            {
                Message_textBox.Text = string.Format("Please enter a value for the 'area'.");
            }
        }

        private void updateSimVersion_button_Click(object sender, EventArgs e)
        {

            string simVersion = simVersion_textBox.Text.ToString();
            string tmp = string.Format("update SimulatorControl set SimVersion='{0}'",
                    simVersion);
            string area = Area_textBox.Text.ToString();

            try
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                dbWrt.Execute(tmp, true);
                dbWrt.Commit();
                dbWrt.DisConnect();
                dbWrt.Dispose();
                Message_textBox.Text = string.Format("Area {0} Simulator Version = {1}", area, simVersion);
            }
            catch (Exception simUpdateExc)
            {
                Message_textBox.Text = string.Format("Area {0} Update exception {1}", area,
                    simUpdateExc.Message.ToString());
            }
        }

        private void UpdateRgwLoadTables_button_click(object sender, EventArgs e)
        {

        }

        private void UpdateRgwLoadTables_mouse_hover(object sender, EventArgs e)
        {
            Message_textBox.Text = string.Format("This will update all area rgw tables to the version specified by Sim Version (above)"); 
        }
        private void purgeQbl_button_Click(object sender, EventArgs e)
        {

            string simVersion = simVersion_textBox.Text.ToString();
            string tmp = string.Format("Truncate table qblidtable");
            string area = Area_textBox.Text.ToString();
            try
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                dbWrt.Execute(tmp, true);
                dbWrt.Commit();
                dbWrt.DisConnect();
                dbWrt.Dispose();
                Message_textBox.Text = string.Format("Area {0} QblId table truncated", area);
            }
            catch 
            {
                Message_textBox.Text = "Threw an exception, probably a bad area name";
            }
        }

        private void AddOutboundTables_Click(object sender, EventArgs e)
        {
            string simVersion = simVersion_textBox.Text.ToString();

            string area = Area_textBox.Text.ToString();
            try
            {
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, area);
                BackEndSubs util = new BackEndSubs();
                util.MakeNewTable("MTS_REF_IDS", "MTS_REF_IDS", dbWrt, area, false);
               util.MakeNewTable("MTS_RCV_TEXT", "MTS_RCV_TEXT", dbWrt, area, false);

                string tmp = string.Format("alter table RECEIVECONTROL add Fmt char(3)");
                dbWrt.ExecuteExc(tmp, true);
                tmp = string.Format("alter table RECEIVECONTROL add RefId int null");
                dbWrt.ExecuteExc(tmp, true);

                Message_textBox.Text = string.Format("Area {0} new tables added", area);
            }
            catch
            {
                Message_textBox.Text = "Threw an exception, probably a bad area name";
            }
        }

        private void CreateEventLogs_Click(object sender, EventArgs e)
        {

            if (!EventLog.SourceExists("Simulator"))
            {
                //An event log source should not be created and immediately used.
                //There is a latency time to enable the source, it should be created
                //prior to executing the application that uses the source.
                //Execute this sample a second time to use the new source.

                EventLog.CreateEventSource("Simulator", "Simulator");
                Console.WriteLine("CreatedEventSource");

                Console.WriteLine("Exiting, execute the application a second time to use the source.");
                // The source is created.  Exit the application to allow it to be registered.
                //return;

                // Create an EventLog instance and assign its source.
                EventLog myLog = new EventLog();
                myLog.Source = "Simulator";

                // Write an informational entry to the event log.    
                myLog.WriteEntry("Writing to event log.");

            }
            if (!EventLog.SourceExists("ACIFeeder"))
            {
                EventLog.CreateEventSource("ACIFeeder", "ACIFeeder");
                Console.WriteLine("CreatedEventSource");

                Console.WriteLine("Exiting, execute the application a second time to use the source.");
                // The source is created.  Exit the application to allow it to be registered.
                //return;

                // Create an EventLog instance and assign its source.
                EventLog myLog1 = new EventLog();
                myLog1.Source = "ACIFeeder";

                // Write an informational entry to the event log.    
                myLog1.WriteEntry("Writing to event log.");
            }

            return;
        }
    }
}