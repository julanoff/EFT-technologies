using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Threading;

/// <summary>
/// Summary description for CacheElement
/// </summary>
///
namespace Simulator
{
    public class CacheElement : IComparable
    {
        public CacheElement(string query, DateTime issued,string source,string fields)
        {
            _query = query;
            _issued = issued;
            _source=source;
            _fields=fields;
            Random random=new Random();
            _id = random.Next().ToString();
            _thread = null;
          
        }
        private string _query;
        private DateTime _issued;
        private int _counter;
        private string _source;
        private string _fields;
        private string _id;
        private Thread _thread;
        public Thread getThread() { return _thread; }
        public void setThread(Thread value) { _thread = value; }
        public string Query
        {
            get { return _query; }
        }
        public DateTime Issued
        {
            get { return _issued; }
        }
        public int Counter
        {
            get { return _counter; }
            set { _counter = value; }
        }
        public string Fields
        {
            get {return _fields;}
            set {_fields=value;}
        }
        public string Source
        {
            get {return _source;}
            set {_source=value;}
        }
        public string ID
        {
            get { return _id; }
        }
        #region IComparable Members
        public int CompareTo(object o)
        {
            CacheElement ce = o as CacheElement;
            if (ce == null)
                throw new Exception("Execution cache does not contain proper object type.");
            if (_issued > ce.Issued)
                return 1;
            else
                if (_issued == ce.Issued)
                    return 0;
            return -1;
        }
        #endregion
    }
}
