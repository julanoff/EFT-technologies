/*                                                             
 Copyright (c) 1999 - 2005 by Professional Practice Automated Solutions, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 Professional Practice Automated Solutions and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 Professional Practice Automated Solutions, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of Professional Practice Automated Solutions, Inc.
*/
using System;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.Text;
using System.IO;
using System.Collections;
using Simulator.DBLibrary;
using Simulator.CompareSubs;
using Simulator.StringArrayCompare;
using System.Data;

/*
 * 10-Mar-07    JR  Change the behavior when we don't find a field in the 'other' table. Just populate the thing
 *                  we show the humans with the name and the value of the field we're looking for and say we couldn't
 *                  find it.
 * 
 *                  Move the message compare logic to one central place in CompareSubs. Let's try to
 *                  use the same code everywhere we're comparing msgs.
 * 
 * 01-Jun-08    JR  A few tweaks here and there to deal with issues I found testing RGW Compares.
 * 16-Jul-08    JR  A final tweak so we can use the new compare methodology.
 * 23-Jul-08    JR  I managed to break the logic so that it never paid attention to the
 *                  key table being passed in here. In other words, it was comparing *every*
 *                  field in the message no matter whether the key table said to ignore that
 *                  element or not. This change fixes that. Or appears to ;-)
 * 
 * 16-Nov-08    JR  Testing with STI Fed messages exposed some logic flaws about how you find
 *                  the message you want to compare *to*. Specifically, when we read the first
 *                  message, we have to pull out the xrefTrn and use that value to find the 2nd
 *                  message - in other words we have to look for the 2nd message where its
 *                  xrefTrn is equal to the xrefTrn of the first message. It sounds sorta screwy
 *                  until you realize that the xrefTrn of the first message will point to itself
 *                  while the xrefTrn of the 2nd message (the 'after') message will point back to
 *                  the original trn. Before this fix, you could compare a 'before' table against
 *                  an 'after' table and it would work. It wouldn't work in the other direction,
 *                  though, trying to compare an 'after' table against a 'before' table; it couldn't
 *                  find the target trns in that mode.
 * 12-Sep-13   JN Comparemsg call , add xmlnode = '/message'
 * 
 */
namespace Simulator
{
    /// <summary>
    /// Summary description for Class1.
    /// </summary>
    public class MsgCompare
    {
        // private DBAccess m_writeConnection;
        private DBAccess m_readConnection;
        private DBAccess m_readConnection1;
        private XmlDocument doc1 = new XmlDocument();
        private XmlDocument doc2 = new XmlDocument();

        public StreamWriter sw;
        StringBuilder msg;
        StringBuilder name;
        StringBuilder name1;
        StringBuilder name2;
        StringBuilder cmp_str1;
        StringBuilder cmp_str2;
        private string trn1;
        private string text1;
        private string text2;
        private string area;
        private string myProcName;
        private string Debug;
        private int debugLevel;
        private string m_LastTrn;
        private bool m_Restart;
        DataTable m_DataTable;

        public bool Restart
        {
            set { m_Restart = true; }
        }
        //public class tag
        //{
        //    public string tag_name;
        //    public string include;
        //}

        public MsgCompare()
        {
            m_readConnection = new DBAccess();
            m_readConnection1 = new DBAccess();
            //m_writeConnection = new DBAccess();
            msg = new StringBuilder();
            name = new StringBuilder();
            name1 = new StringBuilder();
            name2 = new StringBuilder();
            cmp_str1 = new StringBuilder();
            cmp_str2 = new StringBuilder();
            m_Restart = true;
            sw = null;
        }

        public DataTable Compare(string Area, string table1, string table2, string filter)
        {
            string tmp;
            const int showMissing = 2;
            MsgCompare msgCmp = new MsgCompare();
            ArrayList tags = new ArrayList();
            ArrayList enabledKeyList = new ArrayList();
            area = Area.Trim();
            myProcName = "IdiFileCompare" + "_" + area;

            StringArrayCompare.StringArrayCompare sCompare = new Simulator.StringArrayCompare.StringArrayCompare(area);
            //StringArrayCompare sCompare = new StringArrayCompare();

            m_DataTable = new DataTable("DataTable");

            table1 = table1.Trim();
            table2 = table2.Trim();

            m_DataTable.Columns.Add("Trn", typeof(string));
            m_DataTable.Columns.Add("Section", typeof(string));
            m_DataTable.Columns.Add("FieldName", typeof(string));
            m_DataTable.Columns.Add("C", typeof(string));
            m_DataTable.Columns.Add("OldValue", typeof(string));
            m_DataTable.Columns.Add("NewValue", typeof(string));
            // m_DataTable.Columns[3].

            try
            {
                m_readConnection.Connect(false, area);
                m_readConnection1.Connect(false, area);
                // m_writeConnection.Connect(true, area);

                GetSimValues();

                // Get idi file tags from IdiFields table.
                // Could be RGW tags, too.
                string Cmd = string.Format("select * from {0} ", filter);
                m_readConnection.OpenDataReader(Cmd);
                while (m_readConnection.SQLDR.Read())
                {
                    //string SubGroup = m_readConnection.SQLDR["XmlSet"].ToString().TrimEnd();
                    //string Fname = m_readConnection.SQLDR["CmpKey"].ToString().TrimEnd();
                    //string Tn = String.Format("/message/{0}/{1}", SubGroup, Fname);
                    //tag new_tag = new tag();
                    //new_tag.tag_name = Tn;
                    //new_tag.include = m_readConnection.SQLDR["Include"].ToString().TrimEnd();
                    //tags.Add(new_tag);

                    string SubGroup = m_readConnection.SQLDR["XmlSet"].ToString().TrimEnd();
                    string Fname = m_readConnection.SQLDR["CmpKey"].ToString().TrimEnd();
                    string Tn = String.Format("{0}/{1}", SubGroup, Fname);
                    tag new_tag = new tag();
                    new_tag.tag_name = Tn;
                    new_tag.include = m_readConnection.SQLDR["Include"].ToString().TrimEnd();
                    if (new_tag.include.Equals("Y"))
                    {
                        tags.Add(new_tag);
                        enabledKeyList.Add(Tn);
                    }
                }
                m_readConnection.CloseDataReader();

                Cmd = string.Format("select top 5 * from {0}", table1);
                if (!m_Restart)
                    Cmd += string.Format(" where trn > '{0}' order by trn", m_LastTrn);
                m_Restart = false;
                if (m_readConnection.OpenDataReader(Cmd))
                {
                    while (m_readConnection.SQLDR.Read())
                    {
                        /*
                         * We need to get the trn *and* the xrefTrn from this message. For "before"
                         * message traffic (the original messages), the trn and the xrefTrn will
                         * be the same, ie, it will point back to itself. For "after" traffic, the 
                         * xrefTrn should point to the original message.
                         * 
                         * Later on, below, we need to *always* look for the 2nd message using the
                         * xrefTrn that we got out of the first message. 
                         * 
                         */
                        trn1 = m_readConnection.SQLDR["Trn"].ToString();
                        string xrefTrn = m_readConnection.SQLDR["XrefTrn"].ToString();
                        m_LastTrn = trn1;
                        text1 = m_readConnection.SQLDR["Text"].ToString().Replace("&", "_").Replace("\r\n", "");
                        try
                        {
                            text1 = StringArrayCompare.StringArrayCompare.getXmlHeader() + text1;
                            doc1.Load(new StringReader(text1));
                            /*
                             * We have to go looking for the *XrefTrn* in the 2nd table, and we
                             * *have* to use the xrefTrn we got from the first message as the value
                             * to search for. The compare won't work in both directions - 1. original 
                             * vs delta or 2. delta vs original - if we don't do it this way.
                             * 
                             * Bear in mind that in the 'original' message the trn and the xrefTrn
                             * are going to be the same. In the 'delta' message they won't be the
                             * same since the xrefTrn will point back to the other guy.
                             */
                            //Cmd = string.Format("select * from {0} where Trn='{1}'", table2, trn1);
                            //Cmd = string.Format("select * from {0} where XrefTrn='{1}'", table2, trn1);
                            Cmd = string.Format("select * from {0} where XrefTrn='{1}'", table2, xrefTrn);
                            if (m_readConnection1.OpenDataReader(Cmd))
                            {
                                if (m_readConnection1.SQLDR.HasRows)
                                {
                                    m_readConnection1.SQLDR.Read();
                                    string thisTrn = m_readConnection1.SQLDR["Trn"].ToString();
                                    text2 = m_readConnection1.SQLDR["Text"].ToString().Replace("&", "_").Replace("\r\n", "");
                                    try
                                    {
                                        text2 = StringArrayCompare.StringArrayCompare.getXmlHeader() + text2;
                                        doc2.Load(new StringReader(text2));
                                        ArrayList results = sCompare.compareMsg(doc1, doc2, area, "/message");

                                        for (int rIdx = 0; rIdx < results.Count; rIdx++)
                                        {
                                            object[] resultsObj = (object[])results[rIdx];
                                            string xmlSet = (string)resultsObj[0];

                                            Simulator.StringArrayCompare.diffResult diff = (Simulator.StringArrayCompare.diffResult)resultsObj[1];
                                            for (int i = 0; i < diff.before.Count; i++)
                                            {

                                                string Section = xmlSet.Trim();
                                                if (Section.Contains("-"))
                                                {
                                                    Section = Section.Substring(0, Section.IndexOf("-"));
                                                }
                                                string FieldName = diff.fieldName[i].ToString().Trim();

                                                if (enabledKeyList.Contains(String.Format("{0}/{1}", Section, FieldName)) ||
                                                    Section.Equals("HIST") || Section.Equals("TEXT")
                                                    )
                                                {
                                                    DataRow dr;
                                                    dr = m_DataTable.NewRow();

                                                    /*
                                                     * Just show the trn when it changes. And let's show the 'before'
                                                     * trn. 
                                                     * Let's chop the tail off any string we think is too long.
                                                     */
                                                    if (i > 0)
                                                        dr["Trn"] = "";
                                                    else
                                                        dr["Trn"] = trn1;

                                                    dr["Section"] = xmlSet.Trim();
                                                    dr["C"] = diff.changedFlag[i].ToString().Trim();

                                                    tmp = diff.before[i].ToString().Trim();
                                                    dr["OldValue"] = truncateString(tmp, 40);

                                                    dr["FieldName"] = diff.fieldName[i].ToString().Trim();

                                                    tmp = diff.after[i].ToString().Trim();
                                                    dr["NewValue"] = truncateString(tmp, 40);
                                                    m_DataTable.Rows.Add(dr);
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        m_readConnection.RecordEvent(0, myProcName, string.Format("{0}: {1}", DateTime.Now, string.Format("doc2 load failed" + ex.Message + "\r\n")), area);
                                        m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("doc2 load failed" + ex.Message + "\r\n"));
                                        throw ex;
                                    }
                                }
                                else
                                {
                                    string Error = string.Format("{0}: {1}", DateTime.Now, string.Format("Trn - {0} not found in table AFTER\r\n", trn1, area));
                                    Exception ex = new Exception(Error);
                                    m_readConnection.RecordEvent(0, myProcName, Error, area);
                                    // No, let's not throw an exception ...
                                    // throw ex;
                                    // m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("Trn - {0} not found in table AFTER\r\n",trn1));
                                }
                                m_readConnection1.CloseDataReader();
                            }
                            else
                            {
                                string Error = string.Format("{0}: {1}", DateTime.Now, string.Format("Read connection Problem with table AFTER\r\n"));
                                m_readConnection.RecordEvent(0, myProcName, Error, area);
                                Exception ex = new Exception(Error);
                                throw ex;
                            }
                        }
                        catch (Exception ex)
                        {
                            string Error = string.Format("failed" + ex.Message + "\r\n");
                            m_readConnection.RecordEvent(0, myProcName, Error, area);
                            Exception ex1 = new Exception(Error);
                            throw ex1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string Error = "Db access execution failed " + ex.Message + "\r\n";
                m_readConnection.RecordEvent(0, myProcName, Error, area);
                Exception ex1 = new Exception(Error);
                throw ex1;
            }
            finally
            {
                // m_writeConnection.DisConnect();
                m_readConnection.DisConnect();
                m_readConnection1.DisConnect();
            }
            return m_DataTable;
        }
        private string truncateString(string s, int len)
        {
            /*
             * Chop off the tail of a string and then hang
             * an '*' on it to indicate we did so.
             */
            string x;
            if (s.Length <= len)
                return s;
            else
            {
                x = s.Substring(0, len - 1);
            }
            return x + "*";
        }

        private void GetSimValues()
        {
            string l_Area;
            string Cmd;
            Cmd = string.Format("select Area, RootDir, Debug from SimulatorControl");
            m_readConnection.OpenDataReader(Cmd);
            m_readConnection.SQLDR.Read();
            l_Area = m_readConnection.SQLDR["Area"].ToString().TrimEnd();
            Debug = m_readConnection.SQLDR["Debug"].ToString().TrimEnd();
            debugLevel = 0;
            try
            {
                debugLevel = int.Parse(Debug);
            }
            catch { }
            string RootDir = m_readConnection.SQLDR["RootDir"].ToString().TrimEnd();
            m_readConnection.CloseDataReader();
            if (debugLevel > 0 && sw == null)
            {
                DateTime dtCurrTime = DateTime.Now;
                string filename = string.Format("{0}logs/{1}_{2:ddMMMyyyyhhmmss}.log", RootDir, myProcName, dtCurrTime);
                FileStream file1 = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);
                sw = new StreamWriter(file1);   // Create a new stream
            }
            if (area != l_Area)
            {
                string st = "Process not Started. Areas Discrepancy";
                m_readConnection.RecordEvent(0, myProcName, string.Format("{0}: {1}", DateTime.Now, st), area);
                m_readConnection.ConsoleWrite(Debug, myProcName, sw, "Areas Discrepancy");
            }
        }
    }
}