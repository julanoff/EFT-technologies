using System;
using System.Data;
using System.Collections;

/// <summary>
/// Summary description for TableMetaData
/// </summary>
/// 
public class TableMetaData<ItemType> : CollectionBase
{
    public TableMetaData()
    {

    }

    public int Add(ItemType value)
    {
        return List.Add(value);
    }

    public void Remove(ItemType value)
    {
        List.Remove(value);
    }

    public ItemType this[int index]
    {
        get
        {
            return (ItemType)List[index];
        }
        set
        {
            List[index] = value;
        }
    }
}
