using System;
using System.Data;
using System.Collections;

/// <summary>
/// Summary description for ColumnMetaData
/// </summary>
/// 
    public class ColumnMetaData<KeyType, ItemType> : DictionaryBase
    {
        public ColumnMetaData()
        {
        }

        public ItemType this[KeyType id]
        {
            get { return (ItemType)Dictionary[id]; }
            set { Dictionary[id] = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="order"></param>
        public void Add(KeyType Id, ItemType value)
        {
            // Add to order id keyed dictionary
            Dictionary.Add(Id, value);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="order"></param>
        public void Remove(KeyType Id)
        {
            // Remove from order id keyed dictionary
            Dictionary.Remove(Id);
        }
        public bool Contains(KeyType Id)
        {
            return Dictionary.Contains(Id);
        }
    }
