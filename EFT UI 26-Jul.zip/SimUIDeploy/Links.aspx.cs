/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Text;
using System.Data;
using System.Xml;
using System.Collections;
using System.Diagnostics;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Obout.Grid;
using Obout.Interface;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.SimLog;



/*
 * 
 * Project update page.
 * 
 * 09-Mar-03        Orig.
 * 15-Mar-03    JR  Some tweaks to edits. Mostly in the projects.aspx page, though.
 * 03-Apr-15    JR  The link source dropdown needs ISI2 to have the value IS2 or else the insert into the 
 *                  control (when adding a new link) will die with a truncation error.
 *                  
 * 04-Jun-17    JR  we were incorrectly building the name of the allbin directory and the name
 *                  used for a receiver text file.
 * 
 */
public partial class Links : System.Web.UI.Page
{
    DBAccess m_Connection;
    private Hashtable m_groups;
    static int SelectedGroup;
    protected void Page_Load(object sender, EventArgs e)
    {
        DBAccess connection = new DBAccess();
        String dbname = (String)HttpContext.Current.Session["CurrentDB"];
        connection.Connect(false, dbname);
        if (connection.OpenDataReader("select GroupName, GroupNo from LinkGroup"))
        {
            m_groups = new Hashtable();
            m_groups.Add("All", 0);
            while (connection.SQLDR.Read())
            {
                string GroupName = connection.SQLDR[0].ToString().Trim();
                int GroupNo = connection.SQLDR.GetInt32(1);
                m_groups.Add(GroupName, GroupNo);
            }
            connection.CloseDataReader();
            connection.DisConnect();

        }
        OboutDropDownList EdtTmplFmtType = DataGrid1.Templates[0].Container.FindControl("EdtTmplFmtType") as OboutDropDownList;
        ListItem item11 = new ListItem("MQS", "MQS");
        EdtTmplFmtType.Items.Add(item11);

        OboutDropDownList EdtTmplFmtTag = DataGrid1.Templates[0].Container.FindControl("EdtTmplFmtTag") as OboutDropDownList;
        ListItem item21 = new ListItem("MQS", "MQS");
        EdtTmplFmtTag.Items.Add(item21);

        OboutDropDownList EdtTmplSndRcv = DataGrid1.Templates[0].Container.FindControl("EdtTmplSndRcv") as OboutDropDownList;

        ListItem item1 = new ListItem("Send", "S");
        EdtTmplSndRcv.Items.Add(item1);
        ListItem item2 = new ListItem("Receive", "R");
        EdtTmplSndRcv.Items.Add(item2);
        ListItem item3 = new ListItem("Both", "B");
        EdtTmplSndRcv.Items.Add(item3);

        loadSourceDropdown();

        if (!Page.IsPostBack)
        {
            BindDataGrid();
            HttpContext.Current.Session["EditsAllowed"] = "Y";
        }
        DataGrid1.Visible = true;
    }


    protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
    {
        Control ctrl = DataGrid1.Templates[templateIndex].Container.FindControl(controlId);

        return ctrl.ClientID;
    }


    protected void OnGridRowCreated(object sender, GridRowEventArgs args)
    {
        //DataGrid1.Columns[1].ReadOnly = false;
        // gets called before a row created. It stop each time the row is populated from DB not used
    }

    protected void RebindGrid(object sender, EventArgs e)
    {
        BindDataGrid();
    }

    protected void OnSelectedIndexChanged(object sender, EventArgs e)
    {
        //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
    }

    protected void BindDataGrid()
    {
        m_Connection = new DBAccess();
        String dbname = (String)HttpContext.Current.Session["CurrentDB"];
        try
        {
            String Cmd;
            m_Connection.Connect(false, dbname);
            Cmd = "select LineName, NextSeqNo, port, Description, MQMgrName, InputMQName, OutputMQName, OutputMQName1, pin, ConnChannel, Source from LinkControl";
            Cmd = "select * from linkcontrol order by linename";
            DataSet ds = m_Connection.getDataSet(Cmd);
            DataGrid1.DataSource = ds;
            DataGrid1.DataBind();

            DataSet Srcs = null;

            string vendor = HttpContext.Current.Session["Vendor"].ToString();

            Cmd = "select distinct Source, ExternalSrc from MQLINESRC";
            Srcs = m_Connection.getDataSet(Cmd);

        }
        catch (Exception e) { throw e; }
        finally
        {
            m_Connection.DisConnect();
        }
        DataGrid1.Visible = true;
    }

    public void loadSourceDropdown()
    {
        OboutDropDownList EdtTmplSource1 = DataGrid1.Templates[0].Container.FindControl("EdtTmplSource") as OboutDropDownList;
        string vendor = HttpContext.Current.Session["Vendor"].ToString().ToLower().TrimEnd();

        if (vendor == "ft")
        {
            ListItem item4 = new ListItem("   ", "   ");
            EdtTmplSource1.Items.Add(item4);
            ListItem item1 = new ListItem("Fed", "FED");
            EdtTmplSource1.Items.Add(item1);
            ListItem item2 = new ListItem("Chips", "CHP");
            EdtTmplSource1.Items.Add(item2);
            ListItem item3 = new ListItem("MQS", "MQS");
            EdtTmplSource1.Items.Add(item3);
        }
        else
        {
            ListItem item1 = new ListItem("Swift", "SWF");
            EdtTmplSource1.Items.Add(item1);
            ListItem item2 = new ListItem("Fed", "FED");
            EdtTmplSource1.Items.Add(item2);
            ListItem item3 = new ListItem("ASI", "ASI");
            EdtTmplSource1.Items.Add(item3);
            ListItem item4 = new ListItem("Chips", "CHP");
            EdtTmplSource1.Items.Add(item4);
            ListItem item5 = new ListItem("ISI", "ISI");
            EdtTmplSource1.Items.Add(item5);
            ListItem item6 = new ListItem("ISI2", "IS2");
            EdtTmplSource1.Items.Add(item6);
        }
    }
    public void DataGrid_Edit(Object sender, GridRecordEventArgs e)
    {
        // Set the EditItemIndex property to the index of the item clicked
        // in the DataGrid control to enable editing for that item. Be sure
        // to rebind the DataGrid to the data source to refresh the control.
        string UniqueKey, LineName, Description, NextSeqNo, OutSeqNo, Port, OutMQName, OutMQName1, InputMQName,
                MQMgrName, SwfTid, Pin, Source, FmtType, FmtTag, ConnChannel;

        string SndRcv;
        string IntPort;
        string NumberSel;
        string RsnSeqNo;
        string TimeDelay;


        UniqueKey = e.Record["UniqueKey"].ToString().Trim();
        LineName = e.Record["LineName"].ToString().Trim().ToUpper();
        Description = e.Record["Description"].ToString().Trim();
        NextSeqNo = e.Record["NextSeqNo"].ToString().Trim();
        OutSeqNo = e.Record["OutSeqNo"].ToString().Trim();
        Port = e.Record["Port"].ToString().Trim(); ;
        OutMQName = e.Record["OutputMQName"].ToString().Trim().ToUpper();
        OutMQName1 = e.Record["OutputMQName1"].ToString().Trim().ToUpper();
        InputMQName = e.Record["InputMQName"].ToString().Trim().ToUpper();
        MQMgrName = e.Record["MQMgrName"].ToString().Trim().ToUpper();
        SwfTid = e.Record["SwfTid"].ToString().Trim().ToUpper();
        Pin = e.Record["Pin"].ToString().Trim();
        Source = e.Record["Source"].ToString().Trim();
        ConnChannel = e.Record["ConnChannel"].ToString().Trim();

        SndRcv = e.Record["SndRcv"].ToString().Trim();
        FmtType = e.Record["FmtType"].ToString().Trim();
        FmtTag = e.Record["FmtTag"].ToString().Trim();
        IntPort = e.Record["IntPort"].ToString().Trim();
        NumberSel = e.Record["NumberSel"].ToString().Trim();
        RsnSeqNo = e.Record["RsnSeqNo"].ToString().Trim();
        TimeDelay = e.Record["TimeDelay"].ToString().Trim();


        NextSeqNo = testInt(NextSeqNo);
        OutSeqNo = testInt(OutSeqNo);
        Port = testInt(Port);
        IntPort = testInt(IntPort);
        NumberSel = testInt(NumberSel);
        RsnSeqNo = testInt(RsnSeqNo);
        TimeDelay = testInt(TimeDelay);
        if (TimeDelay.Equals("1"))
        {
            TimeDelay = "0";
        }


        string Cmd = string.Format("update LinkControl " +
                    " set Linename='{0}', " +
                    " Description='{1}', " +
                    " OutSeqNo={2}, " +
                    " Port={3}, " +
                    " InputMQName='{4}', " +
                    " OutputMQName='{5}', " +
                    " OutputMQName1='{6}', " +
                    " Pin='{7}', " +
                    " MQMgrName='{8}', " +
                    " NextSeqNo={9}, " +
                    " swftid='{10}', " +
                    " ConnChannel='{11}', " +
            //" Source ='{12}', " +
            //" SndRcv = '{14}', " +
                    " IntPort = {15}, " +
                    " NumberSel = {16}, " +
                    " RsnSeqNo = {17}, " +
                    " TimeDelay = {18} " +


                    " where UniqueKey = '{13}'",
                    LineName, Description, OutSeqNo, Port,
                    InputMQName, OutMQName, OutMQName1, Pin,
                    MQMgrName, NextSeqNo, SwfTid, ConnChannel, Source, UniqueKey,
                    SndRcv, IntPort, NumberSel, RsnSeqNo, TimeDelay
                    );



        DBAccess Connection = new DBAccess();

        String Area = (String)HttpContext.Current.Session["CurrentDB"];
        Simulator.SimLog.log.write(Area, "update link table: " + Cmd);
        try
        {
            Connection.Connect(true, Area);
            Connection.Execute(Cmd, true);
            BindDataGrid();
        }
        catch
        {
            //                editErrors.Text = e1.Message;
            //                editErrors.Visible = true;
            //                editErrors.ForeColor = Color.Red;
        }
        finally
        {
            Connection.DisConnect();
        }
    }

    public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
    {
        //        DataGrid1.EditItemIndex = -1;
        BindDataGrid();
    }
    private string testInt(string num)
    {
        try
        {
            int tst = int.Parse(num);
            return num;
        }
        catch
        {
            return "1";
        }
    }

    public void DataGrid_Insert(object source, GridRecordEventArgs e)
    {
        string LineName, Description, SndRcv, Port, IntPort, NextSeqNo, OutSeqNo;
        string LineStatus;
        //string P1;
        string TrnRef;
        string NumberSel;
        string TimeDelay, OutputMQName, OutputMQName1, InputMQName, MQMgrName, ConnChannel;
        string Mode;
        string Source, RsnSeqNo, SwfTid, Pin, FmtType, FmtTag;

        LineName = e.Record["LineName"].ToString().Trim().ToUpper();
        LineName = LineName.Replace(" ", "_");
        Description = e.Record["Description"].ToString().Trim();
        NextSeqNo = e.Record["NextSeqNo"].ToString().Trim();
        OutSeqNo = e.Record["OutSeqNo"].ToString().Trim();
        Port = e.Record["Port"].ToString().Trim(); ;
        OutputMQName = e.Record["OutputMQName"].ToString().Trim().ToUpper();
        OutputMQName1 = e.Record["OutputMQName1"].ToString().Trim().ToUpper();
        InputMQName = e.Record["InputMQName"].ToString().Trim().ToUpper();
        MQMgrName = e.Record["MQMgrName"].ToString().Trim().ToUpper();
        SwfTid = e.Record["SwfTid"].ToString().Trim().ToUpper();
        Pin = e.Record["Pin"].ToString().Trim();
        Source = e.Record["Source"].ToString().Trim();
        FmtType = e.Record["FmtType"].ToString().Trim();
        FmtTag = e.Record["FmtTag"].ToString().Trim();
        ConnChannel = e.Record["ConnChannel"].ToString().Trim();

        SndRcv = e.Record["SndRcv"].ToString().Trim();
        IntPort = e.Record["IntPort"].ToString().Trim();
        NumberSel = e.Record["NumberSel"].ToString().Trim();
        RsnSeqNo = e.Record["RsnSeqNo"].ToString().Trim();
        TimeDelay = e.Record["TimeDelay"].ToString().Trim();


        NextSeqNo = testInt(NextSeqNo);
        OutSeqNo = testInt(OutSeqNo);
        Port = testInt(Port);
        IntPort = testInt(IntPort);
        NumberSel = testInt(NumberSel);
        RsnSeqNo = testInt(RsnSeqNo);
        TimeDelay = testInt(TimeDelay);
        if (TimeDelay.Equals("1"))
        {
            TimeDelay = "0";
        }

        LineStatus = "*";

        Mode = "0";
        if (MQMgrName.Length > 0)
        {
            Mode = "1";
        }

        int GroupNo = 4;
        switch (Source)
        {
            case "SWF":
                GroupNo = 1;
                break;
            case "IS2":
                GroupNo = 2;
                break;
            case "FED":
            case "ISI":
            case "CHP":
                GroupNo = 3;
                break;

            case "ASI":
            case "MQS":
                GroupNo = 4;
                break;
        }

        TrnRef = "";
        //P1 = "";
        //int defaultCompareTableNo = 0;
        string Tid = "";


        String area = (String)HttpContext.Current.Session["CurrentDB"];
        LoadConfig util = new LoadConfig(area);

        BackEndSubs subs = new BackEndSubs();
        DBAccess db = new DBAccess();


        try
        {
            db.Connect(true, area);
        }
        catch { }

        string lName = LineName;
        string Area = area;

        string ModName = "";
        string ModArgs = area + " " + lName;
        switch (Source)
        {
            case "FED":
                ModName = "Fedlink";
                ModArgs = ModArgs + " B";
                break;
            case "SWF":
                if (SndRcv.Equals("S"))
                {
                    ModName = "SwfServer";
                }
                else
                {
                    ModName = "SwfClient";
                }
                break;
            case "ISI":
                ModName = "IsiLink";
                break;
            case "IS2":
                ModName = "Isi2Link";
                ModArgs = ModArgs + " " + SndRcv;
                break;
            case "CHP":
                ModName = "ChipsLnk";
                break;
            case "MQS":
                ModName = "MQLink";
                break;

        }
        Simulator.SimLog.log.write(Area, string.Format("Links - add new link {0} {1} ", LineName, Description));


        string cmd = string.Format("insert into linkcontrol ( LineName, Description, NextSeqNo, OutSeqNo, " +
            " OutputMQName, OutputMQName1, InputMQName, MQMgrName, SwfTid, Pin, Source, " +
            " ConnChannel, SndRcv, IntPort,  NumberSel, RsnSeqNo, TimeDelay, LineStatus, TrnRef, P1, Port, Mode, GroupNo ) " +
            " values " +
            "('{0}','{1}',{2},{3},'{4}','{5}','{6}','{7}','{8}','{9}', " +
            "'{10}','{11}','{12}',{13},{14},{15},{16},'{17}', ' ', ' ', {18}, 1, {19}) ",
            LineName, Description, NextSeqNo, OutSeqNo,
            OutputMQName, OutputMQName1, InputMQName, MQMgrName, SwfTid, Pin, Source,
            ConnChannel, SndRcv, IntPort, NumberSel, RsnSeqNo, TimeDelay, "*", Port, GroupNo);

        db.Execute(cmd, true);


        util.updateProcTable(ModName, subs.GetSimRootDrive(area) + "/Simulator/allbin/", ModArgs,
            "n", "y", Description, GroupNo);

        string receiverFileName = string.Format(subs.GetSimRootDrive(area) + "/Simulator/{0}/{1}.txt",
            area.ToUpper(), LineName);

        if (SndRcv.Equals("S") || SndRcv.Equals("B"))
        {
            subs.MakeNewTable(lName, "FDR", db, area);
            subs.MakeNewTable(lName, "LNK", db, area);
            if (SndRcv.Equals("B"))
            {
                Simulator.SimLog.log.write(Area, string.Format("Links - add rcv table for {0} ", LineName));
                subs.MakeNewTable(lName, "RCV", db, area);
                Simulator.SimLog.log.write(Area, string.Format("Links - update rcv control for {0} ", LineName));
                util.updateRcvControl(LineName, Source, "N", "N", receiverFileName, "", "", "0", "1", "N", FmtType);
            }
            Simulator.SimLog.log.write(Area, string.Format("Links - update feeder control for {0} ", LineName));
            util.updateFeederControl(LineName, Source, "*", "N", "", "", "1", "1", FmtType, FmtTag);
        }
        else
        {
            Simulator.SimLog.log.write(Area, string.Format("Links - add rcv table for {0} ", LineName));
            subs.MakeNewTable(lName, "RCV", db, area);
            Simulator.SimLog.log.write(Area, string.Format("Links - update rcv control for {0} ", LineName));
            util.updateRcvControl(LineName, Source, "N", "N", receiverFileName, "", "", "0", "1", "N", FmtType);
        }
    }

    public void DataGrid_Delete(object source, GridRecordEventArgs e)
    {
        BackEndSubs subs = new BackEndSubs();
        string UniqueKey = "", LineName = "";
        try
        {
            UniqueKey = (e.Record["UniqueKey"].ToString());
            LineName = (e.Record["LineName"].ToString());
        }
        catch { }
        String _area = (String)HttpContext.Current.Session["CurrentDB"];
        Simulator.SimLog.log.write(_area, string.Format("Links - delete link {0} ", LineName));

        String Cmd = string.Format("delete from linkcontrol where UniqueKey = '{0}'", UniqueKey);
        DBAccess Connection = new DBAccess();
        Connection.Connect(true, _area);
        try
        {
            Connection.Execute(Cmd, true);
        }
        catch { }

        string Tbl = "FDR_" + LineName;
        try { subs.DeleteTable(Tbl, Connection); }
        catch (Exception ex)
        { Simulator.SimLog.log.write(_area, string.Format("Error deleting {0}. {1} ", Tbl, ex.Message)); }

        Tbl = "LNK_" + LineName;
        try { subs.DeleteTable(Tbl, Connection); }
        catch (Exception ex)
        { Simulator.SimLog.log.write(_area, string.Format("Error deleting {0}. {1} ", Tbl, ex.Message)); }

        Tbl = "RCV_" + LineName;
        try { subs.DeleteTable(Tbl, Connection); }
        catch (Exception ex)
        { Simulator.SimLog.log.write(_area, string.Format("Error deleting {0}. {1} ", Tbl, ex.Message)); }

        Cmd = string.Format("delete from simulatorprocesses where modargs like '%{0}%'", LineName);
        try
        {
            Simulator.SimLog.log.write(_area, string.Format("Links - delete link. Update simulator processes {0} ", LineName));
            Connection.Execute(Cmd, true);
        }
        catch { }

        Cmd = string.Format("delete from feedercontrol where linename = '{0}'", LineName);
        try
        {
            Simulator.SimLog.log.write(_area, string.Format("Links - delete link. Update FeederControl {0} ", LineName));
            Connection.Execute(Cmd, true);
        }
        catch { }

        Cmd = string.Format("delete from receivecontrol where linename = '{0}'", LineName);
        try
        {
            Simulator.SimLog.log.write(_area, string.Format("Links - delete link. Update ReceiveControl {0} ", LineName));
            Connection.Execute(Cmd, true);
        }
        catch { }
        finally
        {
            Connection.DisConnect();
            Connection.Dispose();
        }
        BindDataGrid();
    }
}
