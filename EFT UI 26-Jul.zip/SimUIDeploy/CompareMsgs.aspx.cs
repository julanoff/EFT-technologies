/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
using Simulator.CompareSubs;

/*
 * 22-Jun-08    JR  Catch situations where the key table has duplicate entries. We don't want
 *                  to roll over and die, so just ignore it/them. Stay tuned to see how
 *                  this plays out.
 * 26-Jul-08    JR  A few things - a button to paint just the changes. When they hit cancel
 *                  or release, let's repaint the screen so they can keep working (otherwise
 *                  they'd have to go out and re-enter the function).
 * 09-Aug-08    JR  Give 'em a button to reinit the rgw and idi default key tables.
 * 
 * 25-Feb-17    JR  Sort the compare tables by create time when we display them.
 * 
 */ 

namespace Simulator
{
	/// <summary>
	/// Summary description for CompareMsgs.
	/// </summary>
    public partial class CompareMsgs : System.Web.UI.Page
    {
        private Hashtable m_hashTable;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DBAccess Connection = new DBAccess();
                try
                {
                    String dbname = (String)HttpContext.Current.Session["CurrentDB"];
                    Connection.Connect(false, dbname);
                    String Cmd = string.Format("select * from SimTableList where TableType = 'Compare' order by CreateTime desc");
                    //String Cmd = string.Format("select * from SimTableList where TableType = 'CompareK eys'");
                    FirstFileGrid.DataSource = Connection.getDataSet(Cmd); ;
                    FirstFileGrid.DataBind();
                    ReinitButton.Enabled = true;
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    Connection.DisConnect();
                }
            }
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion

        protected void FirstFileGrid_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            string Table = FirstFileGrid.SelectedItem.Cells[1].Text;
            string TableDesc = FirstFileGrid.SelectedItem.Cells[2].Text;
            DBAccess Connection = new DBAccess();
            try
            {
                String dbname = (String)HttpContext.Current.Session["CurrentDB"];
                Connection.Connect(false, dbname);
                String Cmd = string.Format("select TableName, Description from SimTableList where TableName !='" + Table + "'" +
                    " and TableType = 'Compare' order by CreateTime desc");
                SecondFileGrid.DataSource = Connection.getDataSet(Cmd); ;
                SecondFileGrid.DataBind();
                Connection.DisConnect();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.DisConnect();
            }

            // Let's repaint the first list so it contains just the one
            // the human selected.
            try
            {
                String dbname = (String)HttpContext.Current.Session["CurrentDB"];
                Connection.Connect(false, dbname);
                String Cmd = string.Format("select TableName, Description from SimTableList where TableName ='" + Table + "'" +
                    " and TableType = 'Compare'");
                FirstFileGrid.DataSource = Connection.getDataSet(Cmd); ;
                FirstFileGrid.DataBind();
                Connection.DisConnect();
            }
            catch (Exception) { }
            finally
            {
                Connection.DisConnect();
            }

            HttpContext.Current.Session["Table1"] = Table;
            HttpContext.Current.Session["Table1Desc"] = TableDesc;
            SecondFileLabel.Visible = true;
            SecondFileGrid.Visible = true; ;
        }

        protected void SecondFileGrid_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            string Table = SecondFileGrid.SelectedItem.Cells[1].Text;
            string TableDesc = SecondFileGrid.SelectedItem.Cells[2].Text;
            HttpContext.Current.Session["Table2"] = Table;
            HttpContext.Current.Session["Table2Desc"] = TableDesc;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];

            // Let's repaint the 2nd list so it contains just the one
            // the human selected.
            try
            {
                Connection.Connect(false, dbname);
                String Cmd = string.Format("select TableName, Description from SimTableList where TableName ='" + Table + "'" +
                    " and TableType = 'Compare'");
                SecondFileGrid.DataSource = Connection.getDataSet(Cmd); ;
                SecondFileGrid.DataBind();
                Connection.DisConnect();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.DisConnect();
            }

            try
            {
                Connection.Connect(false, dbname);
              
                //String Cmd = string.Format("select TableName, Description from SimTableList where TableName !='MasterIdiCompareKeys' " +
                //    " and TableName !='MasterRGWCompareKeys' " +
                //    " and TableType = 'CompareKeys'");                                               

                String Cmd = string.Format("select TabName as TableName, TabDesc as Description from localKeyName ");

                ThirdFileGrid.DataSource = Connection.getDataSet(Cmd); ;
                ThirdFileGrid.DataBind();
            }
            catch (Exception) { }
            finally
            {
                Connection.DisConnect();
            }
            ThirdFileLabel.Visible = true;
            ThirdFileGrid.Visible = true; ;
        }

        protected void ThirdFileGrid_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            string Table = ThirdFileGrid.SelectedItem.Cells[1].Text.Trim();
            string TableDesc = ThirdFileGrid.SelectedItem.Cells[2].Text;
            HttpContext.Current.Session["Filter"] = Table;
            HttpContext.Current.Session["FilterDesc"] = TableDesc;
            DBAccess Connection = new DBAccess();
            try
            {
                String dbname = (String)HttpContext.Current.Session["CurrentDB"];
                Connection.Connect(false, dbname);
                FileProperties.Visible = true;
                PropertyLabel.Visible = true;
                CompareButton.Enabled = true;
                CompareButtonDelta.Enabled = true;
                ReleaseButton.Enabled = true;
                ReinitButton.Enabled = false;
                CancelButton.Enabled = true;
                DBAccess tmpRdr = new DBAccess();
                tmpRdr.Connect(false, dbname);
                string Cmd = "";
              
                 Cmd = string.Format("select * from localKeyName where tabname = '{0}'", Table);
                tmpRdr.OpenDataReader(Cmd);
                tmpRdr.SQLDR.Read();
                string pk = tmpRdr.SQLDR["pk"].ToString().TrimEnd();
                tmpRdr.CloseDataReader();
                tmpRdr.Dispose();

                Cmd = string.Format("select xmlset,cmpkey,include,0 as setcheck from localKeys " +
               " where (include ='N' and tabNameInd = {0}) union " +
               "select xmlset,cmpkey,include,1 as setcheck from localKeys " +
               " where (include ='Y' and tabNameInd = {0}) order by xmlset,cmpkey", pk);
                

                // Cmd = string.Format("select xmlset,cmpkey,include,0 as setcheck from {0} " +
                //" where (include ='N') union " +
                //"select xmlset,cmpkey,include,1 as setcheck from {0} " +
                //" where (include ='Y' ) order by xmlset,cmpkey", Table);


                /*
                 Cmd = string.Format(
                "select xmlset,cmpkey,include,1 as setcheck from localKeys where pk = {0} " +
                " order by xmlset,cmpkey", pk);
                 * */
                FileProperties.DataSource = Connection.getDataSet(Cmd);
                FileProperties.DataBind();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.DisConnect();
            }
        }
        protected void CompareButtonDelta_Click(object sender, System.EventArgs e)
        {
            FirstFileLabel.Visible = false;
            FirstFileGrid.Visible = false;
            SecondFileGrid.Visible = false;
            SecondFileLabel.Visible = false;
            ThirdFileGrid.Visible = false;
            ThirdFileLabel.Visible = false;
            CompareButton.Enabled = false;
            CompareButtonDelta.Enabled = false;
            FileProperties.Visible = false;
            PropertyLabel.Visible = false;
            ResultsGrid.Visible = false;
            Result_GridView.Visible = true;
            NextButton.Enabled = true;
            CancelButton.Enabled = true;
            ReleaseButton.Enabled = true;
            ReinitButton.Enabled = false;
            UpdatePropertiesTable();
            HttpContext.Current.Session["MsgCompareObj"] = new MsgCompare();
            BindMsgCompare("delta");
            HttpContext.Current.Session["CompareMode"] = "delta";
        }

        protected void CompareButton_Click(object sender, System.EventArgs e)
        {
            FirstFileLabel.Visible = false;
            FirstFileGrid.Visible = false;
            SecondFileGrid.Visible = false;
            SecondFileLabel.Visible = false;
            ThirdFileGrid.Visible = false;
            ThirdFileLabel.Visible = false;
            CompareButton.Enabled = false;
            CompareButtonDelta.Enabled = false;
            FileProperties.Visible = false;
            PropertyLabel.Visible = false;
            ResultsGrid.Visible = false;
            Result_GridView.Visible = true;
            NextButton.Enabled = true;
            CancelButton.Enabled = true;
            ReinitButton.Enabled = false;
            ReleaseButton.Enabled = true;
            UpdatePropertiesTable();
            HttpContext.Current.Session["MsgCompareObj"] = new MsgCompare();
            BindMsgCompare("full");
            HttpContext.Current.Session["CompareMode"] = "full";
        }
        private void BindMsgCompare(string filter)
        {
            string fieldName;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                String Table1 = (String)HttpContext.Current.Session["Table1"].ToString().Trim();
                String Table2 = (String)HttpContext.Current.Session["Table2"].ToString().Trim();
                String Filter = (String)HttpContext.Current.Session["Filter"];
                MsgCompare Msgcompare = (MsgCompare)HttpContext.Current.Session["MsgCompareObj"];
               
                ResultsGrid.Width = 600;
                Result_GridView.Font.Size = 7;

                DataTable results = Msgcompare.Compare(dbname, Table1, Table2, Filter);
                if (filter.Equals("delta"))
                {
                    /*
                     * We want to show *just* the changed rows so let's walk thru the
                     * results table and delete any row that doesn't have the changed
                     * flag set. Note, we have to walk backwards thru the table because
                     * it gets weird deleting rows when you start at the top.
                     * 
                     * We also need to show the trn when it changes, so we don't want
                     * to delete a row that shows the trn. 
                     */
                    int rowCount = results.Rows.Count;
                    if (rowCount > 0)
                    {
                        DataRow firstRow = results.Rows[0];
                        string thisTrn = firstRow[0].ToString();
                    }
                    //string cazzofai = "";
                    for (int i = rowCount - 1; i >= 0; i--)
                    {
                        DataRow dr = results.Rows[i];
                        if (dr[3].ToString().Equals("*"))
                        {
                            // This is stupid, somehow the dst guy is coming back
                            // with the trn in the row. Probably because it's the
                            // first line in an xml section ... anyway, make sure
                            // we wipe the trn clean.
                            if (!dr[2].ToString().StartsWith("TRN_REF"))
                            {
                                dr[0] = " ";
                            }
                        }
                        else
                        {
                            // Gotta check here to see if the trn is changing,
                            // look for trn_ref as the field name. Don't delete
                            // the line if that's the case.
                            fieldName = dr[2].ToString();
                            if (!dr[2].ToString().StartsWith("TRN_REF"))
                            {
                                results.Rows[i].Delete();
                            }
                            else
                            {
                                // This is a trn line that hasn't changed. Do we want to make
                                // it prettier? Yep, maybe a little...
                                dr[1] = " ";
                                dr[2] = " ";
                                dr[3] = " ";
                                dr[4] = " ";
                                dr[5] = " ";
                            }
                        }                      
                    }
                    results.AcceptChanges();
                    Result_GridView.DataSource = results;
                }
                else
                {
                    Result_GridView.DataSource = results;
                }
                Result_GridView.DataBind();
                Result_GridView.Visible = true;
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.DisConnect();
            }

        }

        protected void NextButton_Click(object sender, System.EventArgs e)
        {
            string filter = "full";
            try
            {
                filter = HttpContext.Current.Session["CompareMode"].ToString();
            }
            catch { }
            BindMsgCompare(filter);
        }

        protected void ReleaseButton_Click(object sender, System.EventArgs e)
        {
            NextButton.Enabled = false;
            ReleaseButton.Enabled = false;
            SecondFileGrid.Visible = false;
            SecondFileLabel.Visible = false;
            ThirdFileGrid.Visible = false;
            ThirdFileLabel.Visible = false;
            DBAccess writeConnection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                writeConnection.Connect(true, dbname);
                string ProcessState = "*";
                string Table1 = (String)HttpContext.Current.Session["Table1"];
                string Table2 = (String)HttpContext.Current.Session["Table2"];
                string Filter = (String)HttpContext.Current.Session["Filter"];
                string Table1Desc = (String)HttpContext.Current.Session["Table1Desc"];
                string Table2Desc = (String)HttpContext.Current.Session["Table2Desc"];
                string FilterDesc = (String)HttpContext.Current.Session["FilterDesc"];

                string Cmd = string.Format("insert into CompareControl (ProcessState,Table1,Table2,Filter) " +
                    " values ('{0}','{1}','{2}','{3}')",
                ProcessState, Table1Desc, Table2Desc, FilterDesc);
                writeConnection.Execute(Cmd, true);
            }
            catch (Exception) { }
            finally
            {
                writeConnection.DisConnect();
            }
            FileProperties.Visible = false;
            PropertyLabel.Visible = false;
            CompareButton.Enabled = false;
            CompareButtonDelta.Enabled = false;
            ResultsGrid.Visible = false;
            Result_GridView.Visible = false;
            NextButton.Enabled = false;
            CancelButton.Enabled = false;
            ReinitButton.Enabled = true;
            ReleaseButton.Enabled = false;
            FirstFileLabel.Visible = true;
            FirstFileGrid.Visible = true;

            FirstFileLabel.Visible = true;
            FirstFileGrid.Visible = true;

            DBAccess Connection = new DBAccess();
            try
            {
                String dbname1 = (String)HttpContext.Current.Session["CurrentDB"];
                Connection.Connect(false, dbname1);
                String Cmd = string.Format("select * from SimTableList where TableType = 'Compare'");
                //String Cmd = string.Format("select * from SimTableList where TableType = 'CompareKeys'");
                FirstFileGrid.DataSource = Connection.getDataSet(Cmd); ;
                FirstFileGrid.DataBind();
            }
            catch (Exception ex) { throw ex; }
        }

        private void UpdatePropertiesTable()
        {
            PropertyHashTable();
            DBAccess writeConnection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                writeConnection.Connect(false, dbname);
                string Filter = (String)HttpContext.Current.Session["Filter"];
                foreach (DataGridItem item in FileProperties.Items)
                {
                    CheckBox ChkBxItem = (CheckBox)item.FindControl("CheckBox1");
                    string Key = item.Cells[1].Text.Trim() + item.Cells[2].Text.Trim();
                    string Checked = (String)m_hashTable[Key];
                    string setCmd = "";
                    if (ChkBxItem.Checked && Checked.Equals("N"))
                        setCmd = string.Format("update {2} set include='Y' where xmlset='{0}' and cmpkey='{1}'", item.Cells[1].Text.Trim(), item.Cells[2].Text.Trim(), Filter);
                    else
                        if (!ChkBxItem.Checked && Checked.Equals("Y"))
                            setCmd = string.Format("update {2} set include='N' where xmlset='{0}' and cmpkey='{1}'", item.Cells[1].Text.Trim(), item.Cells[2].Text.Trim(), Filter);
                    if (setCmd.Length != 0)
                        writeConnection.Execute(setCmd, true);
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                writeConnection.DisConnect();
            }
        }

        private void PropertyHashTable()
        {
            m_hashTable = new Hashtable();
            string Filter = (String)HttpContext.Current.Session["Filter"];
            String Cmd = string.Format("select xmlset,cmpkey,include from {0}", Filter);
            DBAccess readConnection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                readConnection.Connect(false, dbname);
                if (readConnection.OpenDataReader(Cmd))
                {
                    while (readConnection.SQLDR.Read())
                    {
                        string xmlSet = readConnection.SQLDR["xmlset"].ToString().TrimEnd();
                        string cmpKey = readConnection.SQLDR["cmpkey"].ToString().TrimEnd();
                        string include = readConnection.SQLDR["include"].ToString().TrimEnd();
                        try
                        {
                            m_hashTable.Add(xmlSet + cmpKey, include);
                        }
                        catch 
                        {
                            // Not sure what to do about this, but we shouldn't roll over
                            // and die. We've already seen this key ... keep on going.
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                readConnection.CloseDataReader();
                readConnection.DisConnect();
            }
        }

        protected bool isChecked(object Check)
        {
            if ((Int32)Check == 1)
                return true;
            return false;
        }

        protected void CancelButton_Click(object sender, System.EventArgs e)
        {
            FirstFileLabel.Visible = true;
            FirstFileGrid.Visible = true;
            SecondFileLabel.Visible = false;
            SecondFileGrid.Visible = false;
            ThirdFileLabel.Visible = false;
            ThirdFileGrid.Visible = false;
            ReinitButton.Enabled = true;

            FileProperties.Visible = false;
            PropertyLabel.Visible = false;
            ResultsGrid.Visible = false;
            Result_GridView.Visible = false;
            CompareButton.Enabled = false;
            CompareButtonDelta.Enabled = false;
            NextButton.Enabled = false;
            CancelButton.Enabled = false;
            ReleaseButton.Enabled = false;

            DBAccess Connection = new DBAccess();
            try
            {
                String dbname = (String)HttpContext.Current.Session["CurrentDB"];
                Connection.Connect(false, dbname);
                String Cmd = string.Format("select * from SimTableList where TableType = 'Compare'");
                FirstFileGrid.DataSource = Connection.getDataSet(Cmd); ;
                FirstFileGrid.DataBind();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.DisConnect();
            }

        }
        protected void ReinitButton_Click(object sender, System.EventArgs e)
        {
            FirstFileLabel.Visible = true;
            FirstFileGrid.Visible = true;
            FileProperties.Visible = false;
            PropertyLabel.Visible = false;
            ResultsGrid.Visible = false;
            Result_GridView.Visible = false;
            CompareButton.Enabled = false;
            CompareButtonDelta.Enabled = false;
            NextButton.Enabled = false;
            CancelButton.Enabled = false;
            ReleaseButton.Enabled = false;

            String area = (String)HttpContext.Current.Session["CurrentDB"];
            BackEndSubs util = new BackEndSubs();
            //util.copyKeyTable("MasterIdiCompareKeys", "IdiTestKeys", 
            //    "Idi Test Compare Key List", area);

            util.loadKeyTable("MasterRGWCompareKeys", "RGWTestKeys",
                "RGW Test Compare Key List", area);
          
             
            //DBAccess Connection = new DBAccess();
            //try
            //{
            //    String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            //    Connection.Connect(false, dbname);
            //    String Cmd = string.Format("select * from SimTableList where TableType = 'Compare'");
            //    FirstFileGrid.DataSource = Connection.getDataSet(Cmd); ;
            //    FirstFileGrid.DataBind();
            //}
            //catch (Exception ex) { throw ex; }
            //finally
            //{
            //    Connection.DisConnect();
            //}

        }
        protected void ResultsGrid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void ResultsGridView_PreRender(object sender, EventArgs e)
        {
            /*
             * If the human hits the 'next' button enough, we'll run out of things to display
             * and we'll get called here with nothing in the grid. Careful to check the grid
             * to make sure something's in it.
             */
            if (Result_GridView.Rows.Count > 0)
            {
                int nCells = Result_GridView.Rows[0].Cells.Count;
                for (int i = 0; i < Result_GridView.Rows.Count; i++)
                {
                    if (Result_GridView.Rows[i].Cells[3].Text.StartsWith("*"))
                    {
                        for (int j = 0; j < nCells; j++)
                        {
                            Result_GridView.Rows[i].Cells[j].ForeColor = System.Drawing.Color.Red;
                        }

                    }
                }
            }
        }
    }
}