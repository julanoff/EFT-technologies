﻿using System;
using System.IO;
using System.Text;
using System.Data;
using System.Xml;
using System.Linq;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Obout.Grid;
using Obout.Interface;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.SimLog;
namespace Simulator
{
    public partial class AdminTools : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

            }
            {
                DataSet ds = new DataSet();

                try
                {
                    BindDataGridFirstTime();
                }
                catch (Exception e1)
                {
                    string tmp = e1.Message;
                }

            }
        }
        protected void BindDataGridFirstTime()
        {
            //TextList.Visible = true;
            //ExecButton.Visible = true;

            IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
            if (procMgr != null)
            {
                DataSet ds = (DataSet)procMgr.printFile(@"C:\Simulator\MtsUat\MtsUat_log.txt");
                foreach (DataTable dt in ds.Tables)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        string info = row["info"].ToString();
                        Console.WriteLine(info);

                    }
                    //TextList.DataSource = dt;
                    //TextList.DataBind();
                    MultiView1.ActiveViewIndex = 1;
                    SearchList.Visible = true;
                    SearchList.DataSource = dt;
                    SearchList.DataBind();
                }
            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton trnControl = sender as LinkButton;
        }
        protected void ExecButtonClick(object sender, EventArgs e)
        {

            BackEndSubs util = new BackEndSubs();
            IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
            if (procMgr != null)
            {
                DataSet ds = (DataSet)procMgr.printFile(@"C:\Simulator\MtsUat\MtsUat_log");
                foreach (DataTable dt in ds.Tables)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        string info = row["info"].ToString();
                        Console.WriteLine(info);

                    }
                }
            }
        }

        /*
         * *******************************************
         */ 
        protected void SearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
        }
        protected void menuItemChanged(object sender, EventArgs e)
        {
        }
        protected void Menu1_MenuItemClick(object sender, EventArgs e)
        {
        }
        protected void _TransferLoadButton_Click(object sender, EventArgs e)
        {
        }
        protected void _TransferImmediateSetup_Click(object sender, EventArgs e)
        {
        }
        protected void SimulatorDataSource_Selecting(object sender, EventArgs e)
        {
        }
        protected void SearchButton_Click(object sender, EventArgs e)
        {
        }
        protected void _TransferButton_Click(object sender, EventArgs e)
        {
        }
        protected void _SearchButton_Click(object sender, EventArgs e)
        {
        }
        protected void _Refresh_Click(object sender, EventArgs e)
        {
        }
        protected void _LoadOnlyButton_Click(object sender, EventArgs e)
        {
        }
        protected void _LoadEntryButton_Click(object sender, EventArgs e)
        {
        }
        protected void _Cancel_Click(object sender, EventArgs e)
        {
        }
    }
}