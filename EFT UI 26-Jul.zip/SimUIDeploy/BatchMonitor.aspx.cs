/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Text;
using System.Data;
using System.Xml;
using System.Collections;
using System.Diagnostics;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Obout.Grid;
using Obout.Interface;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.SimLog;



/*
 * 
 * Project update page.
 * This is a batch monitoring page.
 * 
 * 
 */

namespace Simulator
{
    public partial class BatchMonitor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindDataGrid();
            }
        }

        public void DataGrid_Delete(Object sender, GridRecordEventArgs e)
        {

            // We need to delete all records from : batchq, batchdescr, diffresults, diffsummary.
            string Id, Cmd;
            Id = e.Record["BatchId"].ToString();

            DBAccess connection = new DBAccess();
            DBAccess connection1 = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);
            connection1.Connect(false, dbname);

            Cmd = string.Format("delete from DiffSummary where batchid={0}", Id);
            connection.Execute(Cmd, false);
            Cmd = string.Format("delete from batchdescr where batchid={0}", Id);
            connection.Execute(Cmd, false);
            Cmd = string.Format("delete from batchq where pk={0}", Id);
            connection.Execute(Cmd, false);
            Cmd = string.Format("delete from DiffResults where batchid={0}", Id);
            connection.Execute(Cmd, true);
            Cmd = string.Format("SELECT name FROM sysobjects where name like 'COMPARE%Q'");
            connection1.OpenDataReader(Cmd);
            while (connection1.SQLDR.Read())
            {
                string cmpq = (connection1.SQLDR[0].ToString().Trim());
                string cmd1 = string.Format("delete from {0} where batchind={1}", cmpq, Id);
                connection.Execute(cmd1, true);
            }
            connection.CloseDataReader();
            BindDataGrid();
        }

        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = DataGrid1.Templates[templateIndex].Container.FindControl(controlId);

            //     return ctrl.ClientID;
            return "";
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }

        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {
            //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
        }

        protected void BindDataGrid()
        {
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            string vendor = HttpContext.Current.Session["Vendor"].ToString();
            string Cmd;
            connection.Connect(false, dbname);
            try
            {
                Cmd = "select * from BatchDescr order by batchid, compid";
                DataSet ds = connection.getDataSet(Cmd);
                DataGrid1.DataSource = ds;
                DataGrid1.DataBind();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                connection.CloseDataReader();
                connection.DisConnect();
            }
        }

        public void Refresh_click(object sender, System.EventArgs e)
        {
            BindDataGrid();
        }



        public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
        {
            BindDataGrid();
        }
    }
}