using System;
using System.Collections.Generic;
using System.Collections;
using System.Data;
using System.IO;
using System.Text;
using System.Xml;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using Obout.Grid;
using Obout.Interface;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.SimLog;

namespace Simulator
{
    public partial class FtBrowser : OboutInc.oboutAJAXPage
    {
        private static DataSet m_ds;
        private static DataTable m_dt;
        private static bool m_localDB = true;
        private static string m_table;
        private static string m_tbl_val;
        private static string m_sql;
        private static string m_srcconnstr;
        private static string m_vendor;
        private static DataSet m_fields;
        private static Hashtable m_srcnames;
        private static Hashtable m_trgnames;
        DBAccess m_Connection;
	    private OracleConnection m_OraConnection;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)	// Code to execute first time when the page is loaded.
            {
                OboutDropDownList Ddl1;

                Ddl1 = Table2.FindControl("MidOper") as OboutDropDownList;
                FillOper(Ddl1, 0, true);
                Ddl1 = Table2.FindControl("SrcOper") as OboutDropDownList;
                FillOper(Ddl1, 0, true);
                Ddl1 = Table2.FindControl("DateOper") as OboutDropDownList;
                FillOper(Ddl1, 1, true);
                Ddl1 = Table2.FindControl("AmountOper") as OboutDropDownList;
                FillOper(Ddl1, 1, true);
                Ddl1 = Table2.FindControl("CurrencyOper") as OboutDropDownList;
                FillOper(Ddl1, 0, true);
                Ddl1 = Table2.FindControl("OfficeOper") as OboutDropDownList;
                FillOper(Ddl1, 0, true);
                Ddl1 = Table2.FindControl("MopOper") as OboutDropDownList;
                FillOper(Ddl1, 0, true);
                Ddl1 = Table2.FindControl("SenderOper") as OboutDropDownList;
                FillOper(Ddl1, 0, true);
                Ddl1 = Table2.FindControl("ReceiverOper") as OboutDropDownList;
                FillOper(Ddl1, 0, true);
                Ddl1 = Table3.FindControl("FtTable") as OboutDropDownList;
                ListItem item0 = new System.Web.UI.WebControls.ListItem("    ", "");
                Ddl1.Items.Add(item0);
                m_vendor = (String)HttpContext.Current.Session["vendor"];
                if (m_vendor.ToLower().StartsWith("fts"))
                {
                    ListItem item1 = new System.Web.UI.WebControls.ListItem("MINF", "a");
                    Ddl1.Items.Add(item1);
                }
                else
                {
                    ListItem item2 = new System.Web.UI.WebControls.ListItem("MIF", "a");
                    Ddl1.Items.Add(item2);
                    ListItem item3 = new System.Web.UI.WebControls.ListItem("MTF1000", "b");
                    Ddl1.Items.Add(item3);
                }
                t11.Visible = false;
                t12.Visible = false;
                d11.Visible = false;
                d12.Visible = false;
                Grid1Ds.Visible = false;
                Grid2.Visible = false;
                Btn1.Visible = true;
                Btn2.Visible = false;
                OboutTextBox a = Btn1.FindControl("Msg1") as OboutTextBox;
                a.Visible = false;

                MakeDataSet();
                string area = (String)HttpContext.Current.Session["CurrentDB"];
		        if (area == "") 	// Kludge. if area is empty then this session timed out.
			        Session["_timeout"] = "Y";	// Next statement will fail and Application_error in Global.asax will occur.

                string f_name = string.Format("c:\\Simulator\\{0}\\feed\\connstring.xml", area);
                DataSet srctable = new DataSet();
                srctable.ReadXml(f_name);
                ListItem items0 = new System.Web.UI.WebControls.ListItem("LocalDB", "LocalDB");
                SrcDB.Items.Add(items0);
                m_srcnames = new Hashtable();

                foreach (DataTable table in srctable.Tables)
                {
                    foreach (DataRow row in table.Rows)
                    {
                        if (row["type"].ToString().ToLower() == "src")
                        {
                            ListItem items10 = new System.Web.UI.WebControls.ListItem(row["description"].ToString().TrimEnd(), row["connection_string"].ToString().TrimEnd());
                            SrcDB.Items.Add(items10);
                            m_srcnames.Add(row["connection_string"].ToString().TrimEnd(), row["uniquename"].ToString().TrimEnd());
                        }
                    }
                }

                string b_name = string.Format("c:\\Simulator\\{0}\\feed\\browserfields.xml", area);
                m_fields = new DataSet();
                m_fields.ReadXml(b_name);

                DBAccess connection = new DBAccess();
                String dbname = (String)HttpContext.Current.Session["CurrentDB"];
                string Cmd;
                connection.Connect(false, dbname);
                try
                {
                    Cmd = "select '      ' as TabName, '0' as Pk from LocalKeyName union select  replace(tabname, ' ',''), pk from LocalKeyName";
                    if (connection.OpenDataReader(Cmd))
                    {
                        EdtCmptable.DataSource = connection.SQLDR;
                        EdtCmptable.DataTextField = "TabName";
                        EdtCmptable.DataValueField = "TabName";
                        EdtCmptable.DataBind();
                    }
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    connection.CloseDataReader();
                    connection.DisConnect();
                }
                EdtReffile.Text = "c:\\Simulator\\F.txt";
                
                f_name = string.Format("c:\\Simulator\\{0}\\feed\\connstring.xml", area);
                DataSet trgtable = new DataSet();
                trgtable.ReadXml(f_name);
                ListItem itemt0 = new System.Web.UI.WebControls.ListItem("LocalDB", "LocalDB");
                TrgDB.Items.Add(itemt0);
                m_trgnames = new Hashtable();
                foreach (DataTable table in trgtable.Tables)
                {
                    foreach (DataRow row in table.Rows)
                    {
                        if (row["type"].ToString().ToLower() == "trg")
                        {
                            ListItem itemt10 = new System.Web.UI.WebControls.ListItem(row["description"].ToString().TrimEnd(), row["connection_string"].ToString().TrimEnd());
                            TrgDB.Items.Add(itemt10);
                            m_trgnames.Add(row["connection_string"].ToString().TrimEnd(), row["uniquename"].ToString().TrimEnd());
                        }
                    }
                }

            }
        }
        
        protected void AmtOperChanged(object sender, EventArgs e)
        {
            if (AmountOper.Text == "Between")
            {
                t11.Visible = true;
                t12.Visible = true;
            }
            Orig_amount1.Focus();
        }

        protected void DateOperChanged(object sender, EventArgs e)
        {
            if (DateOper.Text == "Between")
            {
                d11.Visible = true;
                d12.Visible = true;
            }
            Origvaluedate1.Focus();
        }

        protected void FillOper(OboutDropDownList Ddl1, int Mode, bool dd)
        {
            if (Ddl1.Items.Count > 0)
                return;
            if (dd)
            {
                ListItem item0 = new System.Web.UI.WebControls.ListItem("    ", "");
                Ddl1.Items.Add(item0);
            }
            ListItem item1 = new System.Web.UI.WebControls.ListItem("Equal", "=");
            Ddl1.Items.Add(item1);
            ListItem item2 = new System.Web.UI.WebControls.ListItem("Not Equal", "!= ");
            Ddl1.Items.Add(item2);
            ListItem item3 = new System.Web.UI.WebControls.ListItem("In", "In");
            Ddl1.Items.Add(item3);
            ListItem item4 = new System.Web.UI.WebControls.ListItem("Greater", ">");
            Ddl1.Items.Add(item4);
            ListItem item5 = new System.Web.UI.WebControls.ListItem("Less", "<");
            Ddl1.Items.Add(item5);
            ListItem item6 = new System.Web.UI.WebControls.ListItem("Like", "Like");
            Ddl1.Items.Add(item6);
            if (Mode == 1)
            {
                ListItem item7 = new System.Web.UI.WebControls.ListItem("Between", "Between");
                Ddl1.Items.Add(item7);
            }
        }

        protected void TableChanged(object sender, EventArgs e)
        {

            Grid1Ds.Visible = true;
            OboutDropDownList Ddl1 = Table3.FindControl("FtTable") as OboutDropDownList;
            m_table = Ddl1.SelectedItem.Text.ToString().TrimEnd();
            m_tbl_val = Ddl1.SelectedValue.ToString().TrimEnd();
            //  SELECT column_name FROM all_tab_columns WHERE table_name = 'MIF' order by column_name; - oracle
            //  select column_name from information_schema.columns  where table_name = 'MIF' order by COLUMN_NAME
            OboutDropDownList tf = Grid1Ds.Templates[0].Container.FindControl("EdtTmplField1") as OboutDropDownList;
            if (m_localDB)
            {
                string dbname = (String)HttpContext.Current.Session["CurrentDB"];
                DBAccess Connection = new DBAccess();
                Connection.Connect(false, dbname);
                string Cmd = string.Format("select '    ' as column_name from information_schema.columns union select column_name from information_schema.columns where table_name = '{0}' order by COLUMN_NAME", m_table);
                try
                {
                    if (Connection.OpenDataReader(Cmd))
                    {
                        tf.DataSource = Connection.SQLDR;
                        tf.DataTextField = "column_name";
                        tf.DataValueField = "column_name";
                        tf.DataBind();
                    }
                }
                catch (Exception) {  }
                finally
                {
                    Connection.CloseDataReader();
                    Connection.DisConnect();
                }
            }
            else
            {
		        m_OraConnection=new OracleConnection();
		        m_OraConnection.ConnectionString = m_srcconnstr;
		        m_OraConnection.Open(); 
		        string Cmd = string.Format("SELECT '    ' as column_name from all_tab_columns union select column_name FROM all_tab_columns WHERE table_name = '{0}' order by COLUMN_NAME", m_table);
		        OracleCommand command = m_OraConnection.CreateCommand();
   		        command.CommandText = Cmd;
        		DataTable dt  = new DataTable();

    	    	try { dt.Load (command.ExecuteReader()); }
                catch (Exception ex) {	throw ex;}
                tf.DataSource = dt;
                tf.DataTextField = "column_name";
                tf.DataValueField = "column_name";
                tf.DataBind();
                command.Dispose();
		        m_OraConnection.Close();
                m_OraConnection.Dispose();            
            }
/*
		System.IO.StreamWriter outputStream = null;
                string fName = "C:\\Simulator\\BrowserLog.txt";
                outputStream = new System.IO.StreamWriter(new System.IO.FileStream(fName, System.IO.FileMode.OpenOrCreate));
                outputStream.WriteLine("TableChange: tf -  " + tf.Items.Count);
                outputStream.Flush();
*/
            Ddl1 = Grid1Ds.Templates[0].Container.FindControl("EdtTmplOperator1") as OboutDropDownList;
            FillOper(Ddl1, 1, false);
            BindGrid();
        }

        protected void OperatorChanged(object sender, EventArgs e)
        {
            //int b = 0;
        }

        public void DataGrid_Insert(object source, GridRecordEventArgs e)
        {
            DataRow row;
            row = m_dt.NewRow();
            row["RowNo"] = m_dt.Rows.Count;
            row["Table"] = m_table;
            row["TblVal"] = m_tbl_val;
            row["Field"] = e.Record["Field"].ToString();
            row["Operator"] = e.Record["Operator"].ToString();
            row["Val1"] = e.Record["Val1"].ToString();
            row["Val2"] = e.Record["Val2"].ToString();
            m_dt.Rows.Add(row);
            BindGrid();
        }

        public void DataGrid_Delete(object source, GridRecordEventArgs e)
        {
            string exp = string.Format("Rowno = {0}", e.Record["RowNo"]);
            DataRow[] row = m_dt.Select(exp);
            m_dt.Rows.Remove(row[0]);
            BindGrid();
        }

        protected void BindGrid()
        {
            Grid1Ds.DataSource = m_ds;
            Grid1Ds.DataBind();
        }

        private string String_sel(string Opr, string Fld1, string Table)
        {
            //   selstr.Append(String_sel("AmountOper", "P_ORIG_STTLM_AMT", "a"));

            string Str = "";
            string opr_val = "";
            string val1;
            string Fld = Fld1;
            if (m_vendor.ToLower().StartsWith("fts"))
            {
                if (Opr=="MidOper") Fld1="P_MID";
                if (Opr=="SrcOper") Fld1="P_PMNT_SRC";
                if (Opr=="MopOper") Fld1="P_CDT_MOP";
                if (Opr=="OfficeOper") Fld1="P_OFFICE";
                if (Opr=="SenderOper") Fld1="P_INSTG_AGT_BIC_2AND";
                if (Opr=="ReceiverOper") Fld1="P_INSTD_AGT_BIC_2AND";
                if (Opr=="AmountOper") Fld1="P_ORIG_STTLM_AMT";
                if (Opr=="CurrencyOper") Fld1="P_ORIG_STTLM_CCY";
                if (Opr == "DateOper") Fld1 = "P_ORIG_STTLM_DT";
            }
            OboutDropDownList Ddl1 = Table2.FindControl(Opr) as OboutDropDownList;
            opr_val = Ddl1.SelectedValue.ToString().TrimEnd();

            if (opr_val.Length > 0)
            {
                if (opr_val == "Between")
                {
                    OboutTextBox Box1 = Table2.FindControl(Fld.Insert(Fld.Length, "1")) as OboutTextBox;
                    val1 = Box1.Text.ToString().TrimEnd();
                    OboutTextBox Box2 = Table2.FindControl(Fld.Insert(Fld.Length, "2")) as OboutTextBox;
                    string val2 = Box2.Text.ToString().TrimEnd();
                    if (val2.Length > 0)
                    {
                    	if (m_localDB)
	                        Str = string.Format(" and {0}.{1} {2} '{3}' and '{4}'", Table, Fld1, opr_val, val1, val2);
	                else
	                {
	                	if (GetOraDatatype(Table, Fld.ToUpper()).ToUpper()  == "DATE")
		                        Str = string.Format(" and {0}.{1} {2} to_date('{3}','mm/dd/yyyy') and to_date('{4}','mm/dd/yyyy')", Table, Fld1, opr_val, val1, val2);
	                	else
		                        Str = string.Format(" and {0}.{1} {2} '{3}' and '{4}'", Table, Fld1, opr_val, val1, val2);
	                }
                    }
                }
                else
                {
                    OboutTextBox Box1 = Table2.FindControl(Fld.Insert(Fld.Length, "1")) as OboutTextBox;
                    val1 = Box1.Text.ToString().TrimEnd();
                    if (val1.Length > 0)
                    {
                    	if (m_localDB)
                            if (opr_val.ToLower() == "in")
                                Str = string.Format(" and {0}.{1} {2} ({3})", Table, Fld1, opr_val, val1);
                            else
	                        Str = string.Format(" and {0}.{1} {2} '{3}'", Table, Fld1, opr_val, val1);
	                else
	                {
	                    if (GetOraDatatype(Table, Fld.ToUpper()).ToUpper()  == "DATE" )
		                Str = string.Format(" and {0}.{1} {2} to_date('{3}','mm/dd/yyyy')", Table, Fld1, opr_val, val1);
		            else
		            {
                            	if (opr_val.ToLower() == "in")
		            		        Str = string.Format(" and {0}.{1} {2} ({3})", Table, Fld1, opr_val, val1);
                            	else
		            		        Str = string.Format(" and {0}.{1} {2} '{3}'", Table, Fld1, opr_val, val1);
		            }
	                }
                    }
                }
            }
            else
            {
                Str = "";
            }
            return Str;
        }

	protected string GetOraDatatype(string tbl, string Fname)
	{
		string DType="";
		string Tbl_name;
        if (m_vendor.ToLower().StartsWith("ftc"))
        {
            if (tbl == "a")
                Tbl_name = "MIF";
            else
                Tbl_name = "MTF1000";
        }
        else // FTS
            Tbl_name = "MINF";
        m_OraConnection = new OracleConnection();
		m_OraConnection.ConnectionString = m_srcconnstr;
		m_OraConnection.Open(); 
		string Cmd = string.Format("SELECT Data_type FROM all_tab_columns WHERE table_name = '{0}' and column_name = '{1}' order by COLUMN_NAME", Tbl_name,Fname);
		OracleCommand command = m_OraConnection.CreateCommand();
    		command.CommandText = Cmd;
	        OracleDataReader reader;
	        try { reader = command.ExecuteReader(); }
	        catch (Exception ex) { throw ex; }
	        if (reader.Read()) 
	        { 
			DType = reader.GetString(0).ToString();
	        }
	        return DType;
	}
	

        public void DoReplay(string TrgDB, string EdtDescr, string EdtAmtdelta, string EdtAlgorithm, string EdtFilevaldate,
                     string EdtNewvaldate, string EdtDocompare, string EdtCmptable, string EdtPrefix, string EdtReffile)
        {
            DateTime FileTime;
            try { FileTime = DateTime.Parse(EdtFilevaldate); }
            catch { EdtFilevaldate = ""; }
            try { FileTime = DateTime.Parse(EdtNewvaldate); }
            catch { EdtNewvaldate = ""; }
            string where_part = m_sql.Substring(m_sql.IndexOf("where ") + 6);
            string Sql="";
            if (m_vendor.ToLower().StartsWith("ftc"))
            {
                Sql = "select a.service, a.mid, c.contents,  a.office, a.create_date from mif a, mtf1000 b, swfmids c " +
			     "where  a.direction='I' and c.direction='IN' and a.MSG_CLASS <> 'NAC' and a.mid=c.mid and " + where_part;
            }
            if (m_vendor.ToLower().StartsWith("fts"))
            {
                Sql = "select p_dbt_mop as service, p_mid as mid, xml_orig_msg as contents, p_office as office, " +
                      "p_create_dt as create_date from minf a where p_MSG_CLASS <> 'NAC' and " + where_part;
            }
            string trgdb = "LocalDB";
            try { trgdb = m_trgnames[TrgDB].ToString().Trim(); }  //this is an uniqueue name
            catch { };
            string srcdb = "LocalDB";
            try { srcdb = m_srcnames[m_srcconnstr].ToString().Trim(); }  //this is an uniqueue name
            catch { };
            string conndb;
            if (m_localDB)
                conndb = "SQL";
            else
                conndb = "ORA";
            string Area = (String)HttpContext.Current.Session["CurrentDB"];

            StringBuilder thisXml = new StringBuilder();
            thisXml.Length = 0;
            thisXml.Append("<?xml version=\"1.0\" standalone=\"yes\"?>");
            thisXml.Append("\r\n");
            thisXml.Append("<ourxml>");
            thisXml.Append("\r\n");
            thisXml.Append("<src_connection_string>");
            thisXml.Append(srcdb);
            thisXml.Append("</src_connection_string>");
            thisXml.Append("<trg_connection_string>");
            thisXml.Append(trgdb);
            thisXml.Append("</trg_connection_string>");
            thisXml.Append("\r\n");
            thisXml.Append("<description>");
            thisXml.Append(EdtDescr);
            thisXml.Append("</description>");
            thisXml.Append("\r\n");
            thisXml.Append("<conndb>");
            thisXml.Append(conndb);
            thisXml.Append("</conndb>");
            thisXml.Append("\r\n");
            thisXml.Append("<cmptable>");
            thisXml.Append(EdtCmptable);
            thisXml.Append("</cmptable>");
            thisXml.Append("\r\n");
            thisXml.Append("<area>");
            thisXml.Append(Area);
            thisXml.Append("</area>");
            thisXml.Append("\r\n");
            thisXml.Append("<amtdelta>");
            thisXml.Append(EdtAmtdelta);
            thisXml.Append("</amtdelta>");
            thisXml.Append("\r\n");
            thisXml.Append("<algorithm>");
            thisXml.Append(EdtAlgorithm);
            thisXml.Append("</algorithm>");
            thisXml.Append("\r\n");
            thisXml.Append("<reffile>");
            thisXml.Append(EdtReffile);
            thisXml.Append("</reffile>");
            thisXml.Append("\r\n");
            thisXml.Append("<split>");
            thisXml.Append("N");
            thisXml.Append("</split>");
            thisXml.Append("\r\n");
            thisXml.Append("<minstowait>");
            thisXml.Append("1");
            thisXml.Append("</minstowait>");
            thisXml.Append("\r\n");
            thisXml.Append("<maxperfile>");
            thisXml.Append("6000");
            thisXml.Append("</maxperfile>");
            thisXml.Append("\r\n");
            thisXml.Append("<filevaldate>");
            thisXml.Append(EdtFilevaldate);
            thisXml.Append("</filevaldate>");
            thisXml.Append("\r\n");
            thisXml.Append("<show>");
            thisXml.Append("N");
            thisXml.Append("</show>");
            thisXml.Append("\r\n");
            thisXml.Append("<changeref>");
            thisXml.Append("N");
            thisXml.Append("</changeref>");
            thisXml.Append("\r\n");
            thisXml.Append("<docompare>");
            thisXml.Append(EdtDocompare);
            thisXml.Append("</docompare>");
            thisXml.Append("\r\n");
            thisXml.Append("<doreplay>");
            thisXml.Append("Y");
            thisXml.Append("</doreplay>");
            thisXml.Append("\r\n");
            thisXml.Append("<fromdatabase>");
            thisXml.Append("FromDB");
            thisXml.Append("</fromdatabase>");
            thisXml.Append("\r\n");
            thisXml.Append("<todatabase>");
            thisXml.Append("ToDB");
            thisXml.Append("</todatabase>");
            thisXml.Append("\r\n");
            thisXml.Append("<prefix>");
            thisXml.Append(EdtPrefix);
            thisXml.Append("</prefix>");
            thisXml.Append("\r\n");
            thisXml.Append("<scripttmpl>");
            thisXml.Append("");
            thisXml.Append("</scripttmpl>");
            thisXml.Append("\r\n");
            thisXml.Append("<newvaldate>");
            thisXml.Append(EdtNewvaldate);
            thisXml.Append("</newvaldate>");
            thisXml.Append("\r\n");
            Sql = Sql.TrimEnd().Replace(">", "&gt;").Replace("<", "&lt;");
            thisXml.Append("<sql>");
            thisXml.Append(Sql);
            thisXml.Append("</sql>");
            thisXml.Append("\r\n");
            thisXml.Append("</ourxml>");

            DBAccess db = new DBAccess();
            db.Connect(true, Area);
            DateTime dt = DateTime.Now;
            string Cmd = string.Format("insert into BatchQ values " +
                "('{0}','{1}','{2}','D','{3}')",
                "*",
                dt,
                null,
                thisXml.ToString().Replace("'", "''"));
            db.Execute(Cmd, true);
            // Get batch Id from BatchQ PK (identity filed)
            Cmd = string.Format("select Pk from Batchq where AssignTime = '{0}'", dt);
            db.OpenDataReader(Cmd);
            db.SQLDR.Read();
            int Pk = db.SQLDR.GetInt32(0);
            db.CloseDataReader();
            Cmd = string.Format("insert into BatchDescr values " +
                "('{0}',0,'{1}','{2}','{3}','{4}','{5}','',0,0,0,'{6}')",
                Pk,
                EdtDescr,
                "Batch Submitted",
                srcdb,
                trgdb,
                dt,EdtPrefix);
            db.Execute(Cmd, true);

            Grid2.Visible = false;
            Table2.Visible = true;
            Table3.Visible = true;
            Grid1Ds.Visible = false;
            Btn1.Visible = true;
            Btn2.Visible = false;
            BindGrid();
        }

        public void do_select(object sender, EventArgs e)
        {
            string client = (String)HttpContext.Current.Session["client"];
            StringBuilder selstr = new StringBuilder();
            selstr.Clear();
            StringBuilder fldstr = new StringBuilder();
            fldstr.Clear();
            m_sql = "";
            m_srcconnstr = SrcDB.SelectedValue.ToString().TrimEnd();
            if (m_srcconnstr == "LocalDB")
            	m_localDB = true;
            else
            	m_localDB = false;
            foreach (DataTable table in m_fields.Tables)
            {
            	    int i = 0;
                    foreach (DataRow row in table.Rows)
                    {
		        Grid2.Columns.GetColumnByIndex(i).HeaderText = row["header"].ToString().TrimEnd();
		        fldstr.Append( string.Format(" {0} as Fld{1:0},", row["name"].ToString(),i) );
		        i++;
		        if (i > 7)
		           break;
                    }
            }
            string flds = fldstr.ToString();
            flds = flds.Substring(0, flds.Length - 1 );
	        if(m_localDB)
	        {
	            selstr.Append("select TOP 501 ");
	            selstr.Append(flds);
                if (m_vendor.ToLower().StartsWith("fts"))
                    selstr.Append(" from minf a where a.p_mid=a.p_mid ");
                else
                    selstr.Append(" from mif a, mtf1000 b where a.mid=b.mid ");
            }
	        else
	        {
	            selstr.Append("select ");
	            selstr.Append(flds);
                if (m_vendor.ToLower().StartsWith("fts"))
                    selstr.Append(" from minf a where rownum < 501 and a.p_mid=a.p_mid ");
                else
                    selstr.Append(" from mif a, mtf1000 b where rownum < 501 and a.mid=b.mid ");
            }
            selstr.Append(String_sel("MidOper", "Mid", "a"));
            selstr.Append(String_sel("SrcOper", "Service", "a"));
            selstr.Append(String_sel("MopOper", "Orig_mop", "a"));
            selstr.Append(String_sel("OfficeOper", "Office", "a"));
            selstr.Append(String_sel("SenderOper", "Orig_sender", "a"));
            selstr.Append(String_sel("ReceiverOper", "Orig_rec", "a"));
            selstr.Append(String_sel("AmountOper", "Orig_amount", "a"));
            selstr.Append(String_sel("CurrencyOper", "Orig_currency", "a"));
            selstr.Append(String_sel("DateOper", "Origvaluedate", "a"));

            foreach (DataRow row in m_dt.Rows)
            {
                if (row["Operator"].ToString() == "Between")
                {
                    if (row["Val2"].ToString().Length > 0)
                    {
                    	if (m_localDB)
				            selstr.Append(string.Format(" and {0}.{1} {2} '{3}' and '{4}'", row["TblVal"], row["Field"], row["Operator"], row["Val1"], row["Val2"]));
                    	else
                    	{
                            if (GetOraDatatype(row["TblVal"].ToString(), row["Field"].ToString().ToUpper()) == "DATE")
					            selstr.Append(string.Format(" and {0}.{1} {2} to_date('{3}','mm/dd/yyyy') and to_date('{4}','mm/dd/yyyy')", row["TblVal"], row["Field"], row["Operator"], row["Val1"], row["Val2"]) );
				            else
					            selstr.Append(string.Format(" and {0}.{1} {2} '{3}' and '{4}'", row["TblVal"], row["Field"], row["Operator"], row["Val1"], row["Val2"]));
	                    }
                    }
                }
                else
                {
                    if (m_localDB)
                    {
                    	if (row["Operator"].ToString() == "In")
	                        selstr.Append(string.Format(" and {0}.{1} {2} ({3})", row["TblVal"], row["Field"], row["Operator"], row["Val1"]));
			            else
	                        selstr.Append(string.Format(" and {0}.{1} {2} '{3}'", row["TblVal"], row["Field"], row["Operator"], row["Val1"]));
		            }
		            else
		            {
                	    if (GetOraDatatype(row["TblVal"].ToString(), row["Field"].ToString()).ToUpper() == "DATE")
				            selstr.Append(string.Format(" and {0}.{1} {2} to_date('{3}','mm/dd/yyyy')", row["TblVal"], row["Field"], row["Operator"], row["Val1"]) );
			            else
			            {
	                    	if (row["Operator"].ToString() == "In")
		                    selstr.Append(string.Format(" and {0}.{1} {2} ({3})", row["TblVal"], row["Field"], row["Operator"], row["Val1"]));
	                    	else
		                    selstr.Append(string.Format(" and {0}.{1} {2} '{3}'", row["TblVal"], row["Field"], row["Operator"], row["Val1"]));
			            }
		            }
                }
            }
            //select a.mid, a.msg_type, b.bbi from mif a, mtf1000 b where a.mid=b.mid and a.service = 'SWF' and a.msg_type = '103'  and b.bbi like '/ACC%';
            string Cmd = selstr.ToString();

            OboutTextBox a = Btn1.FindControl("Msg1") as OboutTextBox;
            a.Visible = false;

/*
		System.IO.StreamWriter outputStream = null;
		string fName = "C:\\Simulator\\BrowserLog.txt";
		outputStream = new System.IO.StreamWriter(new System.IO.FileStream(fName, System.IO.FileMode.OpenOrCreate));

                outputStream.WriteLine("DoSelect: cmd -  " + Cmd);
                outputStream.Flush();
                outputStream.Close();
*/

            m_sql = Cmd;
            string res = BindDataGrid2(Cmd);

            if (res != "")
            {
                m_sql = "";
                a.Text = "No transactions matches this selection";
                a.ForeColor = System.Drawing.Color.Red;
                a.BackColor = System.Drawing.Color.LightGray;
                a.Visible = true;
                BindGrid();
            }
        }

        protected string BindDataGrid2(string Cmd)
        {
            if (m_localDB)
            {
	            m_Connection = new DBAccess();
	            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
	            try
	            {
	                m_Connection.Connect(false, dbname);
	                DataSet ds = m_Connection.getDataSet(Cmd);
	                if (ds.Tables[0].Rows.Count == 0)
	                {
	                    return "Nothing Selected";
	                }
	                Grid2.DataSource = ds;
	                Grid2.DataBind();
	            }
	            catch (Exception e) { throw e; }
	            finally
	            {
	                m_Connection.DisConnect();
	            }
	    }
	    else
	    {
	        m_OraConnection.Close(); // in case it is left open for any reason
		m_OraConnection.Open(); 
		OracleCommand command = m_OraConnection.CreateCommand();
    		command.CommandText = Cmd;
		OracleDataReader reader;

		try { 
			reader = command.ExecuteReader(); 
	                Grid2.DataSource = reader;
	                Grid2.DataBind();
		    }
		catch (Exception ex) {throw ex; }

                command.Dispose();
	        m_OraConnection.Close();
	    }
            Grid2.Visible = true;
            Table2.Visible = false;
            Table3.Visible = false;
            Grid1Ds.Visible = false;
            Btn1.Visible = false;
            Btn2.Visible = true;

            return "";
        }

        protected void MakeDataSet()
        {
            try
            {
                m_ds.Clear();
            }
            catch { };
            m_ds = new DataSet();
            m_dt = m_ds.Tables.Add();

            DataColumn column;

            column = new DataColumn();
            column.DataType = System.Type.GetType("System.Int32");
            column.ColumnName = "RowNo";
            m_dt.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "Table";
            m_dt.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "TblVal";
            m_dt.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "Field";
            m_dt.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "Operator";
            m_dt.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "Val1";
            m_dt.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "Val2";
            m_dt.Columns.Add(column);
            BindGrid();
            /*
                    row = table.NewRow();
                    row["Id"] = 1;
                    row["Name"] = "Jane";
                    table.Rows.Add(row);
            */
        }

				public string MakeCmd(string mid)
				{
						string cmd;
						if (m_vendor.ToLower().StartsWith("fts"))
						{
								cmd = string.Format("select " +
											"P_MSG_STS,P_PRIORITY,P_DEPARTMENT,P_OFFICE," +
											"P_ORIG_MSG_TYPE,P_CDT_MOP,P_ORIG_INSTR_ID,P_END_TO_END_ID,'0' as CHECK_INT,P_ORIG_STTLM_DT," +
											"P_ORIG_STTLM_CCY,P_ORIG_STTLM_AMT,P_ORIG_STTLM_CCY,P_ORIG_STTLM_AMT,P_ORIG_STTLM_CCY," +
											"P_ORIG_STTLM_AMT,P_INSTG_AGT_BIC_2AND,P_BASE_AMT,'N' as DEAL_BOOKED,P_DBT_ACCT_CCY," +
											"P_DBT_AMT,P_DBT_VD,P_DBT_ACCT_CCY,P_DBT_AMT,P_CDT_ACCT_CCY,P_CDT_AMT,P_CDT_VD," +
											"'RFB' as rfb, 'ORG_BIC' as org_bic, 'ORG_ID' as org_id, 'ORG' as org, 'ORG_ADDR1' as org_addr1, 'ORG_ADDR2' as org_addr2," +
											"'ORG_ADDR3' as org_addr3, 'OGB_BIC' as ogb_bic, 'OGB_ID' as ogb_id, 'OGB' as ogb, 'OGB_ADDR1' as ogb_addr1, 'OGB_ADDR2' as ogb_addr2," +
											"'OGB_ADDR3' as ogb_addr3, 'COR_BIC' as cor_bic, 'COR_ID' as cor_id," +
											"'COR' as cor, 'COR_ADDR1' as cor_addr1, 'COR_ADDR2' as cor_addr2, 'COR_ADDR3' as cor_addr3, 'RCR_BIC' as rcr_bic, " +
											"'RCR_ID' as rcr_id, 'RCR' as rcr, 'RCR_ADDR1' as rcr_addr1, 'RCR_ADDR2' as rcr_addr2, 'RCR_ADDR3' as rcr_addr3," +
											"'RCB_BIC' as rcb_bic, 'RCB_ID' as rcb_id, 'RCB' as rcb, 'RCB_ADDR1' as rcb_addr1, 'RCB_ADDR2' as rcb_addr2, 'RCB_ADDR3' as rcb_addr3," +
											"'SEND_ABA' as send_aba, 'SEND_NAME' as send_name, 'REC_ABA' as rec_aba," +
											"'REC_NAME' as rec_name, 'IBK_BIC' as ibk_bic, 'IBK_ID' as ibk_id, 'IBK' as ibk, 'IBK_ADDR1' as ibk_addr1, 'IBK_ADDR2' as ibk_addr2," +
											"'IBK_ADDR3' as ibk_addr3, 'BBK_BIC' as bbk_bic, 'BBK_ID' as bbk_id, 'BBK' as bbk," +
											"'BBK_ADDR1' as bbk_addr1, 'BBK_ADDR2' as bbk_addr2, 'BBK_ADDR3' as bbk_addr3, " +
											"'BNF_BIC' as bnf_bic, 'BNF_ID' as bnf_id, 'BNF' as bnf, 'BNF_ADDR1' as bnf_addr1, 'BNF_ADDR2' as bnf_addr2, 'BNF_ADDR3' as bnf_addr3," +
											"P_DBT_ACCT_NB,P_DBT_ACCT_NB,P_DBT_FEE_ACCT_NB,P_DBT_APPLY_FEE,P_DBT_FEE_PMT_CCY,P_DBT_RATE,P_CDT_ACCT_NB,P_CDT_ACCT_NB," +
											"P_CDT_FEE_ACCT_NB,P_CDT_APPLY_FEE,P_CDT_FEE_PMT_CCY,'AGENT_FEES' as agent_fees, 'AGENT_FEES_CURRENCY' as agent_fees_currency," +
											"P_DBT_RATE,P_MID" +
						          " from minf where p_mid = '{0}'", mid);
						}
						else
						{
                            cmd = string.Format("select " +
					            "a.MSG_STATUS, a.PRIORITY, a.DEPARTMENT, a.OFFICE," +
					            "a.ORIG_MT, a.MOP, a.ORIG_REFERENCE, a.LOCAL_REF, a.CHEQUE_INT, a.ORIGVALUEDATE," +
					            "a.ORIG_CURRENCY, a.ORIG_AMOUNT, a.ORIG_INSTRUCT_CURRENCY, a.ORIG_INSTRUCT_AMOUNT, a.OCMT_CURRENCY," +
					            "a.OCMT_AMOUNT, a.ORIG_SENDER, a.BASE_AMOUNT, a.DEAL_BOOKED, a.DBCURRENCY," +
					            "a.DBAMOUNT, a.DRVALUEDATE, a.DBCURRENCY, a.DBAMOUNT, a.CRCURRENCY," +
					            "a.CRAMOUNT, a.VALUE_DATE, b.RFB, b.ORG_BIC, b.ORG_ID, b.ORG, b.ORG_ADDR1, b.ORG_ADDR2," +
					            "b.ORG_ADDR3, b.OGB_BIC, b.OGB_ID, b.OGB, b.OGB_ADDR1, b.OGB_ADDR2, b.OGB_ADDR3, b.COR_BIC, b.COR_ID," +
					            "b.COR, b.COR_ADDR1, b.COR_ADDR2, b.COR_ADDR3, b.RCR_BIC, b.RCR_ID, b.RCR, b.RCR_ADDR1, b.RCR_ADDR2, b.RCR_ADDR3," +
					            "b.RCB_BIC, b.RCB_ID, b.RCB, b.RCB_ADDR1, b.RCB_ADDR2, b.RCB_ADDR3, b.SEND_ABA , b.SEND_NAME, b.REC_ABA  ," +
					            "b.REC_NAME, b.IBK_BIC, b.IBK_ID, b.IBK, b.IBK_ADDR1, b.IBK_ADDR2, b.IBK_ADDR3, b.BBK_BIC, b.BBK_ID, b.BBK," +
					            "b.BBK_ADDR1, b.BBK_ADDR2, b.BBK_ADDR3, b.BNF_BIC, b.BNF_ID, b.BNF, b.BNF_ADDR1, b.BNF_ADDR2, b.BNF_ADDR3, b.ACC_NO," +
					            "b.MP_DB_ACC, b.DB_FEE_ACC, b.DB_FEES , b.DB_FEES_CURRENCY, b.DR_RATE, b.CR_ACC_NO, b.MP_CR_ACC, b.CR_FEE_ACC, b.CR_FEES ," +
					            "b.CR_FEES_CURRENCY, b.AGENT_FEES , b.AGENT_FEES_CURRENCY, b.CR_RATE, a.MID " +
					            "from mif a, mtf1000 b where  a.mid = '{0}' and a.mid=b.mid", mid);
						}
						return cmd;
				}
        public string[] LoadRecord(string mid)
        {
            int NoElem = 95;
            string[] sRecord = new string[NoElem];
            string Cmd;
            string dbname = (String)HttpContext.Current.Session["CurrentDB"];
            if (m_localDB)
            {
                DBAccess Connection = new DBAccess();
                Connection.Connect(false, dbname);
				Cmd = MakeCmd (mid);
                try
                {
                    if (Connection.OpenDataReader(Cmd))
                    {
                        if (Connection.SQLDR.Read())
                        {
                            for (int i = 0; i < NoElem; i++)
                            {
                                sRecord[i] = (Connection.SQLDR[i].ToString().Trim());
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    Connection.CloseDataReader();
                    Connection.DisConnect();
                }
            }
            else
            {
		        m_OraConnection=new OracleConnection();
		        m_OraConnection.ConnectionString = m_srcconnstr;
		        m_OraConnection.Open(); 
		        char [] dtype;
		        if (m_vendor.ToLower().StartsWith("fts"))
		        {
				    dtype= new char[] {'s','n','s','s', 
				    's','s','s','s','s','d', 
				    's','n','s','n','s', 
				    'n','s','n','s','s',
				    'n','d','s','n','s',
				    'n','d','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','n','s','s','s','s',
				    's','s','s','n','s'};
		        }
		        else
		        {
				    dtype= new char[] {'s','s','s','s', 
				    's','s','s','s','s','d', 
				    's','n','s','n','s', 
				    'n','s','n','s','s',
				    'n','d','s','n','s',
				    'n','d','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','n','s','s','s','s',
				    's','s','s','n','s'};
		        }
// s- string, n - numeric, d -datetime      
								Cmd = MakeCmd (mid);
				        OracleCommand command = m_OraConnection.CreateCommand();
    		        command.CommandText = Cmd;
		        OracleDataReader reader;
		        try { reader = command.ExecuteReader(); }
		        catch (Exception ex) { throw ex; }
		        if (reader.Read()) 
		        { 
	                        for (int i = 0; i < NoElem; i++)
                                {
                                  if (dtype[i] == 'n')
                                    try { sRecord[i] = reader.GetDecimal(i).ToString(); }
                                    catch (Exception) { sRecord[i] = " "; }
                                  else
                                    if (dtype[i] == 'd')
                                    	try { sRecord[i] = reader.GetDateTime(i).ToString(); }
                                    	catch (Exception) { sRecord[i] = " "; }
                                    else
                                    	try { sRecord[i] = reader.GetString(i).ToString(); }
                                    	catch (Exception) { sRecord[i] = " "; }
                                }
		        }
		
                command.Dispose();
		        m_OraConnection.Close();
                m_OraConnection.Dispose();            
            }
            if (m_vendor.ToLower().StartsWith("fts") )
                Cmd = "select username, status, module_id as description from newjournal where mid = '" + mid + "'";
            else
                Cmd = "select username, status, description from newjournal where mid = '" + mid + "'";

            if (m_localDB)
            {
                m_Connection = new DBAccess();
                SqlConnection conn = new SqlConnection(m_Connection.GetConnString(dbname));
                conn.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand(Cmd, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    History.DataSource = reader;
                    History.DataBind();
                    UpdatePanel("HistPanel");
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    m_Connection.DisConnect();
                    conn.Dispose();
                }
            }
            else
            {
		        m_OraConnection=new OracleConnection();
		        m_OraConnection.ConnectionString = m_srcconnstr;
		        m_OraConnection.Open(); 
		        OracleCommand command = m_OraConnection.CreateCommand();
    		    command.CommandText = Cmd;
		        OracleDataReader reader;

		        try { 
			        reader = command.ExecuteReader(); 
	                        History.DataSource = reader;
	                        History.DataBind();
	                        UpdatePanel("HistPanel");
		            }
        		catch (Exception ex) { throw ex; }
                command.Dispose();
	            m_OraConnection.Close();
                m_OraConnection.Dispose();      
            }
            return sRecord;
        }
    }
}
