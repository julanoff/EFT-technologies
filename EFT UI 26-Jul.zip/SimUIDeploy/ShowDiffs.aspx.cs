/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using System.Data.SqlClient;
using Simulator.BackEndSubLib;
using Obout.Grid;
using Obout.Interface;


/*
 * Difference Page.
 */
public partial class ShowDiffs : System.Web.UI.Page
{
    private static string m_Batchstr;
    private static string m_Filter;
    private static string m_RefBefore;
 //   private BackEndSubs subs;
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillBatch();
            DataGrid1.Visible = false;
        }
        DataGrid2.Visible = false;
        BacktoSummary.Visible = false;
        DoReport.Visible = false;
        Box6.Visible = false;
        Excel.Visible = false;
        AllDiff.Visible = false;

        if (DataGrid2.SelectedRecords != null)  //when user has choosen a record.
        {
            foreach (Hashtable oRecord in DataGrid2.SelectedRecords)
            {
                m_RefBefore = oRecord["RefBefore"].ToString().TrimEnd();
            }
            DataGrid1.Visible = true;
            DataGrid1.AllowFiltering = true;
            BacktoSummary.Visible = true;
            DoReport.Visible = false;
            AllDiff.Visible = true;
            Excel.Visible = true;
            Box6.Visible = false;
            BindDataGrid1();
        }
	}

    protected void FillBatch()
    {
        String Area = (String)HttpContext.Current.Session["CurrentDB"];
        DBAccess Connection = new DBAccess();
        Connection.Connect(false, Area);
        try
        {
            string Cmd = "select '      ' as BatchDescr, '0' as Batchid from BatchDescr union select batchdescr, batchid from BatchDescr where CompId=0";

            if (Connection.OpenDataReader(Cmd))
            {
                BatchIdsDropdown.DataSource = Connection.SQLDR;
                BatchIdsDropdown.DataTextField = "BatchDescr";
                BatchIdsDropdown.DataValueField = "BatchId";
                BatchIdsDropdown.DataBind();
            }
        }
        catch (Exception ex) { throw ex; }
        finally
        {
            Connection.CloseDataReader();
        }
        try
        {
            string Cmd = "select '      ' as FilterName union select filtername from RptFilter";

            if (Connection.OpenDataReader(Cmd))
            {
                FilterDownList.DataSource = Connection.SQLDR;
                FilterDownList.DataTextField = "FilterName";
                FilterDownList.DataBind();
            }
        }
        catch (Exception ex) { throw ex; }
        finally
        {
            Connection.CloseDataReader();
        }
        Connection.DisConnect();
    }
    protected void OnGridRowCreated(object sender, GridRowEventArgs args)
    {
        //DataGrid1.Columns[1].ReadOnly = false;
        // gets called before a row created. It stop each time the row is populated from DB not used
    }

    protected void RebindGrid1(object sender, EventArgs e)
    {
          BindDataGrid1();
    }
    protected void RebindGrid2(object sender, EventArgs e)
    {
        BindDataGrid2();
    }

    protected void OnSelectedIndexChangedFil(object sender, EventArgs e)
// when user chooses to apply pre defined filter
    {
        m_Filter = FilterDownList.SelectedValue;
    }

    protected void OnSelectedIndexChanged(object sender, EventArgs e)
    {
//  when user chooses a mid /trn to show all diff for selected ref
        m_Batchstr = BatchIdsDropdown.SelectedValue;
        string Cmd = string.Format("select * from batchdescr where batchid='{0}'", m_Batchstr);
        String Area = (String)HttpContext.Current.Session["CurrentDB"];

        DBAccess Connection = new DBAccess();
        Connection.Connect(false, Area);
        try
        {
            if (Connection.OpenDataReader(Cmd))
            {
                while (Connection.SQLDR.Read())
                {
                    Box1.Text = Connection.SQLDR["BatchStatus"].ToString().TrimEnd();
                    Box4.Text = Connection.SQLDR["TimeStart"].ToString();
                    Box5.Text = Connection.SQLDR["TimeStart"].ToString();
                }
            }
        }
        catch (Exception ex) { throw ex; }
        finally
        {
            Connection.CloseDataReader();
            Connection.DisConnect();
        }
        DataGrid2.Visible = true;
        DataGrid1.Visible = false;
        DoReport.Visible = true;
        Box6.Visible = false;
        string vendor = Session["vendor"].ToString().Trim().ToLower();
        if (vendor.StartsWith("aci"))
        {
            DataGrid2.Columns[3].HeaderText = "Diffs in MSG";
            DataGrid2.Columns[4].HeaderText = "Diffs in CRD";
            DataGrid2.Columns[5].HeaderText = "Diffs in DBT";
            DataGrid2.Columns[6].HeaderText = "Diffs in DEST";
        }
        if (vendor.StartsWith("fts"))
        {
            DataGrid2.Columns[3].HeaderText = "Diffs in MINF";
            DataGrid2.Columns[4].HeaderText = "Diffs in MERR";
            DataGrid2.Columns[5].HeaderText = "Diffs in MIE";
            DataGrid2.Columns[6].HeaderText = "Diffs in NJRN";
        }
        BindDataGrid2();
    }

    protected void DoExcel(object sender, EventArgs e)
    {
        DataGrid1.Visible = true;
        BacktoSummary.Visible = true;
        AllDiff.Visible = true;
        Excel.Visible = true;
        Box6.Visible = false;
        BindDataGrid1();
    }
    protected void ExcelBatch(object sender, EventArgs e)
    {
        DataGrid2.Visible = true;
        DataGrid1.Visible = false;
        DoReport.Visible = true;
        Box6.Visible = false;
        BacktoSummary.Visible = false;
        AllDiff.Visible = false;
        Excel.Visible = false;
        if (m_Batchstr == "")
        {
            Box6.Visible = true;
            Box6.Text = "No Batch has been chosen";
        }
        else
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess Connection = new DBAccess();
            Connection.Connect(true, Area);
            try
            {
                string Cmd = string.Format("select ProcessState from ExcelQ where batchid='{0}'", m_Batchstr);
                Connection.OpenDataReader(Cmd);
                if (Connection.SQLDR.Read())
                {
                    
                    string st = Connection.SQLDR["ProcessState"].ToString().TrimEnd();
                    Box6.Visible = true;
                    switch (st)
                    {
                        case "*":
                            Box6.Text = "Already Submitted. Waiting to be processed";
                            break;
                        case "I":
                            Box6.Text = "In progress";
                            break;
                        case "P":
                            Box6.Text = "Already Processed";
                            break;
                        case "E":
                            Box6.Text = "Error";
                            break;
                        case "W":
                            Box6.Text = "Job is on Hold";
                            break;
                    }
                }
                else
                {
                    Connection.CloseDataReader();
                    DateTime dt = DateTime.Now;
                    Cmd = string.Format("insert into ExcelQ values " +
                        "('{0}','{1}','{2}','{3}')",
                        "*",
                        m_Batchstr,
                        dt,
                        null);
                    Connection.Execute(Cmd, true);
                }
            }
            catch (Exception ex)
            {
                throw (ex); 
            }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
        }        
        BindDataGrid2();
    }

    protected void ShowAllBatch(object sender, EventArgs e)
    {
        m_RefBefore = "";
        DataGrid1.Visible = true;
        BacktoSummary.Visible = true;
        DoReport.Visible = false;
        AllDiff.Visible = false;
        Excel.Visible = true;
        BindDataGrid1();
    }

    protected void SummaryBatch(object sender, EventArgs e)
    {
        //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
        DoReport.Visible = true;
        BacktoSummary.Visible = false;
        Excel.Visible = false;
        AllDiff.Visible = false;
        DataGrid1.Visible = false;
        DataGrid2.Visible = true;
        BindDataGrid2();
    }
    
    protected void BindDataGrid1()
    {
        DBAccess Connection= new DBAccess();
	    String dbname=(String)HttpContext.Current.Session["CurrentDB"];
        try
        {
	        Connection.Connect(false, dbname);
            string Cmd = "";
            if (m_RefBefore.Length != 0)
                //select * from DiffSummary where RefBefore not in (select distinct RefBefore from DiffResults where xmlset='mif' and FldName='msg_status' and ValBefore = valafter)
                //"select * from DiffSummary where RefBefore not in (select distinct RefBefore from DiffResults where {0}) order by Refbefore"), rptfilter(filtername);
                //"select * from DiffResults where RefBefore not in (select distinct RefBefore from DiffResults where {0}) order by RefBefore"), rptfilter(filtername); 


                Cmd = string.Format("select batchid,refbefore, refafter,fldname,valbefore,valafter, Xmlset from diffresults where batchid={0} and refbefore='{1}' order by refbefore", m_Batchstr, m_RefBefore);
            else
            {
                BackEndSubs subs = new BackEndSubs();
                string wh = subs.reportfilter(dbname, m_Filter); 
                Cmd = string.Format("select batchid,refbefore, refafter,fldname,valbefore,valafter, Xmlset from diffresults where batchid={0} {1} order by refbefore", m_Batchstr, wh);
                Cmd = Cmd.Replace("{0}", m_Batchstr);
            }
            DataSet ds = Connection.getDataSet(Cmd);
            DataGrid1.DataSource = ds;
            DataGrid1.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            Connection.DisConnect();
        }
    }

    protected void BindDataGrid2()
    {
        DBAccess Connection = new DBAccess();
        String dbname = (String)HttpContext.Current.Session["CurrentDB"];
        try
        {
            Connection.Connect(false, dbname);
            BackEndSubs subs = new BackEndSubs();
            string wh = subs.reportfilter(dbname, m_Filter); 
            string Cmd = string.Format("select refbefore, refafter, diffnumber, mifs, mtfs, swfmids, freemsgs  from diffsummary where batchid={0} {1} order by refbefore", m_Batchstr, wh);
            Cmd = Cmd.Replace("{0}", m_Batchstr); 
            DataSet ds = Connection.getDataSet(Cmd);
            DataGrid2.DataSource = ds;
            DataGrid2.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            Connection.DisConnect();
        }
    }
}