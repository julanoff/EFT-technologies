/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                  
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;
using Simulator.DBLibrary;
using Simulator.RGWSubLib;
using Simulator.BackEndSubLib;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;

/*
 * 13-Aug-06    JR      Off to the races we go. This code takes care of loading ByLogs files.
 * 20-Oct-06    JR      Only do batch ByLogs loads.
 *  9-Nov-06    JR      Put a filter on the radio list. If they don't spring for buying the
 *                      browser piece, we only want to let them do the minimum rgw functions
 *                      req'd to load ByLogs and split the trn's.
 * 
 * 17-Nov-06    JR      Coupla bugs with looking in the right database when the rgw database
 *                      isn't local to the area we're in.
 * 
 * 19-Nov-06    JR      Change the verbiage from 'ByLogs' to 'Msgs'.
 * 21-Nov-06    JR      Make the state '*' when inserting the entry into the bylogs control
 *                      table. This'll make the load take off automatically. 
 * 
 * 18-Feb-07    JR      A whole new section - two, actually - to let the humans edit all of the
 *                      various RGW parameters such as where the master repositiory lives,
 *                      what compare table name should be the default (which will be the one
 *                      the receiver uses), etc, etc.
 * 
 * 26-Feb-07    JR      Merge Jacob's version and mine. Change the verbiage on a couple of labels.
 *                      If we throw an exception, display it on the screen.
 * 
 * 24-May-08    JR      Finally we get around to comparing rgw data. Bug with an inconsistency
 *                      between the radio button verbiage and the case statement looking
 *                      for that text.
 *                      
 * 11-Jul-17    JR      Some defensive code - thanks BB&T - so we don't croak if the value in web.config
 *                      we're looking for isn't there ...
 * 
*/

namespace Simulator
{
    /// <summary>
    /// Summary description for RgwMaint.
    /// </summary>
    public partial class RgwMaint : System.Web.UI.Page
    {
        bool DoNotLookInMaster = false;
        bool LookInMaster = true;
        string emptyArea = "Null";
        bool LoadMasterTables = true;
        bool LoadLocalTables = false;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            // Put user code to initialize the page here
            if (!Page.IsPostBack)
            {
                //LoadListBox();
                mListBox.Visible = false;
                ReceiverRgwAreaList.Visible = false;
                LocalRgwAreaList.Visible = false;
                LoadRadioList();
            }
            if (!ClientScript.IsClientScriptBlockRegistered("confirm"))
            {
                string jsConfirm = @"<script language='javascript'> " +
                    "function confirm_delete() " +
                    "{ return (confirm('Are you sure you want to perform this function?')); }" +
                    "</script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "confirm", jsConfirm);
            }
        }
        private void LoadRadioList()
        {
            /*
             * This RGWforSplitterOnly value is an artifact of Sun Trust from 100 years ago. I'm gonna 
             * leave the functionality in place but default to 'normal' behavior and try/catch the
             * appsetting call. Somehow BB&T was missing that value in web.config and this page
             * blew up when they tried to load it.
             */
            string tmp = "N";
            try
            {
                tmp =  System.Configuration.ConfigurationManager.AppSettings["RGWforSplitterOnly"].ToUpper();
            }
            catch { }
            ArrayList values = new ArrayList();
            values.Add("Rename RGW files to reload them");
            if (tmp.StartsWith("Y"))
            {
                values.Add("Purge MDR Database tables");
                values.Add("Load RGW Files for Replay");           

                values.Add("Update Area Message Repository list");
                values.Add("Update Master Message Repository list");
            }
            else
            {
                String Area = (String)HttpContext.Current.Session["CurrentDB"];
                values.Add("Purge MDR Database tables");
                values.Add("Load All RGW files into MDR for Replay/Comparing");

                values.Add("Purge local " + Area + " Database tables");
                values.Add("Load RGW Files for Comparison only (load into " + Area + " Database tables)");
      
                values.Add("Update Area Message Repository list");
                values.Add("Update Master Message Repository list");
            }

            RadioButtonList1.RepeatColumns = 1;
            RadioButtonList1.DataSource = values;
          
            RadioButtonList1.DataBind();

            for (int idx = 0; idx < values.Count; idx++)
            {
               // RadioButtonList1.ToolTip.Insert(idx, "dude");
            }
  
            Label1.Visible = false;
            hideRgwDropDowns();
            ExecButton.Attributes.Add("onclick", "return confirm_delete();");
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion
        private void CancelButtonClick(object sender, System.EventArgs e)
        {
            mListBox.SelectedIndex = -1;
            RadioButtonList1.SelectedIndex = -1;
        }

        protected void ExecButtonClick(object sender, System.EventArgs e)
        {
            if ((!RadioButtonList1.SelectedItem.Text.Equals("Update Area Message Repository list"))
                && (!RadioButtonList1.SelectedItem.Text.Equals("Update Master Message Repository list")))
            {
                //ExecButton.Attributes.Remove("onclick"); 
                ExecButton.Attributes.Add("onclick", "return confirm_delete();");
            }
            Label2.Visible = false;
            /*
            if (mListBox.SelectedIndex > -1)
            {
                Label1.Text = "You chose: " + mListBox.SelectedItem.Text;
                Label1.Visible = true;
                Label2.Text = "Done at " + DateTime.Now;
                Label2.Visible = true;
            }
             * */

            if (RadioButtonList1.SelectedIndex > -1)
            {
                Label1.Text = "You chose: " + RadioButtonList1.SelectedItem.Text;
                Label1.Visible = true;
                Label2.Text = "Done at " + DateTime.Now;
                Label2.Visible = true;
            }

            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            BackEndSubs _util = new BackEndSubs();
            string _area = (string)HttpContext.Current.Session["CurrentDB"];

            //DBAccess dbWriter= new DBAccess();
            try
            {
        
                if (RadioButtonList1.SelectedItem.Text.Equals("Rename RGW files to reload them"))
                {
                    string bylogsPath = _util.GetRgwLoadFilesDir(Area);
                    _util.logInfo(_area, "Msgs", "Reset all RGW Message file names");
                    _util.resetRgwMessageFileList(bylogsPath);
                    Label2.Text = "RGW files renamed. You can load them again.";
                    Label2.Visible = true;
                }


                if (RadioButtonList1.SelectedItem.Text.StartsWith("Load All RGW files into MDR"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE", LoadMasterTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_TEXT", LoadMasterTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_HIST", LoadMasterTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_CR", LoadMasterTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_DR", LoadMasterTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_DEST", LoadMasterTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_ACCTG", LoadMasterTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_PR", LoadMasterTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_PR_MCH", LoadMasterTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_PR_PRM", LoadMasterTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_PR_PVL", LoadMasterTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_REL_AMT", "ALL", LoadMasterTables); // Just to say we've loaded all tables.
                    if (stat != -666)
                    {
                        _util.logInfo(_area, "Msgs", "RGW load for Replay queued");
                        _util.loadSplitterByLogs(_area, "S");
                    }
                }

                if (RadioButtonList1.SelectedItem.Text.StartsWith("Load RGW Files for Comparison only"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE", LoadLocalTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_TEXT", LoadLocalTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_HIST", LoadLocalTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_CR", LoadLocalTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_DR", LoadLocalTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_DEST", LoadLocalTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_ACCTG", LoadLocalTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_PR", LoadLocalTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_PR_MCH", LoadLocalTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_PR_PRM", LoadLocalTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_PR_PVL", LoadLocalTables);
                    //stat = insertRgwMessageLoaderControl("MESSAGE_REL_AMT", "ALL", LoadLocalTables); // Just to say we've loaded all tables.
                }

                if (RadioButtonList1.SelectedItem.Text.StartsWith("Load RGW Files for Replay"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE", LoadMasterTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_TEXT", LoadMasterTables);
                    stat = insertRgwMessageLoaderControl("MESSAGE_HIST", "RGW for Replay", LoadMasterTables);
                    if (stat != -666)
                    {
                        _util.logInfo(_area, "Msgs", "RGW load for Replay queued");
                        _util.loadSplitterByLogs(_area, "S");
                    }
                }
                /*
                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Message file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE");
                }

                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Text file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_TEXT");
                }

                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load History file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_HIST");
                }

                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Credit file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_CR");
                }

                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Debit file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_DR");
                }

                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Destination file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_DEST");
                }

                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Accounting file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_ACCTG");
                }

                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Processing Rules files"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_PR");
                    stat = insertRgwMessageLoaderControl("MESSAGE_PR_MCH");
                    stat = insertRgwMessageLoaderControl("MESSAGE_PR_PRM");
                    stat = insertRgwMessageLoaderControl("MESSAGE_PR_PVL");
                }

                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Rel_Amt file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_REL_AMT");
                }
                if (RadioButtonList1.SelectedItem.Text.Equals("Batch Load Rel_Amt file"))
                {
                    int stat = insertRgwMessageLoaderControl("MESSAGE_REL_AMT");
                }
                */
                if (RadioButtonList1.SelectedItem.Text.Equals("Purge MDR Database tables"))
                {
                    string rgwArea = string.Empty;                
                    rgwArea = _util.GetRgwRepository(_area, true);
                    _util.logInfo(_area, "Msgs", "Purging all MDR tables in database Simulator_" + rgwArea);
                    ArrayList rgwList = new ArrayList();
                    rgwList.Add("MESSAGE");
                    rgwList.Add("MESSAGE_TEXT");
                    rgwList.Add("MESSAGE_HIST");
                    rgwList.Add("MESSAGE_CR");
                    rgwList.Add("MESSAGE_DR");
                    rgwList.Add("MESSAGE_DEST");
                    rgwList.Add("MESSAGE_ACCTG");
                    rgwList.Add("MESSAGE_PR");
                    rgwList.Add("MESSAGE_PR_MCH");
                    rgwList.Add("MESSAGE_PR_PRM");
                    rgwList.Add("MESSAGE_PR_PVL");
                    rgwList.Add("MESSAGE_REL_AMT");
                    _util.TruncateTables(rgwArea, Area, rgwList);
                }

                if (RadioButtonList1.SelectedItem.Text.StartsWith("Purge local " + _area + " Database tables"))
                {
                    string rgwArea = string.Empty;
                    rgwArea = _area;
                    _util.logInfo(_area, "Msgs", "Purging all Message tables in database Simulator_" + rgwArea);
                    ArrayList rgwList = new ArrayList();
                    rgwList.Add("MESSAGE");
                    rgwList.Add("MESSAGE_TEXT");
                    rgwList.Add("MESSAGE_HIST");
                    rgwList.Add("MESSAGE_CR");
                    rgwList.Add("MESSAGE_DR");
                    rgwList.Add("MESSAGE_DEST");
                    rgwList.Add("MESSAGE_ACCTG");
                    rgwList.Add("MESSAGE_PR");
                    rgwList.Add("MESSAGE_PR_MCH");
                    rgwList.Add("MESSAGE_PR_PRM");
                    rgwList.Add("MESSAGE_PR_PVL");
                    rgwList.Add("MESSAGE_REL_AMT");
                    _util.TruncateTables(rgwArea, Area, rgwList);
                }

                //if (RadioButtonList1.SelectedItem.Text.Equals("By logs loader control"))
                //{
                //    //Server.Transfer("ByLogsLoad.aspx");
                //}

                if (RadioButtonList1.SelectedItem.Text.Equals("Update Area Message Repository list"))
                {
                    /*
                     * This is where we present the screen to let the humans
                     * change the configuration regarding where the various rgw (message)
                     * areas are. Hide the radio buttons, populate and show our various
                     * drop-down lists.
                     */
                    hideRadioButtons();
                    Label1.Visible = false;
                    Label2.Visible = false;
                    ExecButton.Visible = false;
                    UpdateMasterRgwAreasListButton.Visible = false;
                    UpdateRgwAreasListButton.Visible = true;
                    CancelRgwAreasUpdateButton.Visible = true;

                    LocalUpdateHeader.Text = "Update MSG Repository values for Area " + _area;

                    ArrayList dbList = _util.getAllSimulatorDataBases(_area);
                    int idx;
                    /*
                     * Stuff that's local to this area.
                     */
                    string RgwRepository = _util.GetRgwRepository(_area, DoNotLookInMaster);
                    string localRgwArea = _util.GetLocalRgwArea(_area);
                    string receiverRgwArea = _util.GetReceiverRgwArea(_area);
                    string compareRgwArea = _util.GetCompareRgwArea(_area, DoNotLookInMaster);
                    string defaultCompareTable = _util.GetDefaultCompareTable(_area, DoNotLookInMaster);
                    /*
                     * Master(global, default) values.
                     */
                    string Master_RgwRepository = _util.GetMasterRgwRepository();
                    string Master_remoteRgwArea = _util.GetMasterRemoteRgwArea();
                    string Master_defaultCompareTable = _util.GetMasterDefaultCompareTable();

                    showRgwDropDowns();

                    RemoteRgwArea.Text = _util.GetRemoteRgwArea(_area, DoNotLookInMaster);
                    DefaultCompareTable.Text = _util.GetDefaultCompareTable(_area, DoNotLookInMaster);

                    RgwRepositoryList.Items.Add(emptyArea);
                    LocalRgwAreaList.Items.Add(emptyArea);
                    ReceiverRgwAreaList.Items.Add(emptyArea);
                    CompareRgwAreaList.Items.Add(emptyArea);

                    string tmp = string.Empty;
                    int listIdx = 1;
                    for (idx = 0; idx < dbList.Count; idx++)
                    {
                        string xyz = dbList[idx].ToString();
                        if ((!xyz.StartsWith("Simulator_Master")) && (!xyz.StartsWith("Simulator_Master")))
                        {
                            try
                            {
                                tmp = xyz.Substring(xyz.IndexOf("_") + 1);
                            }
                            catch { };
                            if (tmp.Length > 0)
                            {
                                RgwRepositoryList.Items.Add(tmp);
                                if (tmp.Equals(RgwRepository))
                                    RgwRepositoryList.SelectedIndex = listIdx;

                                LocalRgwAreaList.Items.Add(tmp);
                                if (tmp.Equals(localRgwArea))
                                    LocalRgwAreaList.SelectedIndex = listIdx;

                                ReceiverRgwAreaList.Items.Add(tmp);
                                if (tmp.Equals(receiverRgwArea))
                                    ReceiverRgwAreaList.SelectedIndex = listIdx;

                                CompareRgwAreaList.Items.Add(tmp);
                                if (tmp.Equals(compareRgwArea))
                                    CompareRgwAreaList.SelectedIndex = listIdx;
                            }

                            listIdx++;
                        }
                    }

                }
                if (RadioButtonList1.SelectedItem.Text.Equals("Update Master Message Repository list"))
                {
                    hideRadioButtons();
                    Label1.Visible = false;
                    Label2.Visible = false;
                    ExecButton.Visible = false;
                    UpdateMasterRgwAreasListButton.Visible = true;
                    UpdateRgwAreasListButton.Visible = false;
                    CancelRgwAreasUpdateButton.Visible = true;

                    LocalUpdateHeader.Text = "          Update Master MSG Repository values";

                    ArrayList dbList = _util.getAllSimulatorDataBases(_area);
                    int idx;

                    /*
                     * Master(global, default) values.
                     */
                    string Master_RgwRepository = _util.GetMasterRgwRepository();
                    string Master_remoteRgwArea = _util.GetMasterRemoteRgwArea();
                    string Master_defaultCompareTable = _util.GetMasterDefaultCompareTable();

                    showMasterRgwDropDowns();

                    RemoteRgwArea.Text = _util.GetRemoteRgwArea(_area, DoNotLookInMaster);
                    DefaultCompareTable.Text = _util.GetMasterDefaultCompareTable();

                    RgwRepositoryList.Items.Add(emptyArea);
                    LocalRgwAreaList.Items.Add(emptyArea);
                    ReceiverRgwAreaList.Items.Add(emptyArea);
                    CompareRgwAreaList.Items.Add(emptyArea);

                    string tmp = string.Empty;
                    int listIdx = 1;
                    for (idx = 0; idx < dbList.Count; idx++)
                    {
                        string xyz = dbList[idx].ToString();
                        if ((!xyz.StartsWith("Simulator_Master")) && (!xyz.StartsWith("Simulator_Master")))
                        {
                            try
                            {
                                tmp = xyz.Substring(xyz.IndexOf("_") + 1);
                            }
                            catch { };
                            if (tmp.Length > 0)
                            {
                                RgwRepositoryList.Items.Add(tmp);
                                if (tmp.Equals(Master_RgwRepository))
                                    RgwRepositoryList.SelectedIndex = listIdx;
                            }

                            listIdx++;
                        }
                    }
                }
            }
            catch (Exception ex) 
            {
                Label2.Text = "ERROR: " + ex.Message;
                Label2.Visible = true;
                _util.logError(_area, "UI", "Exception on operation: " + RadioButtonList1.SelectedItem.Text); 
            }
            finally
            {
                //dbWriter.DisConnect();
            }

        }
        private int insertRgwMessageLoaderControl(string tName, bool LoadMasterTables)
        {
            // Just a dummy routine to call the one below. Makes it easier that
            // you don't have to have the 2nd name if you don't want to. It's only
            // for reporting purposes anyway.

            return insertRgwMessageLoaderControl(tName, tName, LoadMasterTables);
        }

        private int insertRgwMessageLoaderControl(string tName, string tNametoReport, bool LoadMasterTables)
        {
            string x;
            BackEndSubs _util = new BackEndSubs();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess dbWrt = new DBAccess();
            dbWrt.Connect(true, Area);

            string tmp = string.Format("select count(*) from RgwMessageLoaderControl where " +
            "ProcessState = '*' and FileName = '{0}' and FilePath = '{1}'",
            tName, _util.GetRgwLoadFilesDir(Area));

            if (dbWrt.OpenDataReader(tmp))
            {
                dbWrt.SQLDR.Read();
                int idx = dbWrt.SQLDR.GetInt32(0);
                dbWrt.CloseDataReader();
                if (idx > 0)
                {
                    x = tNametoReport;
                    if (x.Equals("*"))
                        x = "all tables";
                    Label2.Text = "Sorry, there's already an outstanding load pending for " + x;
                    Label2.Visible = true;
                    return -666;
                }
            }

            string rgwArea = string.Empty;
            if (LoadMasterTables)
                rgwArea = _util.GetRgwRepository(Area, true);
            else
                rgwArea = Area;

            tmp = string.Format("select count(*) from RgwMessageLoaderControl where " +
            "ProcessState = 'I' and FileName = '{0}' and FilePath = '{1}'",
            tName, _util.GetRgwLoadFilesDir(Area));

            if (dbWrt.OpenDataReader(tmp))
            {
                dbWrt.SQLDR.Read();
                int idx = dbWrt.SQLDR.GetInt32(0);
                dbWrt.CloseDataReader();
                if (idx > 0)
                {
                    x = tNametoReport;
                    if (x.Equals("*"))
                        x = "all tables";
                    Label2.Text = "Sorry, there's already a load in process for " + x;
                    Label2.Visible = true;
                    return -666;
                }
            }

            tmp = string.Format("insert into RgwMessageLoaderControl values (" +
            "'*','{0}','{1}', '{2}', '{3}', '{4}', '')",
            rgwArea, tName, _util.GetRgwLoadFilesDir(Area), DateTime.Now, DateTime.Now);
            dbWrt.Execute(tmp, true);

            x = tNametoReport;
            if (x.Equals("*"))
                x = "all tables";
            Label2.Text = "Load queued for " + x;
            Label2.Visible = true;

            dbWrt.Dispose();
            return 1;
        }


        private static string getAppSetting(string key)
        {
            string tmp = System.Configuration.ConfigurationManager.AppSettings[key];
            if (tmp != null)
                return tmp;
            return "";
        }

        protected void UpdateRgwAreas(object sender, System.EventArgs e)
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            string defaultCompareTable = DefaultCompareTable.Text.ToString().Trim();
            string remoteRgwArea = RemoteRgwArea.Text.ToString().Trim();

            string RgwRepository = RgwRepositoryList.SelectedValue.ToString().Trim();
            string localRgwArea = LocalRgwAreaList.SelectedValue.ToString().Trim();
            string receiverRgwArea = ReceiverRgwAreaList.SelectedValue.ToString().Trim();
            string compareRgwArea = CompareRgwAreaList.SelectedValue.ToString().Trim();


            if (RgwRepository.Equals(emptyArea))
                RgwRepository = "";
            if (localRgwArea.Equals(emptyArea))
                localRgwArea = "";
            if (receiverRgwArea.Equals(emptyArea))
                receiverRgwArea = "";
            if (compareRgwArea.Equals(emptyArea))
                compareRgwArea = "";
            if ((Regex.IsMatch(defaultCompareTable, "^[a-zA-Z0-9._]")) && (defaultCompareTable.IndexOf("-") == -1))
            {
                BackEndSubs util = new BackEndSubs();
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, Area);
                string cmd = string.Format("update SimulatorControl set RgwRepository='{0}', " +
                      "localRgwArea='{1}', receiverRgwArea='{2}', remoteRgwArea='{3}', " +
                      "compareRgwArea='{4}', DefaultCompareTable='{5}'",
                      RgwRepository, localRgwArea, receiverRgwArea, remoteRgwArea, compareRgwArea, defaultCompareTable);
                try
                {
                    dbWrt.Execute(cmd, true);
                    Label1.Text = "Area-wide MSG values updated";
                    util.logInfo(Area, "RGW Maint", "Local MSG areas updated");
                }
                catch
                {
                    util.logError(Area, "RGW Maint", "Exception thrown - Local MSG areas update");
                    Label1.Text = "Unexpected Exception thrown on Area-wide MSG update operation";
                }

                dbWrt.Dispose();
                hideRgwDropDowns();
                showRadioButtons();
            }
            else
            {
                Label1.Text = "Illegal Compare Table Name. Must be Alphanumeric. Underscores are allowed.";
                Label1.Visible = true;
            }
        }

        protected void UpdateMasterRgwAreas(object sender, System.EventArgs e)
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            string defaultCompareTable = DefaultCompareTable.Text.ToString().Trim();
            string remoteRgwArea = RemoteRgwArea.Text.ToString().Trim();

            string RgwRepository = RgwRepositoryList.SelectedValue.ToString().Trim();

            if (RgwRepository.Equals(emptyArea))
                RgwRepository = "";

            if ((Regex.IsMatch(defaultCompareTable, "^[a-zA-Z0-9._]")) && (defaultCompareTable.IndexOf("-") == -1))
            {
                BackEndSubs util = new BackEndSubs();
                DBAccess dbWrt = new DBAccess();
                dbWrt.Connect(true, "Master");
                string cmd = string.Format("update MasterControl set RgwRepository='{0}', " +
                      "remoteRgwArea='{1}', DefaultCompareTable='{2}'",
                      RgwRepository, remoteRgwArea, defaultCompareTable);
                try
                {
                    dbWrt.Execute(cmd, true);
                    Label1.Text = "Master MSG values updated";
                    util.logInfo(Area, "RGW Maint", "Master MSG areas updated");
                }
                catch
                {
                    util.logError(Area, "RGW Maint", "Exception thrown - Master MSG areas update");
                    Label1.Text = "Unexpected Exception thrown on Master MSG update operation";
                }

                dbWrt.Dispose();
                hideRgwDropDowns();
                showRadioButtons();
            }
            else
            {
                Label1.Text = "Illegal Compare Table Name. Must be Alphanumeric. Underscores are allowed.";
                Label1.Visible = true;
            }
        }


        protected void CancelRgwAreasUpdate(object sender, System.EventArgs e)
        {
            showRadioButtons();
            hideRgwDropDowns();
            Label1.Text = "You canceled the update";
        }
        protected void hideRadioButtons()
        {
            RadioButtonList1.Visible = false;
            Label1.Visible = false;
            Label2.Visible = false;
            ExecButton.Visible = false;
        }
        protected void showRadioButtons()
        {
            RadioButtonList1.Visible = true;
            Label1.Visible = true;
            Label2.Visible = true;
            ExecButton.Visible = true;
        }
        protected void showRgwDropDowns()
        {
            RgwRepositoryList.Visible = true;
            LocalRgwAreaList.Visible = true;
            ReceiverRgwAreaList.Visible = true;
            CompareRgwAreaList.Visible = true;
            UpdateRgwAreasListButton.Visible = true;
            UpdateMasterRgwAreasListButton.Visible = false;
            CancelRgwAreasUpdateButton.Visible = true;

            MsgRepLabel.Visible = true;
            LocalLabel.Visible = true;
            ReceiverLabel.Visible = true;
            CompareAreaLabel.Visible = true;
            RemoteLabel.Visible = true;
            CompareTableLabel.Visible = true;
            DefaultCompareTable.Visible = true;
            RemoteRgwArea.Visible = true;
            LocalUpdateHeader.Visible = true;
        }
        protected void showMasterRgwDropDowns()
        {
            RgwRepositoryList.Visible = true;
            LocalRgwAreaList.Visible = false;
            ReceiverRgwAreaList.Visible = false;
            CompareRgwAreaList.Visible = false;
            UpdateRgwAreasListButton.Visible = false;
            UpdateMasterRgwAreasListButton.Visible = true;
            CancelRgwAreasUpdateButton.Visible = true;

            MsgRepLabel.Visible = true;
            LocalLabel.Visible = false;
            ReceiverLabel.Visible = false;
            CompareAreaLabel.Visible = false;
            RemoteLabel.Visible = true;
            CompareTableLabel.Visible = true;
            DefaultCompareTable.Visible = true;
            RemoteRgwArea.Visible = true;
            LocalUpdateHeader.Visible = true;
        }
        protected void hideRgwDropDowns()
        {
            RgwRepositoryList.Visible = false;
            LocalRgwAreaList.Visible = false;
            ReceiverRgwAreaList.Visible = false;
            CompareRgwAreaList.Visible = false;
            UpdateRgwAreasListButton.Visible = false;
            UpdateMasterRgwAreasListButton.Visible = false;
            CancelRgwAreasUpdateButton.Visible = false;

            MsgRepLabel.Visible = false;
            LocalLabel.Visible = false;
            ReceiverLabel.Visible = false;
            CompareAreaLabel.Visible = false;
            RemoteLabel.Visible = false;
            CompareTableLabel.Visible = false;
            DefaultCompareTable.Visible = false;
            RemoteRgwArea.Visible = false;
            LocalUpdateHeader.Visible = false;
        }

    }
}
