/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class PartyBlock : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public void SetProperties(string partyLabel, object idtype, object id, object name1, object name2, object name3)
    {
        PartyLabel.Text = partyLabel;
        string Idtype = idtype as string;
        string Id = id as string;
        string Name1 = name1 as string;
        string Name2 = name2 as string;
        string Name3 = name3 as string;
        if (Idtype == null)
            Idtype = " ";
        if (Name1 == null)
            Name1 = " ";
        if (Name2 == null)
            Name2 = " ";
        if (Name3 == null)
            Name3 = " ";
        string newId = "";
        if (Id == null)
            Id = " ";
        else
        {
             string ans = System.Configuration.ConfigurationManager.AppSettings["ScrambleIDs"].ToUpper();
             if (ans.StartsWith("Y"))
             {
                 for (int index = 0; index < Id.Length; index++)
                 {
                     switch (Id[index])
                     {
                         case '0':
                             newId += "8";
                             break;
                         case '1':
                             newId += "0";
                             break;
                         case '2':
                             newId += "3";
                             break;
                         case '3':
                             newId += "9";
                             break;
                         case '4':
                             newId += "7";
                             break;
                         case '5':
                             newId += "6";
                             break;
                         case '6':
                             newId += "4";
                             break;
                         case '7':
                             newId += "5";
                             break;
                         case '8':
                             newId += "1";
                             break;
                         case '9':
                             newId += "2";
                             break;
                         default:
                             newId += Id[index];
                             break;
                     }
                 }
                 Id = newId;
             }
        }
         
        Label1.Text = string.Format("{0}/{1}", Idtype, Id);
        Label2.Text = Name1;
        Label3.Text = Name2;
        Label4.Text = Name3;
    }
}
