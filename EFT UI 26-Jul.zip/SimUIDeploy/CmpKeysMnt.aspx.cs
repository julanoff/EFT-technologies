/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using Obout.Grid;
using Obout.Interface;
using Simulator.DBLibrary;

namespace Simulator
{
    public partial class CmpKeysMnt : System.Web.UI.Page
    {
        private static string m_key;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                FillBatch();
                HttpContext.Current.Session["EditsAllowed"] = "Y";
                DataGrid1.Visible = false;
                Excel.Visible = false;
                DelTable.Visible = false;
            }

            Box2.Visible = false;
            KeyIdsDropdown1.Visible = false;
            Box3.Visible = false;
            ConfButton.Visible = false;
        }

        protected void FillBatch()
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            try
            {
                string Cmd = "select '      ' as TabName, '0' as Pk from LocalKeyName union select  replace(tabname, ' ',''), pk from LocalKeyName";

                if (Connection.OpenDataReader(Cmd))
                {
                    KeyIdsDropdown.DataSource = Connection.SQLDR;
                    KeyIdsDropdown.DataTextField = "TabName";
                    KeyIdsDropdown.DataValueField = "Pk";
                    KeyIdsDropdown.DataBind();
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
        }

        protected void DelTableEvent(object sender, EventArgs e)
        {

            String Cmd = "delete from LocalKeys where TabNameInd=" + m_key;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, dbname);
                Connection.Execute(Cmd, true);
                Cmd = "delete from LocalKeyName  where Pk=" + m_key;
                Connection.Execute(Cmd, true);
                FillBatch();
                //                DataGrid1.EditItemIndex = -1;
                DataGrid1.Visible = false;
                Box1.Text = "";
            }
            catch (Exception ex)
            { throw ex; }
        }
        protected void AddTableEvent(object sender, EventArgs e)
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            try
            {
                string Cmd = "select 'Default' as TabName, '0' as Pk from LocalKeyName union select  replace(tabname, ' ',''), pk from LocalKeyName";

                if (Connection.OpenDataReader(Cmd))
                {
                    KeyIdsDropdown1.DataSource = Connection.SQLDR;
                    KeyIdsDropdown1.DataTextField = "TabName";
                    KeyIdsDropdown1.DataValueField = "Pk";
                    KeyIdsDropdown1.DataBind();
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
            KeyIdsDropdown1.Visible = true;
            Box2.Visible = true;
            Box3.Visible = true;
            Box2.Focus();
            ConfButton.Visible = true;
        }
        protected void AddNameEvent(object sender, EventArgs e)
        {
            // Add a row into LocalKeyName table and copy masterkey tab into localkeys table
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);
            string name = Box2.Text.TrimEnd();
            string descr = Box3.Text.TrimEnd();
            string Cmd = string.Format("insert into LocalKeyName (tabname, tabdesc, updtime) values ('{0}', '{1}','{2}')", name, descr,DateTime.Now);
            try
            {
                connection.Execute(Cmd, true);
            }
            catch (Exception ex) { throw ex; }
            Cmd = string.Format("select pk from localkeyname where tabname='{0}'", name);
            int Pk = 0;
            if (connection.OpenDataReader(Cmd))
            {
                while (connection.SQLDR.Read())
                {
                    Pk = connection.SQLDR.GetInt32(0);
                }
            }

            string TabName = KeyIdsDropdown1.SelectedItem.Text;
            string TabInd = KeyIdsDropdown1.SelectedValue.ToString();
            string Cmd1;
            if (TabInd == "0")
                Cmd1 = string.Format("select * from masterfundtechcomparekeys");
            else
                Cmd1 = string.Format("select * from localkeys where tabnameind={0}", TabInd);

            if (connection.OpenDataReader(Cmd1))
            {
                DBAccess w_connection = new DBAccess();
                w_connection.Connect(true, dbname);
                while (connection.SQLDR.Read())
                {
                    string idikey = connection.SQLDR["Idikey"].ToString().TrimEnd();
                    string cmpkey = connection.SQLDR["cmpkey"].ToString().TrimEnd();
                    string xmlset = connection.SQLDR["xmlset"].ToString().TrimEnd();
                    string compexpression = connection.SQLDR["compexpression"].ToString().TrimEnd();
                    string include = connection.SQLDR["Include"].ToString().TrimEnd();
                    Cmd = string.Format("INSERT INTO localkeys (tabnameind, IdiKey, cmpkey,xmlset,compexpression,include) values ({0}, '{1}', '{2}', '{3}', '{4}', '{5}')", Pk, idikey, cmpkey, xmlset, compexpression, include);
                    try
                    {
                        w_connection.Execute(Cmd, true);
                    }
                    catch (Exception ex) { throw ex; }
                }
                Cmd = string.Format("update LocalKeyName set UpdTime='{0}'  where pk={1}", DateTime.Now, Pk);
                w_connection.Execute(Cmd, true);
                connection.CloseDataReader();
                connection.DisConnect();
                w_connection.DisConnect();
            }
            FillBatch();
        }

        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = DataGrid1.Templates[templateIndex].Container.FindControl(controlId);

            return ctrl.ClientID;
        }


        protected void OnGridRowCreated(object sender, GridRowEventArgs args)
        {
            //DataGrid1.Columns[1].ReadOnly = false;
            // gets called before a row created. It stop each time the row is populated from DB not used
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }

        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {
            //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
            //  when user chooses a mid /trn to show all diff for selected ref
            m_key = KeyIdsDropdown.SelectedValue.TrimEnd();
            string Cmd = string.Format("select * from LocalKeyName where pk={0}", m_key);
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            try
            {
                if (Connection.OpenDataReader(Cmd))
                {
                    while (Connection.SQLDR.Read())
                    {
                        Box1.Text = Connection.SQLDR["TabDesc"].ToString().TrimEnd();
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
            DataGrid1.Visible = true;
            Excel.Visible = true;
            DelTable.Visible = true;
            BindDataGrid();
        }

        protected void BindDataGrid()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            Connection.Connect(false, dbname);
            string Cmd = string.Format("select * from LocalKeys where TabNameInd = '{0}' order by pk desc", m_key);
            try
            {
                DataSet ds = Connection.getDataSet(Cmd);
                DataGrid1.DataSource = ds;
                DataGrid1.DataBind();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                Connection.DisConnect();
            }
        }


        public void DataGrid_Edit(Object sender, GridRecordEventArgs e)
        {
            string UniqueKey, IdiKey, CmpKey, XmlSet, CompExpression, Include, TabInd;

            UniqueKey = e.Record["Pk"].ToString();
            TabInd = e.Record["TabNameInd"].ToString();
            IdiKey = e.Record["IdiKey"].ToString();
            CmpKey = e.Record["CmpKey"].ToString();
            XmlSet = e.Record["XmlSet"].ToString();
            CompExpression = e.Record["CompExpression"].ToString();
            Include = e.Record["Include"].ToString();

            string Cmd = string.Format("update LocalKeys set IdiKey='{0}',CmpKey='{1}',XmlSet='{2}',CompExpression='{3}',Include='{4}' " +
                       " where Pk='{5}'",
                       IdiKey, CmpKey, XmlSet, CompExpression, Include, UniqueKey);
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);
            connection.Execute(Cmd, true);
            Cmd = string.Format("update LocalKeyName set UpdTime='{0}'  where pk={1}", DateTime.Now, TabInd);
            connection.Execute(Cmd, true);


            BindDataGrid();
        }

        public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
        {
            //        DataGrid1.EditItemIndex = -1;
            BindDataGrid();
        }

        public void DataGrid_Insert(object source, GridRecordEventArgs e)
        {
            string Tabnameind, IdiKey, CmpKey, XmlSet, CompExpression, Include;
            Tabnameind = m_key;
            IdiKey = e.Record["IdiKey"].ToString();
            CmpKey = e.Record["CmpKey"].ToString();
            XmlSet = e.Record["XmlSet"].ToString();
            CompExpression = e.Record["CompExpression"].ToString();
            Include = e.Record["Include"].ToString();

            string Cmd = string.Format("insert into LocalKeys (Tabnameind,IdiKey,CmpKey,XmlSet,CompExpression,Include)" +
                    " values ({0},'{1}','{2}','{3}','{4}','{5}')",
                    Tabnameind, IdiKey, CmpKey, XmlSet, CompExpression, Include);
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                Connection.Execute(Cmd, true);
                Cmd = string.Format("update LocalKeyName set UpdTime='{0}'  where pk={1}", DateTime.Now, Tabnameind);
                Connection.Execute(Cmd, true);
                BindDataGrid();

            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                Connection.DisConnect();
                Connection.Dispose();
            }
        }

        public void DataGrid_Delete(object source, GridRecordEventArgs e)
        {
            string UniqueKey = "";
            try
            {
                UniqueKey = (e.Record["Pk"].ToString());
            }
            catch
            {
            }
            String Cmd = "delete from LocalKeys where Pk=" + UniqueKey;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, dbname);
                Connection.Execute(Cmd, true);
                //                DataGrid1.EditItemIndex = -1;
                BindDataGrid();
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                Connection.DisConnect();
                Connection.Dispose();
            }
        }
    }
}