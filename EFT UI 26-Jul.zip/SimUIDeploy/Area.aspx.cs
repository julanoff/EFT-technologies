//===========================================================================
// This file was modified as part of an ASP.NET 2.0 Web project conversion.
// The class name was changed and the class modified to inherit from the abstract base class 
// in file 'App_Code\Migrated\Stub_Area_aspx_cs.cs'.
// During runtime, this allows other classes in your web application to bind and access 
// the code-behind page using the abstract base class.
// The associated content page 'Area.aspx' was also modified to refer to the new class name.
// For more information on this code pattern, please refer to http://go.microsoft.com/fwlink/?LinkId=46995 
//===========================================================================
/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;

/// <summary>
/// Summary description for Area.
/// </summary>
/// 
public partial class Area : System.Web.UI.Page
{

    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DBAccess connection = new DBAccess();
            try
            {
                connection.Connect(false, "Master");
                String Cmd = "select AreaName from Areas";
                if (connection.OpenDataReader(Cmd))
                {
                    AreaList.DataSource = connection.SQLDR;
                    AreaList.DataTextField = "AreaName";
                    AreaList.DataValueField = "AreaName";
                    AreaList.DataBind();
                }
            }
            catch (Exception exp) { throw exp; }
            finally
            {
                connection.DisConnect();
            }
        }
        String _timeout = "";
        try
        {
            _timeout = (String)HttpContext.Current.Session["_timeout"];
        }
        catch { }
        if (_timeout == "Y")
        {
            LbTimeout.ForeColor = Color.Red;
            LbTimeout.BackColor = Color.White;
            LbTimeout.Visible = true;
            Session["_timeout"] = "N";
        }
        else
        {
            LbTimeout.Visible = false;
        }
    }

    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
        //
        // CODEGEN: This call is required by the ASP.NET Web Form Designer.
        //
        InitializeComponent();
        base.OnInit(e);
    }

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {

    }
    #endregion


    protected void SetAreaButton_Click(object sender, System.EventArgs e)
    {
        string vendor = "ACI";
        string client = "";
        Session["CurrentDB"] = AreaList.SelectedItem.Value.TrimEnd();
        Session.Timeout = 60;

        string area = AreaList.SelectedItem.Value.TrimEnd();
        DBAccess connection = new DBAccess();
        try
        {
            connection.Connect(false, AreaList.SelectedItem.Value.TrimEnd());
            String Cmd = "select vendor, client from SimulatorControl";
            if (connection.OpenDataReader(Cmd))
            {
                if (connection.SQLDR.Read())
                {
                    /*
                     * Set the vendor uppercase so we're immune to the case of what was entered in the sql field.
                     */ 
                    vendor = connection.SQLDR.GetString(0).ToUpper();
                    /*
                     * BBT setup cya. We ended up with a Sim control table with a blank vendor.
                     * So, if we get an empty string back from the query, let's plug in ACI. On
                     * 2nd thought, let's check for FT or ACI and if neither, plug in ACI ...
                     */ 
                    vendor = vendor.Trim();
                    if (vendor.Equals("ACI") || vendor.Equals("FT"))
                    { }
                    else
                    {
                        vendor = "ACI";
                    }

                    client = connection.SQLDR.GetString(1);
                }
            }
        }
        catch (Exception exp) { throw exp; }
        finally
        {
            connection.DisConnect();
        }

        Session["vendor"] = vendor;
        Session["client"] = client;
        MasterPage mp = (MasterPage)Page.Master;
        mp.taskMenuVisible = true;
        mp.setMenuForVendor();
        //	Response.Write("<script language=\"JavaScript\">parent.topframe.location = \"TopFrame.aspx\"</script>");		
        //	Response.Write("<script language=\"JavaScript\">parent.bottom.location = \"Actions.aspx\"</script>");							
    }
}
