using System;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace SwfClient
{
	public class SwfClient
	{
		//[DllImport("c:\\simulator\\allbin\\Des.dll", EntryPoint="des_pr", CharSet = CharSet.Auto)]
// It should look in the current dir from where this app is launched.
		[DllImport("Des.dll", EntryPoint="des_pr", CharSet = CharSet.Auto)]
		public static extern int des_pr([MarshalAs(UnmanagedType.LPArray)] byte[] m_drv, [MarshalAs(UnmanagedType.LPArray)] byte[] m_pass);

		byte[]  m_pass = new byte[200];
		byte[]  m_drv = new byte[2];

		[STAThread]
		static void Main(string[] args)
		{
			SwfClient cln = new SwfClient();
			cln.dorcv(args);
		}
		private void dorcv(string[] args)
		{
			Console.WriteLine ("TESTING DES DLL LOADING.");
			m_pass = System.Text.Encoding.ASCII.GetBytes("marina12345678901234567890123456");
			m_drv = System.Text.Encoding.ASCII.GetBytes("c:");
			des_pr(m_drv, m_pass);	// pass is a key that is created from LAU data. Do it once per session.
			Console.WriteLine( "\nGood!");
			string hex = BitConverter.ToString(m_pass);
			Console.WriteLine (" pas - " + hex);
			Console.WriteLine ("     ");
			Console.WriteLine ("     ");
			string serverIP = "localhost";
			Console.WriteLine ("TESTING DHS TRANSLATION. NAME - "+serverIP);
			IPHostEntry hostInfo = Dns.GetHostEntry(serverIP);
			IPAddress[] address = hostInfo.AddressList;
			string m_serverIP=address[0].ToString();
			if (m_serverIP != "")
			{
				Console.WriteLine ("Good translation " + m_serverIP);
				return;
			}
			Console.WriteLine ("     ");
			serverIP = "QW-EFTISS01"; //CHECK IF IT IS FINE!!!
			Console.WriteLine ("TESTING DHS TRANSLATION. NAME - "+serverIP);
			hostInfo = Dns.GetHostEntry(serverIP);
			address = hostInfo.AddressList;
			m_serverIP=address[0].ToString();
			if (m_serverIP != "")
			{
				Console.WriteLine ("Good translation " + m_serverIP);
				return;
			}

		}
	}
}