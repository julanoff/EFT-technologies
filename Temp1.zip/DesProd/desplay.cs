/*                                                              
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
 
 28-Nov-15    JR  Synch code between Jacob and John
 
 
*/
using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace DesPlay
{
	/// <summary>
	/// Summary description for mqputmsg.
	/// </summary>
	public class DesPlay
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[DllImport("f:\\desprod\\Des.dll", EntryPoint="des_pr", CharSet = CharSet.Auto)]
		public static extern int des_pr([MarshalAs(UnmanagedType.LPArray)] byte[] pass);

		[STAThread]
		static void Main(string[] args)
		{
			DesPlay desplay = new DesPlay();
			desplay.Run(args);
		}

		private int Run(string [] args)
		{
			byte[] pass = new byte[200];
			pass=System.Text.Encoding.ASCII.GetBytes("marina12345678901234567890123456");

			des_pr(pass);

			//for (int i=0; i < 32; i++)
			//{
			//	Console.WriteLine(string.Format("{0} - {1:x2} \n",i, (pass[i])));
			//}

	string clearText = 
	"<?xml version=\"1.0\"?><SwInt:SendRequest><SwSec:AuthorisationContext><SwSec:UserDN>cn=fin-irvtgb2" +
	"x-t1,o=irvtgb2x,o=swift</SwSec:UserDN></SwSec:AuthorisationContext><SwInt:Request><SwInt:Request" +
	"Control><SwInt:NRIndicator>FALSE</SwInt:NRIndicator><SwInt:RequestCrypto>FALSE</SwInt:RequestCrypto>" +
	"<SwInt:DeliveryCtrl><SwInt:SNLEP>MTS_IRVTGB20B</SwInt:SNLEP></SwInt:DeliveryCtrl></SwInt:RequestControl>" +
	"<SwInt:RequestHeader><SwInt:Requestor>cn=fin-irvtgb2x-t1,o=irvtgb2x,o=swift</SwInt:Requestor>" +
	"<SwInt:Responder>cn=fb65,cn=fin,o=swift,o=swift</SwInt:Responder><SwInt:Service>swift.fin</SwInt:Service>" +
	"<SwInt:RequestType>DATA</SwInt:RequestType><SwInt:RequestRef>" +
	"010025F21IRVTGB20BXXX0542077556025F21IRVTGB20BAMS0542077557025F21IRVTGB20BAMS0542077" +
	"558025F21IRVTGB20BAMS0542077559025F21IRVTGB20BAMS0542077560025F21IRVTGB20BAMS0542077" +
	"561025F21IRVTGB20BAMS0542077562025F21IRVTGB20BAMS0542077563025F21IRVTGB20BAMS0542077" +
	"564025F21IRVTGB20BAMS0542077565" +
	"</SwInt:RequestRef></SwInt:RequestHeader><SwInt:RequestPayload><SenderRef>IRVTGB20B0312150042</SenderRef>" +
	"<ReceiverRef>12053484425620080308</ReceiverRef><SequenceNo>000003</SequenceNo><Data>" +
	"<![CDATA[000056{1:F21IRVTGB20BXXX0542077556}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077557}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077558}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077559}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077560}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077561}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077562}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077563}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077564}{4:{177:0803121502}{451:0}}" +
	"000056{1:F21IRVTGB20BAMS0542077565}{4:{177:0803121502}{451:0}}]]>" +
	"</Data></SwInt:RequestPayload></SwInt:Request></SwInt:SendRequest>\0";

			Console.Write ("length = " + clearText.Length + "\n");
		        byte[] MessageBytes = System.Text.Encoding.ASCII.GetBytes(clearText);
		        //byte[] key = System.Text.Encoding.ASCII.GetBytes(pass);
		        HMACSHA256 myhmacsha256 = new HMACSHA256(pass);
        		byte[] hashValue = myhmacsha256.ComputeHash(MessageBytes);
    			StringBuilder strHex = new StringBuilder();
    			foreach (byte b in hashValue)
    			        strHex.Append(String.Format("{0:x2}", b));
    			Console.WriteLine(strHex);
    			Console.WriteLine("\n" + System.Text.Encoding.ASCII.GetString(hashValue));
    			

			string key1 = "Jefe";
			clearText = "what do ya want for nothing?";
			MessageBytes = System.Text.Encoding.ASCII.GetBytes(clearText);
			byte[] key = System.Text.Encoding.ASCII.GetBytes(key1);
			myhmacsha256 = new HMACSHA256(key);
			hashValue = myhmacsha256.ComputeHash(MessageBytes);
			strHex = new StringBuilder();
			foreach (byte b in hashValue)
			        strHex.Append(String.Format("{0:x2}", b));
    			Console.WriteLine("\n" + strHex);
			return (0);
		}
	}
}