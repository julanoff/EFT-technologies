#include <sys/types.h>
#include <sys/stat.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <des.h>
#include <windows.h>

void main() {

unsigned char pass[100];

{
	  typedef struct
	  {
	    des_cblock hi;
	    des_cblock lo;
	  } desKey;
	  des_cblock *KeyIn;
	  des_cblock *KeyOut;

	  des_key_schedule localKeySchedHi;
	  des_key_schedule localKeySchedLo;

	  desKey localKey;
	  char key1[11];
	  int i;
	  int iCount;
	  int iStrCryptLen;
	  size_t szFileLength;
	  char *pxStrCrypt = NULL;
	  char Rec[400];
	  char *px;
	  char *pxszStrCrypt = NULL;
	  FILE *iSecretFile = fopen("c:\\simulator\\laukey.dat", "r");
        	if (iSecretFile)
        	{	printf ("file here\n");
        	}
        	else
			{
				printf ("LAU not found.\n");
				return;
			}
			szFileLength = fread(Rec, sizeof(char), 400, iSecretFile);
  	  		fclose(iSecretFile);

			for ( px = Rec; px < (Rec + szFileLength); px++ )
    		{
		      if ( !strncmp( px, "Length=", 7 ))
		        pxszStrCrypt = (px + 7);
		      if ( !strncmp( px, "EncryptedData=", 14 ))
		        pxStrCrypt = (px + 14);
		    }
			px = memchr(pxszStrCrypt, '\n', 4);
			if (!(NULL == px))
		    {
		      *px = '\0';
		      iStrCryptLen = atoi( pxszStrCrypt );
		    }
			else
				printf ("error in size.\n");

			strcpy(key1, "MasterKey12");
			des_string_to_2keys(key1, &(localKey.hi), &(localKey.lo));

			if (i = des_set_key(&localKey.lo, localKeySchedLo))
				printf ("1st call to des_set_key failed.\n");


			if (i = des_set_key(&localKey.hi, localKeySchedHi))
				printf ("2nd call to des_set_key failed.\n");

			memset(&localKey, '\0', sizeof(localKey));

			KeyIn = (des_cblock*)pxStrCrypt;
			KeyOut = (des_cblock*)pass;

			for (iCount = 0; iCount < iStrCryptLen; iCount += DES_KEY_SZ)
		    {
		       des_ecb3_encrypt(KeyIn, KeyOut,
                        localKeySchedHi, localKeySchedLo, localKeySchedHi,
                        DES_DECRYPT);
		       KeyIn++;
		       KeyOut++;
		    }
			for (i=0;i<32;i++) {
    			printf("%02X ", pass[i]);
			    if ((i%16==0) && i)
			      printf("\n");
			  }
			return ;
	}
}
