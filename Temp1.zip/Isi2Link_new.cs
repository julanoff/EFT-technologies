/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
 * 
 * 
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 
*/
using System;
using System.IO;
using System.Text;
using System.Collections;
using Simulator.DBLibrary;
using System.Net;
using System.Net.Sockets;
using Simulator.BackEndSubLib;
using Simulator.QueueInterface;
using Simulator.Interfaces;
using Simulator.MQClass;
using Simulator.TcpIp;

/*
 * This is the ISI2 Link.
 * 
 * J.Richardson		09-Aug-05. Don't trim the end of the data when pulling it out
 *					of the database. That ends up stripping off the trailing 
 *					carriage return and causes the MTS side of the house to hang
 *					waiting for the msg to end.
 *					The get_next_msg call was screwed up in being able to tell
 *					when there was nothing more on queue. I'll have it take a
 *					2 second nap when the table's empty before looking again.
 * 17-Aug-05	JR	Search for the LinkSeqNo explicitly rather than relying on it.
 *					being in a particular place in the table.
 
	24-Aug-05	JR	SwiftCheck DLA's have a spot in the body of the msg where we have to
					insert the SeqNo. Look for that.
	02-Sep-05	JR	Watch out for multi-block msgs. Don't crank up the sequence number in
					that case.
	07-Sep-05	JR	Long story ... bottom line is that the calculation of the length of the
					text (apparently only in multi-block msgs) is sometimes off. To be honest,
					I'm not 100% sure what's going on up in the feeder. Most of the time it
					gets it right, but not always. The multi-block ones that are causing
					trouble are 700's if that's of any help. So, screw it, let's do some
					sanity checking in here to ensure that we get the data length correct.
					If not, the other side goes down, boom, being unable to parse the ISI2
					header since we're telling it a lie about where the header's located.
	08-Sep-05	JR	Watch out for single quotes inbound from WTX.
	22-Sep-05	JR	A slew of changes. Among other things, the whole receive side has
					been re-written to support multi-block msgs and multi-msg buffers. The
					annoying part is that they don't necessarily send a complete Isi2 header;
					it could span from one read to the next. Oh well.
					The send side seems to tolerate (and format) multi-block traffic, too.
	13-Oct-05	JR	This includes Dave's QI routine. I just finished testing this at BofA 
					today and it seems to behave itself. This code does *not* include the
					attempt to read complete msg blocks being sent from MTS. I basically
					couldn't get that to work 100% of the time today, so I've reverted
					to this version.
	28-Oct-05	JR	Watch out for the link sequence number going above 999999; reset it 
					to 1 if that happens.
 * 
 * 30-Dec-06    JR  Twiddle with the way we log things. I've now got 3 levels of debug,
 *                  the idea being that the lowest level will just show the bare-bones steps
 *                  in the process, the highest level will dump buffers and all that crap, and
 *                  the medium level is somewhere in between those two extremes. This is stored
 *                  in the P1 param in the linkcontrol table. 'DEBUG', 'DEBUG-MEDIUM', 'DEBUG-HIGH'
 *                  are the strings to put in there ...
 *
 *  2-Jan-07    JR  I'm testing the rgw line into us. The ISI2 data header coming into us from WTX isn't
 *                  the same as it used to be. Is this just for RGW or is this across the board
 *                  for traffic coming to us? Stay tuned. I suspect it's just RGW, but I don't know
 *                  that yet; will have to test some of the other links into us.
 * 
 *                  The new one looks like this:
 *          1         2         3         4         5
 * 12345678901234567890123456789012345678901234567890
 * DS      00057607002900361854057607    003999         <---- This is the isi2 header.      
 *           ||||||  ||||||||||||||||
 *             |   **    sender ref  ****
 *            seq   |                    ||||||
 * 	       interblock              length of what's left...
 * 
 *              Bottom line, I'm going to have to start supporting different versions of the isi2
 *              header. By default I'll have the constructor pick version 1. This can be overridden
 *              by looking at the line name (or any other crazy criteria we come up with).
 * 
 *              Fortunately, it appears that the only thing that's changed are that the isi2 header
 *              itself has more info in it and some of the fields have moved. Luckily nothing else in
 *              the msg appears different. Stay tuned ...
 * 
 * 3/9/2007     JN  Add support from MQ.
 * 8/7/2007	JN&DM	Use sync2 library.
 *		NOTE: the message bundling up is taken care by the Feeder. It creates a blob with # of msgs=NumberSel(linkcontrol table).
 *
*/
namespace Isi2Link
{
    class Isi2Link
    {
        private string LineName;
        private string SndRcv;
        private string dbCmd;
        private String LnkBuf;
        private StringBuilder Lbuf;
        private StringBuilder ResponseBuf;
        private string AckBuf;
        private StringBuilder temp;
        private int stat;
        private string SeqNoString;

        private DBAccess dbReader;
        private DBAccess dbWriter;
        private bool dbConnected;

        private string LastTrn;
        private string ThisTrn;
        private int LinkSeqNo;
        private int ptr;
        private int ptr1;
        private string scratch;
        private int RcvBlockNo;
        private int nCharsRead;
        private int LinkMsgId;
        private int LinkPriority;
        private const int FlagsStart = 0;
        private const int SeqStart = 7;
        private const int RefStart = 16;
        private const int DatalenStart = 32;
        private const int _lengthLength = 4;
        private const int _lengthOffset = 32;
        private string Isi2Hdr;
        private string HostAddress;
        private string MTSHostName;
        private string Area;
        private string Debug;
        private int PortNumber, TimeDelay;
        private int LastSeqPtr;
        int cdqPtr;
        string OrigTrn;
        private int isi2Version;
        private int isi2HdrLength;
        private string Transport = "IP";
        private string MqRead;
        private string MqWrite;
        private string MqManager;
        private string m_channel;
        private bool MQConnected = false;
        private SynchInterface m_transportConnection;		// interface to mq/ip classes

        int nCharThisBlock, nLeftThisBuf;
        int nLeftThisBlock;

        char[] buffer;

        private StreamWriter LogStream;
        private BackEndSubs util;
        string myProcName;

        int TheirSeq;
        int retValue;
        bool PeekFoundSomething;
        //        int PeekStat;
        int ConnectCtr;

        string AckFileName;
        Hashtable AckTable;
        string InboundSeqNo;
        string LastCompleteInboundSeqNo;
        int dbg;
        int nPassThruBuffer;
        QueueInterface m_Qi;

        const int noDebug = 0;
        const int dbgLow = 1;
        const int dbgMed = 3;
        const int dbgHigh = 5;

        enum RcvState
        {
            unknown = 0,
            SingleBlock = 1,
            SingleBlockInProgress = 2,
            MultiBlock = 3,
            MultiBlockInProgress = 4,
            MultiBlockLastBlock = 5,
            SingleBlockComplete = 6,
            ResynchReq = 7,
            DownReq = 8,
            KeepAlive = 9,
            MsgComplete = 10,
            MultiBlockLastBlockInProgress = 11,
            MsgCompleteNotAckd = 12,
        }
        StringBuilder rcvMsg;
        RcvState rState;
        string HdrFragment;
        bool IncompleteIsiHdr;


        // some stuff to calculate the xmit rate ...
        int msgctr;
        long d1tick;
        long d2tick;
        long delta;
        float xmsg;
        float msgsec;

        public Isi2Link()
        {
            ResponseBuf = new StringBuilder();
            temp = new StringBuilder();
            dbReader = new DBAccess();
            dbWriter = new DBAccess();
            dbConnected = false;
            Lbuf = new StringBuilder();
            buffer = new char[20000];
            util = new BackEndSubs();
            rcvMsg = new StringBuilder();
            isi2Version = 1;
            isi2HdrLength = 36;
        }

        [STAThread]
        static void Main(string[] args)
        {
            Isi2Link lnk = new Isi2Link();
            lnk.StartLink(args);
        }

        private void StartLink(string[] args)
        {
            Area = args[0];
            LineName = args[1];
            SndRcv = args[2];
            if (!dbConnected)
            {
                dbReader.Connect(false, Area);
                dbWriter.Connect(true, Area);
                dbConnected = true;
                int NumberofQueueItemstoCache = 10;
                m_Qi = new QueueInterface("LNK_" + LineName, NumberofQueueItemstoCache, Area);
            }

            myProcName = "ISI2_" + LineName;
            string filename = string.Format("{0}{1}_{2}.log", util.GetLogDir(dbReader), myProcName,
                util.GetTimestampTag());
            FileStream file1 = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);
            LogStream = new StreamWriter(file1);

            CommInfo();


            if (SndRcv == "S")
                DoSendSide();
            if (SndRcv == "R")
                DoRcvSide();
        }

        private void DoSendSide()
        {
            if (Transport == "IP")
                DoSendSideIP();
            else
                DoSendSideMQ();
        }

        private void DoSendSideMQ()
        {
            if (!dbConnected)
            {
                dbReader.Connect(false, Area);
                dbWriter.Connect(true, Area);
                dbConnected = true;
            }
            LogIt("  *****", dbgLow);
            //LogInfo("Start the send side");
            LogIt("start the send side", dbgLow);
            ConnectCtr = 0;
            ConnectMQ("O");

            msgctr = 0;
            DateTime d1 = new DateTime();
            DateTime d2 = new DateTime();

            while (true)
            {
                if (getNextMsg() == 0)
                {
                    System.Threading.Thread.Sleep(4000);
                    continue;
                }
                if (msgctr == 0)
                {
                    d1 = DateTime.Now;
                }
                InsertSeqNo();


                LogIt(string.Format("WriteData {0} bytes", LnkBuf.Length), dbgHigh);
                LogIt(LnkBuf, dbgHigh);

                //                    stat = WriteData(netWriter, ref LnkBuf);
                stat = WriteData(ref LnkBuf);
                if ((stat < 0) || (LnkBuf.Length <= 0))
                {
                    LogIt(string.Format("WriteData failure inside the main loop, Stat:{0} Len:{1}", stat, LnkBuf.Length), dbgLow);
                    LogError(string.Format("MQ Write Failed, Stat:{0} Len:{1}", stat, LnkBuf.Length));
                    return;
                }
                delete_link_item(LinkMsgId, LinkPriority);
                update_resynch_info(ThisTrn);
                msgctr++;
                if ((msgctr % 100) == 0)
                {
                    d2 = DateTime.Now;
                    d1tick = d1.Ticks;
                    d2tick = d2.Ticks;
                    delta = (d2tick - d1tick) / 10000;
                    xmsg = (float)delta / (float)msgctr;
                    msgsec = ((float)delta / xmsg) * ((float)1000.0 / (float)delta);
                    string tmp = string.Format("{0} msgs in {1} milliseconds = {2} msec/msg = {3} msg/sec",
                        msgctr, delta, xmsg, msgsec);
                    LogIt(tmp, dbgLow);
                    msgctr = 0;
                }
            }
        }

        private void DoSendSideIP()
        {
            if (!dbConnected)
            {
                dbReader.Connect(false, Area);
                dbWriter.Connect(true, Area);
                dbConnected = true;
            }
            LogIt("  *****", dbgLow);
            //LogInfo("Start the send side");
            LogIt("start the send side", dbgLow);
            ConnectCtr = 0;
            m_transportConnection = new IPSync2(SynchInterface.Type.Client, MTSHostName, PortNumber);
            m_transportConnection.setReadAttributes(_lengthOffset, _lengthLength, 36, false);

            ConnectPort();

            msgctr = 0;
            DateTime d1 = new DateTime();
            DateTime d2 = new DateTime();

            //
            // We're the sender. Start off with a resynch msg.
            //
            //            stat = do_resynch(netReader, netWriter);
            stat = do_resynch();
            LogIt(string.Format("   1st Resynch: Status {0}", stat), dbgLow);
            if (stat == -666)
            {
                // Wtx will have knocked down the port. Wait for it to
                // come back. Take a nap first to let things calm down.

                //               netReader.Close();
                //               netWriter.Close();
                m_transportConnection.DisConnect();
                System.Threading.Thread.Sleep(3000);
                LogIt("Connect port after bad resynch", dbgLow);
                ConnectPort();
            }

            if (stat < 0)
            {
                int i;
                LogInfo("Resynch failed for bad sequence. Fixed");
                LogIt("Resynch bad seq. Fixed to match theirs", dbgLow);
                //                i = do_resynch(netReader, netWriter);
                i = do_resynch();
                if (i == -666)
                    return;
            }

            while (true)
            {
                // Take a peek at the other side. If they've got something for
                // us - like some ack's that are queued up, let's get them.
                //
                // It's a nice idea and, in theory, this should work. However, back
                // in the real world we never seem to see anything the other side has
                // waiting for us. I never did get to the bottom of this; probably
                // never will. Too bad, it would have been handy because then we could
                // see a 'down' command they sent when we're in this loop
                PeekFoundSomething = false;
                //LogIt("Take a peek");

                // LogIt(string.Format("  Peek status {0}", PeekStat));
                /*
                if (dbg > 0)
                {
                    nCharsRead = netReader.Read(buffer, 0, 10000);
                    LogIt(string.Format("  Read {0} chars", nCharsRead), dbgLow);
                }
                 * */

                if (m_transportConnection.PeekRead())
                {
                    // Aha, something's waiting for us.
                    PeekFoundSomething = true;
                    LogIt("Peek found something. Read it.", dbgLow);
                }
                else
                {

                    //LogIt("Peek didn't find anything ... normal processing.", dbgLow);
                    if (getNextMsg() == 0)
                    {
                        System.Threading.Thread.Sleep(4000);
                        continue;
                    }
                    if (msgctr == 0)
                    {
                        d1 = DateTime.Now;
                    }
                    InsertSeqNo();


                    LogIt(string.Format("WriteData {0} bytes", LnkBuf.Length), dbgHigh);
                    LogIt(LnkBuf, dbgHigh);

                    if ((LnkBuf.Length % 1024) == 0)
                    {
                        // Twilight Zone time ... If we try to send a 1024-byte buffer,
                        // the write status on this side is good, but the read never
                        // completes on the receiver side. Whoa !!!!! Dunno if this is
                        // confined to just loopback stuff on my home machine here or whether
                        // this has been lurking, unseen, in talking to the real MTS box
                        // at the bank. Gotta fix it for the demos, if nothing else.
                        // Insert an extra space at the tail of the buffer and adust the
                        // length in the ISI2 header. Pain in the ass, what?

                        // More news from the Zone ... it's any multiple of 1024. Geez.
                        // And even *more* news, it doesn't happen when talking to the
                        // MTS test box tx2dwtx010 ... So, let's do this stuff when we're
                        // talking to ourselves.

                        if (MTSHostName.Equals("LOCALHOST"))
                        {
                            LnkBuf = LnkBuf.Insert(LnkBuf.Length - 2, " ");
                            string lString = LnkBuf.Substring(LastSeqPtr + 24, 4);
                            int newlen = Convert.ToInt16(lString);
                            newlen++;
                            lString = string.Format("{0:D4}", newlen);
                            LnkBuf = LnkBuf.Remove(LastSeqPtr + 24, 4);
                            LnkBuf = LnkBuf.Insert(LastSeqPtr + 24, lString);
                        }
                    }
                    //                 stat = WriteData(netWriter, ref LnkBuf);
                    stat = WriteData(ref LnkBuf);
                    if ((stat < 0) || (LnkBuf.Length <= 0))
                    {
                        LogIt(string.Format("WriteData failure inside the main loop, Stat:{0} Len:{1}",
                            stat, LnkBuf.Length), dbgLow);
                        m_transportConnection.DisConnect();
                        ConnectPort();
                        //                        stat = do_resynch(netReader, netWriter);
                        stat = do_resynch();
                    }
                    //LogInfo(string.Format("Sent: {0}", ThisTrn));
                    LogIt(string.Format("Sent buffer: {0} bytes, stat {1}",
                        LnkBuf.Length, stat), dbgHigh);
                    //LogIt(string.Format("Sent: {0}", ThisTrn));
                    msgctr++;
                    if ((msgctr % 100) == 0)
                    {
                        d2 = DateTime.Now;
                        d1tick = d1.Ticks;
                        d2tick = d2.Ticks;
                        delta = (d2tick - d1tick) / 10000;
                        xmsg = (float)delta / (float)msgctr;
                        msgsec = ((float)delta / xmsg) * ((float)1000.0 / (float)delta);
                        string tmp = string.Format("{0} msgs in {1} milliseconds = {2} msec/msg = {3} msg/sec",
                            msgctr, delta, xmsg, msgsec);
                        LogIt(tmp, dbgLow);
                        msgctr = 0;
                    }
                }

                LogIt("Read the response ", dbgMed);
                //                stat = ReadData(netReader, ref LnkBuf);
                stat = ReadData(ref LnkBuf);
                cdqPtr = LnkBuf.IndexOf("CDQ      ");
                if (cdqPtr > 0)
                    LogIt("Found buried CDQ.", dbgLow);
                if ((stat < 0) || (LnkBuf.Length <= 0))
                {
                    // So, what are we going to do about this? Stay tuned ..
                    LogIt(string.Format("ReadData failure inside the main loop, Stat:{0} Len:{1}",
                        stat, LnkBuf.Length), dbgLow);
                    m_transportConnection.DisConnect();
                    stat = ConnectPort();
                    //                    stat = do_resynch(netReader, netWriter);
                    stat = do_resynch();
                }

                if (LnkBuf.Substring(0, 2).Equals("CK"))
                {
                    // KeepAlive msg. Send it back
                    stat = WriteData(ref LnkBuf);

                }

                if (LnkBuf.Substring(0, 2).Equals("CA"))
                {
                    //
                    // Ack. Update the sequence number, etc.
                    //
                    ThisTrn = LnkBuf.Substring(16, 16);
                    if (dbg > 0)
                    {
                        LogIt(string.Format("Ack for {0}", ThisTrn), dbgMed);
                        LogIt("got ack", dbgHigh);
                        LogIt(LnkBuf, dbgHigh);
                    }
                    if (!PeekFoundSomething)
                        delete_link_item(LinkMsgId, LinkPriority);
                    update_resynch_info(ThisTrn);
                }

                if ((LnkBuf.Substring(0, 3).Equals("CDQ")) || (cdqPtr >= 0))
                {
                    LogInfo("Received ''down'' command");
                    LogIt("down command", dbgLow);
                    LogIt("   " + LnkBuf.Substring(0, LnkBuf.Length), dbgMed);
                    /*
                       Down.
                       Well ... we're looking for an ack at this point and
                       they sent us a 'down' msg. Judging from what I see the
                       other side doing, I take this to mean that this CDQ also
                       contains an implicit ACK, as well. Certainly when we
                       start back up after they issue an up, we come up out of
                       sequence. Fair enough ... let's bump our sequence number, too.
                       Stay tuned. I haven't quite got my mind around how the protocol's
                       supposed to work if they send a down command out of the blue
                       while we're sitting here waiting for a msg to deliver. The way
                       this sucker's written at the moment, it won't see their down
                       until we send something again. Clearly, the receipt of their
                       responses, etc, needs to run asynchronously - some day, anyway.
                     */
                    delete_link_item(LinkMsgId, LinkPriority);
                    update_resynch_info(OrigTrn);
                    LogIt("Connect the port", dbgLow);
                    // Hmmm, a little bit of a timing issue.
                    // Let's take a little nap to make sure the
                    // connection comes down. We seem to sail right thru
                    // this 'connectport' call in some situations.
                    //                    netReader.Close();
                    //                    netWriter.Close();
                    m_transportConnection.DisConnect();
                    System.Threading.Thread.Sleep(10000);
                    stat = ConnectPort();

                    //
                    // Send 'em another resynch msg ...
                    //
                    //                    stat = do_resynch(netReader, netWriter);
                    stat = do_resynch();
                    if (stat < 0)
                    {
                        LogInfo("Resynch failed for bad sequence. Fixed");
                        LogIt("Resynch failed for bad sequence. After Down cmd. Fixed", dbgLow);
                        //                        do_resynch(netReader, netWriter);
                        do_resynch();
                    }
                }
            }
        }

        private int InsertSeqNo()
        {
            int nLeft;
            int nexthdr;
            int msglenptr;
            int msglen, RealLen;

            while (true)
            {
                ptr = LnkBuf.IndexOf("??????");
                if (ptr < 0) break;
                // Look for the block number. If it's '00' bump the
                // sequence
                if (LnkBuf.Substring(ptr + 6, 2).Equals("00"))
                {
                    LinkSeqNo++;
                    if (LinkSeqNo > 999999)
                        LinkSeqNo = 1;
                }
                else
                {
                    scratch = LnkBuf.Substring(ptr + 6, 2);
                    if (dbg > 0)
                    {
                        LogIt("  multi-block msg. Don't bump sequence number.", dbgMed);
                        string tmps1 = string.Format("  block number: {0}", LnkBuf.Substring(ptr + 6, 2));
                        LogIt(tmps1, dbgMed);
                    }
                }
                SeqNoString = string.Format("{0:D6}", LinkSeqNo);
                LnkBuf = LnkBuf.Remove(ptr, 6);
                LnkBuf = LnkBuf.Insert(ptr, SeqNoString);
                LastSeqPtr = ptr;
                ptr += 8;
                OrigTrn = LnkBuf.Substring(ptr, 16);

                //
                // Hmmm ... gotta do some checking since the feeder is somehow getting out-foxed
                // on the length of these buffers. Empirical evidence shows that most of the
                // multi-block lengths were short by 1, so I changed the isi2format routine
                // to deal with that. Still, I've run into another one where the length is
                // 1 too long. Damn... So, let's check everybody at this point. If the length
                // is off, let's just fix it right here.
                //
                // First check is to make sure we're not overflowing the tail of the buffer.
                //
                msglenptr = ptr + 16;
                msglen = Convert.ToInt16(LnkBuf.Substring(msglenptr, 4));
                if (dbg > 0)
                {
                    string xyz = string.Format("  inserted seq number {0} {1}",
                        SeqNoString, OrigTrn);
                    string xxx = string.Format("   Length:{0}", msglen);
                    string zzz = xyz + xxx;
                    LogIt(zzz, dbgMed);
                }
                ptr += 20;								// now pointing to the start of the data ...
                RealLen = LnkBuf.Length - ptr;
                if (msglen > RealLen)
                {
                    // Msglen can't be longer than RealLen since RealLen is how
                    // much is left to the end of the buffer.
                    LnkBuf = LnkBuf.Remove(msglenptr, 4);
                    LnkBuf = LnkBuf.Insert(msglenptr, string.Format("{0:D4}", RealLen));
                    msglen = RealLen;
                    //LogIt(string.Format("Fixed multi-block length for trn {2} msglen: {0}, RealLen {1}", 
                    //	msglen, RealLen, OrigTrn));
                }
                //
                // The next check is to jump ahead to where we think the next ISI2 header
                // should be. Let's make sure we find one exactly there. If not, figure
                // out where it really is and adjust the length.
                //
                nexthdr = ptr + msglen;
                nLeft = LnkBuf.Length - nexthdr;
                if (nLeft > 0)
                {
                    scratch = LnkBuf.Substring(nexthdr, isi2HdrLength);
                    //
                    // Getting complicated ... The next header could start with
                    // DB, DS, DE, or Dspace.
                    //
                    if ((scratch.StartsWith("DB    ")) ||
                        (scratch.StartsWith("DS    ")) ||
                        (scratch.StartsWith("DE    ")) ||
                        (scratch.StartsWith("D     ")))
                    {
                        nLeft = nLeft;
                    }
                    else
                    {
                        // We're usually off by one, one way or another. There should
                        // be a header here somewhere. Trouble is, we may have overshot
                        // it. Let's look for the next string of ????'s and figure out
                        // where the start of the header is from there.
                        int p;
                        p = LnkBuf.IndexOf("??????", ptr);

                        p -= 8;
                        scratch = LnkBuf.Substring(p, 32);

                        RealLen = p - ptr;
                        //LogIt(string.Format("Fixed multi-block length for trn {2} msglen: {0}, RealLen {1}", 
                        //	msglen, RealLen, OrigTrn));
                        LnkBuf = LnkBuf.Remove(msglenptr, 4);
                        LnkBuf = LnkBuf.Insert(msglenptr, string.Format("{0:D4}", RealLen));
                    }
                }

                ptr = LnkBuf.IndexOf("!!!!!!");
                if (ptr > 0)
                {
                    LnkBuf = LnkBuf.Remove(ptr, 6);
                    LnkBuf = LnkBuf.Insert(ptr, SeqNoString);
                    LastSeqPtr = ptr;
                }
            }
            return 1;
        }


        private int getNextMsg()
        {
            LogIt("getNextMsg", dbgMed);
            QueueItem qi = m_Qi.getQueueItem();
            if (qi != null)
            {
                LnkBuf = qi.Text;
                LinkMsgId = qi.Qblid;
                LinkPriority = qi.Priority;
                ThisTrn = LnkBuf.Substring(16, 16);
                return (1);
            }
            return 0;
        }

        private void delete_link_item(int id, int Prio)
        {
            dbCmd = string.Format("delete from LNK_{0} where Prio='{1}' and Qbl = {2}", LineName, Prio, id);
            dbWriter.Execute(dbCmd, false);
        }


        //        private int do_resynch(StreamReader netReader, StreamWriter netWriter)
        private int do_resynch()
        {
            int ReadResynchStat, AnalyzeResynchStat;
            retValue = 1;
            while (true)
            {
                SendResynch();
                ReadResynchStat = ReadResynchResponse();
                if (ReadResynchStat < 1)
                {
                    LogIt(string.Format("   ReadResynchStat: {0} Into ConnectPort", ReadResynchStat), dbgLow);
                    //if (SndRcv == "S")
                    // {
                    //	System.Threading.Thread.Sleep (5000);
                    //	LogIt("   Into ConnectPort on bad ReadResynchStat");
                    //	ConnectPort();
                    // }
                }
                else
                {
                    AnalyzeResynchStat = AnalyzeResynchResponse();
                    if (AnalyzeResynchStat > 0)
                        break;
                }
                if (SndRcv == "S")
                {
                    LogIt("   Into ConnectPort at the bottom of the loop", dbgLow);
                    System.Threading.Thread.Sleep(5000);
                    m_transportConnection.DisConnect();
                    ConnectPort();
                }
            }
            return 1;
        }

        private void SendResynch()
        {
            //sprintf(lcb->buffer, "CRQ     00000100ISI2 inbound $$$0048");
            //build_isi2_resynch_hdr(lcb);
            /*
                               123456789012345678901234567890123456789012345678
            */
            //strcat(lcb->buffer, "1                SL       20050524              ");

            // scratch = string.Format("CRQ     00000100050509062471CNF 0048" +
            //	"1                SL       20050524              ");
            //LogInfo("SendResynch");
            get_resynch_info();
            SeqNoString = string.Format("{0:D6}", LinkSeqNo);
            temp.Length = 0;
            temp.Append(LastTrn.Substring(2, 6));
            temp.Append(LastTrn.Substring(10, 6));

            LnkBuf = string.Format("CRQ     {0}00{1}CNF 0048" +
                "1                SL       20050524              ",
                SeqNoString, temp);
            SeqNoString = string.Format("{0:D6}", LinkSeqNo);
            temp.Length = 0;
            temp.Append(LastTrn);
            LnkBuf = string.Format("CRQ     {0}00{1}0048" +
                "1                SL       20050524              ",
                SeqNoString, temp);

            //            stat = WriteData(netWriter, ref LnkBuf);
            stat = WriteData(ref LnkBuf);
            LogIt(string.Format("   resynch sent: {0}", LnkBuf), dbgLow);
        }

        private int ReadResynchResponse()
        {
            LogIt("ReadResynchResponse", dbgLow);
            stat = ReadData(ref LnkBuf);
            //            stat = ReadData(netReader, ref LnkBuf);
            LogIt(string.Format("   Resynch ReadData Status:{0} buf:{1})", stat, LnkBuf), dbgLow);
            if (stat < 1) return stat;
            if (LnkBuf.Length <= 0) return -1;
            return 1;
        }

        private int AnalyzeResynchResponse()
        {
            LogIt("AnalyzeResynchResponse", dbgLow);
            if (LnkBuf.Length < isi2HdrLength)
                return -1;

            retValue = 1;

            if (LnkBuf[61].Equals("X"))
                retValue = -1;

            /*
                Let's see what the other side thought about our sequence number.
                If we don't match, fix our side to match theirs.
            */
            ptr = LnkBuf.IndexOf("out-of-range");
            if (ptr >= 0)
            {
                if (dbg > 0)
                {
                    LogIt("   out-of-range", dbgLow);
                    LogIt(LnkBuf, dbgHigh);
                }

                ptr = LnkBuf.IndexOf("lower bound=");
                if (ptr > 0)
                {
                    scratch = string.Format("lower bound=");
                    ptr += scratch.Length;
                    //ptr1 = ptr;
                    ptr1 = LnkBuf.IndexOf(";", ptr);
                    scratch = LnkBuf.Substring(ptr, ptr1 - ptr);
                    LinkSeqNo = Convert.ToInt32(LnkBuf.Substring(ptr, ptr1 - ptr));
                    LogInfo(string.Format("Resynch out of range. Set to their value {0}",
                        LinkSeqNo));
                    LogIt(string.Format("   Resynch: new sequence set to Lower Bound {0}", LinkSeqNo), dbgLow);
                    update_resynch_info(LastTrn);
                    retValue = -1;
                }
                else
                {
                    ptr = LnkBuf.IndexOf("upper bound=");
                    if (ptr > 0)
                    {
                        scratch = string.Format("upper bound=");
                        ptr += scratch.Length;
                        scratch = LnkBuf.Substring(ptr, LnkBuf.Length - 1 - ptr);
                        LinkSeqNo = Convert.ToInt32(LnkBuf.Substring(ptr, LnkBuf.Length - 1 - ptr));
                        LogInfo(string.Format("Resynch out of range. Set to their value {0}",
                            LinkSeqNo));
                        LogIt(string.Format("   Resynch: new sequence set to Upper Bound {0}", LinkSeqNo), dbgLow);
                        update_resynch_info(LastTrn);
                        retValue = -1;
                    }
                }
            }
            scratch = LnkBuf.Substring(16, 16);
            if (!scratch.Equals(LastTrn))
            {
                LogIt(string.Format("   ref mismatch: {0}/{1}", scratch, LastTrn), dbgLow);
                LastTrn = scratch;
                update_resynch_info(LastTrn);
                retValue = -1;
            }

            scratch = LnkBuf.Substring(8, 6);
            TheirSeq = Convert.ToInt32(scratch);
            if (TheirSeq != LinkSeqNo)
            {
                LinkSeqNo = TheirSeq;
                update_resynch_info(LastTrn);
                LogIt(string.Format("   Mismatch on their seq. Set to {0}", TheirSeq), dbgLow);
                retValue = -666;
                retValue = -1;
            }
            return (retValue);
        }

        private int get_resynch_info()
        {
            dbCmd = string.Format("select * from LinkControl where LineName = '{0}'",
                LineName);
            dbReader.CloseDataReader();
            dbReader.OpenDataReader(dbCmd);
            dbReader.SQLDR.Read();

            LinkSeqNo = Convert.ToInt32(dbReader.SQLDR["NextSeqNo"].ToString().TrimEnd());
            LastTrn = dbReader.SQLDR["TrnRef"].ToString();
            dbReader.CloseDataReader();
            if (dbg > 0)
                LogIt(string.Format("   TrnRef in linkcontrol: {0}", LastTrn), dbgMed);
            return (1);
        }


        private int update_resynch_info(string Trn)
        {
            dbCmd = string.Format("update LinkControl " +
                " set NextSeqNo = {0}, TrnRef = '{1}'" +
                " where LineName = '{2}'",
                LinkSeqNo, Trn, LineName);
            dbWriter.Execute(dbCmd, true);
            if (dbg > 0)
            {
                LogIt(string.Format("   Update_Resynch cmd:"), dbgMed);
                LogIt("      " + dbCmd, dbgMed);
            }
            return (1);
        }

        private int WriteData(ref string buf)
        {
            /*
                        if (Transport == "IP")
                        {
                            try
                            {
                                netWriter.Write(buf);
                                netWriter.Flush();
                                return (1);
                            }
                            catch
                            {
                                LogIt("   Problem in WriteData", dbgLow);
                                return -666;
                            }
                        }
                        else //MQ transport
                        {
                            if (!m_transportConnection.Write(buf))			// if write fails, flush transaction
                            {
                                LogIt(string.Format("{0}:MQ write error in ISI2link {1}", DateTime.Now, LineName), dbgLow);
                                return -666;			// and reconnect
                            }
                            else
                                return 1;
                        }
             * */

            if (!m_transportConnection.Write(buf))			// if write fails, flush transaction
            {
                LogIt(string.Format("{0}:MQ write error in ISI2link {1}", DateTime.Now, LineName), dbgLow);
                return -666;			// and reconnect
            }
            return 1;

        }

        private int ReadData(ref string buf)
        {
            if (Transport == "IP")
            {
                try
                {
                    //                    nCharsRead = netReader.Read(buffer, 0, 10000);
                    m_transportConnection.Read(ref buf);
                    nCharsRead = buf.Length;
                    //                        Lbuf.Length = 0;
                    //                    for (int idx = 0; idx < nCharsRead; idx++) Lbuf.Append(buffer[idx]);
                    //                      buf = Lbuf.ToString(0, Lbuf.Length);
                    Lbuf.Append(buf);
                }
                catch
                {
                    // Yes, we most certainly come here when the process on the
                    // wtx side is killed.
                    LogIt("ReadData catch block, return -666 - MTS side killed?", dbgLow);
                    return -666;
                }
                return (1);
            }
            else
            {
                int ReadTimeout = 0; // Sit and wait for data to come;
                try
                {
                    if (m_transportConnection.Read(ref buf, ReadTimeout))	//
                    {
                        return 1;
                    }
                }
                catch
                {
                    LogIt(string.Format("{0}:MQ Read error in ISI2link {1}", DateTime.Now, LineName), dbgLow);
                    return -666;
                }
                return 1;
            }
        }
        private int GetHostByName()
        {
            return (1);
        }

        private int CloseSocket(int socket)
        {
            return (1);
        }

        private int ConnectPort()
        {
            LogIt(string.Format("Connect Port: {0}:{1}", MTSHostName, PortNumber), dbgLow);
            m_transportConnection.Connect();
            ConnectCtr++;
            return (1);
        }

        private int ConnectMQ(string dir)
        {
            if (dir.Equals("O"))
                LogIt(string.Format("Connect to MQManager: {0} Output - {1}", MqManager, MqWrite), dbgLow);
            if (dir.Equals("I"))
                LogIt(string.Format("Connect to MQManager: {0} Input - {1}", MqManager, MqRead), dbgLow);
            m_transportConnection = new SimMQ(Area, MqManager, m_channel);
            if (!(MQConnected))
            {
                bool Stat = false;
                if (dir.Equals("I"))
                    Stat = m_transportConnection.Connect_Input(MqRead);
                if (dir.Equals("O"))
                    Stat = m_transportConnection.Connect_Output(MqWrite);
                if (Stat)
                {
                    MQConnected = true;
                }
                else
                {
                    LogIt(string.Format("Connect to MQManager: {0} Input - {1} Output - {2} FAILED", MqManager, MqRead, MqWrite), dbgLow);
                    return -666;
                }
            }
            return 1;
        }
        private int BindPort()
        {
            //         if (Transport == "MQ")
            //                return 1;
            return m_transportConnection.Connect() ? 1 : 0;

            //IPAddress localAddr = IPAddress.Parse(HostAddress);
            /*
                        IPAddress localAddr = IPAddress.Any;
                        TcpListener tcpListener = new TcpListener(localAddr, PortNumber);
                        tcpListener.Start();
                        while (!(tcpListener.Pending()))
                            System.Threading.Thread.Sleep(3000);
                        socketForClient = tcpListener.AcceptSocket();

                        NetworkStream networkStream = new NetworkStream(socketForClient);
                        System.IO.StreamWriter netWrt = new System.IO.StreamWriter(networkStream);
                        System.IO.StreamReader netRdr = new System.IO.StreamReader(networkStream);
                        netWriter = netWrt;
                        netReader = netRdr;
                        myListener = tcpListener;
                        return (1);
                        */
        }

        private void DoRcvSide()
        {
            if (Transport == "IP")
                DoRcvSideIP();
            else
                DoRcvSideMQ();
        }

        private void DoRcvSideMQ()
        {
            if (LineName.Contains("_RGW"))
            {
                isi2Version = 2;
                isi2HdrLength = 44;
            }
            if (!dbConnected)
            {
                dbReader.Connect(false, Area);
                dbWriter.Connect(true, Area);
                dbConnected = true;
            }
            AckFileName = util.GetConfigDir(dbReader) + myProcName + "_" + "acklist.txt";

            AckTable = new Hashtable();

            RecoverHashTable();
            rState = RcvState.unknown;
            LogInfo("Start the receive side");
            if (ConnectMQ("I") != 1)
            {
                return;
            }
            StringBuilder netbuf = new StringBuilder();
            netbuf.Length = 0;
            while (true)
            {
                //                stat = ReadData(netReader, ref LnkBuf);
                stat = ReadData(ref LnkBuf);
                if (dbg > 0)
                {
                    LogIt(string.Format("read {0} bytes:", LnkBuf.Length), dbgHigh);
                    LogIt(LnkBuf, dbgHigh);
                    //LogIt(string.Format("read {0} bytes", LnkBuf.Length), dbgHigh);
                }
                rcvMsg.Append(LnkBuf);
                StoreMsg();
                netbuf.Length = 0;
            }
        }

        private void DoRcvSideIP()
        {
            if (LineName.Contains("_RGW"))
            {
                isi2Version = 2;
                isi2HdrLength = 44;
            }
            if (!dbConnected)
            {
                dbReader.Connect(false, Area);
                dbWriter.Connect(true, Area);
                dbConnected = true;
            }
            AckFileName = util.GetConfigDir(dbReader) + myProcName + "_" + "acklist.txt";

            AckTable = new Hashtable();

            RecoverHashTable();
            rState = RcvState.unknown;
            LogInfo("Start the receive side");
            m_transportConnection = new IPSync2(SynchInterface.Type.Server, HostAddress, PortNumber);
            m_transportConnection.setReadAttributes(_lengthOffset, _lengthLength, 36, false);
            if (BindPort() == 0)
                throw new Exception("Could not bind to server port");
            StringBuilder netbuf = new StringBuilder();
            netbuf.Length = 0;
            RcvBlockNo = -1;
            Isi2Hdr = "Initialization xxxxxxxxxxxxxxxxxxxxxxx";
            IncompleteIsiHdr = false;
            while (true)
            {
                //                stat = ReadData(netReader, ref LnkBuf);
                stat = ReadData(ref LnkBuf);
                if (IncompleteIsiHdr)
                {
                    LnkBuf = HdrFragment + LnkBuf;
                    IncompleteIsiHdr = false;
                }
                if (dbg > 0)
                {
                    LogIt(string.Format("read {0} bytes:", LnkBuf.Length), dbgHigh);
                    LogIt(LnkBuf, dbgHigh);
                    //LogIt(string.Format("read {0} bytes", LnkBuf.Length), dbgHigh);
                }
                RcvBlockNo++;
                if ((LnkBuf.Length == 0) || (stat < 0))
                {
                    //
                    // Let's see if this handles the situation
                    // where the MTS link process is killed.
                    //
                    //                    myListener.Stop();
                    m_transportConnection.DisConnect();
                    BindPort();
                    continue;
                }
                nLeftThisBuf = LnkBuf.Length;
                nPassThruBuffer = 0;
                while (nLeftThisBuf > 0)
                {
                    nPassThruBuffer++;
                    if (LnkBuf.StartsWith("DB    ") || LnkBuf.StartsWith("DBD   "))
                    {
                        rState = RcvState.SingleBlock;
                        rcvMsg.Length = 0;
                        if (LnkBuf.Length >= isi2HdrLength)
                        {
                            decodeHdr(ref LnkBuf);
                            // We're looking at an Isi2Hdr that starts the block.
                            // Let's see how much more is in the buffer.
                            nLeftThisBuf -= isi2HdrLength;
                            if (nCharThisBlock <= nLeftThisBuf)
                            {
                                rcvMsg.Append(LnkBuf.Substring(isi2HdrLength, nCharThisBlock));
                                nLeftThisBuf -= nCharThisBlock;
                                StoreMsg();
                                nLeftThisBlock = 0;
                                if (dbg > 0)
                                    LogIt("Got everything for this msg in the first block", dbgMed);
                            }
                            else
                            {
                                rcvMsg.Append(LnkBuf.Substring(isi2HdrLength, nLeftThisBuf));
                                rState = RcvState.SingleBlockInProgress;
                                nLeftThisBlock = nCharThisBlock - nLeftThisBuf;
                                // scratch = string.Format("appended {0} chars, {1} remaining to get", 
                                //	nLeftThisBuf, nLeftThisBlock);
                                // LogIt(scratch, "Y");
                                nLeftThisBuf = 0;
                            }
                        }
                        else
                        {
                            HdrFragment = string.Format("{0}", LnkBuf);
                            IncompleteIsiHdr = true;
                            nLeftThisBuf = 0;
                            continue;
                        }
                    }
                    if (LnkBuf.StartsWith("DS    "))
                    {
                        LogIt("Header starts with DS", dbgHigh);
                        rState = RcvState.MultiBlock;

                        rcvMsg.Length = 0;
                        if (LnkBuf.Length >= isi2HdrLength)
                        {
                            decodeHdr(ref LnkBuf);
                            nLeftThisBuf -= isi2HdrLength;
                            if (nCharThisBlock <= nLeftThisBuf)
                            {
                                rcvMsg.Append(LnkBuf.Substring(isi2HdrLength, nCharThisBlock));
                                rState = RcvState.MultiBlockInProgress;
                                nLeftThisBuf -= nCharThisBlock;
                                nLeftThisBlock = 0;
                            }
                            else
                            {
                                rcvMsg.Append(LnkBuf.Substring(isi2HdrLength, nLeftThisBuf));
                                rState = RcvState.MultiBlockInProgress;
                                nLeftThisBlock = nCharThisBlock - nLeftThisBuf;
                                nLeftThisBuf = 0; ;
                            }
                        }
                        else
                        {
                            HdrFragment = string.Format("{0}", LnkBuf);
                            IncompleteIsiHdr = true;
                            nLeftThisBuf = 0;
                            continue;
                        }
                    }

                    if ((rState == RcvState.MultiBlockInProgress) ||
                        (rState == RcvState.MultiBlock))
                    {
                        LogIt("MultiBlockInProgress", dbgHigh);
                        if (LnkBuf.StartsWith("D     "))
                        {
                            LogIt("Header starts with D", dbgHigh);
                            rState = RcvState.MultiBlockInProgress;
                            if (LnkBuf.Length >= isi2HdrLength)
                            {
                                decodeHdr(ref LnkBuf);

                                nLeftThisBuf -= isi2HdrLength;
                                if (nCharThisBlock <= nLeftThisBuf)
                                {
                                    rcvMsg.Append(LnkBuf.Substring(36, nCharThisBlock));
                                    nLeftThisBuf -= nCharThisBlock;
                                    rState = RcvState.MultiBlockInProgress;
                                    nLeftThisBlock = 0;
                                }
                                else
                                {
                                    rcvMsg.Append(LnkBuf.Substring(36, nLeftThisBuf));
                                    rState = RcvState.MultiBlockInProgress;
                                    nLeftThisBlock = nCharThisBlock - nLeftThisBuf;
                                    nLeftThisBuf = 0;
                                    continue;
                                }
                            }
                            else
                            {
                                HdrFragment = string.Format("{0}", LnkBuf);
                                IncompleteIsiHdr = true;
                                nLeftThisBuf = 0;
                                continue;
                            }
                        }
                    }

                    if ((rState == RcvState.MultiBlockInProgress) ||
                        (rState == RcvState.MultiBlock) ||
                        (rState == RcvState.MultiBlockLastBlock))
                    {
                        if (LnkBuf.StartsWith("DE    "))
                        {
                            LogIt("Header starts with DE", dbgHigh);
                            rState = RcvState.MultiBlockLastBlock;
                            if (LnkBuf.Length >= 36)
                            {
                                decodeHdr(ref LnkBuf);
                                nLeftThisBuf -= isi2HdrLength;
                                if (nCharThisBlock <= nLeftThisBuf)
                                {
                                    rcvMsg.Append(LnkBuf.Substring(isi2HdrLength, nCharThisBlock));
                                    StoreMsg();
                                    nLeftThisBuf -= nCharThisBlock;
                                    nLeftThisBlock = 0;
                                }
                                else
                                {
                                    int zztop = LnkBuf.Length;
                                    rcvMsg.Append(LnkBuf.Substring(isi2HdrLength, nLeftThisBuf));
                                    rState = RcvState.MultiBlockLastBlockInProgress;
                                    nLeftThisBlock = nCharThisBlock - nLeftThisBuf;
                                    nLeftThisBuf = 0; ;
                                    continue;
                                }
                            }
                            else
                            {
                                HdrFragment = string.Format("{0}", LnkBuf);
                                IncompleteIsiHdr = true;
                                nLeftThisBuf = 0;
                                continue;
                            }
                        }
                    }
                    if (LnkBuf.StartsWith("CK    "))
                    {
                        // rState = RcvState.KeepAlive;
                        //                        WriteData(netWriter, ref LnkBuf);
                        WriteData(ref LnkBuf);
                        RcvBlockNo = -1;
                        nCharsRead = 0;
                        if (dbg > 0)
                            LogIt("Responded to keep-alive", dbgLow);
                        if (LnkBuf.Length > isi2HdrLength)
                        {
                            LnkBuf = LnkBuf.Substring(isi2HdrLength, LnkBuf.Length - isi2HdrLength);
                            nLeftThisBuf -= isi2HdrLength;
                        }
                        else
                            nLeftThisBuf = 0;
                        // We need to let the code fall thru so we'll be sure
                        // to send an ack. WTX seems fond of tagging a keep-alive
                        // on the tail of the last block of a big msg. Sometimes, anyway.
                        // continue;
                    }

                    if (LnkBuf.StartsWith("CRQ   "))
                    {
                        rState = RcvState.ResynchReq;
                        LnkBuf = LnkBuf.Remove(2, 1);
                        LnkBuf = LnkBuf.Insert(2, "R");
                        //                        WriteData(netWriter, ref LnkBuf);
                        WriteData(ref LnkBuf);
                        LogIt(string.Format("Got CRQ, sending buf: '{0}'", LnkBuf), dbgMed);
                        RcvBlockNo = -1;
                        nCharsRead = 0;
                        rState = RcvState.unknown;
                        nLeftThisBuf = 0;
                        continue;
                    }

                    if (LnkBuf.StartsWith("CDQ   "))
                    {
                        rState = RcvState.DownReq;
                        LogInfo("Down command received");
                        LnkBuf = LnkBuf.Remove(2, 1);
                        LnkBuf = LnkBuf.Insert(2, "R");
                        //                        WriteData(netWriter, ref LnkBuf);
                        WriteData(ref LnkBuf);
                        LogIt(string.Format("Got CDQ, sending buf: '{0}'", LnkBuf), dbgMed);
                        RcvBlockNo = -1;
                        nCharsRead = 0;
                        //
                        //	Down command on the other side knocks
                        //	down the port.
                        //
                        //                       myListener.Stop();
                        m_transportConnection.DisConnect();
                        BindPort();
                        rState = RcvState.unknown;
                        nLeftThisBuf = 0;
                        continue;
                    }

                    if ((nLeftThisBuf <= 0) && (rState == RcvState.MsgCompleteNotAckd))
                    {
                        AckMsg(LastCompleteInboundSeqNo);
                    }
                    if (nLeftThisBuf <= 0)
                        continue;

                    //
                    // Ok, there's something left in the buffer and/or we did another
                    // read whose buffer didn't start with one of our headers above...
                    // This should be a continuation of a block in
                    // progress. We should find the state set to indicate that.
                    //
                    if ((rState == RcvState.SingleBlockInProgress) ||
                        (rState == RcvState.MultiBlockInProgress) ||
                        (rState == RcvState.MultiBlockLastBlockInProgress))
                    {
                        if (nLeftThisBlock <= nLeftThisBuf)
                        {
                            if (nLeftThisBlock > 0)
                            {
                                // Ok, we've got the rest of our block. It might
                                // be the rest of the msg. Might not, too.
                                rcvMsg.Append(LnkBuf.Substring(0, nLeftThisBlock));
                                if (dbg > 0)
                                {
                                    scratch = string.Format("appended {0} chars", nLeftThisBlock);
                                    LogIt(scratch, dbgMed);
                                }
                                if ((rState == RcvState.SingleBlockInProgress) ||
                                    (rState == RcvState.MultiBlockLastBlockInProgress))
                                {
                                    StoreMsg();
                                }
                                nLeftThisBuf -= nLeftThisBlock;
                                // if (dbg > 0)
                                // 	LogIt(string.Format("nLeftThisBuf: {0}", nLeftThisBuf), "Y");
                            }
                        }
                        else
                        {
                            // They didn't send the rest of the msg block in this buffer.
                            // We *do*, however, want all that's here. We should get the
                            // rest in the next read. (or reads...)
                            rcvMsg.Append(LnkBuf.Substring(0, nLeftThisBuf));
                            nLeftThisBlock -= nLeftThisBuf;
                            if (dbg > 0)
                            {
                                scratch = string.Format("appended {0} chars, {1} remaining to get",
                                    nLeftThisBuf, nLeftThisBlock);
                                LogIt(scratch, dbgMed);
                            }
                            nLeftThisBuf = 0; ;
                        }
                    }

                    if ((nLeftThisBuf <= 0) && (rState == RcvState.MsgCompleteNotAckd))
                    {
                        // The buffer's empty *and* we've got a msg to ack. So, let's 
                        // ack it. Curiously enough, this simple mechanism appears to
                        // behave well in the mutli-msg mode of operation. Kind of makes
                        // sense - the buffer's empty with no overflow - and we've got
                        // something to ack. Sometimes they hang a CK keep-alive on the
                        // tail of a complete transmission; that'll out-fox this logic
                        // right here, but we'll catch that when we do the keep-alive
                        // response above.
                        AckMsg(LastCompleteInboundSeqNo);
                    }
                    if (nLeftThisBuf <= 0)
                        continue;

                    // Ok, there's still something left in the buffer
                    // and we're going to loop back to the top. Sleazy,
                    // but let's throw away all the stuff we're already
                    // processed.
                    LnkBuf = LnkBuf.Substring(LnkBuf.Length - nLeftThisBuf, nLeftThisBuf);

                    if (dbg > 0)
                    {
                        LogIt(" trimmed lnkbuf. It's now:", dbgHigh);
                        LogIt(LnkBuf, dbgHigh);
                        if ((LnkBuf.StartsWith("DB   ")) ||
                            (LnkBuf.StartsWith("DS   ")) ||
                            (LnkBuf.StartsWith("DE   ")) ||
                            (LnkBuf.StartsWith("CK   ")) ||
                            (LnkBuf.StartsWith("D    ")))
                            LogIt("Next buf segment is ok", dbgMed);
                    }

                    // And now for one last attempt to plug all the holes ...
                    // If our buffer is less than 6 chars long, it's not big
                    // enough for us to recognize the start of a header of
                    // some sort. So, if the length is less than 6, let's 
                    // save it and glue it onto the front of the next buffer
                    // that we read. Stay tuned ..
                    if (LnkBuf.Length < 6)
                    {
                        HdrFragment = string.Format("{0}", LnkBuf);
                        IncompleteIsiHdr = true;
                    }
                    //
                    // Let's be on the lookout for any tight loops where we've lost
                    // our way. If, somehow, we can't find the start of the next Isi2hdr (etc)
                    // we'll loop thru this buffer forever. I think I've got most of
                    // the holes plugged, but just to make sure, let's self-destruct if
                    // we've run thru this buffer too many times.
                    //
                    if (nPassThruBuffer > 1000)
                    {
                        LogIt("Too many times thru this buffer. Something's wrong", dbgLow);
                        LogIt(LnkBuf, dbgHigh);
                        return;
                    }
                }
            }
        }

        private void AckMsg(string key)
        {
            AckBuf = AckTable[key].ToString();
            AckBuf = AckBuf.Remove(FlagsStart, 2);
            AckBuf = AckBuf.Insert(FlagsStart, "CA");
            AckBuf = AckBuf.Remove(DatalenStart, 4);
            AckBuf = AckBuf.Insert(DatalenStart, "0000");
            //            WriteData(netWriter, ref AckBuf);
            WriteData(ref AckBuf);
            RcvBlockNo = -1;
            nCharsRead = 0;
            rState = RcvState.MsgComplete;
            if (dbg > 0)
            {
                // LogIt(AckBuf, "Y");
                LogIt("ackd the msg", dbgMed);
            }

            // Let's store the sequence number. We don't really use it in
            // the resynch process, but it *does* show up in the queue
            // display.
            string seqno = AckBuf.Substring(8, 6);
            int seq = Convert.ToInt32(seqno);

            string dbCmd = string.Format("update LinkControl " +
                " set NextSeqNo = {0} " +
                " where LineName = '{1}'",
                seq, LineName);
            dbWriter.Execute(dbCmd, true);
            if (dbg > 0)
                LogIt(string.Format(" ack update linkcontrol: {0}", dbCmd), dbgMed);
        }

        private void StoreMsg()
        {
            string msg = Convert.ToString(rcvMsg);
            for (int i1 = 0; i1 < msg.Length; i1++)
            {
                if (msg[i1] == '\'')
                {
                    msg = msg.Insert(i1, "'");
                    i1++;
                }
            }
            dbCmd = string.Format("Insert into RCV_{0} (qbltext) values ('{1}')", LineName, msg);
            dbWriter.Execute(dbCmd, true);
            rcvMsg.Length = 0;
            if (dbg > 0)
            {
                LogIt("Stored:", dbgHigh);
                LogIt(msg, dbgHigh);
            }
            rState = RcvState.MsgCompleteNotAckd;
            LastCompleteInboundSeqNo = InboundSeqNo;
        }

        private void decodeHdr(ref string buf)
        {
            // Damn ... we have to get the length of this block or all
            // sorts of hell breaks loose. However, we don't want to save
            // the header unless it's one that indicates the start of a
            // msg. Geesh.
            if (isi2Version == 1)
            {
                try
                {
                    nCharThisBlock = Convert.ToInt32(buf.Substring(32, 4));
                    LogIt("decodeHdr", dbgHigh);
                    if ((buf.StartsWith("DS")) || (buf.StartsWith("DB")))
                    {
                        Isi2Hdr = buf.Substring(0, isi2HdrLength);
                        LogIt("   Isi2Hdr:" + Isi2Hdr, dbgMed);
                        InboundSeqNo = Isi2Hdr.Substring(8, 6);
                        nCharThisBlock = Convert.ToInt32(buf.Substring(32, 4));
                        LogIt(string.Format("   nCharThisBlock: {0}", nCharThisBlock), dbgMed);

                        InboundSeqNo = Isi2Hdr.Substring(8, 6);
                        if (!AckTable.ContainsKey(InboundSeqNo))
                        {
                            LogIt("   Add seq no to ack table:" + InboundSeqNo, dbgHigh);
                            AckTable.Add(InboundSeqNo, Isi2Hdr);
                            UpdateHashTable(InboundSeqNo);
                        }
                    }
                }
                catch
                {
                }
            }

            if (isi2Version == 2)
            {
                try
                {
                    nCharThisBlock = Convert.ToInt32(buf.Substring(38, 6));
                    LogIt("decodeHdr", dbgHigh);
                    if ((buf.StartsWith("DS")) || (buf.StartsWith("DB")))
                    {
                        Isi2Hdr = buf.Substring(0, isi2HdrLength);
                        LogIt("   Isi2Hdr:" + Isi2Hdr, dbgMed);
                        InboundSeqNo = Isi2Hdr.Substring(10, 6);
                        nCharThisBlock = Convert.ToInt32(buf.Substring(38, 6));
                        LogIt(string.Format("   nCharThisBlock: {0}", nCharThisBlock), dbgMed);

                        //InboundSeqNo = Isi2Hdr.Substring(8, 6);
                        if (!AckTable.ContainsKey(InboundSeqNo))
                        {
                            LogIt("   Add seq no to ack table:" + InboundSeqNo, dbgHigh);
                            AckTable.Add(InboundSeqNo, Isi2Hdr);
                            UpdateHashTable(InboundSeqNo);
                        }
                    }
                }
                catch
                {
                }
            }

        }
        private void LogInfo(string buf)
        {
            dbReader.RecordEvent(0, LineName, string.Format("{0}", buf), Area);
        }

        private void LogIt(string buf, int debugLevel)
        {
            if (debugLevel == noDebug)
                return;
            //dbReader.ConsoleWrite(d, LineName, LogStream, buf);
            if (debugLevel <= dbg)
            {
                LogStream.WriteLine(buf);
                LogStream.Flush();
            }
        }

        private void LogError(string buf)
        {
            dbReader.RecordEvent(1, LineName, string.Format("{0}", buf), Area);
        }
        private int CommInfo()
        {
            dbCmd = string.Format("select Port, SndRcv, P1, TimeDelay, outputMQName, inputMQName, MQMgrName, ConnChannel from LinkControl where LineName = '{0}'", LineName);
            dbReader.OpenDataReader(dbCmd);
            dbReader.SQLDR.Read();
            SndRcv = dbReader.SQLDR["SndRcv"].ToString().TrimEnd();
            SndRcv = SndRcv.ToUpper();
            PortNumber = dbReader.SQLDR.GetInt32(0);
            //
            // Get P1. At the moment I'm just using it to set the debug level.
            //
            scratch = dbReader.SQLDR["P1"].ToString().TrimEnd();
            scratch = scratch.ToUpper();
            dbg = 0;
            if (scratch.StartsWith("DEBUG"))
                dbg = dbgLow;
            if (scratch.StartsWith("DEBUG-M"))
                dbg = dbgMed;
            if (scratch.StartsWith("DEBUG-H"))
                dbg = dbgHigh;

            /*
             * 14-Jan-16. Wow, haven't looked at this code in a looooong time ;-)
             * Let's use the debug level from the sim control table.
             * 
             */ 
            dbg = util.GetDebugLevel(Area);

            TimeDelay = dbReader.SQLDR.GetInt32(3);
            MqRead = dbReader.SQLDR["inputMQName"].ToString().TrimEnd();
            MqWrite = dbReader.SQLDR["outputMQName"].ToString().TrimEnd();
            MqManager = dbReader.SQLDR["MQMgrName"].ToString().TrimEnd();
            m_channel = dbReader.SQLDR["ConnChannel"].ToString().TrimEnd();

            if ((MqManager.Length > 0) && (PortNumber == 0))
                Transport = "MQ";
            dbReader.CloseDataReader();

            string l_area;
            dbCmd = string.Format("select * from SimulatorControl");
            dbReader.CloseDataReader();
            dbReader.OpenDataReader(dbCmd);
            dbReader.SQLDR.Read();
            HostAddress = dbReader.SQLDR["OurHostAddress"].ToString().TrimEnd();
            l_area = dbReader.SQLDR["Area"].ToString().TrimEnd();
            Debug = dbReader.SQLDR["Debug"].ToString().TrimEnd();
            Debug = Debug.ToUpper();
            MTSHostName = dbReader.SQLDR["MTSHostName"].ToString().TrimEnd().ToUpper();
            dbReader.CloseDataReader();

            scratch = string.Format("Link started with params:");
            LogStream.WriteLine(scratch);
            scratch = string.Format("   dbg:{0}", dbg);
            LogStream.WriteLine(scratch);
            scratch = string.Format("   timedelay:{0}", TimeDelay);
            LogStream.WriteLine(scratch);
            scratch = string.Format("   HostName:{0}:{1}", MTSHostName, PortNumber);
            LogStream.WriteLine(scratch);
            scratch = string.Format("");
            LogStream.WriteLine(scratch);
            LogStream.Flush();

            if (l_area != Area)
            {
                return (0);
            }
            return (1);
        }
        private void RecoverHashTable()
        {
            FileStream AckFile;
            StreamReader ackRdr;
            try
            {
                AckFile = new FileStream(AckFileName, FileMode.Open,
                    FileAccess.Read);
                ackRdr = new StreamReader(AckFile);
            }
            catch
            {
                return;
            }
            do
            {
                string entry = ackRdr.ReadLine();

                if (entry != null)
                {
                    string key = entry.Substring(0, entry.IndexOf("|"));
                    string ackvalue = entry.Substring(entry.LastIndexOf("|") + 1);
                    AckTable.Add(key, ackvalue);
                }
                else break;
            } while (true);
            ackRdr.Close();
            AckFile.Close();
        }

        private void UpdateHashTable(string SeqNo)
        {
            FileStream AckFile;
            StreamWriter ackWrt;
            try
            {
                AckFile = new FileStream(AckFileName, FileMode.Create,
                    FileAccess.Write);
                ackWrt = new StreamWriter(AckFile);
            }
            catch
            {
                return;
            }
            int seqno = Convert.ToInt32(SeqNo);
            int hashseqno;
            IDictionaryEnumerator Enumerator = AckTable.GetEnumerator();
            while (Enumerator.MoveNext())
            {
                // let's try to be somewhat economical and save just the last
                // N number of acks. For want of knowing any better at the moment,
                // let's set N to 50. Overkill, I suspect.
                hashseqno = Convert.ToInt32(Enumerator.Key.ToString());
                if ((seqno - hashseqno) < 50)
                {
                    string AckEntry = Enumerator.Key.ToString() + "|" +
                        Enumerator.Value.ToString();
                    ackWrt.WriteLine(AckEntry);
                }
            }
            ackWrt.Close();
            AckFile.Close();
        }
    }
}