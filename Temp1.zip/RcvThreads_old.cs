/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Text;
using System.Data;
using System.Collections;
using System.Diagnostics;
using Simulator.DBLibrary;
using System.Xml;
using System.Net;
using System.Threading;
using Simulator.FormatersLib;
using Simulator.BackEndSubLib;
using Simulator.QueueInterface;
using Simulator.RGWSubLib;
/*
	29-Sep-05	JR	Run all the receivers as threads inside this process.
	07-Oct-05	JR	On the initial select out of the RCV table, we need to limit
					how many we select or else we run the (very real) risk of
					timing out when we go to delete the msg from the table.
					Let's pick 10 for the time being.
					
					Nope, I think that's still too high. Let's make it 5. And
					let's throw a try/catch on that sucker and report the error.
					
	10-Oct-05	JR	Add a field to the table to control how many to select.
	19-Oct-05	JR	Enough with having a log file per thread. Just one log file now, and each
					thread log activity will include a little preamble telling who's doing the
					logging.
	20-Oct-05	JR	Some cleanup of the recordevent error/info codes.
	 6-Dec-05	DM	Numerous changes.
	 8-Dec-05	JR	When opening/closing the receiver text file(s), check to see if it's a source
					we're writing in xml format. If so, plug in the top-level tag(s).
	 6-Jan-06	JR	The Swift WriteToFile routine takes an additional arg, the m_LogWrt writer.
 * 
 *  15-Jan-07    JR  Plug in the logic to pull RGW buffers out and stuff them into the database.
 *                  Virtually all of the real work is in RGWSubs in the RgwLinkSubs class.
 * 
 * 19-Jan-07    JN  Add Fed.
 * 
 * 18-Feb-07    JR  Change how the receiver figures out where to stash rgw traffic.
 * 
 * 19-Feb-07    JR  If the WriteFile flag is set to 'Y', this tells the RGW link routine that
 *                  it should also take a msg and to the xml-format and insert into compare
 *                  table dance. The compare table name it will use is the 'DefaultCompareTable'
 *                  in SimulatorControl. There are tools in the MSG maintenance part of the UI
 *                  that will let you change that table name.
 * 
 * 30-Apr-07    JN  Some more changes for the Fed.
 *  8-Mar-2013	JN  Usage to AckType. Add new way of figuring out the Source.
                    Use Source of ReceiverContorl instead of the line name.
                    Add MQ process ACK routines
 * 23-Sep-2013  JN  Add RBCS ack to MQ processing for CitiBank
 * 29-Oct-2013  JN  Add support for FXLM CitiBank
 * 23-Dec-2013  JN  Add support for DSM Citibank
 * 07-Nov-2014  JN  Add support for MTS outbound text capture. This is for the lines that DO not store the
 *		    outbound text on MTS DB. It gets created on a fly. We will store it in our own table MTS_RCV_TEXT and used it
 *                  to do comparison.
 * 09-Nov-14    JR  When we store the traffic in MTS_RCV_TEXT, let's store it in the database defined by ReceiverRgwArea
 *                  from Simulator Control. Long story, but see the comments below. Search for 'ReceiverRgwArea' ...
 *                  
 * 28-Nov-15    JR  Synch code between Jacob and John
 */
namespace ReceiverThreads
{
    public class RcvThread
    {
        /// <summary>
        /// This is the Receiver.
        //
        private DBAccess m_Connection;
        private DBAccess m_AckConnection;
        private DBAccess m_ReadConnection;
        private DBAccess m_AckReadConnection;
        private SwiftRcv m_swfFormatter;
        private ChpFormatter m_chpFormatter;
        private MQFormatter m_mqsFormatter;
        private FedFormatter m_fedFormatter;
        private string m_Status;
        private string m_LineName;
        private string m_Source;
        private string m_Area;
        private string m_Debug;
        private string m_RootDir;
        private string m_ApplId;
        private string m_CycleDate;
        private string m_Lterm;
        private int m_NoPerBatch;

        private string m_myProcName;
        private string m_StopAckQue;
        private string m_WriteFile;
        public string m_FileName;
        private string m_AckRuleTableName;
        private string m_ReleaseAckQue;
        private string m_Finalmsg;
        private string m_SendLine;
        private string m_ChpAba;
        private string m_FedAba;
        private string m_AckType;
        private string m_ChangeRef;
        private StreamWriter m_rcvOutputStream;
        private int m_TimeDelay;
        private bool m_Swift;
        private bool m_Chips;
        private bool m_Fed;
        private bool m_Mqs;
        private string m_SrcDb;
        private string m_TrgDb;
        private string m_DbPrefix;
        private string m_SrcConnStr;
        private string m_TrgConnStr;
        private string m_DbType;
        private int m_nSelect;
        private string m_doedits;
        private string m_fmtname;
        private StreamWriter m_LogWrt;
        private const int ERROR = 1;
        private const int INFO = 0;
        private bool m_Show;
        private string m_MsgFormat;
        private int m_RefId;

        BackEndSubs util;
        bool init;
        RgwLinkSubs rlink;
        private string m_rgwArea;




        public RcvThread(string area, string linename, string src)
        {
            init = true;
            m_Show = false;
            util = new BackEndSubs();
            m_Connection = new DBAccess();
            m_ReadConnection = new DBAccess();
            m_Area = area;
            m_LineName = linename.ToUpper();
            m_Source = src.ToUpper();
            m_Swift = false;
            m_FileName = " ";
            m_WriteFile = "N";
            m_rcvOutputStream = null;
            m_chpFormatter = null;
            m_mqsFormatter = null;
            m_fedFormatter = null;
            m_swfFormatter = null;
            m_MsgFormat = null;
            m_RefId = 0;
            if (m_LineName.IndexOf("F_SND") != -1)
            {
                m_AckReadConnection = new DBAccess();
                m_Swift = true;
                m_swfFormatter = new SwiftRcv();
            }
            m_Chips = false;
            if (src == "CHP")
            {
                m_Chips = true;
                m_chpFormatter = new ChpFormatter();
            }
            m_Fed = false;
            if (src == "FED")
            {
                m_AckReadConnection = new DBAccess();
                m_AckConnection = new DBAccess();
                m_Fed = true;
                m_fedFormatter = new FedFormatter();
            }
            m_Mqs = false;
            if (src == "MQS")
            {
                m_Mqs = true;
                m_mqsFormatter = new MQFormatter(area);
            }
            rlink = null;

        }

        public void dorcv()
        {
            try
            {
                executeReceive();
            }
            catch (Exception ex)
            {
                string error = string.Format("Rcv thread for line {0} failed. Error is {1}", m_LineName, ex.Message);
                try
                {
                    Console.WriteLine(error);
                    m_AckReadConnection.RecordEvent(1, "Receiver Thread for " + m_LineName, error, m_Area);
                }
                catch { }
            }
        }
        private void executeReceive()
        {
            string qm_LineName = "RCV_" + m_LineName;
            m_myProcName = "Receiver" + "_" + m_Area + "_" + m_LineName;

            // open up a trace file 
            try
            {
                m_Connection.Connect(true, m_Area);
                m_ReadConnection.Connect(false, m_Area);
            }
            catch
            {
                LogIt(string.Format("Connection failure {0}", m_LineName), "Y");
                m_Connection.RecordEvent(ERROR, m_myProcName, string.Format("{0}", "Connection failure"), m_Area);
                return;										// exit the thread.
            }

            BackEndSubs util = new BackEndSubs();
            string ldir = util.GetLogDir(m_Connection);
            string ts = util.GetTimestampTag();
            string filename = string.Format("{0}Receiver_{2}_{1}.log", ldir, ts, m_LineName);
            FileStream file1 = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);
            m_LogWrt = new StreamWriter(file1);
            LogIt("start", "Y");
            if (m_Swift)
            {
		m_AckReadConnection.Connect(false, m_Area);
            }
            if (m_Fed)
            {
                string Cmd = string.Format("select SwfTid from LinkControl where LineName='{0}'", m_LineName);
                m_Connection.OpenDataReader(Cmd);
                m_Connection.SQLDR.Read();
                m_Lterm = m_Connection.SQLDR["SwfTid"].ToString().TrimEnd();
                m_Connection.CloseDataReader();
                m_AckReadConnection.Connect(false, m_Area);
                m_AckConnection.Connect(true, m_Area);
            }

            bool receiveQueueType = true;
            if (m_nSelect < 1)
                m_nSelect = 10;
            QueueInterface m_QI = new QueueInterface(qm_LineName, m_nSelect, m_Area, receiveQueueType);

            GetSimValues();
            try
            {
                string Cmd = string.Format("select AckType, SrcDb, TrgDb, DbPrefix from MQLINESRC where Source = '{0}' and LineName='{1}'", m_Source, m_LineName.Replace("IN", "OUT"));
                m_ReadConnection.OpenDataReader(Cmd);
                if (!m_ReadConnection.SQLDR.Read())
                {
                    m_ReadConnection.CloseDataReader();
                    string ln1 = "xxx_" + m_LineName.Substring(4).Replace("IN", "OUT");
                    Cmd = string.Format("select AckType, SrcDb, TrgDb, DbPrefix from MQLINESRC where Source = '{0}' and LineName='{1}'", m_Source, ln1);
                    m_ReadConnection.OpenDataReader(Cmd);
                }
                m_AckType = m_ReadConnection.SQLDR["AckType"].ToString().TrimEnd().ToUpper();
                m_SrcDb = m_ReadConnection.SQLDR["SrcDb"].ToString().TrimEnd();
                m_TrgDb = m_ReadConnection.SQLDR["TrgDb"].ToString().TrimEnd();
                m_DbPrefix = m_ReadConnection.SQLDR["DbPrefix"].ToString().TrimEnd();
                if (m_Show)
                    Console.WriteLine("Var: Ack - " + m_AckType + " Srcdb - " + m_SrcDb + " trgdb - " + m_TrgDb);
                string f_name = string.Format("c:\\Simulator\\{0}\\feed\\connstring.xml", m_Area);
                DataSet srctable = new DataSet();
                srctable.ReadXml(f_name);
                foreach (DataTable table in srctable.Tables)
                {
                    foreach (DataRow row in table.Rows)
                    {
                        if ((row["type"].ToString().ToLower() == "src") && (row["uniquename"].ToString() == m_SrcDb))
                        {
                            m_DbType = row["conndb"].ToString().TrimEnd();
                            m_SrcConnStr = row["connection_string"].ToString().TrimEnd();
                        }
                        if ((row["type"].ToString().ToLower() == "trg") && (row["uniquename"].ToString() == m_TrgDb))
                            m_TrgConnStr = row["connection_string"].ToString().TrimEnd();
                    }
                }
            }
            catch { m_AckType = ""; }
            m_ReadConnection.CloseDataReader();

            string qblText;
            int qblId = 0;
            for (; ; )
            {
                CheckOutputStatus();
                for (int index = 0; index < m_nSelect; index++)
                {
                    QueueItem qi = m_QI.getQueueItem();
                    if (qi == null)
                    {
                        // Nothing on queue. Take a nap. How long should we nap?
                        // 30 seconds is today's answer.
                        System.Threading.Thread.Sleep(5000);
                        break;
                    }
                    qblText = qi.Text;
                    qblId = qi.Qblid;
                    string src;
                    src = m_fmtname;
                    if (m_Show)
                        Console.WriteLine("In main loop: src- " + src + " RefId( not 0 store the text) - " + m_RefId);

                    if (m_RefId > 0) // we need to store the receiving text in MTS_RCV_TEXT
                        AciStoreText(m_RefId, m_MsgFormat, qblText);

                    switch (src)
                    {
                        case "MQS":
                            if (!ProcessMqs(qblText))
                                return;
                            break;

                        case "CHP":
                            if (!ProcessChips(qblText))
                                return;
                            break;

                        case "FED":
                            if (!ProcessFed(qblText))
                                return;
                            break;

                        case "ISI":
                            if (m_WriteFile.Equals("Y"))
                            {
                                m_rcvOutputStream.Write(qblText);
                                m_rcvOutputStream.Flush();					// Flush StreamWriter
                            }
                            break;

                        case "SWF":
                            if (!ProcessSwifts(qblText))
                                return;
                            break;

                        case "IS2":
                            if (init)
                            {
                                m_rgwArea = util.GetReceiverRgwArea(m_Area);
                                if (m_LineName.IndexOf("_RGW") > 0)
                                {
                                    /*
                                     * If the m_WriteFile flag is on, we want to have the
                                     * underlying routine(s) save our msg in xml format in
                                     * the compare table.
                                     */
                                    if (m_WriteFile.Equals("Y"))
                                        rlink = new RgwLinkSubs(m_Area);
                                    else
                                        rlink = new RgwLinkSubs();
                                }
                            }
                            if (m_WriteFile.Equals("Y"))
                            {
                                m_rcvOutputStream.Write(qblText);
                                m_rcvOutputStream.Flush();			// Close StreamWriter
                                if (m_LineName.IndexOf("_SCK") >= 0)
                                    doSwfchkDla(qblText);           // SwiftCheck inbounds. Let's create the Delivery Ack.
                                if (m_LineName.IndexOf("_RGW") > 0)
                                    doRgwReceive(qblText, m_rgwArea);
                            }
                            else
                            {
                                if (m_LineName.IndexOf("_RGW") > 0)
                                    doRgwReceive(qblText, m_rgwArea);
                            }
                            init = false;
                            break;

                        default:
                            m_Status = "Wrong Source Received. Discarded.";
                            LogIt(m_Status, m_Debug);
                            break;
                    }
                    try
                    {
                        string Cmd = string.Format("delete from {0} where qbl={1}", qm_LineName, qblId);
                        m_Connection.Execute(Cmd, true);
                    }
                    catch
                    {
                        LogIt("DB Error Deleting from RCV table", "Y");
                        m_Connection.RecordEvent(ERROR, m_myProcName, string.Format("{0}", "Error deleting from table"), m_Area);
                        return;
                    }
                    if (src == "SWF")  //we need to see if any of those msgs that we are ACKing need MT012 back
                    {
			m_swfFormatter.MakeMt012(m_LineName, m_ReadConnection,m_AckReadConnection, m_Connection);
                    }
                }
            }
        }

        private bool ProcessMqs(string qblText)
        {
            if (m_AckType.Length == 0)	// no ack needed
                return true;
            string prio = "1";
            string Ack = "";
            string Cmd = "";
            if (m_Show)
                Console.WriteLine("in process_mq. acktype - " + m_AckType);
            switch (m_AckType)
            {
                case "RBCS":
                    Ack = m_mqsFormatter.Ack_RBCS(m_Connection, m_ReadConnection, qblText, m_AckRuleTableName);
                    if (Ack.Length == 0)
                        break;
                    m_SendLine = "LNK_" + m_LineName.Replace("_IN", "_OUT");
                    Ack = Ack.Replace("'", "''");
                    Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, Ack);
                    m_Connection.Execute(Cmd, false);
                    break;

                case "FXLM":
                    string[] arr1 = new string[2];
                    arr1 = m_mqsFormatter.Ack_FXLM(m_Connection, m_ReadConnection, qblText, m_DbType, m_SrcConnStr, m_TrgConnStr, m_ChangeRef, m_DbPrefix);
                    foreach (string st in arr1)
                    {
                        Ack = st;
                        if (Ack.Length == 0)
                            break;
                        m_SendLine = "LNK_" + m_LineName.Replace("_IN", "_OUT");
                        Ack = Ack.Replace("'", "''");
                        Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, Ack);
                        m_Connection.Execute(Cmd, false);
                    }
                    break;

                case "FXRATE":
                    Ack = m_mqsFormatter.Ack_FXRATE(m_Connection, m_ReadConnection, qblText, m_DbType, m_SrcConnStr, m_TrgConnStr, m_ChangeRef, m_DbPrefix);
                    if (Ack.Length == 0)
                        break;
                    m_SendLine = "LNK_" + m_LineName.Replace("_IN", "_OUT");
                    Ack = Ack.Replace("'", "''");
                    Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, Ack);
                    m_Connection.Execute(Cmd, false);
                    break;

                case "MT012":
                    m_StopAckQue = "N"; //if they specified the table no stop queue 'business'
                    Ack = m_mqsFormatter.MakeFinCopy(m_Connection, m_ReadConnection, m_SendLine, qblText, m_AckRuleTableName);
                    if (Ack.Length > 0)
                    {
                        m_SendLine = "LNK_" + m_LineName.Replace("_IN", "_OUT");
                        Ack = Ack.Replace("'", "''");
                        Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, Ack);
                        m_Connection.Execute(Cmd, false);
                    }
                    break;

                case "DSM":
                    m_StopAckQue = "N"; //if they specified the table no stop queue 'business'
                    Ack = m_mqsFormatter.Ack_DSM(m_Connection, m_ReadConnection, m_SendLine, qblText, m_AckRuleTableName);
                    if (Ack.Length > 0)
                    {
                        m_SendLine = "LNK_" + m_LineName.Replace("_IN", "_OUT");
                        Ack = Ack.Replace("'", "''");
                        Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, Ack);
                        m_Connection.Execute(Cmd, false);
                    }
                    break;

                default:
                    m_Status = "Wrong Source Received. Discarded.";
                    LogIt(m_Status, m_Debug);
                    break;
            }
            return true;
        }

        private void AciStoreText(int RefId, string Fmt, string qblText)
        {
            // 1. Get ALL entries from MTS_REF_IDS table for this ID
            string Cmd = string.Format("select RefLen, StRefTag, EnRefTag, RefPos from MTS_REF_IDS where RefId = {0} order by RefSeq", RefId);
            m_ReadConnection.OpenDataReader(Cmd);
            bool hasRows = m_ReadConnection.SQLDR.HasRows;
            if (!hasRows)
            {
                m_Status = "MTS_REF_IDS does not have RefId = " + RefId;
                m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                m_ReadConnection.CloseDataReader();
                return;
            }
            int cnt = 0;
            // Read all of them and get the reference from the text. The first one is TRN or MID. All the other we concatinate into a string.
            string TrnStr = "";
            string OtherRef = "";
            while (m_ReadConnection.SQLDR.Read())
            {
                int RefLen = m_ReadConnection.SQLDR.GetInt32(0);
                string StRefTag = m_ReadConnection.SQLDR[1].ToString().TrimEnd();
                string EnRefTag = m_ReadConnection.SQLDR[2].ToString().TrimEnd();
                int RefPos = m_ReadConnection.SQLDR.GetInt32(3);
                cnt++;
                string TmpRef = "";
                if (RefPos > 0) // we have a fixed position and the length
                {
                    try
                    {
                        TmpRef = qblText.Substring(RefPos, RefLen);
                    }
                    catch
                    {
                        m_Status = "1. MTS_REF_IDS has incorrect entry for RefId = " + RefId;
                        m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                        m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                        m_ReadConnection.CloseDataReader();
                        return;
                    }
                }
                else // we have start and end postion
                {
                    try
                    {
                        int ptr = qblText.IndexOf(StRefTag);
                        ptr = ptr + StRefTag.Length;
                        if (RefLen > 0)
                            TmpRef = qblText.Substring(ptr, RefLen);
                        else
                        {
                            int ptr1 = qblText.IndexOf(EnRefTag, ptr);
                            TmpRef = qblText.Substring(ptr, ptr1 - ptr);
                        }
                    }
                    catch
                    {
                        m_Status = "2. MTS_REF_IDS has incorrect entry for RefId = " + RefId;
                        m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                        m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                        m_ReadConnection.CloseDataReader();
                        return;
                    }
                }
                if (cnt == 1) // that is TRN
                    TrnStr = TmpRef.Replace("\r\n", "").TrimEnd();
                else
                    OtherRef = OtherRef + TmpRef.TrimEnd();
                //Console.WriteLine("trnstr - " + TrnStr + " len-" + TrnStr.Length + " Other - " + OtherRef);
            }
            m_ReadConnection.CloseDataReader();
            /*
             * Long story ... we've been told to store the receive text in a table that's going to be used when we
             * compare messages. Let's store this in the table in the db defined by the 'ReceiverRgwArea' value in 
             * Sim control. Why not just store it in our local area, you ask.
             * 
             * The source data for the compare is coming out of the MDR database but, to be complete, we need to replay
             * that into an MTS area with production code and have MTS feed us the outbound traffic it's going to generate.
             * We want to capture the outbound traffic that some of the links generate on the fly but don't save (bastards).
             * 
             * So, when we replay the source traffic to capture the outbounds, we should store the outbounds in the MDR
             * database.
             * 
             * Later on, we'll replay the traffic into the new code set on MTS and capture its output; that's the target data.
             * And, for that, we want to store the outbound stuff in the local area.
             * 
             * If we do that, then when we run compare, we'll find the source outbound text in the MDR table and we'll
             * find the target text in the local area. 
             * 
             * We'll use ReceiverRgwArea to control which database the data is being stored in.
             * 
             * 
             */
            /*
             * It's probably inefficient as hell to get a new connection for every message we're going to store, but
             * what the heck, let's do it this way for the moment.
             */
            m_rgwArea = util.GetReceiverRgwArea(m_Area);
            DBAccess textConnection = new DBAccess();
            textConnection.Connect(true, m_rgwArea);
            Cmd = string.Format("insert into MTS_RCV_TEXT values ('{0}','{1}','{2}','{3}')", TrnStr, OtherRef, Fmt, qblText.Replace("''", "'").Replace("'", "''"));
            textConnection.Execute(Cmd, true);
            textConnection.DisConnect();
            textConnection.Dispose();
            return;
        }

        private bool ProcessFed(string qblText)
        {
            string Cmd = string.Format("select * from FedControl");
            m_Connection.OpenDataReader(Cmd);
            m_Connection.SQLDR.Read();
            m_ApplId = m_Connection.SQLDR["ApplID"].ToString().TrimEnd();
            DateTime CycleDate = m_Connection.SQLDR.GetDateTime(1);
            m_NoPerBatch = m_Connection.SQLDR.GetInt32(2);
            string m_GenOMAD = m_Connection.SQLDR["GenOmad"].ToString().TrimEnd();
            string m_CheckDups = m_Connection.SQLDR["CheckDups"].ToString().TrimEnd();
            string m_CheckGaps = m_Connection.SQLDR["CheckGaps"].ToString().TrimEnd();
            decimal m_OpenBal = m_Connection.SQLDR.GetSqlMoney(7).ToDecimal();
            m_Connection.CloseDataReader();
            m_SendLine = "LNK_" + m_LineName.Replace("OUT", "IN");
            Cmd = string.Format("delete from FedReceiveAckQue where LineName='{0}'", m_SendLine);
            m_Connection.Execute(Cmd, true);
            m_CycleDate = string.Format("{0:yyyyMMdd}", CycleDate);
            int stat = m_fedFormatter.Fed_parse(m_Connection, m_ReadConnection, qblText, m_FedAba, m_Lterm, m_CycleDate, m_CheckDups, m_CheckGaps, m_SendLine, m_LogWrt, m_Debug, m_ApplId);
            if (stat == 0)
            {
                m_Status = "Fed Ack Formatter failed";
                m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                return true;
            }
            if (m_WriteFile.Equals("Y"))
            {
                if (!m_fedFormatter.WritetoFile(m_Connection, m_rcvOutputStream, m_SendLine))
                {
                    m_Status = "FED Ack writetofile  failed";
                    m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                    m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                    return false;
                }
            }
            if (stat == 2) // Not a payment or nak
                return true;
            //DoBatchAcks();
            if (!(m_AckRuleTableName.TrimEnd() == ""))
            {
                m_StopAckQue = "N"; //if they specified the table no stop queue 'business'
                m_fedFormatter.MakeFinalMsg(m_Connection, m_ReadConnection, m_SendLine, m_AckRuleTableName, m_doedits, m_ApplId);
                return true;
            }
            if (m_StopAckQue == "Y")// create an ActionQue Entry. ActionId is RLSECHPACKQ to remind the user to release the que
            {
                string ActionId = "RLSEFEDACKQ";
                Cmd = string.Format("select *	from ActionQue where ActionId = '{0}'", ActionId);
                m_Connection.OpenDataReader(Cmd);
                bool hasRows = m_Connection.SQLDR.HasRows;
                m_Connection.CloseDataReader();
                if (!hasRows)
                {
                    m_Status = "FED Ack Queue is halted. Release to continue processing messages";
                    m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                    m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                    Cmd = string.Format("insert into ActionQue values ('{0}','{1}',{2},'{3}')", ActionId, DateTime.Now, 1, m_Status);
                    m_Connection.Execute(Cmd, true);
                }
                while (m_ReleaseAckQue == "N")							//Write warning to the user that the queue must be release if they want to continue
                {
                    bool rls_reset = false;
                    get_control_values(m_LineName, rls_reset);
                    m_Status = "Waiting for Releasing ACK Queue.";
                    m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                    m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                    System.Threading.Thread.Sleep(8000);
                }
                // delete the action queue entry.
                Cmd = string.Format("select *	from ActionQue where ActionId = '{0}'", ActionId);
                m_Connection.OpenDataReader(Cmd);
                hasRows = m_Connection.SQLDR.HasRows;
                m_Connection.CloseDataReader();
                if (hasRows)
                {
                    Cmd = string.Format("delete  ActionQue where ActionId ='{0}'", ActionId);
                    m_Connection.Execute(Cmd, true);
                    m_Status = "FED Ack Queue was Released.";
                    m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                    m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                }
                m_fedFormatter.MakeFinalMsg(m_Connection, m_ReadConnection, m_SendLine, "", m_doedits, m_ApplId);
                return true;
            }
            m_fedFormatter.MakeFinalMsg(m_Connection, m_ReadConnection, m_SendLine, "", m_doedits, m_ApplId);
            return true;
        }

        /*	Obsolete in FED IP. I'll keep it here until I see the docs on it.
                private void OnTimerEvent(object source, ElapsedEventArgs e)
                {
                    _Timer.Stop();
                    m_fedFormatter.BatchAck(m_AckConnection, m_AckReadConnection, m_SendLine, m_Lterm, m_CycleDate, m_NoPerBatch, true, 0, 0);
                    m_NoOfProcessedFeds = 0;
                }

                private void DoBatchAcks()
                {
                    m_NoOfProcessedFeds++;
                    if (m_NoOfProcessedFeds == 1)
                    {
                        //set up the timer for 10 sec. If we don't reach noperbatch within 10 sec we are going to ack all newly processed Feds.
                        _Timer.Start();
                    }
                    if (m_NoOfProcessedFeds > m_NoPerBatch)
                    {
                        _Timer.Stop();
                        m_fedFormatter.BatchAck(m_AckConnection, m_AckReadConnection, m_SendLine, m_Lterm, m_CycleDate, m_NoPerBatch, true, 0, 0);
                        m_NoOfProcessedFeds = 0;
                    }
                }
        */
        private bool ProcessChips(string qblText)
        {
            string prio = "0";
            string Cmd = string.Format("select * from ChipsControl");
            m_Connection.OpenDataReader(Cmd);
            m_Connection.SQLDR.Read();
            decimal m_Act_fund = m_Connection.SQLDR.GetSqlMoney(1).ToDecimal();
            string m_DupPsnChk = m_Connection.SQLDR["Dup_psn_check"].ToString().TrimEnd();
            string m_NewDay = m_Connection.SQLDR["New_day"].ToString().TrimEnd();
            string m_Gen_ssn = m_Connection.SQLDR["Gen_ssn"].ToString().TrimEnd();
            DateTime m_Valdata = m_Connection.SQLDR.GetDateTime(0);
            m_Connection.CloseDataReader();
            Cmd = string.Format("delete from ChpReceiveAckQue where LineName='{0}'", m_LineName);
            m_Connection.Execute(Cmd, true);
            int stat = m_chpFormatter.Chp_parse(m_Connection, qblText, m_LineName, m_LogWrt, m_Debug, m_DupPsnChk, m_NewDay, m_Act_fund);
            if (stat == 0)
            {
                m_Status = "Chp Ack Formater failed";
                m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                return true;
            }
            if (m_WriteFile.Equals("Y"))
            {
                if (!m_chpFormatter.WritetoFile(m_Connection, m_rcvOutputStream, m_LineName))
                {
                    m_Status = "Chp Ack writetofile  failed";
                    m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                    m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                    return false;
                }
            }
            if (stat == 2) // Not a payment or PSN DUP nak
                return true;

            if (!(m_AckRuleTableName.TrimEnd() == ""))
            {
                m_StopAckQue = "N"; //if they specified the table no stop queue 'business'
                //				Cmd=string.Format("select * from ChpAckNakRuleTable where RuleName = '{0}'",m_AckRuleTableName);
                //				m_Connection.OpenDataReader(Cmd);
                //				m_Connection.SQLDR.Read();
                //				string AbaOrString=m_Connection.SQLDR["AbaOrString"].ToString().TrimEnd();
                //				string AbaString=m_Connection.SQLDR["AbaString"].ToString().TrimEnd();
                //				string err_code=m_Connection.SQLDR["ErrorCode"].ToString().TrimEnd();
                //				string errno=m_Connection.SQLDR["NoOfErrors"].ToString().TrimEnd();
                //				m_Connection.CloseDataReader();
                //				string Rulestr = AbaOrString+"/"+AbaString+"/"+err_code+"/"+errno;
                //				m_Finalmsg = m_chpFormatter.MakeFinalMsg(m_ChpAba,m_Connection,m_LineName,Rulestr);
                m_Finalmsg = m_chpFormatter.MakeFinalMsg(m_ChpAba, m_Connection, m_ReadConnection, m_LineName, m_AckRuleTableName, m_doedits);
                m_SendLine = "LNK_" + m_LineName.Replace("OUT", "IN");
                Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", GetChipsLine(m_SendLine), prio, m_Finalmsg);
                m_Connection.Execute(Cmd, false);

                if ((m_Finalmsg.IndexOf("25[025]") != -1) && (m_Finalmsg.IndexOf("[076]") == -1))
                {
                    //				string Resolver = m_chpFormatter.MakeResolver(m_ChpAba, m_Finalmsg);
                    // Get SSN, ISN, PSN, Amount from store response [025] and make resolver 
                    string Ssn = m_Finalmsg.Substring(81, 7);
                    string Isn = m_Finalmsg.Substring(88, 6);
                    string Psn = m_Finalmsg.Substring(m_Finalmsg.IndexOf("[27") + 5, 6);
                    decimal Amt = Convert.ToDecimal(m_Finalmsg.Substring(m_Finalmsg.IndexOf("[260") + 5, 12));
                    Amt = Amt / 100;
                    Cmd = string.Format("insert into ResolverQ values ('{0}','{1}','{2}',{3},'{4}','{5}')", Psn, Isn, Ssn, Amt, m_SendLine, qblText);
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("insert into PSNQueue values ('{0}','{1}','{2}', 0, {3},'S','{4}','{5}')", Psn, Ssn, Isn, Amt, DateTime.Now, m_Finalmsg);
                    m_Connection.Execute(Cmd, false);
                }
                return true;
            }

            if (m_StopAckQue == "Y")// create an ActionQue Entry. ActionId is RLSECHPACKQ to remind the user to release the que
            {
                string ActionId = "RLSECHPACKQ";
                Cmd = string.Format("select *	from ActionQue where ActionId = '{0}'", ActionId);
                m_Connection.OpenDataReader(Cmd);
                bool hasRows = m_Connection.SQLDR.HasRows;
                m_Connection.CloseDataReader();
                if (!hasRows)
                {
                    m_Status = "Chips Ack Queue is halted. Release to continue processing messages";
                    m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                    m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                    Cmd = string.Format("insert into ActionQue values ('{0}','{1}',{2},'{3}')", ActionId, DateTime.Now, 1, m_Status);
                    m_Connection.Execute(Cmd, true);
                }
                while (m_ReleaseAckQue == "N")							//Write warning to the user that the queue must be release if they want to continue
                {
                    bool rls_reset = false;
                    get_control_values(m_LineName, rls_reset);
                    m_Status = "Waiting for Releasing ACK Queue.";
                    m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                    m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                    System.Threading.Thread.Sleep(8000);
                }
                // delete the action queue entry.
                Cmd = string.Format("select *	from ActionQue where ActionId = '{0}'", ActionId);
                m_Connection.OpenDataReader(Cmd);
                hasRows = m_Connection.SQLDR.HasRows;
                m_Connection.CloseDataReader();
                if (hasRows)
                {
                    Cmd = string.Format("delete  ActionQue where ActionId ='{0}'", ActionId);
                    m_Connection.Execute(Cmd, true);
                    m_Status = "Chips Ack Queue was Released.";
                    m_Connection.RecordEvent(0, m_myProcName, string.Format("{0}: {1}", DateTime.Now, m_Status), m_Area);
                    m_Connection.ConsoleWrite(m_Debug, m_myProcName, m_LogWrt, string.Format("{0}\r\n", m_Status));
                }
                m_Finalmsg = m_chpFormatter.MakeFinalMsg(m_ChpAba, m_Connection, m_ReadConnection, m_LineName, "", m_doedits);
                m_SendLine = "LNK_" + m_LineName.Replace("OUT", "IN");
                Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", GetChipsLine(m_SendLine), prio, m_Finalmsg);
                m_Connection.Execute(Cmd, false);
                return true;
            }
            m_Finalmsg = m_chpFormatter.MakeFinalMsg(m_ChpAba, m_Connection, m_ReadConnection, m_LineName, "", m_doedits);
            m_SendLine = "LNK_" + m_LineName.Replace("OUT", "IN");
            m_Finalmsg = m_Finalmsg.Replace("'", "''");
            Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", GetChipsLine(m_SendLine), prio, m_Finalmsg);
            m_Connection.Execute(Cmd, false);
            if ((m_Finalmsg.IndexOf("25[025]") != -1) && (m_Finalmsg.Substring(m_Finalmsg.IndexOf("25[025]") + 44, 1) != "3"))
            {
                //				string Resolver = m_chpFormatter.MakeResolver(m_ChpAba, m_Finalmsg);
                // Get SSN, ISN, PSN, Amount from store response [025] and make resolver 
                string Ssn = m_Finalmsg.Substring(81, 7);
                string Isn = m_Finalmsg.Substring(88, 6);
                string Psn = m_Finalmsg.Substring(m_Finalmsg.IndexOf("[27") + 5, 6);
                decimal Amt = Convert.ToDecimal(m_Finalmsg.Substring(m_Finalmsg.IndexOf("[260") + 5, 12));
                Amt = Amt / 100;
                Cmd = string.Format("insert into ResolverQ values ('{0}','{1}','{2}',{3},'{4}','{5}')", Psn, Isn, Ssn, Amt, m_SendLine, qblText.Replace("'", "''"));
                m_Connection.Execute(Cmd, false);
                Cmd = string.Format("insert into PSNQueue values ('{0}','{1}','{2}', 0, {3},'S','{4}','{5}')", Psn, Ssn, Isn, Amt, DateTime.Now, m_Finalmsg);
                m_Connection.Execute(Cmd, false);
            }
            return true;
        }

        private string GetChipsLine(string line) // get the least busy line to send responses back like CHIPS
        {
            string Cmd = string.Format("select min(msgcount) as cnt, linename from chplinelist group by msgcount, linename");
            m_Connection.OpenDataReader(Cmd);
            string line1 = line;
            try
            {
                m_Connection.SQLDR.Read();
                line1 = "LNK_" + m_Connection.SQLDR["LineName"].ToString().TrimEnd();
                Console.Write("came from " + line + "  goes over " + line1 + "\n");
            }
            catch
            {
            }
            m_Connection.CloseDataReader();
            return line1;
        }


        private bool ProcessSwifts(string qblText)
        {
            string prio = "0";

            string Cmd = string.Format("delete from SwfReceiveAckQue where LineName='{0}'", m_LineName);
            m_Connection.Execute(Cmd, true);
            if (!m_swfFormatter.Swf_parse(m_Connection, qblText, m_LineName, m_LogWrt, m_Debug))
            {
                m_Status = "Swf Ack Formater failed or Nothing to send";
                m_Connection.RecordEvent(INFO, m_myProcName, string.Format("{0}", m_Status), m_Area);
                LogIt(m_Status, m_Debug);
                return true;
            }
            if (m_WriteFile.Trim() == "Y")
            {
                if (!m_swfFormatter.WritetoFile(m_Connection, m_rcvOutputStream, m_LineName, m_LogWrt))
                {
                    m_Status = "Swf Ack writetofile  failed";
                    m_Connection.RecordEvent(ERROR, m_myProcName, string.Format("{0}", m_Status), m_Area);
                    LogIt(m_Status, "Y");
                    return false;
                }
            }
            if (!(m_AckRuleTableName.Trim().Length == 0))
            {
                m_StopAckQue = "N"; //if they specified the table no stop queue
                //				Cmd=string.Format("select *	from SwfAckNakRuleTable where RuleName = '{0}'",m_AckRuleTableName);
                //				m_Connection.OpenDataReader(Cmd);
                //				m_Connection.SQLDR.Read();
                //				string BicOrString=m_Connection.SQLDR["BicOrString"].ToString().TrimEnd();
                //				string BicString=m_Connection.SQLDR["BicString"].ToString().TrimEnd();
                //				string err_code=m_Connection.SQLDR["ErrorCode"].ToString().TrimEnd();
                //				string LineN=m_Connection.SQLDR["LineN"].ToString().TrimEnd();
                //				m_Connection.CloseDataReader();
                //				if (LineN.Length==1)
                //					LineN="0"+LineN;
                //				string Rulestr = BicOrString+"/"+BicString+"/"+err_code+"/"+LineN;
                //				m_Finalmsg = m_swfFormatter.MakeFinalMsg(m_Connection,m_LineName,Rulestr);
                m_Finalmsg = m_swfFormatter.MakeFinalMsg(m_Connection, m_ReadConnection, m_LineName, m_AckRuleTableName.Trim(), m_doedits);
                m_SendLine = "LNK_" + m_LineName.Replace("_SND", "_RCV");
                Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, m_Finalmsg);
                m_Connection.Execute(Cmd, false);
                return true;
            }
            if (m_StopAckQue == "Y")// create an ActionQue Entry. ActionId is RLSESWFACKQ to remind the user to release the que
            {
                string ActionId = "RLSESWFACKQ";
                Cmd = string.Format("select *	from ActionQue where ActionId = '{0}'", ActionId);
                m_Connection.OpenDataReader(Cmd);
                bool hasRows = m_Connection.SQLDR.HasRows;
                m_Connection.CloseDataReader();
                if (!hasRows)
                {
                    m_Status = "Swift Ack Queue is halted. Release to continue receiving messages";
                    m_Connection.RecordEvent(INFO, m_myProcName, string.Format("{0}", m_Status), m_Area);
                    LogIt(m_Status, m_Debug);
                    Cmd = string.Format("insert into ActionQue values ('{0}','{1}',{2},'{3}')", ActionId, DateTime.Now, 1, m_Status);
                    m_Connection.Execute(Cmd, true);
                }
                while (m_ReleaseAckQue == "N")//Write warning to the user that the queue must be release if they want to continue
                {
                    bool rls_reset = false;
                    get_control_values(m_LineName, rls_reset);
                    m_Status = "Waiting for Releasing ACK Queue.";
                    m_Connection.RecordEvent(INFO, m_myProcName, string.Format("{0}", m_Status), m_Area);
                    LogIt(m_Status, m_Debug);
                    System.Threading.Thread.Sleep(8000);
                }
                // delete the action queue entry.
                Cmd = string.Format("select *	from ActionQue where ActionId = '{0}'", ActionId);
                m_Connection.OpenDataReader(Cmd);
                hasRows = m_Connection.SQLDR.HasRows;
                m_Connection.CloseDataReader();
                if (hasRows)
                {
                    Cmd = string.Format("delete ActionQue where ActionId ='{0}'", ActionId);
                    m_Connection.Execute(Cmd, true);
                    m_Status = "Swift Ack Queue was Released.";
                    m_Connection.RecordEvent(INFO, m_myProcName, string.Format("{0}", m_Status), m_Area);
                    LogIt(m_Status, m_Debug);
                }
                m_Finalmsg = m_swfFormatter.MakeFinalMsg(m_Connection, m_ReadConnection, m_LineName, "", m_doedits);
                m_SendLine = "LNK_" + m_LineName.Replace("_SND", "_RCV");
                Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, m_Finalmsg);
                m_Connection.Execute(Cmd, false);
                return true;
            }
            m_Finalmsg = m_swfFormatter.MakeFinalMsg(m_Connection, m_ReadConnection, m_LineName, "", m_doedits);
            m_SendLine = "LNK_" + m_LineName.Replace("_SND", "_RCV");
            Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, m_Finalmsg);
            m_Connection.Execute(Cmd, false);
            return true;
        }

        private void GetSimValues()
        {
            string Cmd = string.Format("select Area, RootDir, Debug, ChpAba, FedAba, ChangeRef from SimulatorControl");
            m_Connection.OpenDataReader(Cmd);
            m_Connection.SQLDR.Read();
            string l_Area = m_Connection.SQLDR["Area"].ToString().TrimEnd();
            m_ChpAba = m_Connection.SQLDR["ChpAba"].ToString().TrimEnd();
            m_FedAba = m_Connection.SQLDR["FedAba"].ToString().TrimEnd();
            m_Debug = m_Connection.SQLDR["Debug"].ToString().TrimEnd().ToUpper();
            m_RootDir = m_Connection.SQLDR["RootDir"].ToString().TrimEnd();
            m_ChangeRef = m_Connection.SQLDR["ChangeRef"].ToString().TrimEnd();
            m_Connection.CloseDataReader();
            if ((m_Area != l_Area) && (l_Area != "test"))
            {
                string st = "Process not Started. Areas Discrepancy";
                m_Connection.RecordEvent(ERROR, m_myProcName, string.Format("{0}", st), m_Area);
                LogIt(st, "Y");
                throw new Exception("Receiver thread has bad area specified. area is " + m_Area);
                //            Thread.CurrentThread.Interrupt();
            }
        }

        private void get_control_values(string m_LineName, bool rls_reset)
        {
            string Cmd;
            Cmd = string.Format("select source, StopAckQue, WritetoFile, FileName, AckRuleTableName," +
                " ReleaseAckQue, TimeDelay, nSelect, DoEdits, FmtName, MsgFormat, RefId " +
                " from receivecontrol where LineName = '{0}'", m_LineName);
            m_Connection.OpenDataReader(Cmd);
            m_Connection.SQLDR.Read();
            m_Source = m_Connection.SQLDR["source"].ToString().TrimEnd();
            m_StopAckQue = m_Connection.SQLDR["StopAckQue"].ToString().TrimEnd();
            m_WriteFile = m_Connection.SQLDR["WritetoFile"].ToString().TrimEnd();
            m_FileName = m_Connection.SQLDR["FileName"].ToString().TrimEnd();
            m_AckRuleTableName = m_Connection.SQLDR["AckRuleTableName"].ToString().TrimEnd();
            m_ReleaseAckQue = m_Connection.SQLDR["ReleaseAckQue"].ToString().TrimEnd();
            m_TimeDelay = m_Connection.SQLDR.GetInt32(6);
            m_nSelect = m_Connection.SQLDR.GetInt32(7);
            m_doedits = m_Connection.SQLDR["DoEdits"].ToString().TrimEnd();
            m_fmtname = m_Connection.SQLDR["FmtName"].ToString().TrimEnd();
            m_MsgFormat = m_Connection.SQLDR["MsgFormat"].ToString().TrimEnd();
            m_RefId = m_Connection.SQLDR.GetInt32(11);
            m_Connection.CloseDataReader();
            if ((rls_reset) && (m_ReleaseAckQue != "N"))
            {
                Cmd = string.Format("update ReceiveControl set ReleaseAckQue='N' where LineName='{0}'", m_LineName);
                m_Connection.Execute(Cmd, true);
            }
        }

        private void doRgwReceive(string inBuf, string rgwArea)
        {
            bool saveXml = false;
            if (m_WriteFile == "Y")
                saveXml = true;
            DBAccess rgwConnection = new DBAccess();
            rgwConnection.Connect(true, rgwArea);
            rlink.processRgwBuffer(inBuf, rgwArea, rgwConnection, m_LogWrt, saveXml);
            rgwConnection.Dispose();
        }

        private void doSwfchkDla(string inbound)
        {
            //FileStream out_file;	
            //StreamWriter swriter;
            //out_file = new FileStream("c:\\xyz.txt", 
            //	FileMode.Create, FileAccess.Write);
            //swriter = new StreamWriter(out_file);
            char backslash = '\\';
            int i;
            int ptr, ptr1;
            string buf;
            bool tst;
            tst = false;
            if (tst)
            {
                string tstbuf;
                string yoda = "DB      00000400050726002305CNF" +
                    "07430000000000000000!!CNF!103!0!|" +
                    "0!050726USD3000,00!BKT!!!DBT!!0!!2005072600002305!!20050725ZUE00054!" +
                    "SWF!050726GIBAATWWAXXX8352308659!!!!BT!!!NYKO!050726!|" +
                    "1!!D-4924223!Paula Luise Buchmeier!!Speisingerstr 221/10!1230 Wien!OEsterreich!|" +
                    "4!!S-GIBAATWW!ERSTE BANKDER OESTERREICHICHEN!!SPARKASSEN AG!POBOX 255  SCHUBERTRING 5!1011VIENNA," +
                    "AUSTRIA!|" +
                    "5!!D-655095" +
                    "2580!ERSTE BANK DER OESTERREICHI" +
                    "SCHEN!!SPARKASSEN AG!POBOX 255 " +
                    "SCHUBERTRING 5!1011 VIENNA, AUST" +
                    "RIA!!!!!!DDA!D-6550952580!USD300" +
                    " BANK DER OESTERREICHISCHEN!!SPA" +
                    "RKASSEN AG SWIFT CHECK ACCT!SCHU" +
                    "BERTRING 5 P.O. BOX 255!A-1011 V" +
                    "IENNA, AUSTRIA!!!B!!!DDA!D-65505" +
                    "52582!USD3000,00!00JB!|8!!!Mr. C" +
                    "yrus Arthur Abtahi!!1341 Caminit" +
                    "o Gabaldon!San Diego!California 92108 USA!|";

                //DB      00000300SK05072600000218

                //[^ISI2data: 0xda (218.) bytes (ascii) 19-Aug-2005 19:44:17.790]

                //00000305072620SA\DLA\\\SK0507260000\050726002305CNF\\|
                //0\050726USD3000,00\BKT\\\DBT\\0\\2005072600002305\\20050725ZUE00054\
                //SWF\050726GIBAATWWAXXX8352308659\\\\BT\\\NYKO\050726\|
                //D\1\SCK\050726164106\0001/01-6010\117872\|

                tstbuf = yoda.Replace("!", "\\");

                //swriter.WriteLine("tstbuf");
                //swriter.Write(tstbuf);
                //swriter.Write("\r\n\r\n");

                string hRefDate = tstbuf.Substring(16, 6);
                string hRef = tstbuf.Substring(16, 15);
                string f1 = string.Format("{0}20SA", hRefDate);
                string f2 = "DLA";
                string f3 = string.Format("SK{0}0000", hRefDate);

                string bsString = Convert.ToString(backslash);

                StringBuilder sbldr = new StringBuilder();
                sbldr.Length = 0;
                // Isi2 header.
                sbldr.Append("DB      ??????");
                sbldr.Append("00SK");
                sbldr.Append(hRefDate);
                sbldr.Append("0000    size");
                // start the data.
                sbldr.Append("??????");
                sbldr.Append(f1);
                sbldr.Append(backslash);
                sbldr.Append(f2);
                for (i = 0; i < 3; i++)
                    sbldr.Append(backslash);
                sbldr.Append(f3);
                sbldr.Append(backslash);
                sbldr.Append(hRef);
                for (i = 0; i < 2; i++)
                    sbldr.Append(backslash);
                sbldr.Append("|");
                // Now extract line0 from the text and glue that in.
                ptr = tstbuf.IndexOf("|0");
                ptr++;
                ptr1 = tstbuf.IndexOf("|", ptr);
                string line0 = tstbuf.Substring(ptr, ptr1 - ptr + 1);
                //Console.WriteLine(line0);
                //sbldr.Append("\r\n");
                sbldr.Append(line0);
                //sbldr.Append("\r\n");

                sbldr.Append("D");
                sbldr.Append(backslash);
                sbldr.Append("1");
                sbldr.Append(backslash);
                sbldr.Append("SCK");
                sbldr.Append(backslash);
                sbldr.Append(hRefDate);
                string tmp = string.Format("{0:D2}{1:D2}{2:D2}",
                    DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
                sbldr.Append(tmp);
                sbldr.Append(backslash);
                sbldr.Append("0001/01-6010");
                sbldr.Append(backslash);
                sbldr.Append("117872");
                sbldr.Append(backslash);
                sbldr.Append("|");

                buf = Convert.ToString(sbldr);

                tmp = string.Format("{0:D4}", buf.Length - 36);
                buf = buf.Replace("size", tmp);
                //swriter.WriteLine("sbldr");
                //Console.WriteLine(buf);
                //swriter.Write(buf);
                //swriter.Flush();
                //swriter.Close();
                m_SendLine = "LNK_" + m_LineName.Replace("_SND", "_RCV");
                string prio = "0";
                string Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, buf);
                m_Connection.Execute(Cmd, false);
            }
            else
            {
                string hRefDate = inbound.Substring(16, 6);
                string hRef = inbound.Substring(16, 15);
                string f1 = string.Format("{0}20SA", hRefDate);
                string f2 = "DLA";
                string f3 = string.Format("SK{0}0000", hRefDate);

                StringBuilder sbldr = new StringBuilder();
                sbldr.Length = 0;
                // Isi2 header.
                sbldr.Append("DB      ??????");
                sbldr.Append("00SK");
                sbldr.Append(hRefDate);
                sbldr.Append("0000    size");
                // start the data.
                sbldr.Append("!!!!!!");
                sbldr.Append(f1);
                sbldr.Append(backslash);
                sbldr.Append(f2);
                for (i = 0; i < 3; i++)
                    sbldr.Append(backslash);
                sbldr.Append(f3);
                sbldr.Append(backslash);
                sbldr.Append(hRef);
                for (i = 0; i < 2; i++)
                    sbldr.Append(backslash);
                sbldr.Append("|");
                // Now extract line0 from the text and glue that in.
                ptr = inbound.IndexOf("|0");
                ptr++;
                ptr1 = inbound.IndexOf("|", ptr);
                string line0 = inbound.Substring(ptr, ptr1 - ptr + 1);
                //Console.WriteLine(line0);
                //sbldr.Append("\r\n");
                sbldr.Append(line0);
                //sbldr.Append("\r\n");

                sbldr.Append("D");
                sbldr.Append(backslash);
                sbldr.Append("1");
                sbldr.Append(backslash);
                sbldr.Append("SCK");
                sbldr.Append(backslash);
                sbldr.Append(hRefDate);
                string tmp = string.Format("{0:D2}{1:D2}{2:D2}",
                    DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
                sbldr.Append(tmp);
                sbldr.Append(backslash);
                sbldr.Append("0001/01-6010");
                sbldr.Append(backslash);
                sbldr.Append("117872");
                sbldr.Append(backslash);
                sbldr.Append("|");
                sbldr.Append("\r\n");

                buf = Convert.ToString(sbldr);

                tmp = string.Format("{0:D4}", buf.Length - 36);
                buf = buf.Replace("size", tmp);

                m_SendLine = "LNK_" + m_LineName.Replace("_SND", "_RCV");
                string prio = "0";
                string Cmd = string.Format("insert into {0} values ('{1}',0,'{2}')", m_SendLine, prio, buf);
                m_Connection.Execute(Cmd, true);
            }
        }
        private void LogIt(string msg, string dbg)
        {
            string tmp = m_LineName + " " + msg;
            m_Connection.ConsoleWrite(dbg, "Receiver", m_LogWrt, tmp);
        }

        private void CheckOutputStatus()
        {
            //			lock(this)					// we can insert this out if we know the main thread will call this 
            {

                string oldFileName = m_FileName;
                bool rls_reset = false;
                if (m_Swift || m_Chips)
                    rls_reset = true;
                get_control_values(m_LineName, rls_reset);
                if (m_WriteFile.Equals("N"))				// if file is not being written to.
                {
                    if (m_rcvOutputStream != null)			// if it was in the past.
                    {
                        //Console.WriteLine("Line {1}: Closing file {0}", oldFileName, m_LineName);
                        // Some of the traffic is being written in xml format. If so, we need
                        // to include the top-level tag. Swift only for the moment...
                        if (m_Source.Equals("SWF"))
                        {
                            m_rcvOutputStream.WriteLine("</msgs>");
                        }
                        m_rcvOutputStream.Close();
                        m_rcvOutputStream = null;
                    }
                }
                else										// we are writing to file
                {
                    if (!oldFileName.Equals(m_FileName))			// if it was in the past.
                    {
                        if (m_rcvOutputStream != null)			// if it was in the past.
                        {
                            //Console.WriteLine("Line {1}: Closing file {0}", oldFileName, m_LineName);
                            if (m_Source.Equals("SWF"))
                            {
                                m_rcvOutputStream.WriteLine("</msgs>");
                            }
                            m_rcvOutputStream.Close();
                        }
                        m_rcvOutputStream = null;
                    }
                    if (m_rcvOutputStream == null)
                    {
                        // Create a new stream to write to the file.
                        // Put a timestamp on the filename so it's unique.
                        // Leave the original file name - m_FileName - alone or else we'll
                        // end up closing and opening a new xml file for every trn.
                        BackEndSubs util = new BackEndSubs();
                        string tag = "_" + util.GetTimestampTag();
                        int x = m_FileName.IndexOf(".");
                        string tmp_FileName = m_FileName.Insert(x, tag);
                        if (m_Source.Equals("SWF"))
                        {
                            x = tmp_FileName.IndexOf(".");
                            x++;
                            tmp_FileName = tmp_FileName.Remove(x, tmp_FileName.Length - x);
                            tmp_FileName = tmp_FileName.Insert(x, "xml");
                        }

                        //Console.WriteLine("Line {1}: Opening file {0}", tmp_FileName, m_LineName);
                        FileStream file = new FileStream(tmp_FileName, FileMode.OpenOrCreate, FileAccess.Write);
                        m_rcvOutputStream = new StreamWriter(file);

                        // See if this is one of our xml files.
                        if (m_Source.Equals("SWF"))
                        {
                            m_rcvOutputStream.WriteLine("<msgs>");
                        }
                    }
                }
            }
        }

    }

    class RTController
    {
        private DBAccess dbReader;
        private DBAccess dbWriter;

        public RTController()
        {
            dbReader = new DBAccess();
            dbWriter = new DBAccess();
        }

        [STAThread]
        static void Main(string[] args)
        {
            RTController rtController = new RTController();
            rtController.Run(args);
        }

        private void Run(string[] args)
        {

            string area = args[0];
            dbReader.Connect(false, area);


            BackEndSubs util = new BackEndSubs();
            string ldir = util.GetLogDir(dbReader);
            string ts = util.GetTimestampTag();
            string filename = string.Format("{0}Receiver_{1}_Controller.log", ldir, ts);
            FileStream file1 = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw = new StreamWriter(file1);

            dbReader.RecordEvent(0, "Receivers", string.Format("{0}", "Started all threads"), area);
            // maintain a list of thread objects in case we want to control individual threads from this thread.
            ArrayList threadList = new ArrayList();
            ArrayList objectList = new ArrayList();
            int idx = 0;
            // lines for debugging purposes. They should be commented and the line below uncommented.
            // string dbCmd = "select LineName, Source from ReceiveControl where linename='175_INTA_F_SND'";
            //string dbCmd = "select LineName, Source from ReceiveControl where linename='AU1_SWIFT_IN'";
            //string dbCmd = "select LineName, Source from ReceiveControl where linename='GB3_FXLM_IN'";

            // This line below is the one for production.
            string dbCmd = "select LineName, Source from ReceiveControl";
            dbReader.OpenDataReader(dbCmd);
            while (dbReader.SQLDR.Read())
            {
                string LineName = dbReader.SQLDR[0].ToString().TrimEnd();
                string Src = dbReader.SQLDR[1].ToString().TrimEnd();
                string threadName = LineName + "_" + idx;
                RcvThread rcvThread = new RcvThread(area, LineName, Src);
                Thread newThread = new Thread(new ThreadStart(rcvThread.dorcv));
                newThread.Name = threadName;
                objectList.Add(rcvThread);
                threadList.Add(newThread);
                newThread.Start();
                string tmp = string.Format("Creating Receiver: {0}", threadName);
                Console.WriteLine(tmp);
            }

            sw.Flush();

            // close db connections dm-12-06-05
            dbReader.DisConnect();
            // for now
            Thread.Sleep(System.Threading.Timeout.Infinite);
            // Wait for them all to finish. They never will, of course ;-)
            //
            foreach (Thread rThread in threadList)
            {
                try
                {
                    rThread.Join();
                }
                catch { }
            }
            sw.WriteLine("done with all threads... exiting");
            sw.Close();
        }

    }
}