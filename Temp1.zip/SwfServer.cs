/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Timers;
using Simulator.TcpIp;
using System.Net;
using Simulator.DBLibrary;
using Simulator.QueueInterface;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace SwfServer
/*
   28-Oct-05	JR	Watch out for NextOsn or m_Sequence going past 999999 (6 digits);
					wrap it back to 1 if that happens.
 * 
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 24-May-17	JR  Comment out the load of des from C: drive and, for BBT, load it from D:
 * 
*/
{
    /// <summary>
    /// This is SwfServer. It sends data to the MTS. It gets the data from LNK_queue.
    /// </summary>
    public class SwfServer
    {
		// BBT - our stuff lives on the D: drive over there ...
		
        // [DllImport("C:\\simulator\\allbin\\Des.dll", EntryPoint = "des_pr", CharSet = CharSet.Auto)]
	[DllImport("Des.dll", EntryPoint = "des_pr", CharSet = CharSet.Auto)]
	public static extern int des_pr([MarshalAs(UnmanagedType.LPArray)] byte[] m_drv, [MarshalAs(UnmanagedType.LPArray)] byte[] m_pass);
        private DBAccess m_readConnection;
        private DBAccess m_writeConnection;
        private bool m_DBConnected;
        private static string line_name;
        private string OurHostAddress;
        private string Area;
        private string Debug;
        private int debugLevel;
        private string RootDir;
        private string Args;
        private string myProcName;
        private string status;
        private StreamWriter sw;
        private Process myProcess;

        private string m_RefNo;
        private enum LinkState { AwaitingRefNo, AwaitingA21, Sending, SendF25, SendA26, SendClose };
        private LinkState m_LinkState;
        private bool m_timerBusy;
        private System.Timers.Timer m_Timer;
        private TcpIpClient m_IpMtsClient;
        private TcpIpServer m_IpOurServer;
        int nSel;
        int NextOsn;
        bool do_login_proc = true;
        string m_swftid;
        private string m_ClientAddress;
        string qline_name;
        string m_ServerAddress;
        int m_ServerPort;
        string m_newswf;
        int m_ClientPort;
        private int m_Sequence;
        private int m_TimerFiredCount;
        private int SNLADPHDRTYPE_FINHANDLE;
        QueueInterface m_QI;
        byte[] m_pass = new byte[200];
	byte[]  m_drv = new byte[2];

        public SwfServer()
        {
            m_readConnection = new DBAccess();
            m_writeConnection = new DBAccess();
            m_DBConnected = false;
            m_ClientAddress = "localhost";
            m_QI = null;
            m_pass = System.Text.Encoding.ASCII.GetBytes("marina12345678901234567890123456");
            m_drv = System.Text.Encoding.ASCII.GetBytes("d:");
        }

        [STAThread]
        // Server comes up and binds to the SWFClient (local port and ourhostname) and waits for
        // RefNo from the SwfClient. After that it connects to MTS application and starts the
        // session.
        // m_IpMtsClient is used to communicate to MTS.
        //   It connects to MTS.
        // m_IpOurServer is used to communicate to SwfClient (our program).
        //   It waits for connection from SwfClient. 
        //
        static void Main(string[] args)
        {
            SwfServer serv = new SwfServer();
            serv.doserv(args);
        }
        private void doserv(string[] args)
        {
            Area = args.GetValue(0).ToString();
            line_name = args.GetValue(1).ToString();
            qline_name = "LNK_" + line_name;
            myProcName = "SwfServer" + "_" + Area + "_" + line_name;
            Args = String.Format("{0} {1}", args[0].TrimEnd(), args[1].TrimEnd());
            myProcess = Process.GetCurrentProcess();
            get_sim_values();
            //Register the process. 
            if (!m_readConnection.RegisterProcess(m_readConnection, m_writeConnection, "SwfServer", Args, sw, debugLevel, Area))
            {
                status = "Error registering a process.";
                m_readConnection.RecordEvent(0, myProcName, string.Format("{0}", status), Area);
                m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
                return;
            }
            get_line_values(line_name);

            // Server LISTENS and WAITS for connections from SwfClient. Therefore should not be stopped at ALL.
            m_IpOurServer = new TcpIpServer(m_ClientAddress, m_ClientPort);
            if (m_newswf == "V1")
                m_IpOurServer.readLength = 40;
            else
                m_IpOurServer.readLength = 8;
            m_IpOurServer.eventDelegateClientDisConnected += new LinkEventHandler(OnOurSwfClientDisConnected);
            m_IpOurServer.eventDelegateDataRecieved += new ReceivedEventHandler(OnOurServerDataRecieved);
            m_IpOurServer.eventDelegateClientConnected += new LinkEventHandler(OnOurSwfClientConnected);
            m_IpOurServer.Start(); // listens on local port to the SWFClient(our program)

            // Client CONNECTS to MTS.
            m_IpMtsClient = new TcpIpClient(m_ServerAddress, m_ServerPort);
            if (m_newswf == "V1")
                m_IpMtsClient.readLength = 40;
            else
                m_IpMtsClient.readLength = 8;
            m_IpMtsClient.eventDelegateDataRecieved += new ReceivedEventHandler(OnMtsClientDataRecieved);
            m_IpMtsClient.eventDelegateServerDisConnected += new LinkEventHandler(OnMtsDisConnected);

            m_timerBusy = false;
            m_LinkState = LinkState.AwaitingRefNo;

            m_Sequence = 3;
            m_DBConnected = false;
            SNLADPHDRTYPE_FINHANDLE = -2;
            m_TimerFiredCount = 0;

            for (; ; )		///  loop for ever
            {
                if (do_login_proc)
                {
                    // before we start sending traffic we have to delete ALL F21s (ACKS) that are awaiting to go to MTS.
                    // Failure to do so will bring swfapc down. It is done to comply with SWF protocol. SWFAPC does not process ACKs for 
                    // msgs that are not on the PND queue. 
                    string Cmd = string.Format("delete from {0} where prio='0'", qline_name);
                    m_writeConnection.Execute(Cmd, true);
                }
                System.Threading.Thread.Sleep(-1);
                do_login_proc = false;
            }
        }

        private void get_sim_values()
        {
            if (!m_DBConnected)
            {
                m_readConnection.Connect(false, Area);
                m_writeConnection.Connect(true, Area);
                m_DBConnected = true;
            }
            string Cmd;
            string l_area;
            Cmd = string.Format("select OurHostAddress, Area, RootDir, Debug, MTSHostName, SwfVersion from SimulatorControl");
            m_readConnection.OpenDataReader(Cmd);
            m_readConnection.SQLDR.Read();
            OurHostAddress = m_readConnection.SQLDR["OurHostAddress"].ToString().TrimEnd();
            l_area = m_readConnection.SQLDR["Area"].ToString().TrimEnd();
            Debug = m_readConnection.SQLDR["Debug"].ToString().TrimEnd();
            debugLevel = 0;
            try
            {
                debugLevel = int.Parse(Debug);
            }
            catch { }
            RootDir = m_readConnection.SQLDR["RootDir"].ToString().TrimEnd();
            m_ServerAddress = m_readConnection.SQLDR["MTSHostName"].ToString().TrimEnd();
            m_newswf = m_readConnection.SQLDR["SwfVersion"].ToString().TrimEnd();
            if ((m_newswf != "V0") && (m_newswf != "V1"))
                m_newswf = "V0";
            m_readConnection.CloseDataReader();
            if (Debug == "Y")
            {
                string filename = string.Format("{0}logs/{1}_{2}{3}.log", RootDir, myProcName, DateTime.Now.ToShortDateString().Replace("/", ""), DateTime.Now.ToShortTimeString().Replace(":", "").Substring(0, 4));
                FileStream file1 = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);
                sw = new StreamWriter(file1);// Create a new strem
            }
            if (Area != l_area)
            {
                string st = "Process not Started. Areas Discrepancy";
                m_readConnection.RecordEvent(0, myProcName, string.Format("{0}", st), Area);
                m_readConnection.ConsoleWrite(Debug, myProcName, sw, "Areas Discrepancy");
                myProcess.Kill();	//unexcpected error DIE.
            }
        }

        private void get_line_values(string line_name)
        {
            if (!m_DBConnected)
            {
                m_readConnection.Connect(false, Area);
                m_writeConnection.Connect(true, Area);
                m_DBConnected = true;
            }
            string Cmd;
            Cmd = string.Format("select Port, NextSeqNo, NumberSel, IntPort,SwfTid from LinkControl where LineName = '{0}'", line_name);
            m_readConnection.OpenDataReader(Cmd);
            m_readConnection.SQLDR.Read();
            m_ServerPort = m_readConnection.SQLDR.GetInt32(0);
            NextOsn = m_readConnection.SQLDR.GetInt32(1);
            nSel = m_readConnection.SQLDR.GetInt32(2);
            m_ClientPort = m_readConnection.SQLDR.GetInt32(3);  //local port to talk to SwfServer(our process NOT MTS). Confusing? See comments on top.
            m_swftid = m_readConnection.SQLDR["SwfTid"].ToString().TrimEnd();
            m_readConnection.CloseDataReader();
        }

        private void OnOurSwfClientConnected(object sender, ClientContextArgs ca)
        {
            status = string.Format("{0} connected.", ca.Context.Socket.RemoteEndPoint.ToString());
            m_readConnection.RecordEvent(0, myProcName, string.Format("{0}", status), Area);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
        }

        private void OnMtsDisConnected(object sender, ClientContextArgs ca)
        {
            m_readConnection.RecordEvent(0, myProcName, string.Format("{0}", status), Area);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            m_IpMtsClient.Stop();			// if disconnected from server
            //			m_IpOurServer.Stop();
            m_Timer.Stop();
            do_login_proc = true;
            m_LinkState = LinkState.AwaitingRefNo;
            m_Sequence = 3;
            m_TimerFiredCount = 0;
        }

        private void OnOurSwfClientDisConnected(object sender, ClientContextArgs ca)
        {
            status = string.Format("{0} disconnected.", ca.Context.Socket.RemoteEndPoint.ToString());
            m_readConnection.RecordEvent(0, myProcName, string.Format("{0}", status), Area);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            m_IpMtsClient.Stop();			// if disconnected from server
            m_IpOurServer.Stop();
            m_Timer.Stop();
            do_login_proc = true;
            m_LinkState = LinkState.AwaitingRefNo;
            m_Sequence = 3;
            m_TimerFiredCount = 0;
        }

        private void OnMtsClientDataRecieved(object sender, ClientContextArgs ca, byte[] rcvBfr, int byteCount)
        {
            // This never happens. MTS DOES NOT SEND ANYTHING TO the SwfServer. MTS sends traffic ONLY to SwfClient.
            // This process ONLY sends traffic to MTS.
            if (m_IpMtsClient.firstBlock)
            {
                int rcvLength = getReadLength(rcvBfr);
                m_IpMtsClient.readLength = rcvLength;
                m_readConnection.RecordEvent(0, myProcName, string.Format("ClientRcvd: {0} is {1} byes to read", rcvBfr, rcvLength), Area);
                m_IpMtsClient.firstBlock = false;
                return;
            }
            else
            {
                if (m_newswf == "V1")
                    m_IpMtsClient.readLength = 40;
                else
                    m_IpMtsClient.readLength = 8;
                m_IpMtsClient.firstBlock = true;
            }
            status = string.Format("Received from client {0} - {1}", ca.Context.Socket.RemoteEndPoint.ToString(), Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
            m_readConnection.RecordEvent(0, myProcName, string.Format("{0}", status), Area);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
        }

        private void OnOurServerDataRecieved(object sender, ClientContextArgs ca, byte[] rcvBfr, int byteCount)
        {
            // Here we receive communication from OUR swfCleint. It tell this process what to do.
            if (m_IpOurServer.firstBlock)
            {
                int rcvLength = getReadLength(rcvBfr);
                m_IpOurServer.readLength = rcvLength;
                string test = string.Format("ServerRcvd: {0} is {1} byes to read", rcvBfr, rcvLength);
                m_readConnection.ConsoleWrite(Debug, myProcName, sw, test);

                m_IpOurServer.firstBlock = false;
                return;
            }
            else
            {
                if (m_newswf == "V1")
                    m_IpOurServer.readLength = 40;
                else
                    m_IpOurServer.readLength = 8;
                m_IpOurServer.firstBlock = true;
            }
            status = string.Format("State: {0} Received from {1} ByteCount - {2}", m_LinkState.ToString(), ca.Context.Socket.RemoteEndPoint.ToString(), Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            if (m_newswf == "V1")
                switch (m_LinkState)
                {
                    case LinkState.AwaitingRefNo:
                        get_line_values(line_name);
                        m_LinkState = LinkState.AwaitingA21;
                        m_RefNo = Encoding.ASCII.GetString(rcvBfr, 0, byteCount);
                        //						Console.Write ("Starting client\r\n");
                        m_IpMtsClient.Start(true);
                        //						Console.Write ("Sending connection data\r\n");
                        SendConnectionData_v1();
                        SendConnectionData();
                        break;
                    case LinkState.AwaitingA21:
                        m_LinkState = LinkState.Sending;
                        Console.Write("Sending a21\r\n");
                        SendA23(Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
                        m_Timer = new System.Timers.Timer();
                        m_Timer.Elapsed += new ElapsedEventHandler(OnTimerEvent);
                        // Set to send in one sec
                        m_Timer.Interval = 0001;
                        m_Timer.AutoReset = false;
                        m_Timer.Start();
                        break;
                    case LinkState.Sending:
                        m_LinkState = LinkState.SendF25;
                        Console.Write("Sending F25\r\n");
                        SendF25(Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
                        m_Timer = new System.Timers.Timer();
                        m_Timer.Elapsed += new ElapsedEventHandler(OnTimerEvent);
                        // Set to send in one sec
                        m_Timer.Interval = 0001;
                        m_Timer.AutoReset = false;
                        m_Timer.Start();
                        break;
                    case LinkState.SendF25:
                        m_LinkState = LinkState.SendA26;
                        Console.Write("Sending A26\r\n");
                        SendA26(Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
                        break;
                    case LinkState.SendA26:
                        Console.Write("Sending Close-Conf\r\n");
                        SendClose(Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
                        //m_IpMtsClient.Stop();
                        //m_IpOurServer.Stop();
                        m_Timer.Stop();
                        do_login_proc = true;
                        m_LinkState = LinkState.AwaitingRefNo;
                        m_Sequence = 3;
                        m_TimerFiredCount = 0;
                        break;
                }
            else		// Version V0 OLD way
                switch (m_LinkState)
                {
                    case LinkState.AwaitingRefNo:
                        get_line_values(line_name);
                        m_LinkState = LinkState.AwaitingA21;
                        m_RefNo = Encoding.ASCII.GetString(rcvBfr, 0, byteCount);
                        //						Console.Write ("Starting client\r\n");
                        m_IpMtsClient.Start(true);
                        //						Console.Write ("Sending connection data\r\n");
                        SendConnectionData();
                        break;
                    case LinkState.AwaitingA21:
                        m_LinkState = LinkState.Sending;
                        Console.Write("Sending a21\r\n");
                        SendA23(Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
                        m_Timer = new System.Timers.Timer();
                        m_Timer.Elapsed += new ElapsedEventHandler(OnTimerEvent);
                        // Set to send in one sec
                        m_Timer.Interval = 0001;
                        m_Timer.AutoReset = false;
                        m_Timer.Start();
                        break;
                    case LinkState.Sending:
                        m_LinkState = LinkState.SendF25;
                        Console.Write("Sending F25\r\n");
                        SendF25(Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
                        m_Timer = new System.Timers.Timer();
                        m_Timer.Elapsed += new ElapsedEventHandler(OnTimerEvent);
                        // Set to send in one sec
                        m_Timer.Interval = 0001;
                        m_Timer.AutoReset = false;
                        m_Timer.Start();
                        break;
                    case LinkState.SendF25:
                        m_LinkState = LinkState.SendA26;
                        Console.Write("Sending A26\r\n");
                        SendA26(Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
                        break;
                    case LinkState.SendA26:
                        Console.Write("Sending Close-Conf\r\n");
                        SendClose(Encoding.ASCII.GetString(rcvBfr, 0, byteCount));
                        m_Timer.Stop();
                        do_login_proc = true;
                        m_LinkState = LinkState.AwaitingRefNo;
                        m_Sequence = 3;
                        m_TimerFiredCount = 0;
                        break;
                }
        }

        private void OnTimerEvent(object source, ElapsedEventArgs e)
        {
            lock (this)
            {
                m_TimerFiredCount++;
                if (m_timerBusy)
                    return;
                m_timerBusy = true;
            }
            int NumberofQueueItemstoCache = 10;
            try
            {
                if (!m_DBConnected)
                {
                    m_readConnection.Connect(false, Area);
                    m_writeConnection.Connect(true, Area);
                    m_DBConnected = true;
                }
                if (m_QI == null)
                    m_QI = new QueueInterface("LNK_" + line_name, NumberofQueueItemstoCache, Area);

                string qblText;
                int qblId = 0;
                int qblPriority = 0;
                int msgCount = 0;
                for (; ; )
                {
                    QueueItem qi = m_QI.getQueueItem();
                    if (qi != null)
                    {
                        qblText = qi.Text;
                        qblId = qi.Qblid;
                        qblPriority = qi.Priority;
                        bool SendStatus = true;
                        int Nomsg = 0;
                        int osnpl = qblText.IndexOf("======");
                        while (osnpl != -1)
                        {
                            string seq_s = string.Format("{0:000000}", NextOsn++);
                            // Watch out for NextOsn overflowing 6 digits. Wrap
                            // back to 1 if that happens.
                            if (NextOsn > 999999)
                                NextOsn = 1;
                            qblText = qblText.Remove(osnpl, 6);
                            qblText = qblText.Insert(osnpl, seq_s);
                            osnpl = qblText.IndexOf("??????");
                            qblText = qblText.Remove(osnpl, 6);
                            qblText = qblText.Insert(osnpl, seq_s);
                            osnpl = qblText.IndexOf("======");
                            Nomsg++;
                        };
                        try
                        {
                            SendMsg(qblText);
                        }
                        catch (Exception ex)
                        {
                            SendStatus = false;
                            string st = string.Format("Send to failed Error - {0}", ex.Message);
                            m_readConnection.RecordEvent(0, myProcName, string.Format("{0}", st), Area);
                            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}/r/n", st));
                            m_Timer.Interval = 100000000;

                        }
                        if (!SendStatus)
                            break;
                        // don't implement so far Wacks it may not be needed at all 
                        //						Cmd=string.Format("update {0} set Wack='W' where qbl={1}",qline_name,qblid);
                        //						m_writeConnection.Execute(Cmd,false);
                        string Cmd = string.Format("update SwfStats set NoSent=NoSent+{0} where SessionNo='{1}'", Nomsg, m_RefNo);
                        m_writeConnection.Execute(Cmd, false);
                        Cmd = string.Format("update linkcontrol set NextSeqNo={0} where LineName='{1}'", NextOsn, line_name);
                        m_writeConnection.Execute(Cmd, false);
                        Cmd = string.Format("delete from {0} where qbl={1} and prio='{2}'", qline_name, qblId, qblPriority);
                        m_writeConnection.Execute(Cmd, true);
                        if (msgCount++ == 20)
                        {
                            m_Timer.Interval = 10;
                            break;
                        }
                    }
                    else
                    {
                        m_Timer.Interval = 5000;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                string st = string.Format("Db access execution failed Error - {0}", ex.Message);
                m_readConnection.RecordEvent(0, myProcName, string.Format("{0}", st), Area);
                m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}/r/n", st));
                Process myProcess = Process.GetCurrentProcess();
                myProcess.Kill();	//unexcpected error DIE.
            }
            finally
            {
                m_timerBusy = false;
                m_Timer.Start();
            }
        }

        private void OnReceiveCompleted(object sender, ClientContextArgs ca)
        {
            //			Console.Write ("\nReceived data complete.");
        }

        private void SendConnectionData_v1()
        {
            string buffer = "cn=george-bush,o=bofaus6s,o=swift";
            status = string.Format("server.   send buffer {0}  -len - {1}", buffer, buffer.Length);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            sendClient(buffer, -3);
        }

        private void SendConnectionData()
        {
            int pkType;
            if (m_newswf == "V1")
                pkType = -2;
            else
                pkType = 0;
            string buffer =
                "<?xml version=\"1.0\"?>\n" +
                "<SwInt:HandleRequest>\n" +
                "<SwInt:RequestHandle>\n" +
                "    <SwInt:RequestDescriptor>\n" +
                "        <SwInt:SwiftRequestRef>snp00067-2005-04-21T17:24:22.7184.491748Z</SwInt:SwiftRequestRef>\n" +
                "        <SwInt:SwiftRef>swi00001-2005-04-21T17:24:22.24059.1091524Z</SwInt:SwiftRef>\n" +
                "        <SwInt:MRRResult>" +
                "          <SwInt:SNLId>snl11063</SwInt:SNLId>" +
                //				"          <SwInt:SNLEP>fin_bofaus60a</SwInt:SNLEP>"+
                "          <SwInt:SNLEP>fin_" + m_swftid.ToLower() + "</SwInt:SNLEP>" +
                "        </SwInt:MRRResult>\n" +
                "    </SwInt:RequestDescriptor>\n" +
                "    <SwInt:RequestHeader>\n" +
                "       <SwInt:Requestor>cn=fb67,cn=fin,o=swift,o=swift</SwInt:Requestor>\n" +
                //				"       <SwInt:Responder>cn=george-bush,o=bofaus6s,o=swift</SwInt:Responder>\n"+
                "       <SwInt:Responder>cn=george-bush,o=" + m_swftid.Substring(0, 7).ToLower() + "s,o=swift</SwInt:Responder>\n" +
                "       <SwInt:Service>swift.fin</SwInt:Service>\n" +
                "       <SwInt:RequestType>OPEN-CONF</SwInt:RequestType>\n" +
                //				"       <SwInt:RequestRef>BOFAUS60A0421132408000000</SwInt:RequestRef>\n"+
                "       <SwInt:RequestRef>" + m_swftid.ToUpper() + "0421132408000000</SwInt:RequestRef>\n" +
                "    </SwInt:RequestHeader>\n" +
                "    <SwInt:RequestPayload>\n" +
                "      <SenderRef>11141042607110037209</SenderRef>" +
                "      <ReceiverRef>" + m_RefNo + "</ReceiverRef>" +
                "      <SequenceNo>000000</SequenceNo>" +
                "      <LSfreq>9999</LSfreq>" +
                "      <BatchingTimeout>02</BatchingTimeout>" +
                "      <MaxBatchCount>30</MaxBatchCount>\n" +
                "    </SwInt:RequestPayload>\n" +
                " </SwInt:RequestHandle>\n" +
                "</SwInt:HandleRequest>";
            status = string.Format("server.   send buffer {0}  -len - {1}", buffer, buffer.Length);
            //			m_readConnection.RecordEvent(0,myProcName,string.Format("{0}: {1}", DateTime.Now, status), Area);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            sendClient(buffer, pkType);

            // send Login ack
            buffer =
                "<?xml version=\"1.0\"?>\n<SwInt:HandleRequest>\n" +
                "    <SwInt:RequestHandle>\n" +
                "        <SwInt:RequestDescriptor>\n" +
                "            <SwInt:SwiftRequestRef>snp00067-2005-04-21T17:25:21.7185.492771Z" +
                "</SwInt:SwiftRequestRef>\n" +
                "            <SwInt:SwiftRef>swi00001-2005-04-21T17:25:21.24060.1087570Z</SwInt:SwiftRef>\n" +
                "            <SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId>" +
                //				"<SwInt:SNLEP>fin_bofaus60a</SwInt:SNLEP></SwInt:MRRResult>\n"+
                "<SwInt:SNLEP>fin_" + m_swftid.ToLower() + "</SwInt:SNLEP></SwInt:MRRResult>\n" +
                "    </SwInt:RequestDescriptor>\n" +
                "    <SwInt:RequestHeader>\n" +
                "<SwInt:Requestor>cn=fb67,cn=fin,o=swift,o=swift</SwInt:Requestor>\n" +
                //				"<SwInt:Responder>cn=george-bush,o=bofaus6s,o=swift</SwInt:Responder>\n"+
                "<SwInt:Responder>cn=george-bush,o=" + m_swftid.Substring(0, 7).ToLower() + "s,o=swift</SwInt:Responder>\n" +
                "<SwInt:Service>swift.fin</SwInt:Service>.<SwInt:RequestType>DATA</SwInt:RequestType>\n" +
                //				"<SwInt:RequestRef>001015L22BOFAUS60AXXX</SwInt:RequestRef>\n"+
                "<SwInt:RequestRef>001015L22" + m_swftid.ToUpper() + "XXX</SwInt:RequestRef>\n" +
                "</SwInt:RequestHeader>\n" +
                "        <SwInt:RequestPayload>\n" +
                "<SenderRef>11141042607110037209</SenderRef>" +
                "<ReceiverRef>" + m_RefNo + "</ReceiverRef><SequenceNo>000001</SequenceNo>" +
                //				"<Data><![CDATA[000173{1:L22BOFAUS60AXXX}{4:{502:211725180082008300820082A14D"+
                "<Data><![CDATA[000173{1:L22" + m_swftid.ToUpper() + "XXX}{4:{502:211725180082008300820082A14D" +
                "9A26BDD076E80001000003              }" +
                "{151:0082}{177:0504211325}{110:001}{333:050420111700810504211325052000003000" +
                "005}}]]></Data>\n" +
                "</SwInt:RequestPayload>\n" +
                "    </SwInt:RequestHandle>.</SwInt:HandleRequest>";
            status = string.Format("server. send buffer {0}  - len - {1}", buffer, buffer.Length);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            sendClient(buffer, pkType);
        }

        private void SendA23(string bfr)
        {
            int pkType;
            if (m_newswf == "V1")
                pkType = -2;
            else
                pkType = 0;
            if ((bfr[0] == 'A') && (bfr[1] == '0'))
            {
                // I think this is the right thing to do ... If NextOsn is 1, then
                // we've wrapped the OSN around past 999999 to 1 ... (Is this 100% true?
                // What happens the first time the link ever comes up? Is NextOsn set to
                // 1 at that point, too? Stay tuned, we'll find out.)
                // Anyway, if NextOsn is 1, format the seq_s string to be 999999.
                string seq_s;
                if (NextOsn > 1)
                    seq_s = string.Format("{0:000000}", NextOsn - 1);
                else
                    seq_s = string.Format("{0:000000}", 999999);

                string buffer =
                    "<?xml version=\"1.0\"?>\n<SwInt:HandleRequest>\n" +
                    "    <SwInt:RequestHandle>\n" +
                    "        <SwInt:RequestDescriptor>\n" +
                    "<SwInt:SwiftRequestRef>snp00067-2005-04-21T17:27:02.7188.493604Z" +
                    "</SwInt:SwiftRequestRef>\n" +
                    "<SwInt:SwiftRef>swi00001-2005-04-21T17:27:02.24071.6026194Z</SwInt:SwiftRef>\n" +
                    //					"<SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId><SwInt:SNLEP>fin_bofaus60a"+
                    "<SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId><SwInt:SNLEP>fin_" + m_swftid.ToLower() +
                    "</SwInt:SNLEP></SwInt:MRRResult>\n" +
                    "    </SwInt:RequestDescriptor>\n" +
                    "    <SwInt:RequestHeader>\n" +
                    "<SwInt:Requestor>cn=fb67,cn=fin,o=swift,o=swift</SwInt:Requestor>\n" +
                    //					"<SwInt:Responder>cn=george-bush,o=bofaus6s,o=swift</SwInt:Responder>\n"+
                    "<SwInt:Responder>cn=george-bush,o=" + m_swftid.Substring(0, 7).ToLower() + "s,o=swift</SwInt:Responder>\n" +
                    "<SwInt:Service>swift.fin</SwInt:Service>\n<SwInt:RequestType>DATA</SwInt:RequestType>\n" +
                    //					"<SwInt:RequestRef>001025A43BOFAUS60AXXX0082000003</SwInt:RequestRef>\n"+
                    "<SwInt:RequestRef>001025A43" + m_swftid.ToUpper() + "XXX0082000003</SwInt:RequestRef>\n" +
                    "</SwInt:RequestHeader>\n" +
                    "   <SwInt:RequestPayload>\n<SenderRef>11141042607110037209</SenderRef>" +
                    "<ReceiverRef>" + m_RefNo + "</ReceiverRef>" +
                    "<SequenceNo>000002</SequenceNo>" +
                    //					"<Data><![CDATA[000205{1:A23BOFAUS60AXXX0082000004}"+
                    "<Data><![CDATA[000205{1:A23" + m_swftid.ToUpper() + "XXX0082000004}" +
                    "{4:{101:F}{502:211727280089009000890089EEFB6D2D75C180670001000003              }" +
                    "{151:0082}{177:0504211327}{110:030}{204:YY}{208:Y}";
                //					if (m_newswf == "V1")
                // try without						buffer += "{338:SYSTEMURGENTNORMAL}";
                buffer += "{333:050420111900810504211325052089467" + seq_s + "}}]]></Data>\n" +
                "</SwInt:RequestPayload>\n" +
                "    </SwInt:RequestHandle>\n</SwInt:HandleRequest>";
                status = string.Format("server. send buffer {0}  -len - {1}", buffer, buffer.Length);
                m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
                sendClient(buffer, pkType);
            }
        }

        private void SendF25(string bfr)
        {
            int pkType;
            if (m_newswf == "V1")
                pkType = -2;
            else
                pkType = 0;
            string seq_s = string.Format("{0:000000}", m_Sequence);
            m_Sequence++;
            // If sequence goes above 6 digits, wrap it back to 1.
            if (m_Sequence > 999999)
                m_Sequence = 1;
            string buffer =
                "<?xml version=\"1.0\"?>\n<SwInt:HandleRequest>\n" +
                "    <SwInt:RequestHandle>\n" +
                "        <SwInt:RequestDescriptor>\n" +
                "<SwInt:SwiftRequestRef>snp00067-2005-04-21T17:27:02.7188.493604Z" +
                "</SwInt:SwiftRequestRef>\n" +
                "<SwInt:SwiftRef>swi00001-2005-04-21T17:27:02.24071.6026194Z</SwInt:SwiftRef>\n" +
                //				"<SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId><SwInt:SNLEP>fin_bofaus60a"+
                "<SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId><SwInt:SNLEP>fin_" + m_swftid.ToLower() +
                "</SwInt:SNLEP></SwInt:MRRResult>\n" +
                "    </SwInt:RequestDescriptor>\n" +
                "    <SwInt:RequestHeader>\n" +
                "<SwInt:Requestor>cn=fb67,cn=fin,o=swift,o=swift</SwInt:Requestor>\n" +
                //				"<SwInt:Responder>cn=george-bush,o=bofaus6s,o=swift</SwInt:Responder>\n"+
                "<SwInt:Responder>cn=george-bush,o=" + m_swftid.Substring(0, 7).ToLower() + "s,o=swift</SwInt:Responder>\n" +
                "<SwInt:Service>swift.fin</SwInt:Service>\n<SwInt:RequestType>DATA</SwInt:RequestType>\n" +
                //				"<SwInt:RequestRef>001025A43BOFAUS60AXXX0082000003</SwInt:RequestRef>\n"+
                "<SwInt:RequestRef>001025A43" + m_swftid.ToUpper() + "XXX0082000003</SwInt:RequestRef>\n" +
                "</SwInt:RequestHeader>\n" +
                "   <SwInt:RequestPayload>\n<SenderRef>11141042607110037209</SenderRef>" +
                "<ReceiverRef>" + m_RefNo + "</ReceiverRef>" +
                "<SequenceNo>" + seq_s + "</SequenceNo>" +
                //				"<Data><![CDATA[000102{1:F25BOFAUS60AXXX2893413062}"+
                "<Data><![CDATA[000102{1:F25" + m_swftid.ToUpper() + "XXX2893413062}" +
                "{4:{331:289306022314170602231417000000001000000413062413062263060263059}}]]" +
                "></Data>\n" +
                "</SwInt:RequestPayload>\n" +
                "    </SwInt:RequestHandle>\n</SwInt:HandleRequest>";
            status = string.Format("server. send buffer {0}  -len - {1}", buffer, buffer.Length);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            sendClient(buffer, pkType);
        }

        private void SendA26(string bfr)
        {
            int pkType;
            if (m_newswf == "V1")
                pkType = -2;
            else
                pkType = 0;
            string seq_s = string.Format("{0:000000}", m_Sequence);
            m_Sequence++;
            // If sequence goes above 6 digits, wrap it back to 1.
            if (m_Sequence > 999999)
                m_Sequence = 1;
            string buffer =
                "<?xml version=\"1.0\"?>\n<SwInt:HandleRequest>\n" +
                "    <SwInt:RequestHandle>\n" +
                "        <SwInt:RequestDescriptor>\n" +
                "<SwInt:SwiftRequestRef>snp00067-2005-04-21T17:27:02.7188.493604Z" +
                "</SwInt:SwiftRequestRef>\n" +
                "<SwInt:SwiftRef>swi00001-2005-04-21T17:27:02.24071.6026194Z</SwInt:SwiftRef>\n" +
                //				"<SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId><SwInt:SNLEP>fin_bofaus60a"+
                "<SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId><SwInt:SNLEP>fin_" + m_swftid.ToLower() +
                "</SwInt:SNLEP></SwInt:MRRResult>\n" +
                "    </SwInt:RequestDescriptor>\n" +
                "    <SwInt:RequestHeader>\n" +
                "<SwInt:Requestor>cn=fb67,cn=fin,o=swift,o=swift</SwInt:Requestor>\n" +
                //				"<SwInt:Responder>cn=george-bush,o=bofaus6s,o=swift</SwInt:Responder>\n"+
                "<SwInt:Responder>cn=george-bush,o=" + m_swftid.Substring(0, 7).ToLower() + "s,o=swift</SwInt:Responder>\n" +
                "<SwInt:Service>swift.fin</SwInt:Service>\n<SwInt:RequestType>DATA</SwInt:RequestType>\n" +
                //				"<SwInt:RequestRef>001025A43BOFAUS60AXXX0082000003</SwInt:RequestRef>\n"+
                "<SwInt:RequestRef>001025A43" + m_swftid.ToUpper() + "XXX0082000003</SwInt:RequestRef>\n" +
                "</SwInt:RequestHeader>\n" +
                "   <SwInt:RequestPayload>\n<SenderRef>11141042607110037209</SenderRef>" +
                "<ReceiverRef>" + m_RefNo + "</ReceiverRef>" +
                "<SequenceNo>" + seq_s + "</SequenceNo>" +
                //				"<Data><![CDATA[000102{1:A26BOFAUS60AXXX2893413062}"+
                "<Data><![CDATA[000102{1:A26" + m_swftid.ToUpper() + "XXX2893413062}" +
                "{4:{331:289306022314170602231417000000001000000413062413062263060263059}}]]" +
                "></Data>\n" +
                "</SwInt:RequestPayload>\n" +
                "    </SwInt:RequestHandle>\n</SwInt:HandleRequest>";
            status = string.Format("server. send buffer {0}  -len - {1}", buffer, buffer.Length);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            sendClient(buffer, pkType);
        }

        private void SendClose(string bfr)
        {
            int pkType;
            if (m_newswf == "V1")
                pkType = -2;
            else
                pkType = 0;
            string seq_s = string.Format("{0:000000}", m_Sequence);
            m_Sequence++;
            // If sequence goes above 6 digits, wrap it back to 1.
            if (m_Sequence > 999999)
                m_Sequence = 1;
            string buffer =
                "<?xml version=\"1.0\"?>\n<SwInt:HandleRequest>\n" +
                "    <SwInt:RequestHandle>\n" +
                "        <SwInt:RequestDescriptor>\n" +
                "<SwInt:SwiftRequestRef>snp00067-2005-04-21T17:27:02.7188.493604Z" +
                "</SwInt:SwiftRequestRef>\n" +
                "<SwInt:SwiftRef>swi00001-2005-04-21T17:27:02.24071.6026194Z</SwInt:SwiftRef>\n" +
                //				"<SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId><SwInt:SNLEP>fin_bofaus60a"+
                "<SwInt:MRRResult><SwInt:SNLId>snl11063</SwInt:SNLId><SwInt:SNLEP>fin_" + m_swftid.ToLower() +
                "</SwInt:SNLEP></SwInt:MRRResult>\n" +
                "    </SwInt:RequestDescriptor>\n" +
                "    <SwInt:RequestHeader>\n" +
                "<SwInt:Requestor>cn=fb67,cn=fin,o=swift,o=swift</SwInt:Requestor>\n" +
                //				"<SwInt:Responder>cn=george-bush,o=bofaus6s,o=swift</SwInt:Responder>\n"+
                "<SwInt:Responder>cn=george-bush,o=" + m_swftid.Substring(0, 7).ToLower() + "s,o=swift</SwInt:Responder>\n" +
                "<SwInt:Service>swift.fin</SwInt:Service>\n<SwInt:RequestType>CLOSE-CONF</SwInt:RequestType>\n" +
                //				"<SwInt:RequestRef>001025A43BOFAUS60AXXX0082000003</SwInt:RequestRef>\n"+
                "<SwInt:RequestRef>001025A43" + m_swftid.ToUpper() + "XXX0082000003</SwInt:RequestRef>\n" +
                "</SwInt:RequestHeader>\n" +
                "   <SwInt:RequestPayload>\n<SenderRef>11141042607110037209</SenderRef>" +
                "<ReceiverRef>" + m_RefNo + "</ReceiverRef>" +
                "<SequenceNo>" + seq_s + "</SequenceNo>" +
                "</SwInt:RequestPayload>\n" +
                "    </SwInt:RequestHandle>\n</SwInt:HandleRequest>";
            status = string.Format("server. send buffer {0}  -len - {1}", buffer, buffer.Length);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            sendClient(buffer, pkType);
        }

        private void SendMsg(string msg)
        {
            int pkType;
            if (m_newswf == "V1")
                pkType = -2;
            else
                pkType = 0;
            string seq_s = string.Format("{0:000000}", m_Sequence);
            m_Sequence++;
            // If sequence goes above 6 digits, wrap it back to 1.
            if (m_Sequence > 999999)
                m_Sequence = 1;
            int seqPos = msg.IndexOf("<SequenceNo>") + "<SequenceNo>".Length;
            int refPos = msg.IndexOf("<ReceiverRef>") + "<ReceiverRef>".Length;
            string buffer = msg.Substring(0, refPos) + m_RefNo + msg.Substring(refPos + 19, seqPos - refPos - 19 + 1) + seq_s + msg.Substring(seqPos + 6);
            status = string.Format("server. send buffer {0}  -len - {1}", buffer, buffer.Length);
            m_readConnection.ConsoleWrite(Debug, myProcName, sw, string.Format("{0}\r\n", status));
            sendClient(buffer, pkType);
        }

        private void sendClient(string bfr, int pktType)
        {
            if (m_newswf == "V1")
            /*   unsigned char xLAUValue[ SNLADPHDR_LAU_SIZE] (32 byte) 256-byte LAU value */
            {
                string byte1 = Encoding.ASCII.GetString(m_pass, 0, 1);
                string byte2 = Encoding.ASCII.GetString(m_pass, 1, 1);
                if (byte1 == "m" && byte2 == "a")
                    des_pr(m_drv,m_pass);	// pass is a key that is created from LAU data. Do it once per session.
                byte[] MessageBytes = System.Text.Encoding.ASCII.GetBytes(bfr);
                HMACSHA256 myhmacsha256 = new HMACSHA256(m_pass);
                byte[] LAUData = myhmacsha256.ComputeHash(MessageBytes);
                //byte[] LAUData = new byte[32]; 	/* new 32 byte. need to find what to map */
                byte[] type = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(pktType));
                byte[] length = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(bfr.Length));
                byte[] byData = new byte[40];
                Array.Copy(type, 0, byData, 0, 4);
                Array.Copy(length, 0, byData, 4, 4);
                Array.Copy(LAUData, 0, byData, 8, 32);
                m_IpMtsClient.Send(byData);
                byData = System.Text.Encoding.ASCII.GetBytes(bfr);
                m_IpMtsClient.Send(byData);
            }
            else
            {
                byte[] type = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(pktType));
                byte[] length = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(bfr.Length));
                byte[] byData = new byte[8];
                Array.Copy(type, 0, byData, 0, 4);
                Array.Copy(length, 0, byData, 4, 4);
                m_IpMtsClient.Send(byData);
                byData = System.Text.Encoding.ASCII.GetBytes(bfr);
                m_IpMtsClient.Send(byData);
            }
        }

        private int getReadLength(byte[] bfr)
        {
            byte[] byData = new byte[4];
            Array.Copy(bfr, 4, byData, 0, 4);
            int Length = BitConverter.ToInt32(byData, 0);				// unbox
            int fixedLength = IPAddress.NetworkToHostOrder(Length);
            return fixedLength;
        }
    }
}
