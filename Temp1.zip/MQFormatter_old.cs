/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using Simulator.SimLog;
using Simulator.EventLogger;
using System.Diagnostics;

/* 
Revisions.
24-Sep-2013	JN	Add RBCS ACK support
29-Oct_2013	JN	Add FXLM support
21-Nov-2013	JN	Derive FXRATE response from the incoming request using fxrate sheet
22-Nov-2013	JN	Add response derivation from the special table that CtitFT will create with ALL responses.
23-Dec-2013	JN	Add DSM responses
 * 
 * 28-Nov-15    JR  Synch code between Jacob and John
*/
namespace Simulator.FormatersLib
{
	/// </summary>
	public class MQFormatter
	{
		StringBuilder mqmsg;
		String scratch=null;
		private OracleConnection m_OraSrcConnection;
		private OracleConnection m_OraTrgConnection;
		private DBAccess m_SqlConnection;
		private SimulatorLog _simLog = null;
		private string m_Area;
		private string m_DbPrefix;
		private	bool Show = true;
		private int m_FxlmSeq;
		static private IDictionary<string, string> m_FxRates;
		
		public MQFormatter(string area)
		{
			mqmsg = new StringBuilder();
			this.m_Area = area;
		}
		
/*
Example of MT012 . Ack of sending from Swift
{1:F01CITIGB2LAXXX0902515100}
{2:O0121440070223LYDXXXXXLXXX00002095730702231540S}
{4:{175:1540}{106:070223CITIGB2LAXXX0902870616}{108:11B040737270DD00}{102:DEUTDEFFXXXX}
{103:TGT}{114:TEST}}
{5:{CHK:B8D43AB620C5}{SYS:1540070223CITIGB2LAXXX0902870616}}
=02231441 LN BR27510

EBACT
.LONFUCB
TEST NR
{1:F01CITIGB20AX010000000000}{2:I103DEUTDEF0XXXXN}{3:{103:EBA}{108:11B040737270DD00}}{4:
:20:3116683633
:23B:CRED
:32A:110705EUR2001,

B185008325828738



103/019 example

CLOB) AQR9702 
XX LONFU
.LONXPCB 181202
TEST NR
{1:F01CITIGB2LAXXX7430515270}
{2:O0191202070918MDDYXXXX3XXX00000279600709181302S}
{4:{175:0801}{106:070918CITIGB2LAXXX7430985071}
{108:1361110572406400}{102:CHASGB2LXXXX}
{432:L1}{619:STG}}	<----- diff
{5:{CHK:319B17438ACC}{SYS:0801070918CITIGB2LAXXX7430985071}{TNG:}}
=09181202 LN DP65637
CN CHPCT

.LONFUCB
TEST NR
{1:F01CITIGB2LAXXX0000000000}{2:I103CHASGB2LXXXXN}{3:{103:STG}{108:1361110572406400}{119:STP}}{4:
:20:B185008321164653
:23B:CRED
:32A:130610GBP302356,68
:33B:GBP302356,68
:50K:/GB63CITI18500810856290
CMPC CELULOSA SA
C/0 CITIBANK, ANDRES BELLO 2687
PISO 3, LAS CONDES, SANTIAGO
CHILE
:52A:CITIGB2LXXX
:59:/GB75BARC20000066145255
HBA LTD IBA
:70:SETTLEMENT 04/08/2010
:71A:SHA
:72:/INVALID/
-}{5:{PDE:}}


*/

		public string MakeFinCopy(DBAccess m_Connection, DBAccess m_ReadConnection, string linename, string msgbody, string RuleNak)
		{

			AckNakProcess m_rules=new AckNakProcess();
			string mtNo = "012";
			string st3 = "";
			string F01 = msgbody.Substring(msgbody.IndexOf("{1:"),29);
			string F02 = msgbody.Substring(msgbody.IndexOf("{2:"),21);
			string F103 = "";
			string F108 = "";
			int pos = msgbody.IndexOf("{108:");
			if (pos != -1)
			{
				pos = pos + 5;
				int pos1 = msgbody.IndexOf("}", pos);
				F108 = msgbody.Substring(pos, pos1 - pos);
			}
			pos = msgbody.IndexOf("{103:");
			if (pos != -1)
			{
				pos = pos + 5;
				int pos1 = msgbody.IndexOf("}", pos);
				F103 = msgbody.Substring(pos, pos1 - pos);
			}
			if ((F103.Length == 0) || (F108.Length == 0 ))	//no ack if one of those flds are empty
				return "";

			if (!(RuleNak=="")) //Apply rules that are specified in the table
			{
				string rtn = m_rules.CheckAckRules(m_ReadConnection,msgbody,RuleNak,"SWF");
				if (rtn!="")
				{
					int Ind = rtn.IndexOf("/");
					string err_code=rtn.Substring(0,Ind);
					mtNo = "019";
					st3 = string.Format("{{432:{0}}}{{619:{1}}}}}",err_code,F103);
				}
			}
			else
			{	// make mt012 and send
				st3 = string.Format("{{103:{0}}}{{114:TEST}}}}",F103);
			}
			mqmsg.Length =0;
			mqmsg.Append("CUR0986\r\n");
			mqmsg.Append("XX LONYD\r\n");
			mqmsg.Append(".LONXPCB ======\r\n");
			mqmsg.Append("TEST NR\r\n");
			mqmsg.Append(F01.Substring(0,22));
			mqmsg.Append("======}{2:O");
			mqmsg.Append(mtNo);
			mqmsg.Append(string.Format("{0:HHmm}",DateTime.Now));
			mqmsg.Append(string.Format("{0:yyMMdd}",DateTime.Now));
			mqmsg.Append("MDDYXXXX3XXX");
			mqmsg.Append("0000======");
			mqmsg.Append(string.Format("{0:yyMMdd}",DateTime.Now));
			mqmsg.Append(string.Format("{0:HHmm}",DateTime.Now));
			mqmsg.Append("S}{4:{175:");
			mqmsg.Append(string.Format("{0:HHmm}",DateTime.Now));
			mqmsg.Append("}{106:");
            		mqmsg.Append(string.Format("{0:yyMMdd}", DateTime.Now));
           		mqmsg.Append(F01.Substring(6, 23));
			mqmsg.Append("{108:");
			mqmsg.Append(F108);
			mqmsg.Append("}{102:");
			mqmsg.Append(F02.Substring(7,12));
			mqmsg.Append("}");
			mqmsg.Append(st3);
			mqmsg.Append("{5:{CHK:319B17438ACC}{SYS:0000");
			mqmsg.Append(string.Format("{0:yyMMdd}",DateTime.Now));
			mqmsg.Append(F01.Substring(6,23));
			mqmsg.Append("}");
			mqmsg.Append("\r\n=02231441 LN BR27510");

			string ack = Convert.ToString(mqmsg);
			return ack;
		}

		public string Ack_DSM(DBAccess Sql_Connection, DBAccess m_ReadConnection, string linename, string msgbody, string RuleNak)
		{

			AckNakProcess m_rules=new AckNakProcess();
			string F01 = msgbody.Substring(msgbody.IndexOf("{1:"),29);
			string F02 = msgbody.Substring(msgbody.IndexOf("{2:"),21);
			string F103 = "";
			string F108 = "";
			int pos = msgbody.IndexOf("{108:") + 5;
			if (pos != -1)
			{
				int pos1 = msgbody.IndexOf("}", pos);
				F108 = msgbody.Substring(pos, pos1 - pos);
			}
			pos = msgbody.IndexOf("{103:") + 5;
			if (pos != -1)
			{
				int pos1 = msgbody.IndexOf("}", pos);
				F103 = msgbody.Substring(pos, pos1 - pos);
			}
			if ((F103.Length == 0) || (F108.Length == 0 ))	//no ack if one of those flds are empty
				return "";

			mqmsg.Length =0;
			mqmsg.Append("FHS3640 XXX9999\r\n");
			mqmsg.Append("QU SYDIY\r\n");
			mqmsg.Append(".HKGFNCB 221945\r\n");
			mqmsg.Append(".TEST NR\r\n");
			mqmsg.Append(F01);
			mqmsg.Append("{2:O9990000090322CBIIXXXXAXXX00000000000903221945N}{4:\r\n");
			mqmsg.Append(":20:DSM\r\n");
			mqmsg.Append(":21:FHR53480000\r\n");
			mqmsg.Append(":79:F21CITIAU2XBXXX0419267967\r\n");
			mqmsg.Append(" :2:I103ANZBNZ22XXXXN\r\n");
			mqmsg.Append(" :20:3142297574\r\n");
			mqmsg.Append(" :177:1303230645\r\n");
 			if (!(RuleNak=="")) //Apply rules that are specified in the table
			{
				string rtn = m_rules.CheckAckRules(m_ReadConnection,msgbody,RuleNak,"SWF");
				if (rtn!="")
				{
					mqmsg.Append(":451:1\r\n");
					int Ind = rtn.IndexOf("/");
					string err_code=rtn.Substring(0,Ind);
					mqmsg.Append(":405:");
					mqmsg.Append(err_code);
				}
			}
			else
			{
				mqmsg.Append(":451:0\r\n");
			}
			mqmsg.Append(":108:");
			mqmsg.Append(F108);
			mqmsg.Append("\r\n-}");

			string ack = Convert.ToString(mqmsg);
			return ack;
		}
		
		public string Ack_RBCS(DBAccess Sql_Connection, DBAccess ReadConnection, string XmlText, string RuleNak)
/*
swf-excho request <?xml version='1.0'?><!DOCTYPE rbcs SYSTEM 'rbcsmqapi.dtd'><rbcs><rbcheader messagetypeid='RBC001' versionid='03.00'><rbctxn><sourcesystem>0016</sourcesystem><txnbranch>600</txnbranch><txnreference>3339924028</txnreference><amount>24500.00</amount><currency>EUR</currency><debitbranch>600</debitbranch><debitaccount>0011286056</debitaccount><debitvaluedate>20130823</debitvaluedate><creditbranch>600</creditbranch><creditaccount>0005512654</creditaccount><creditvaluedate>20130823</creditvaluedate><finalbenebranch>600</finalbenebranch><finalbeneaccount>0005512654</finalbeneaccount><timeoutdate>20130823</timeoutdate><timeouttime>1800</timeouttime><clearedfundsflag>0</clearedfundsflag><benebankswiftaddress>CHASUS33XXX</benebankswiftaddress><benecustomername>DOUGLAS J. GASSMAN</benecustomername><curenabledflag>0</curenabledflag></rbctxn></rbcheader></rbcs>
swf-exch response <?xml version='1.0'?><rbcs><rbcheader messagetypeid='RBC500' versionid='02.00'><rbcstatus><sourcesystem>0016</sourcesystem><txnbranch>600</txnbranch><txnreference>3339924028</txnreference><txnstatus>51</txnstatus></rbcstatus></rbcheader></rbcs>
*/
		{
			string finalmsg = "";
			string sourcesystem = "";
			string txnbranch = "";
			string txnreference= "";
			string txnstatus="50";
			AckNakProcess m_rules=new AckNakProcess();
 			XmlDocument xmlDoc = new XmlDocument();
 			XmlNodeList nodes;
			if (_simLog == null )
				_simLog = new SimulatorLog("Receiver");
				
	//make sure we don't have DOCTYPE in it. It traps the loadxml.
			if (XmlText.IndexOf ("<!DOCTYPE") != -1)
			{
				int pos = XmlText.IndexOf ("<!DOCTYPE");
				int pos1 = XmlText.IndexOf (">",pos);
				XmlText = XmlText.Substring(0,pos) + XmlText.Substring(pos1 + 1);
			}

			try 
			{
				xmlDoc.LoadXml(XmlText);
				nodes = xmlDoc.SelectNodes("/rbcs/rbcheader/rbctxn");
			}
			catch (Exception ex)
			{
				ReportError(string.Format("Ack_RBCS. XML error: {0},",ex.Message),2);
				return "";
			}

            		foreach(XmlNode node in nodes)
            		{
            			try {sourcesystem = node.SelectSingleNode("sourcesystem").InnerText; }
            			catch {sourcesystem = ""; }
            			try {txnbranch = node.SelectSingleNode("txnbranch").InnerText; }
            			catch {txnbranch = ""; }
            			try {txnreference = node.SelectSingleNode("txnreference").InnerText; }
            			catch {txnreference = ""; }
			}
			
			if ((sourcesystem == "") || (txnbranch == "") || (txnreference == "") ) // All should be present
			{
				ReportError(string.Format("Ack_RBCS. Mandatory fields are missing"),2);
				return "";
			}

		//Console.WriteLine ("Rule table - " + RuleNak);
			if (!(RuleNak=="")) //Apply rules that are specified in the table
			{
				string rtn = m_rules.CheckAckRules(ReadConnection,XmlText,RuleNak,"MQS");
		//Console.WriteLine ("Return from acrrulecheck - " + rtn);
				if (rtn!="")
				{
					int Ind = rtn.IndexOf("/");
		//Console.WriteLine ("ind  - " + Ind);
					txnstatus=rtn.Substring(0,Ind);
				}
			}

			finalmsg = string.Format("<?xml version='1.0'?><rbcs><rbcheader messagetypeid='RBC500' versionid='02.00'><rbcstatus><sourcesystem>{0}</sourcesystem><txnbranch>{1}</txnbranch><txnreference>{2}</txnreference><txnstatus>{3}</txnstatus></rbcstatus></rbcheader></rbcs>",sourcesystem,txnbranch,txnreference,txnstatus);
			
			if (Show)
				Console.WriteLine ("RBCS Response - " + finalmsg);
			return finalmsg;
		}

		private void LoadFxRates()
		{
			if (m_FxRates != null) // this is the list of m_FxRates records.
				return;
			m_FxlmSeq = 0;
//Init fxrates...

			m_FxRates = new Dictionary<string, string>();

			string DocName = "c:\\Simulator\\" + m_Area + "\\feed\\fxrates.csv";
			FileStream RateFile;
		        try
		        { RateFile = new FileStream(DocName, FileMode.Open,FileAccess.Read); }
		        catch (Exception ex)
		        {
				string Errstr = string.Format ("FXLM FxRate Load - " + ex.Message);
				ReportError(Errstr, 1);
				return;
		        }
            		StreamReader srdr = new StreamReader(RateFile);
			string ln;

/*
GB3,GBPSHEET,GBP,USD,1.5819,1.5219,131227,1,1,4    Debit - remit, Credit - Pay
*/

			do
			{
				ln = srdr.ReadLine();
				if (ln ==  null)
					break;
				string[] line = ln.Split(',');
				if (line.Length > 3)
				{
					m_FxRates.Add(line[2]+line[3],line[4]);  // buy rate
					m_FxRates.Add(line[3]+line[2],line[5]);  // sell rate
				}
			} while (true);

			RateFile.Close();
			srdr.Close();
			if (Show)
			{
				Console.WriteLine("Loading FX Rates - ");
				foreach (KeyValuePair<String,String> entry in m_FxRates)
				{
					Console.WriteLine(" CCY Pair - " + entry.Key + "  Rate - " + entry.Value);
				}
			}
		}

		private string FindResponse(string SrcStr, string AccType, string Mid)
		{
			string finalmsg="";
			if (m_OraSrcConnection == null)
			{
				m_OraSrcConnection=new OracleConnection();
				m_OraSrcConnection.ConnectionString = SrcStr;
				m_OraSrcConnection.Open(); 
			}
				OracleCommand command = m_OraSrcConnection.CreateCommand();
				if (m_OraSrcConnection == null )
					Console.WriteLine ("src null");

			command.CommandText = string.Format("select response from rsptable where mid='{0}' and swfprtnrid='{1}'", Mid );
			OracleDataReader reader; 
			try { reader = command.ExecuteReader(); }
			catch (Exception ex)
			{
				if (Show)
					Console.WriteLine ("Try to get response from src. Oracle Error.");
				ReportError(string.Format("FindResponse: Oracle error: {0},",ex.Message),2);
				return finalmsg;
			}
			if (reader.Read()) 
			{ 
				if ( !reader.IsDBNull(0) )
					finalmsg = ((string)reader["RESPONSE"]);
				if (Show)
					Console.WriteLine ("-  Derived Response : " + finalmsg);
			}
			return finalmsg;
		}

//FXLM request  <?xml version="1.0" encoding="utf-8"?><WORLDLINK><BenchReq><BRHeader><Source>CFTNL2</Source><ClientNo>35386</ClientNo><FXLMEntity>4437340</FXLMEntity><HDRTrn>3300965766</HDRTrn><SentDateTime>2013-10-15 04:10:09</SentDateTime><WLFlag>O</WLFlag></BRHeader><BRDetail><DetailTrn>3300965766</DetailTrn><DealTyp>Q</DealTyp><RateTerm>E</RateTerm><PayCCY>USD</PayCCY><PayAmt>6135489.50</PayAmt><RemitCCY>EUR</RemitCCY><ValDate>2013-10-15</ValDate><BenchFixing>QUOTED</BenchFixing></BRDetail></BenchReq></WORLDLINK>																																																									
//FXLM response	<?xml version="1.0" encoding="UTF-8"?><WORLDLINK><BenchRsp><BPHeader><Source>CFTGB3</Source><ClientNo>35386</ClientNo><BranchNo></BranchNo><PrefPrice>N</PrefPrice><BaseNo></BaseNo><FXLMEntity>36525652</FXLMEntity><BPHdrTrn>3339948322</BPHdrTrn><RspDateTime>2013-09-03-04.38.22</RspDateTime></BPHeader><BPDetail><DetailTrn>3339948322</DetailTrn><BPStatus>000</BPStatus><BPErrorTyp></BPErrorTyp><BPErrMessage></BPErrMessage><BPPOQRef>000003121</BPPOQRef><DealTyp>Q</DealTyp><PayCCY>JPY</PayCCY><PayAmt>     26694761.00</PayAmt><RemitCCY>USD</RemitCCY><RemitAmt>       268045.52</RemitAmt><RateTerm>E</RateTerm><BPRate>      99.59040000</BPRate><ValDate>2013-09-04</ValDate><BookDate>2013-09-03</BookDate><BAOrderNo>1828265</BAOrderNo><BenchFixing></BenchFixing><OLRDealNo>U01029000887441</OLRDealNo></BPDetail></BenchRsp></WORLDLINK>																																																									
	
		public string[] Ack_FXLM(DBAccess Sql_Connection, DBAccess Sql_ReadConnection, string XmlText, string DbType, string SrcStr, string TrgStr, string ChangeRef, string DbPrefix)
		{
			m_DbPrefix = DbPrefix;
			string[] finalmsg = new string[2];
			string SrcMid="";
			string RqSource="";
			string RqClient="";
			string RqEntity="";
			string RqHdrTrn="";
			string RqSentDate="";
			string RqDetailTrn="";
			string RqDealTyp="";
			string RqRateTerm="";
			string RqPayCCY="";
			string RqPayAmt="";
			string RqRemitCCY="";
			string RqRemitAmt="";
			string RqBench="";
			string RqValDate="";

			if (m_FxRates == null)
				LoadFxRates();
			if (_simLog == null )
				_simLog = new SimulatorLog("Receiver");
			if ( (m_OraSrcConnection == null) && (DbType=="ORA") )
			{
				m_OraSrcConnection=new OracleConnection();
				m_OraSrcConnection.ConnectionString = SrcStr;
				m_OraSrcConnection.Open(); 
			}
			if (m_OraTrgConnection == null)
			{
				m_OraTrgConnection=new OracleConnection();
				m_OraTrgConnection.ConnectionString = TrgStr;
				m_OraTrgConnection.Open(); 
			}
			if (Show)
				Console.WriteLine ("SrcStr - " + SrcStr + " TrgStr - " + TrgStr);
// 1.1 Get <DetailTrn from the request.

 			XmlDocument xmlDoc = new XmlDocument();
 			XmlNodeList nodes;

	//make sure we don't have DOCTYPE in it. It traps the loadxml.
			if (XmlText.IndexOf ("<!DOCTYPE") != -1)
			{
				int pos = XmlText.IndexOf ("<!DOCTYPE");
				int pos1 = XmlText.IndexOf (">",pos);
				XmlText = XmlText.Substring(0,pos) + XmlText.Substring(pos1 + 1);
			}

			try 
			{
				xmlDoc.LoadXml(XmlText);
				nodes = xmlDoc.SelectNodes("/WORLDLINK/BenchReq/BRHeader");
			}
			catch (Exception ex)
			{
				ReportError(string.Format("Ack_FXLM. XML error: {0},",ex.Message),2);
				return finalmsg;
			}

            		foreach(XmlNode node in nodes)
            		{
            			try {RqSource = node.SelectSingleNode("Source").InnerText; }
            			catch {RqSource = ""; }
            			try {RqClient = node.SelectSingleNode("ClientNo").InnerText; }
            			catch {RqClient = ""; }
            			try {RqEntity = node.SelectSingleNode("FXLMEntity").InnerText; }
            			catch {RqEntity = ""; }
            			try {RqHdrTrn = node.SelectSingleNode("HDRTrn").InnerText; }
            			catch {RqHdrTrn = ""; }
            			try {RqSentDate = node.SelectSingleNode("SentDateTime").InnerText; }
            			catch {RqSentDate = ""; }
            			try {RqDetailTrn = node.SelectSingleNode("txnreference").InnerText; }
            			catch {RqDetailTrn = ""; }
            			try {RqValDate = node.SelectSingleNode("txnreference").InnerText; }
            			catch {RqValDate = ""; }
			}

			try 
			{
				xmlDoc.LoadXml(XmlText);
				nodes = xmlDoc.SelectNodes("/WORLDLINK/BenchReq/BRDetail");
			}
			catch (Exception ex)
			{
				ReportError(string.Format("Ack_FXLM. XML error: {0},",ex.Message),2);
				return finalmsg;
			}

            		foreach(XmlNode node in nodes)
            		{
            			try {RqDetailTrn = node.SelectSingleNode("DetailTrn").InnerText; }
            			catch {RqDetailTrn = ""; }
            			try {RqDealTyp = node.SelectSingleNode("DealTyp").InnerText; }
            			catch {RqDealTyp = ""; }
            			try {RqRateTerm = node.SelectSingleNode("RateTerm").InnerText; }
            			catch {RqRateTerm= ""; }
            			try {RqPayCCY = node.SelectSingleNode("PayCCY").InnerText; }
            			catch {RqPayCCY= ""; }
            			try {RqPayAmt = node.SelectSingleNode("PayAmt").InnerText; }
            			catch {RqPayAmt= ""; }
            			try {RqRemitCCY = node.SelectSingleNode("RemitCCY").InnerText; }
            			catch {RqRemitCCY= ""; }
            			try {RqRemitAmt = node.SelectSingleNode("RemitAmt").InnerText; }
            			catch {RqRemitAmt= ""; }
            			try {RqValDate = node.SelectSingleNode("ValDate").InnerText; }
            			catch {RqValDate = ""; }
            			try {RqBench = node.SelectSingleNode("BenchFixing").InnerText; }
            			catch {RqBench= ""; }
			}

			if (RqDetailTrn == "")
			{
				if (Show)
					Console.WriteLine ("DetailTrn not found. No Ack back.");
				return finalmsg;
			}
// 2. Get the original mid from trg DB and look it up in Src.
			if (Show)
				Console.WriteLine ("DetailTrn (refernce) - " + RqDetailTrn);
			if (DbType == "ORA")
			{
				SrcMid = GetTrgMidOra(ChangeRef, "local_ref", RqDetailTrn);
			}
			else
			{
				SrcMid = GetSrcMidSql(Sql_ReadConnection,ChangeRef,"local_ref", RqDetailTrn);
			}
			if (Show)
				Console.WriteLine ("Source mid derived - " + SrcMid);

// 2.1 Get responses from response table using mid + swfprtnid
/* for now until we get 
			string resp = FindResponse(SrcStr, AccType, SrcMid);
			if (resp != "")
			{
				string outresp ="";
				return outresp;
			}
*/			
// 3. Get the original info from the Source DB. See FXLN Response Emea doc in Citibank CR design directory
			string OlrInfo="";
			string FxlmInfo="";
			if (DbType == "ORA")
			{
				OracleCommand command = m_OraSrcConnection.CreateCommand();
				if (m_OraSrcConnection == null )
					Console.WriteLine ("src null");

				command.CommandText = string.Format("select description from {0}newjournal where mid='{1}' and description like '%Positive Receipt Acknowledgment%'", m_DbPrefix, SrcMid );
				OracleDataReader reader; 
				try { reader = command.ExecuteReader(); }
				catch (Exception ex)
				{
					if (Show)
						Console.WriteLine ("Try to  get NEWJOURNAL OLR contents. Oracle Error.");
					ReportError(string.Format("Ack_FXLM: 23. Oracle error: {0},",ex.Message),2);
					return finalmsg;
				}
				if (reader.Read()) 
				{ 
					if ( !reader.IsDBNull(0) )
						OlrInfo = ((string)reader["DESCRIPTION"]);
					else
						OlrInfo ="";
					if (Show)
						Console.WriteLine ("ORA. Derived OlrInfo : " + OlrInfo);
				}

				command.CommandText = string.Format("select description from {0}newjournal where mid='{1}' and description like '%Positive Deal Booking%'", m_DbPrefix, SrcMid );
				try { reader = command.ExecuteReader(); }
				catch (Exception ex)
				{
					if (Show)
						Console.WriteLine ("Try to  get NEWJOURNAL FLXM contents. Oracle Error.");
					ReportError(string.Format("Ack_FXLM: 24. Oracle error: {0},",ex.Message),2);
					return finalmsg;
				}
				if (reader.Read()) 
				{ 
					if ( !reader.IsDBNull(0) )
						FxlmInfo = ((string)reader["DESCRIPTION"]); 
					else
						FxlmInfo ="";
					if (Show)
						Console.WriteLine ("ORA. Derived FxlmInfo : " + FxlmInfo);
				}
				command.Dispose();
				reader.Close();
			}
			else
			{
				string Cmd = string.Format("select description from {0}newjournal where mid='{1}' and description like '%Positive Receipt Acknowledgment%';", m_DbPrefix, SrcMid );
				try { Sql_ReadConnection.OpenDataReader(Cmd); }
				catch (Exception ex)
				{
					ReportError(string.Format("Ack_FXLM 1: SQL error: {0},",ex.Message),2);
					return finalmsg;
				}
				if (Sql_ReadConnection.SQLDR.Read())
				{
					FxlmInfo = (Sql_ReadConnection.SQLDR[0].ToString().Trim()); 
				}
				if (Show)
					Console.WriteLine ("SQL. Derived FxlmInfo : " + FxlmInfo);
				Sql_ReadConnection.CloseDataReader();

				Cmd = string.Format("select description from {0}newjournal where mid='{1}' and description like '%Positive Deal Booking%';", m_DbPrefix, SrcMid );
				try { Sql_ReadConnection.OpenDataReader(Cmd); }
				catch (Exception ex)
				{
					ReportError(string.Format("Ack_FXLM 2: SQL error: {0},",ex.Message),2);
					return finalmsg;
				}
				if (Sql_ReadConnection.SQLDR.Read())
				{
					FxlmInfo = (Sql_ReadConnection.SQLDR[0].ToString().Trim()); 
				}
				if (Show)
					Console.WriteLine ("SQL. Derived FxlmInfo : " + FxlmInfo);
				Sql_ReadConnection.CloseDataReader();
			}
// 4. Take FXLM Info apart and get needed info.

	// See if all the info is there if it is missing try to generate. 
			if (OlrInfo.Length==0)
			{
				m_FxlmSeq++;
				OlrInfo=OlrInfo + string.Format("<Source>={0},<BAStatus>=000,<POQRef>={1:000000000},<BAFixing>=AMS1234CITI,<BAOrderNo>={2:000},<DetailTrn>={3}",RqSource,m_FxlmSeq+2000,m_FxlmSeq,RqDetailTrn);
			}
			if (FxlmInfo.Length==0)
			{
				string PayAmount="";
				string RemitAmount="";
				string Rate="";
				if ( (m_FxRates!=null) && (m_FxRates.TryGetValue(RqRemitCCY+RqPayCCY, out Rate)) && RqRemitAmt == "")
				{
					if ((RqPayAmt != "") && (RqRemitAmt == ""))
					{
						decimal amt = Convert.ToDecimal(RqPayAmt);
						decimal rt = Convert.ToDecimal(Rate);
						decimal amt1=amt*rt;
						RemitAmount=amt1.ToString("0.00");
						PayAmount=RqPayAmt;
					}
					if (Show)
						Console.WriteLine("1. rate - " + Rate + "  patamt - " + PayAmount + " remamt " + RemitAmount);
				}

				if ( (m_FxRates!=null) && (m_FxRates.TryGetValue(RqPayCCY+RqRemitCCY, out Rate)) && (RqPayAmt==""))
				{
					if ((RqPayAmt == "") && (RqRemitAmt != ""))
					{
						decimal amt = Convert.ToDecimal(RqRemitAmt);
						decimal rt = Convert.ToDecimal(Rate);
						decimal amt1=amt*rt;
						PayAmount=amt1.ToString("0.00");
						RemitAmount=RqRemitAmt;
					}
					if (Show)
						Console.WriteLine("2. rate - " + Rate + "  patamt - " + PayAmount + " remamt " + RemitAmount);
				}

				FxlmInfo=string.Format("<Source>={0},<BPPOQRef>={1:000000000},<PayCCY>={2},<PayAmt>={3},<RemitCCY>={4},<RemitAmt>={5},",RqSource,m_FxlmSeq+2000,RqPayCCY,PayAmount,RqRemitCCY,RemitAmount);
				FxlmInfo=FxlmInfo+string.Format("<BPStatus>=000,<BPRate>={0},<BPPOQRef>={1:000000000},<OLRDealNo>=MO{2:00000000000000}",Rate,m_FxlmSeq+2000,m_FxlmSeq+2500);
			}

			IDictionary<String, String> RspInfo = new Dictionary<String, String>();
			int pos2=OlrInfo.IndexOf("<Source>");
			if ( pos2 > -1 ) // found <Source>
			{
				FillRsp(ref RspInfo, OlrInfo.Substring(pos2));
			}
			pos2=FxlmInfo.IndexOf("<Source>");
			if ( pos2 > -1 ) // found <Source>
			{
				FillRsp(ref RspInfo, FxlmInfo.Substring(pos2));
			}
			
			if (Show)
				foreach ( KeyValuePair<string, string> a in RspInfo)
					Console.WriteLine ("Key list - " + a.Key + " val - " + a.Value);
					
	// We found the msg in the Src Db. See if the local_ref in there = to the local_ref in request.
			if (RqDetailTrn != RspInfo["<DetailTrn>"] )
			{
				ReportError(string.Format("Ack_FXLM 15: Skip Ack. Reference not equal Req - {0}; Reply - {1} ",RqDetailTrn,RspInfo["<DetailTrn>"]),2);
				// for now return finalmsg;
			}
		
// 5. Use fetched info to format outgoing response.
			StringBuilder outText = new StringBuilder();
			outText.Length=0;
			outText.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><WORLDLINK><BenchAck><BAHeader>");
			outText.Append(string.Format("<Source>{0}</Source>",RqSource) );
			outText.Append(string.Format("<ClientNo>{0}</ClientNo>",RqClient) );
			outText.Append("<BranchNo></BranchNo>");
			outText.Append("<PrefPrice>N</PrefPrice>");
			outText.Append("<BaseNo></BaseNo>");
			outText.Append(string.Format("<FXLMEntity>{0}</FXLMEntity>",RqEntity) );
			outText.Append(string.Format("<HDRTrn>{0}</HDRTrn>",RqHdrTrn) );
			outText.Append(string.Format("<RspDateTime>{0}</RspDateTime></BAHeader>",RqSentDate.Replace(" ","-").Replace(":",".") ) );
			outText.Append(string.Format("<BADetail><DetailTrn>{0}</DetailTrn>",RqDetailTrn ) );
			outText.Append(string.Format("<BAStatus>{0}</BAStatus>",RspInfo["<BAStatus>"] ) );
			outText.Append("<BAErrorTyp></BAErrorTyp>");
			outText.Append("<BAErrMessage></BAErrMessage>");
			outText.Append(string.Format("<POQRef>{0}</POQRef>",RspInfo["<POQRef>"] ) );
			outText.Append(string.Format("<BAFixing>{0}</BAFixing>",RspInfo["<BAFixing>"] ) );
			outText.Append(string.Format("<BAOrderNo>{0}</BAOrderNo></BADetail></BenchAck></WORLDLINK>",RspInfo["<BAOrderNo>"] ) );

			finalmsg[0]=Convert.ToString(outText);

			if (Show)
				Console.WriteLine (" final - " + finalmsg[0]);

			outText.Length=0;
			outText.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><WORLDLINK><BenchRsp><BPHeader>");
			outText.Append(string.Format("<Source>{0}</Source>",RqSource) );
			outText.Append(string.Format("<ClientNo>{0}</ClientNo>",RqClient) );
			outText.Append("<BranchNo></BranchNo>");
			outText.Append("<PrefPrice>N</PrefPrice>");
			outText.Append("<BaseNo></BaseNo>");
			outText.Append(string.Format("<FXLMEntity>{0}</FXLMEntity>",RqEntity) );
			outText.Append(string.Format("<HDRTrn>{0}</HDRTrn>",RqHdrTrn) );
			outText.Append(string.Format("<RspDateTime>{0}</RspDateTime></BPHeader>",RqSentDate.Replace(" ","-").Replace(":",".") ) );
			outText.Append(string.Format("<BPDetail><DetailTrn>{0}</DetailTrn>",RqDetailTrn ) );
			outText.Append(string.Format("<BPStatus>{0}</BPStatus>",RspInfo["<BPStatus>"] ) );
			outText.Append("<BPErrorTyp></BPErrorTyp>");
			outText.Append("<BPErrMessage></BPErrMessage>");
			outText.Append(string.Format("<BPPOQRef>{0}</BPPOQRef>",RspInfo["<BPPOQRef>"] ) );
			outText.Append(string.Format("<DealTyp>{0}</DealTyp>",RqDealTyp) );
			outText.Append(string.Format("<PayCCY>{0}</PayCCY>",RspInfo["<PayCCY>"]) );
			outText.Append("<PayAmt>");
			outText.Append(string.Format("{0,16}",RspInfo["<PayAmt>"]));  //16 ch long
			outText.Append("</PayAmt>");
			outText.Append(string.Format("<RemitCCY>{0}</RemitCCY>",RspInfo["<RemitCCY>"] ) );
			outText.Append("<RemitAmt>");
			outText.Append(string.Format("{0,16}",RspInfo["<RemitAmt>"] ) ); // 16 ch (from newjournal or calculated)
			outText.Append("</RemitAmt>");
			outText.Append(string.Format("<RateTerm>{0}</RateTerm>",RqRateTerm) );
			outText.Append("<BPRate>");
			outText.Append(string.Format("{0,17}",RspInfo["<BPRate>"] ) ); // 17 ch (from newjournal or calculated)
			outText.Append("</BPRate>");
			outText.Append(string.Format("<ValDate>{0}</ValDate>",RqValDate) );
			outText.Append(string.Format("<BookDate>{0}</BookDate>",RqValDate) );
			outText.Append(string.Format("<BAOrderNo>{0}</BAOrderNo>",RspInfo["<BAOrderNo>"] ) );  //(from newjournal or make it up)
			outText.Append(string.Format("<BenchFixing>{0}</BenchFixing>",RqBench) );
			outText.Append(string.Format("<OLRDealNo>{0}</OLRDealNo></BPDetail></BenchRsp></WORLDLINK>",RspInfo["<OLRDealNo>"] ) );  // (from newjournal or make up)

			finalmsg[1]=Convert.ToString(outText);

			if (Show)
				Console.WriteLine (" final - " + finalmsg[1]);

			RspInfo.Clear();
			return finalmsg;			
		}

		private void FillRsp(ref IDictionary<String,String> RspData, string intext)
		{
			string[] info1 = intext.Split(',');
			foreach (string line in info1)
			{
				if (Show)
					Console.WriteLine ("line before split " + line);
				if (line.IndexOf("=") == -1)
					continue;
				string[] t1 = line.Split('=');
				if (Show)
					Console.WriteLine ("Info Split " + t1[0] + " - " + t1[1]);
				if (t1[0].IndexOf("Date") != -1)
					t1[1] = t1[1].Replace(" ","-").Replace(":",".");
				try { RspData.Add(t1[0],t1[1].TrimEnd() ); }
				catch {}
			}
		}
		
		public string Ack_FXRATE(DBAccess Sql_Connection, DBAccess Sql_ReadConnection, string InText, string DbType, string SrcStr, string TrgStr, string ChangeRef, string DbPrefix)

		{
			if (Show)
				Console.WriteLine ("FXRATE ack");
			m_DbPrefix = DbPrefix;
			string finalmsg="";
			string SrcMid="";
			string TrgMid="";
			if (_simLog == null )
				_simLog = new SimulatorLog("Receiver");
			if ( (m_OraSrcConnection == null) && (DbType=="ORA") )
			{
				m_OraSrcConnection=new OracleConnection();
				m_OraSrcConnection.ConnectionString = SrcStr;
				m_OraSrcConnection.Open(); 
			}
			if (m_OraTrgConnection == null)
			{
				m_OraTrgConnection=new OracleConnection();
				m_OraTrgConnection.ConnectionString = TrgStr;
				m_OraTrgConnection.Open(); 
			}
// 1. Find MID from incoming Text.
			int pos = InText.IndexOf("{108:");
			if (pos != -1)
			{
				pos = pos + 5;
				TrgMid = InText.Substring(pos, 16);
				if (DbType == "ORA")
				{
					SrcMid = GetTrgMidOra(ChangeRef, "mid", TrgMid);
				}
				else
				{
					SrcMid = GetSrcMidSql(Sql_ReadConnection,ChangeRef,"mid", TrgMid);
				}
				if (Show)
					Console.WriteLine ("Source mid derived - " + SrcMid);
			}
			else
			{
				if (Show)
					Console.WriteLine ("Target Mid not found no Ack back.");
				return "";
			}
			
			string Content="";
			if (DbType == "ORA")
			{
				OracleCommand command = m_OraSrcConnection.CreateCommand();

				command.CommandText = string.Format("select contents from {0}swfmids where mid='{1}' and direction='OUT'", m_DbPrefix, SrcMid );
				OracleDataReader reader=null;
				try { reader = command.ExecuteReader(); }
				catch (Exception ex)
				{
					if (Show)
						Console.WriteLine ("Try to  get SWFMID contents. Oracle Error.");
					ReportError(string.Format("Ack_FXRATE: 23. Oracle error: {0},",ex.Message),2);
					Content = MakeContent(InText);	// Original response not found . Lets make one.
				}
				if (reader.Read()) 
				{ 
					if ( !reader.IsDBNull(0) )
						Content = ((string)reader["CONTENTS"]); 
					else
						Content ="";
					if (Show)
						Console.WriteLine ("ORA. Derived content : " + Content);
				}
				else
					Content = MakeContent(InText);	// Original response not found . Lets make one.
				command.Dispose();
				reader.Close();
			}
			else
			{
				string Cmd = string.Format("select contents from {0}swfmids where mid='{1}' and direction='OUT'",m_DbPrefix,SrcMid );
				try { Sql_ReadConnection.OpenDataReader(Cmd); }
				catch (Exception ex)
				{
					ReportError(string.Format("Ack_FXRATE: SQL error: {0},",ex.Message),2);
					Content = MakeContent(InText);	// Original response not found . Lets make one.
				}
				if (Sql_ReadConnection.SQLDR.Read())
				{
					Content = (Sql_ReadConnection.SQLDR[0].ToString().Trim()); 
				}
				else
					Content = MakeContent(InText);	// Original response not found . Lets make one.
				if (Show)
					Console.WriteLine ("SQL. Derived content : " + Content);

				Sql_ReadConnection.CloseDataReader();
			}
// We need to get text between --Response from WL GPP-- and --DEAL 
			string tg1 = "----Response from WL GPP----";
			string tg2 = "----Deal Request to WL GPP----";
			finalmsg = GetTextBetween (Content,tg1,tg2);
			if (finalmsg.Length > 0)
			{
				pos = finalmsg.IndexOf("{108:");
				if (pos != -1)
				{
					pos = pos + 5;
					string s1 = finalmsg.Substring(0, pos);
					int pos1 = finalmsg.IndexOf("}", pos);
					string s2 = finalmsg.Substring(pos1);
					finalmsg = s1 + TrgMid + s2;
				}
			}
			if (Show)
				Console.WriteLine ("WL Response - " + finalmsg);
			return finalmsg;
		}

// SOURCE CAN BE SQL OR ORACLE. TARGET IS ALWAYS ORACLE in FT world.

// Returns Source Mid if Src Db is SQL. 		
		private string GetSrcMidSql (DBAccess ReadConnection, string ChRef, string FldName, string TrgFldValue)
		{
			if (Show)
				Console.WriteLine("Chref = " + ChRef + " Fldname = " + FldName + " Value = " + TrgFldValue);
			string Mid="";
			string Cmd ="";
			string orig_ref="";
			string orig_amt="";
			string orig_curr="";
			if ( ChRef=="N")
				Cmd = string.Format("select orig_reference,orig_amount,orig_currency from mif where {0}='{1}'", FldName, TrgFldValue); 
			else
				Cmd = string.Format("select orig_reference from mif where {0}='{1}'", FldName, TrgFldValue); 
			try { ReadConnection.OpenDataReader(Cmd); }
			catch (Exception ex)
			{
				ReportError(string.Format("Ack_FXRATE: SQL error: {0},",ex.Message),2);
				return "";
			}
			if (ReadConnection.SQLDR.Read())
			{
				if ( ChRef=="N")
				{
					orig_ref = (ReadConnection.SQLDR[0].ToString().Trim()); 
					orig_amt = (ReadConnection.SQLDR[1].ToString().Trim());
					orig_curr = (ReadConnection.SQLDR[2].ToString().Trim());
				}
				else
				{
					orig_ref = (ReadConnection.SQLDR[0].ToString().Trim()); 
				}
				if (Show)
					Console.WriteLine ("Look for source mid. Ref - " + orig_ref + " Amt- " + orig_amt + " Curr- " + orig_curr);
			}
			ReadConnection.CloseDataReader();
			if ( ChRef=="N")
			{
				m_SqlConnection = ReadConnection;
				Mid = GetSrcFromTrg(orig_ref,orig_amt,orig_curr, "SQL");
			}
			else
				Mid = orig_ref;
			return Mid;
		}


// Returns TrgMid if TrgDB is ORA.
		private string GetTrgMidOra (string ChRef, string FldName, string TrgFldValue)
		{
			string Mid="";
			string orig_ref="";
			string orig_amt="";
			string orig_curr="";
			if (Show)
				Console.WriteLine("Chref = " + ChRef + " Fldname = " + FldName + " Value = " + TrgFldValue);
			
			OracleCommand command = m_OraTrgConnection.CreateCommand();

			if ( ChRef=="N")
				command.CommandText = string.Format("select orig_reference, orig_amount, orig_currency from mif where {0}='{1}'", FldName, TrgFldValue );
			else
				command.CommandText = string.Format("select orig_reference from mif where {0}='{1}'", FldName,TrgFldValue );

			OracleDataReader reader;
			try { reader = command.ExecuteReader(); }
			catch (Exception ex)
			{
				ReportError(string.Format("GetTrgMidOra: 23. Oracle error: {0},",ex.Message),2);
				return "";
			}
			if (reader.Read()) 
			{ 
				if (ChRef=="N")
				{
					if ( !reader.IsDBNull(0) )
						orig_ref = ((string)reader["ORIG_REFERENCE"]); 
					else
						orig_ref ="";
					try {	orig_amt = reader.GetDecimal(1).ToString(); }
					catch { orig_amt = ""; }
					if ( !reader.IsDBNull(2) )
						orig_curr = ((string)reader["ORIG_CURRENCY"]); 
					else
						orig_curr = "";
				}
				else
				{
					if ( !reader.IsDBNull(0) )
						orig_ref = ((string)reader["ORIG_REFERENCE"]); 
					else
						orig_ref ="";
				}
				if (Show)
					Console.WriteLine("orig ref - " + orig_ref);
			}
			command.Dispose();
			reader.Close();
			if ( ChRef=="N")
				Mid = GetSrcFromTrg(orig_ref,orig_amt,orig_curr,"ORA");
			else
				Mid = orig_ref;
			if (Show)
				Console.WriteLine ("SrcMid = " + Mid);

			return Mid;
		}

// Returns SrcMid from SrcDB using ref,amt,curr
		private string GetSrcFromTrg (string ref1, string amt, string curr, string DbType)
		{
// Now use orig fields go to Src and look for Src mid.
			string Mid="";
			if (DbType == "ORA")
			{
				OracleCommand command = m_OraSrcConnection.CreateCommand();

				command.CommandText = string.Format("select mid from {0}mif where orig_reference='{1}' and orig_amount='{2}' and orig_currency='{3}'", m_DbPrefix,ref1, amt, curr );
				OracleDataReader reader;
				try { reader = command.ExecuteReader(); }
				catch (Exception ex)
				{
					ReportError(string.Format("Ack GetSrcFromTrg: 23. Oracle error: {0},",ex.Message),2);
					return "";
				}
				if (reader.Read()) 
				{ 
					if ( !reader.IsDBNull(0) )
						Mid = ((string)reader["MID"]); 
					else
						Mid ="";
				}
				command.Dispose();
				reader.Close();
			}
			else
			{
				string Cmd = string.Format("select mid from {0}mif where orig_reference='{1}' and orig_amount='{2}' and orig_currency='{3}'", m_DbPrefix,ref1, amt, curr ); 
				try { m_SqlConnection.OpenDataReader(Cmd); }
				catch (Exception ex)
				{
					ReportError(string.Format("ACK GetSrcFromTrg: 23. SQL error: {0},",ex.Message),2);
					return "";
				}
				if (m_SqlConnection.SQLDR.Read())
				{
					Mid = (m_SqlConnection.SQLDR[0].ToString().Trim()); 
					if (Show)
						Console.WriteLine ("Look for source mid. Ref - " + Mid);
				}
				m_SqlConnection.CloseDataReader();
				
			}
			return Mid;

		}

		private string MakeContent(string InText)
		{
			string OutText="";
			StringBuilder outmsg = new StringBuilder();
			outmsg.Length = 0;
			if (m_FxRates == null)
				LoadFxRates();
			int pos = InText.IndexOf("{1:F01");
			if (pos != -1)
			{
				OutText = InText.Substring(pos);
			}
			string bic1="";
			string bic2="";
			pos=OutText.IndexOf("{1:F01") + 6;
			if (pos!=-1)
				bic1=OutText.Substring(pos,12);
			pos=OutText.IndexOf("{2:I103") + 7;
			if (pos!=-1)
				bic2=OutText.Substring(pos,12);

			outmsg.Append("----Response from WL GPP----");
			outmsg.Append("{1:F01");
			outmsg.Append(bic2);
			outmsg.Append("0000000000}{2:I103");
			outmsg.Append(bic1);
			outmsg.Append("N}");
			pos=OutText.IndexOf("{3:");
			string scratch="";
			int pos1=OutText.IndexOf(":20");
			if (pos!=-1)
				scratch=OutText.Substring(pos,pos1 - pos);
			outmsg.Append(scratch);
			pos=OutText.IndexOf(":32");
			if (pos!=-1)
				scratch=OutText.Substring(pos1,pos - pos1);
			outmsg.Append(scratch);
			scratch=OutText.Substring(pos,11);
			outmsg.Append(scratch);
			pos+=11;
			string cur=OutText.Substring(pos,3);
			outmsg.Append(cur);
			pos+=3;
			pos1=OutText.IndexOf("\r\n", pos);
			string amt=OutText.Substring(pos,pos1 - pos);
			outmsg.Append(amt);
			outmsg.Append("\r\n:33B:");
			pos=OutText.IndexOf(":33B");
			string cur1=OutText.Substring(pos+5,3);
			string Rate="";
			string amt2="";

			if ( (m_FxRates!=null) && (m_FxRates.TryGetValue(cur+cur1, out Rate)) )
			{
				CultureInfo ci = new CultureInfo("de-DE");
                                decimal amtd = Convert.ToDecimal(amt,ci);
				decimal rt = Convert.ToDecimal(Rate);
				decimal amt1=amtd*rt;
				ci.NumberFormat.CurrencySymbol = "euro";
				amt2=amt1.ToString("F", ci);
			}
			else
			{
				amt2=amt;
				Rate="1,";
			}
			if (Show)
				Console.WriteLine("1. rate - " + Rate + "  payamt - " + amt + " remamt " + amt2);
			outmsg.Append(cur1);
			outmsg.Append(amt2);
			outmsg.Append("\r\n");
			outmsg.Append(":36:");
			outmsg.Append(Rate);
			outmsg.Append("\r\n");
			pos=OutText.IndexOf(":5");
			pos1=OutText.IndexOf(":72");
			scratch=OutText.Substring(pos,pos1 - pos);
			outmsg.Append(scratch);
			scratch = string.Format(":72:/NEWT/I{0:000000}",m_FxlmSeq);
			outmsg.Append(scratch);
			outmsg.Append("\r\n");
			outmsg.Append("/GPPREF/KDAIXX2ZOXL4\r\n");
			outmsg.Append("/RATETYPE/GUARANTEED\r\n-}");
			outmsg.Append("----Deal Request to WL GPP----");
			if (Show)
				Console.WriteLine("out text " + outmsg.ToString());
			return outmsg.ToString();
		}

		private string GetTextBetween (string txt, string tag1, string tag2)
		{
			int pos = txt.IndexOf(tag1);
			if (pos != -1)
			{
				pos = pos + tag1.Length;
				int pos1 = txt.IndexOf(tag2, pos);
				return txt.Substring(pos, pos1 - pos);
			}
			return "";
		}

		private void ReportError(string ErrMsg, int Arg)
		{
		    _simLog.Source = "Receiver";

		    // Write an error entry to the event log.
		    if (Arg == 2)
		    {
			    _simLog.WriteEntry(ErrMsg, EventLogEntryType.Error);
		    }
		    SimLog.log.write(m_Area, ErrMsg, true);
		    return;
        }
		
		public string FmtMsg(string source, ArrayList msgs)				
		{
			string finalmsg="";
			mqmsg.Length = 0;
            		switch (source)
            		{
				case "MQS":

					for (int i=0; i<msgs.Count;i++)
					{
				/*
				 * Plug in '??????' where the sequence number should go,
				 * and stuff the original trn into the header.
				 * Copy the first 14 bytes of the first line and turn it
				 * into a trailer.
		 		 */

						msg_array next_msg = (msg_array)msgs[i];
/*
				next_msg.qbltext = next_msg.qbltext.Remove(8,6);
				next_msg.qbltext = next_msg.qbltext.Insert(8, "??????");
				next_msg.qbltext = next_msg.qbltext.Remove(14,16);
				next_msg.qbltext = next_msg.qbltext.Insert(14, next_msg.OrigTrn);
				scratch = string.Format(next_msg.qbltext.Substring(0,14));
				scratch = scratch.Remove(0,1);
				scratch = scratch.Insert(0, "/");
*/
				/*
				 * Walk the msg text and fix the single quote issue.
				 */
						for (int i1 = 0; i1 < next_msg.qbltext.Length; i1++)
						{
						if (next_msg.qbltext[i1] == '\'')
						{
							next_msg.qbltext=next_msg.qbltext.Insert(i1,"'");
							i1++;
						}
						}
						mqmsg.Length = 0;
						mqmsg.Append(next_msg.qbltext);
						mqmsg.Append(scratch);
						mqmsg.Append("\r\n");
					
						finalmsg += mqmsg;
					}
					break;
				default:
					Console.WriteLine ("Unimplemented MQ source - {0}", source);
					break;
			}
			return (finalmsg);
		}
	}
}