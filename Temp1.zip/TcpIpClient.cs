/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
 * 
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 25-Jun-2017  JN  BBT research/debug additions. Use hard wired IP address cause DNS gethost 
 			cannot translate localhost.
 * 
*/
using System;
using System.Net;
using System.Net.Sockets;

namespace Simulator.TcpIp
{
	/// <summary>
	/// Summary description for tcpip client class
	/// </summary>
	public class TcpIpClient 
	{
		private const int BUFFERSIZE = 200000;
		private int m_port;
		private string m_serverIP;
		private Socket m_Socket;
		private int m_readLength;
		private ClientContext m_clientContext;
		private AsyncCallback d_dataRecievedCallback;
		public event ReceivedEventHandler eventDelegateDataRecieved;
		public event LinkEventHandler eventDelegateServerDisConnected;
		public event LogError eventError;
		private bool m_firstBlock;

		public bool firstBlock
		{
			set {m_firstBlock=value;}
			get {return m_firstBlock;}
		}
		
		public int readLength 
		{
			set {m_readLength=value;}
			get {return m_readLength;}
		}
		
		public TcpIpClient(string serverIP,int port)
		{
			Console.WriteLine(string.Format("Client connecting to address {0},port {1}",serverIP,m_port));
			try
			{
				
				IPHostEntry hostInfo = Dns.GetHostEntry(serverIP);
				IPAddress[] address = hostInfo.AddressList;
				m_serverIP=address[0].ToString();					 
			}
			catch(Exception e)
			{
				if(eventError != null)
					eventError(this,e);
				Console.WriteLine("Exception caught!!!");
				Console.WriteLine("Source : " + e.Source);
				Console.WriteLine("Message : " + e.Message);
			}

			if (m_serverIP == "")	//BBT problem. Temp solution in this case
				m_serverIP = "172.31.70.35";
			m_port = port;			
			m_Socket=null;
			m_readLength=BUFFERSIZE;
			m_firstBlock=true;
			Console.WriteLine(string.Format("Client connecting to address {0},port {1}",m_serverIP,m_port));

		}

		public void Start(bool WaitForConn)
		{
			Console.WriteLine("IpCleint Start.!!");
			if(m_Socket == null || !m_Socket.Connected)
			{
				m_Socket = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
				m_clientContext = new ClientContext(m_Socket,new byte[BUFFERSIZE]);
				d_dataRecievedCallback = new AsyncCallback(OnDataRecieved);
				while (WaitForConn)
				{
					try
					{
						m_Socket.Connect(new IPEndPoint(IPAddress.Parse(m_serverIP),m_port));
					}
					catch(Exception )//e)
					{
						System.Threading.Thread.Sleep(2000);	//sleep for 2 sec before
					}											// attempt another connection
					if (m_Socket.Connected)
					{
						Console.WriteLine(string.Format("Successfully connected to address {0},port {1}",m_serverIP,m_port));
						WaitForConn = false;
					}
					else
						Console.WriteLine(string.Format("Cannot connect to address {0},port {1}",m_serverIP,m_port));
				}
				Receive();
			}
		}

		public void Stop()
		{
			if (m_Socket.Connected)
			{
//				m_Socket.Shutdown(SocketShutdown.Both);
				m_Socket.Close();
			}
			
		}

	// wait for data. pass the callback routine to be called when data received
		public void Receive()
		{
			if (m_Socket.Connected)
				m_Socket.BeginReceive(m_clientContext.Buffer,0,m_readLength,SocketFlags.None,d_dataRecievedCallback,null);
		}

		private void OnDataRecieved(IAsyncResult ar)
		{			
			int byteCount = 0;
			bool postRead=true;
			try 
			{
				byteCount = m_Socket.EndReceive(ar);
			}
			catch(Exception ex)
			{
				Console.Write("Server disconnected. error code {0}",ex.Message);
				postRead=false;
				byteCount=0;
			}

//			if (byteCount == 0)
			if ((!postRead) ||(byteCount == 0))
			{
				if (eventDelegateServerDisConnected != null)	// server disconnected.
					eventDelegateServerDisConnected(this,new ClientContextArgs(m_clientContext)); // call the delegate
			}
			else
			{
// call the delegate to process what we got, then re-post the read
				if (eventDelegateDataRecieved != null)
				{
					if(byteCount != 0)
					{
						byte[] received=new byte[byteCount];
						Array.Copy(m_clientContext.Buffer,0,received,0,byteCount);
						eventDelegateDataRecieved(this,new ClientContextArgs(m_clientContext),received,byteCount);
					}
				}
				Receive();
			}
		}
		public void Send(byte [] data)
		{
			if (m_Socket != null && m_Socket.Connected)
				m_Socket.Send(data);
		}
	}
}
