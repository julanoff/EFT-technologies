/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Diagnostics;
using Simulator.DBLibrary;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Net;
using Simulator.TcpIp;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
/*
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 24-May-17	JR	Comment out loading DES from C: and, for BBT, load it from D:
 */

namespace SwfClient
{
	/// <summary>
	/// This is SwfClient link. It receives msgs from MTS system and queues them to receive queue.
	/// EVERYTHING THAT REFERFS TO 'Client' IN THIS PROGRAM ACTUALLY IS OUR SwfServer.cs
	/// That runs on this machine and simulates SnlSwiftClientAdapter and is being called by
	/// MTS system 'CLIENT'.
	/// </summary>
	public class SwfClient
	{
		//[DllImport("c:\\simulator\\allbin\\Des.dll", EntryPoint="des_pr", CharSet = CharSet.Auto)]
		[DllImport("Des.dll", EntryPoint="des_pr", CharSet = CharSet.Auto)]
		public static extern int des_pr([MarshalAs(UnmanagedType.LPArray)] byte[] m_drv, [MarshalAs(UnmanagedType.LPArray)] byte[] m_pass);
		private DBAccess m_readConnection;
		private DBAccess m_writeConnection;
		private bool m_DBConnected;
		private static string line_name;
		private string OurHostAddress;
		private string Area;
		private string Debug;
	        private int debugLevel;
		private string RootDir;
		private string Args;
		private string Refno;
		private string myProcName;
		private string status;
		string hold_text="";
		bool incomplete=false;
		private Process myProcess;
		private string m_partialBfr;

// File for logging if Debug is on.
		private StreamWriter sw;

		private	TcpIpClient m_IpOurClient;
		private	TcpIpServer m_IpMtsServer;
		private	ClientContext m_ServerContext;
		bool	m_LoggedOn;
		//bool	do_login_proc = true;
		bool	first_time = true;
		string	m_newswf;
		private	string m_ClientAddress;
		string  rline_name;
		string	m_ServerAddress;
		string  m_swftid;
		int	m_ServerPort;
		int	m_ClientPort;
		byte[]  m_pass = new byte[200];
		byte[]  m_drv = new byte[2];

		/// <summary>

		/// SwfClient comes up and binds to MTS application on the MTS host name
		/// and on port; After it receives connection from MTS it CONNECTS to
		/// SwfServer (local program) and sends it Session Reference.
		/// m_IpMtsServer is used to communicate to MTS. It waits for connection from MTS.
		/// m_IpOurClient is used to communicate to SwfServer (our program). It connects to SwfServer.

		/// This is the summary of Swift Process.
		/// The simulator should start SwfClient and SwfServer.
		/// SwfClient waits for connection from MTS.
		/// SwfServer waits for connection from SwfClient.
		/// MTS starts up and connects to SwfClient. SwfClient connects to SwfServer and tells it
		/// to send connection data. SwfServer gets the signal from SwfClient and connects to MTS.
		/// 
		/// </summary>
		public SwfClient()
		{
			m_readConnection=new DBAccess();
			m_writeConnection=new DBAccess();
			m_DBConnected=false;
			m_ClientAddress="localhost";
			m_partialBfr="";
			m_pass = System.Text.Encoding.ASCII.GetBytes("marina12345678901234567890123456");
			m_drv = System.Text.Encoding.ASCII.GetBytes("d:");

			m_LoggedOn=false;
		}

		[STAThread]
		static void Main(string[] args)
		{
			SwfClient cln = new SwfClient();
			cln.dorcv(args);
		}
		private void dorcv(string[] args)
		{
			Area = args.GetValue(0).ToString();
			line_name = args.GetValue(1).ToString();
			rline_name = "RCV_"+line_name.Substring(0,10)+"_SND";
			myProcess = Process.GetCurrentProcess();
			myProcName="SwfClient"+"_"+Area+"_"+line_name; 
			Args = String.Format("{0} {1}", args[0].TrimEnd(),args[1].TrimEnd()); 
			get_sim_values();

//Register the process. 
			if (!m_readConnection.RegisterProcess(m_readConnection, m_writeConnection, "SwfClient", Args, sw, debugLevel, Area))
			{
				status="Error registering a process.";
				m_readConnection.RecordEvent(0,myProcName,string.Format("{0}", status), Area);
				m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
				return;
			}

			get_line_values(line_name);
// SWPAPC connects to us here. Therefore override Server host name
// IpServer uses '.Any' to Bind.
			m_IpMtsServer = new TcpIpServer(m_ServerAddress,m_ServerPort);
			if (m_newswf == "V1")
				m_IpMtsServer.readLength=40;
			else
				m_IpMtsServer.readLength=8;
			m_IpMtsServer.eventDelegateDataRecieved+=new ReceivedEventHandler(OnServerDataRecieved);
			m_IpMtsServer.eventDelegateClientConnected+=new LinkEventHandler(OnMTSConnected);
			m_IpMtsServer.eventDelegateClientDisConnected+=new LinkEventHandler(OnMTSDisConnected);

			m_IpMtsServer.Start();     // listens to MTS to start the session.
			for (;;)		//  loop forever
			{
//				if (do_login_proc)
//					m_IpMtsServer.Start(); // Listen to MTS to start the session
				System.Threading.Thread.Sleep (-1);
			}
		}
		private void get_sim_values()
		{
			if(!m_DBConnected)
			{
				m_readConnection.Connect(false,Area);
				m_writeConnection.Connect(true,Area);
				m_DBConnected=true;
			}
			string Cmd;
			string l_Area;
			Cmd=string.Format("select OurHostAddress, Area, RootDir, Debug, MTSHostName, SwfVersion from SimulatorControl");
			m_readConnection.OpenDataReader(Cmd);
			m_readConnection.SQLDR.Read();
			OurHostAddress=m_readConnection.SQLDR["OurHostAddress"].ToString().TrimEnd();
			Debug=m_readConnection.SQLDR["Debug"].ToString().TrimEnd();
            debugLevel = 0;

            try
            {
                debugLevel = int.Parse(Debug);
            }
            catch { }
			RootDir=m_readConnection.SQLDR["RootDir"].ToString().TrimEnd();
			l_Area=m_readConnection.SQLDR["Area"].ToString().TrimEnd();
			m_ServerAddress=m_readConnection.SQLDR["MTSHostName"].ToString().TrimEnd();
			m_newswf=m_readConnection.SQLDR["SwfVersion"].ToString().TrimEnd();
			if ((m_newswf != "V0") && (m_newswf != "V1"))
				m_newswf = "V0";
			m_readConnection.CloseDataReader();
			if (Debug=="Y")
			{
				string filename=string.Format("{0}logs/{1}_{2}{3}.log",RootDir,myProcName,DateTime.Now.ToShortDateString().Replace("/",""),DateTime.Now.ToShortTimeString().Replace(":","").Substring(0,4));
				FileStream file1 = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);            
				sw = new StreamWriter(file1);// Create a new strem
			}
			if (Area != l_Area)
			{
				string st="Process not Started. Areas Discrepancy";
				m_readConnection.RecordEvent(0,myProcName,string.Format("{0}", st), Area);
				m_readConnection.ConsoleWrite(Debug,myProcName,sw,"Areas Discrepancy");
				myProcess.Kill();	//unexcpected error DIE.
			}
		}
		private void get_line_values(string line_name)
		{
			if(!m_DBConnected)
			{
				m_readConnection.Connect(false,Area);
				m_writeConnection.Connect(true,Area);
				m_DBConnected=true;
			}
			string Cmd;
			Cmd=string.Format("select Port, IntPort, SwfTid from LinkControl where LineName='{0}'",line_name);
			m_readConnection.OpenDataReader(Cmd);
			m_readConnection.SQLDR.Read();
			m_ServerPort=m_readConnection.SQLDR.GetInt32(0);
//			m_ServerPort++;
			m_ClientPort=m_readConnection.SQLDR.GetInt32(1);  //local port to talk to SwfServer. Confusing? See comments on top.
			m_swftid=m_readConnection.SQLDR["SwfTid"].ToString().TrimEnd();
			m_readConnection.CloseDataReader();
		}

		private void OnMTSConnected(object sender, ClientContextArgs ca)
		{
			status = string.Format("{0} connected to MTS.",ca.Context.Socket.RemoteEndPoint.ToString());
			m_readConnection.RecordEvent(0,myProcName,string.Format("{0}", status), Area);
			m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
			// when we receive a connection from the client, we connect to the server port
			m_ServerContext=ca.Context;
			if (first_time)
			{
				m_IpOurClient = new TcpIpClient(m_ClientAddress,m_ClientPort);
				if (m_newswf == "V1")
					m_IpOurClient.readLength=40;
				else
					m_IpOurClient.readLength=8;

				m_IpOurClient.eventDelegateDataRecieved+=new ReceivedEventHandler(OnClientDataRecieved);
//				Console.Write ("Connecting to SwfServer on local machine.\n");
				first_time = false;

	Console.WriteLine (" First time. starting SWFServer " + m_ClientAddress + " on port " + m_ClientPort);

				m_IpOurClient.Start(true);
			}
			if (m_newswf == "V1")
			{
	Console.WriteLine (" starting SWFServer " + m_ClientAddress + " on port " + m_ClientPort);
				string answer="cn=george-bush,o=bofaus6s,o=swift";
				sendMTS(answer,-3);
	Console.WriteLine (" after send ");
			}
		}

		private void OnMTSDisConnected(object sender, ClientContextArgs ca)
		{
			status = string.Format ("{0} disconnected.",ca.Context.Socket.RemoteEndPoint.ToString());
			m_readConnection.RecordEvent(0,myProcName,string.Format("{0}", status), Area);
			m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
//			m_IpOurClient.Stop();			// if disconnected from server
			m_IpMtsServer.Stop();
			m_LoggedOn=false;
			string Cmd=string.Format("update SwfStats set EndTime = '{0}' where SessionNo='{1}'", DateTime.Now,Refno);
			m_writeConnection.Execute(Cmd,true);
// added this to reconnect
//			m_IpOurClient.Start(true);
		}

		private void OnClientDataRecieved(object sender, ClientContextArgs ca,byte[] rcvBfr,int byteCount)
//  Data from SwfServer (our other process).
		{
			if(m_IpOurClient.firstBlock)
			{
				m_IpOurClient.readLength=getReadLength(rcvBfr);
				m_IpOurClient.firstBlock=false;
			}
			else
			{
				if (m_newswf == "V1")
					m_IpOurClient.readLength=40;
				else
					m_IpOurClient.readLength=8;
				m_IpOurClient.firstBlock=true;
				status = string.Format ("Received from client {0} - {1}", ca.Context.Socket.RemoteEndPoint.ToString(),Encoding.ASCII.GetString(rcvBfr,0,byteCount));
//				m_readConnection.RecordEvent(0,myProcName,string.Format("{0}: {1}", DateTime.Now, status), Area);
				m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
			}
		}

		private void OnServerDataRecieved(object sender, ClientContextArgs ca,byte[] rcvBfr,int byteCount)
// Data from MTS.
		{
			if(m_IpMtsServer.firstBlock)
			{
				int rcvLength=m_IpMtsServer.readLength=getReadLength(rcvBfr);
				int rcvStatus=getRcvStatus(rcvBfr);
				status = string.Format ("Length block: length {0} readlength {1} status {2}",byteCount,rcvLength,rcvStatus);
				m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
				m_IpMtsServer.firstBlock=false;
			}
			else
			{
				string buffer=Encoding.ASCII.GetString(rcvBfr,0,byteCount);			
				if(byteCount < m_IpMtsServer.readLength)
				{
					m_partialBfr+=buffer;
					m_IpMtsServer.readLength -= byteCount;
					status = string.Format ("Partial rcv.  Received from server  {1} bytes {0} - {2}", byteCount,ca.Context.Socket.RemoteEndPoint.ToString(), Encoding.ASCII.GetString(rcvBfr,0,byteCount));
				}
				else
				{
					if (m_newswf == "V1")
						m_IpMtsServer.readLength=40;
					else
						m_IpMtsServer.readLength=8;
					m_IpMtsServer.firstBlock=true;
					status = string.Format ("Received from server bytes {2} {0} - {1}", byteCount,ca.Context.Socket.RemoteEndPoint.ToString(), Encoding.ASCII.GetString(rcvBfr,0,byteCount));
					string processBfr=m_partialBfr+buffer;
					if (m_newswf == "V1")
						ProcessRcv_v1(processBfr );
					else
						ProcessRcv_v0(processBfr );
					m_partialBfr="";
				}
				m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
			}
		}
		
		private void ProcessRcv_v1(string buffer )
		{	
			if(!m_LoggedOn)
			{
	/*  ------------------------- */
				if(buffer.IndexOf("{1:L02") != -1)	// Ignore L02. Server fires L22 regardless.
				{
	//					Console.Write ("L02 received\n");
					return;
				}
	//  ----- Look for FIN login request. Notify client to snd A23 msg */
				if(buffer.IndexOf("{1:A03") != -1)
				{
//					Console.Write ("A03 received\n");
					m_LoggedOn=true;
					sendSwfServer("A03 received");
					return;
				}

				if(buffer.IndexOf("AuthorisationContext")!= -1)
				{
				/* Before we send response get ref number */
				int RefNoStart=buffer.IndexOf("<SenderRef>");
				if(RefNoStart != -1)
				{
					RefNoStart+="<SenderRef>".Length;
					int RefNoEnd=buffer.IndexOf("<",RefNoStart);
						if(RefNoEnd != -1)
						{
							string Refno=buffer.Substring(RefNoStart,RefNoEnd-RefNoStart);
							sendSwfServer(Refno);	// send session ref no to SwfServer

							string Cmd=string.Format("insert into SwfStats (SessionNo, StartTime, NoSent, NoReceived) values ('{0}','{1}',0,0)", Refno,DateTime.Now);
                            m_writeConnection.Execute(Cmd, true);
						return;
						}
					}
				}
			}
			else
				ProcessRcv_v0(buffer);
		}

		private void ProcessRcv_v0(string buffer )
		{			
			string answer;
			if(!m_LoggedOn)
			{
				if(buffer.IndexOf("<Sw:CryptoMode>Automatic</Sw") != -1)
				{
					answer="<?xml version=\"1.0\"?>\n"+
						"<!DOCTYPE SwSec:CreateContextResponse SYSTEM \"SwPrimitive.dtd\">\n\n"+
						"Sw:InitResponse SYSTEM \"SwPrimitive.dtd\">\n"+
						"<Sw:InitResponse/>";
					sendMTS(answer,0);
					return;
				}
				if(buffer.IndexOf("CreateContextRequest") != -1)
				{
					answer="<?xml version=\"1.0\"?>\n"+
						"<!DOCTYPE SwSec:CreateContextResponse SYSTEM \"SwPrimitive.dtd\">\n\n"+
						"<SwSec:CreateContextResponse>\n"+
						"    <SwSec:SecurityContext>\n"+
//						"        <SwSec:UserDN>cn=george-bush,o=bofaus6s,o=swift</SwSec:UserDN>\n"+
						"        <SwSec:UserDN>cn=george-bush,o="+m_swftid.Substring(0,7).ToLower()+"s,o=swift</SwSec:UserDN>\n"+
						"    </SwSec:SecurityContext>\n"+
						"<SwSec:CertPolicyId>1.3.21.6.1</SwSec:CertPolicyId>\n"+
						"</SwSec:CreateContextResponse>";
					sendMTS(answer,0);
					return;
				}
	
				//  ----- Look for FIN login request. Notify client to snd A23 msg */
				if(buffer.IndexOf("{1:A03") != -1)
				{
//					Console.Write ("A03 received\n");
					m_LoggedOn=true;
					answer=
						"<?xml version=\"1.0\"?>\n"+
						"<!DOCTYPE SwInt:SendResponse SYSTEM \"SwPrimitive.dtd\">\n\n"+
						"<SwInt:SendResponse>\n"+
						"    <SwInt:SendReference>\n"+
						"     <SwInt:SendReferenceVal>2</SwInt:SendReferenceVal>\n"+
						"    </SwInt:SendReference>\n"+
						"    <SwInt:SwiftRequestRef>SNL11063-2005-04-21T17:25:03.29988.000007Z</SwInt:SwiftRequestRef>\n"+
						"</SwInt:SendResponse>" ;
					sendMTS(answer,0);
					sendSwfServer("A03 received");
					return;
				}
				/*  ------------------------- */
				if(buffer.IndexOf("ExchangeRequest")!= -1)
				{
					/* Before we send response get ref number */
					int RefNoStart=buffer.IndexOf("<SenderRef>");
					if(RefNoStart != -1)
					{
						RefNoStart+="<SenderRef>".Length;
						int RefNoEnd=buffer.IndexOf("<",RefNoStart);
						if(RefNoEnd != -1)
						{
							Refno=buffer.Substring(RefNoStart,RefNoEnd-RefNoStart);
							sendSwfServer(Refno);	// send session ref no to SwfServer

							string Cmd=string.Format("insert into SwfStats (SessionNo, StartTime, NoSent, NoReceived) values ('{0}','{1}',0,0)", Refno,DateTime.Now);

							m_writeConnection.Execute(Cmd,true);
							answer=
								"<?xml version=\"1.0\"?>\n"+
								"<SwInt:ExchangeResponse>"+
								"  <SwInt:ResponseHandle>\n"+
								"          <SwInt:RequestDescriptor>\n"+
								"              <SwInt:SwiftRequestRef>SNL11063-2005-04-21T17:24:19.29988.000004Z"+
								"          </SwInt:SwiftRequestRef>\n"+
								"          <SwInt:SwiftRef>swi00003-2005-04-21T17:24:20.15393.6302791Z"+
								"          </SwInt:SwiftRef>\n"+
								"      </SwInt:RequestDescriptor>\n"+
								"         <SwInt:ResponseDescriptor>\n"+
								"          <SwInt:SwiftResponseRef>snp00099-2005-04-21T17:24:20.8313.016926Z"+
								"     </SwInt:SwiftResponseRef>\n"+
								"      </SwInt:ResponseDescriptor>\n"+
								"      <SwInt:ResponseHeader>\n"+
								"  <SwInt:Responder>cn=fa,cn=fin,o=swift,o=swift</SwInt:Responder>\n"+
								"  </SwInt:ResponseHeader>\n"+
								"      <SwInt:ResponsePayload></SwInt:ResponsePayload>\n"+
								"    </SwInt:ResponseHandle>"+
								"</SwInt:ExchangeResponse>" ;
							sendMTS(answer,0);
							return;
						}
					}
				}
				/*  ------------------------- */
				if(buffer.IndexOf("RequestPayload")!= -1)
				{
					answer=
						"<?xml version=\"1.0\"?>\n"+
						"<!DOCTYPE SwInt:SendResponse SYSTEM \"SwPrimitive.dtd\">\n\n"+
						"<SwInt:SendResponse>\n"+
						"    <SwInt:SendReference>\n"+
						"     <SwInt:SendReferenceVal>1</SwInt:SendReferenceVal>\n"+
						"    </SwInt:SendReference>\n"+
						"    <SwInt:SwiftRequestRef>SNL11063-2005-04-21T17:25:03.29988.000007Z</SwInt:SwiftRequestRef>\n"+
						"</SwInt:SendResponse>" ;
					sendMTS(answer,0);
					return;
				}	
				/*  ------------------------- */
				if(buffer.IndexOf("WaitRequest")!= -1)
				{
					answer=
						"<?xml version=\"1.0\"?>\n"+
						"<SwInt:WaitResponse><SwInt:WaitReference>\n"+
						"        <SwInt:SendReferenceVal>2</SwInt:SendReferenceVal>\n"+
						"    </SwInt:WaitReference><SwInt:ResponseHandle>\n"+
						"        <SwInt:RequestDescriptor>\n"+
						"            <SwInt:SwiftRequestRef>SNL11063-2005-04-21T17:25:03.29988.000007Z</SwInt:SwiftRequestRef>\n"+
						"<SwInt:SwiftRef>swi00001-2005-04-21T17:25:04.24072.580232Z</SwInt:SwiftRef>\n"+
						"        </SwInt:RequestDescriptor>\n"+
						"        <SwInt:ResponseDescriptor>\n"+
						"            <SwInt:SwiftResponseRef>snp00067-2005-04-21T17:25:04.7133.1036438Z</SwInt:SwiftResponseRef>\n"+
						"  </SwInt:ResponseDescriptor>\n"+
						"      <SwInt:ResponseHeader>.<SwInt:Responder>cn=fb67,cn=fin,o=swift,o=swift</SwInt:Responder>\n"+
						"</SwInt:ResponseHeader>\n"+
						"        <SwInt:ResponsePayload></SwInt:ResponsePayload>\n"+
						"    </SwInt:ResponseHandle></SwInt:WaitResponse>" ;
					sendMTS(answer,0);
					return;
				}
			}
			else
			{			
				if (incomplete)
				{
					for (int i1 = 0; i1 < buffer.Length; i1++)
					{
						if (buffer[i1] == '\'')
						{
							buffer=buffer.Insert(i1,"'");
							i1++;
						}
					}
					hold_text += buffer;					
					string Cmd=string.Format("insert into {0} values ('{1}')", rline_name,hold_text);
					m_writeConnection.Execute(Cmd,true);
					incomplete = false;
				}
				if(buffer.IndexOf("RequestType>CLOSE</SwInt")!= -1)
				{
					answer=
					"<?xml version=\"1.0\"?>\n<SwInt:ExchangeResponse><SwInt:ResponseHandle>\n"+
					"<SwInt:RequestDescriptor>\n"+
					"<SwInt:SwiftRequestRef>SNL11063-2006-03-01T17:19:43.23426.000039Z</SwInt:SwiftRequestRef>\n"+
					"<SwInt:SwiftRef>swi00003-2006-03-01T17:19:43.16972.4853563Z</SwInt:SwiftRef>\n"+
					"</SwInt:RequestDescriptor>\n<SwInt:ResponseDescriptor>\n"+
					"<SwInt:SwiftResponseRef>snp00055-2006-03-01T17:19:43.5867.342500Z</SwInt:SwiftResponseRef>\n"+
					"</SwInt:ResponseDescriptor>\n"+
					"<SwInt:ResponseHeader>\n<SwInt:Responder>cn=fb55,cn=fin,o=swift,o=swift</SwInt:Responder>\n"+
					"</SwInt:ResponseHeader>\n<SwInt:ResponsePayload></SwInt:ResponsePayload>\n"+
					"</SwInt:ResponseHandle></SwInt:ExchangeResponse>";
					if (m_newswf != "V1")
						sendMTS(answer,0);
					sendSwfServer("CLOSE Session");
					status="Close Session from MTS.";
					m_readConnection.RecordEvent(0,myProcName,string.Format("{0}", status), Area);
					m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
					m_LoggedOn=false;
					if (m_newswf == "V1")
					{
//						m_IpOurClient.Stop();			// if disconnected from server
//						m_IpMtsServer.Stop();
					}
					return;
				}
				if(buffer.IndexOf("![CDATA")!= -1)
				{
// Look for F05 and A06 - quit requests from MTS
					if ((buffer.IndexOf("{1:F05")!= -1) ||
					    (buffer.IndexOf("{1:A06")!= -1))
					{
						if (buffer.IndexOf("{1:F05")!= -1)
							sendSwfServer("F05 received");
						else
							sendSwfServer("A06 received");
					}
					else
					{
// We got data. enqueue it to the receiver queue.
// Change all single quota's ' to ''.
						for (int i1 = 0; i1 < buffer.Length; i1++)
						{
							if (buffer[i1] == '\'')
							{
								buffer=buffer.Insert(i1,"'");
								i1++;
							}
						}
						if (buffer.IndexOf("</SwInt:SendRequest>")==-1)
						{
							status="Received Incomplete Message.";
							m_readConnection.RecordEvent(0,myProcName,string.Format("{0}", status), Area);
							m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
							hold_text += buffer;
							incomplete = true;
						}
						else
						{
							string Cmd=string.Format("insert into {0} values ('{1}')", rline_name,buffer);
							m_writeConnection.Execute(Cmd,true);
							incomplete = false;
						}
					}
					answer=
						"<?xml version=\"1.0\"?>\n"+
						"<!DOCTYPE SwInt:SendResponse SYSTEM \"SwPrimitive.dtd\">\n\n"+
						"<SwInt:SendResponse>\n"+
						"    <SwInt:SendReference>\n"+
						"     <SwInt:SendReferenceVal>1</SwInt:SendReferenceVal>\n"+
						"    </SwInt:SendReference>\n"+
						"    <SwInt:SwiftRequestRef>SNL11063-2005-04-21T17:25:03.29988.000007Z</SwInt:SwiftRequestRef>\n"+
						"</SwInt:SendResponse>";
					if (m_newswf != "V1")	// old way V0
						sendMTS(answer,0);	
					return;
				}
				if ((buffer.IndexOf("<SwInt:RequestType>ABORT<") != -1) ||
				    (buffer.IndexOf("<AbortCode>") != -1))
				{
					status="Received Abort from MTS Disconnecting.";
					m_readConnection.RecordEvent(0,myProcName,string.Format("{0}", status), Area);
					m_readConnection.ConsoleWrite(Debug,myProcName,sw,string.Format("{0}\r\n",status));
					if (m_newswf != "V1")
					{
//						m_IpOurClient.Stop();			// if disconnected from server
						m_IpMtsServer.Stop();
					}
					m_LoggedOn=false;
					return;
				}
				if (buffer.IndexOf("WaitRequest")!= -1)
				{						
					answer= "<?xml version=\"1.0\"?>\n"+
						"<SwInt:WaitResponse><SwInt:WaitReference>\n"+
						"        <SwInt:SendReferenceVal>2</SwInt:SendReferenceVal>\n"+
						"    </SwInt:WaitReference><SwInt:ResponseHandle>\n"+
						"        <SwInt:RequestDescriptor>\n"+
						"            <SwInt:SwiftRequestRef>SNL11063-2005-04-21T17:25:03.29988.000007Z</SwInt:SwiftRequestRef>\n"+
						"<SwInt:SwiftRef>swi00001-2005-04-21T17:25:04.24072.580232Z</SwInt:SwiftRef>\n"+
						"        </SwInt:RequestDescriptor>\n"+
						"        <SwInt:ResponseDescriptor>\n"+
						"            <SwInt:SwiftResponseRef>snp00067-2005-04-21T17:25:04.7133.1036438Z</SwInt:SwiftResponseRef>\n"+
						"  </SwInt:ResponseDescriptor>\n"+
						"      <SwInt:ResponseHeader>.<SwInt:Responder>cn=fb67,cn=fin,o=swift,o=swift</SwInt:Responder>\n"+
						"</SwInt:ResponseHeader>\n"+
						"        <SwInt:ResponsePayload></SwInt:ResponsePayload>\n"+
						"    </SwInt:ResponseHandle></SwInt:WaitResponse>";
					if (m_newswf != "V1")
						sendMTS(answer,0);
					return;
				}
			}
		}

		private void sendSwfServer(string bfr)  // This date for SwfServer. Our other program.
		{
			if (m_newswf == "V1")
			{
/*   unsigned char xLAUValue[ SNLADPHDR_LAU_SIZE] (32 byte) 256-byte LAU value */
				byte[] LAUData = new byte[32]; 	/* new 32 byte. need to find what to map */
				byte[] type=BitConverter.GetBytes(0);
				byte[] length=BitConverter.GetBytes(bfr.Length);			
				byte[] byData = new byte[40];
				Array.Copy(type,0,byData,0,4);			
				Array.Copy(length,0,byData,4,4);
				Array.Copy(LAUData,0,byData,8,32);
				m_IpOurClient.Send(byData);
				byData = System.Text.Encoding.ASCII.GetBytes(bfr);
				m_IpOurClient.Send(byData);
			}
			else
			{
				byte[] type=BitConverter.GetBytes(0);
				byte[] length=BitConverter.GetBytes(bfr.Length);			
				byte[] byData = new byte[8];
				Array.Copy(type,0,byData,0,4);			
				Array.Copy(length,0,byData,4,4);
				m_IpOurClient.Send(byData);
				byData = System.Text.Encoding.ASCII.GetBytes(bfr);
				m_IpOurClient.Send(byData);
			}
		}


		private void sendMTS(string bfr, int ty_pe)  //This data is for MTS appl.
		{
			if (m_newswf == "V1")
/*   unsigned char xLAUValue[ SNLADPHDR_LAU_SIZE] (32 byte) 256-byte LAU value */
			{
				string byte1=Encoding.ASCII.GetString(m_pass,0,1);
				string byte2=Encoding.ASCII.GetString(m_pass,1,1);
				if (byte1=="m" && byte2=="a")
					des_pr(m_drv, m_pass);	// m_pass is a key that is created from LAU data. Do it once per session.
			    	byte[] MessageBytes = System.Text.Encoding.ASCII.GetBytes(bfr);
		        	HMACSHA256 myhmacsha256 = new HMACSHA256(m_pass);
        			byte[] LAUData = myhmacsha256.ComputeHash(MessageBytes);
				//byte[] LAUData = new byte[32]; 	/* new 32 byte. need to find what to map */

				byte[] type=BitConverter.GetBytes(IPAddress.HostToNetworkOrder(ty_pe));
				byte[] length=BitConverter.GetBytes(IPAddress.HostToNetworkOrder(bfr.Length));			
				byte[] byData = new byte[40];
				Array.Copy(type,0,byData,0,4);			
				Array.Copy(length,0,byData,4,4);
				Array.Copy(LAUData,0,byData,8,32);

				m_IpMtsServer.Send(m_ServerContext,byData);
				byData = System.Text.Encoding.ASCII.GetBytes(bfr);
				m_IpMtsServer.Send(m_ServerContext,byData);
			}
			else
			{
				byte[] type=BitConverter.GetBytes(IPAddress.HostToNetworkOrder(0));
				byte[] length=BitConverter.GetBytes(IPAddress.HostToNetworkOrder(bfr.Length));			
				byte[] byData = new byte[8];
				Array.Copy(type,0,byData,0,4);			
				Array.Copy(length,0,byData,4,4);

				m_IpMtsServer.Send(m_ServerContext,byData);
				byData = System.Text.Encoding.ASCII.GetBytes(bfr);
				m_IpMtsServer.Send(m_ServerContext,byData);
			}
		}

		private int getReadLength(byte[] bfr)
		{
			byte[] byData = new byte[4];
			Array.Copy(bfr,4,byData,0,4);			
			int Length=BitConverter.ToInt32(byData,0);				// unbox
			int fixedLength=IPAddress.NetworkToHostOrder(Length);
			//			Console.Write ("to read "+fixedLength.ToString()+"\r\n");
			return fixedLength;
		}
		private int getRcvStatus(byte[] bfr)
		{
			byte[] byData = new byte[4];
			Array.Copy(bfr,0,byData,0,4);			
			int Length=BitConverter.ToInt32(byData,0);				// unbox
			int fixedLength=IPAddress.NetworkToHostOrder(Length);
			//			Console.Write ("to read "+fixedLength.ToString()+"\r\n");
			return fixedLength;
		}
	}
}