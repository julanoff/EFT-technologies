﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Simulator.DBLibrary;
using System.Collections;
using System.Data;
using System.Threading;

namespace AddPrivsToDatabase
{
    class AddPrivsToDatabase
    {
        string[] users = {@"NT AUTHORITY\SYSTEM",
                          @"IIS APPPOOL\DefaultAppPool",
                          @"NT AUTHORITY\NETWORK SERVICE"};

        static void Main(string[] args)
        {
            AddPrivsToDatabase me = new AddPrivsToDatabase();
            Console.WriteLine("We are going to add privileges to your Simulator* databases");
            Console.Write("Enter the name of one of your areas just to get us started: ");
            string ans = Console.ReadLine().ToUpper();
            if (ans.StartsWith("SIMULATOR"))
            {
                ans = ans.Substring(ans.IndexOf("_") + 1);
            }
            DBAccess test = new DBAccess();

            if (!test.Connect(false, ans))
            {
                Console.WriteLine("sorry, I couldn't connect to that database. Try again with a valid area name...");
                System.Threading.Thread.Sleep(15000);
                return;
            }
            Console.WriteLine("");

            test.DisConnect();
            test.Dispose();
            me.doIt(ans);
            Console.WriteLine("");
            Console.Write("All done ... hit return to exit");
            Console.ReadLine();
        }

        private void doIt(string initialArea)
        {
            ArrayList list = getSimDBNames(initialArea);
            Console.WriteLine("We found " + list.Count + " Simulator databases:");
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine("   " + list[i].ToString());
            }
            Console.WriteLine("");
            for (int i = 0; i < list.Count; i++)
            {
                Console.Write("Hit return to process " + list[i].ToString());
                Console.ReadLine();

                string db = list[i].ToString();
                db = db.Substring(db.IndexOf("_") + 1);
                Console.WriteLine("Doing tables for " + db);
                doTables(db);
                Console.WriteLine("Doing stored procedures for " + db);
                doStoredProcs(db);
            }
        }



        private void doStoredProcs(string db)
        {
            DBAccess dbWrt = new DBAccess();
            dbWrt.Connect(true, db);
            DataTable dt = dbWrt.getSchema("Procedures");
            ArrayList procs = new ArrayList();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                procs.Add(dr.ItemArray[2].ToString());
            }
            procs.Sort();

            for (int i = 0; i < procs.Count; i++)
            {
                for (int j = 0; j < users.Length; j++)
                {
                    string tmp = string.Format("grant EXEC ON [dbo].[{0}] TO [{1}]",
                        procs[i].ToString(), users[j]);
                    try
                    {
                        dbWrt.Execute(tmp, true);
                        Console.WriteLine("   " + procs[i].ToString() + " " + users[j] + " - ok");
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("   " + procs[i].ToString() + " " + users[j] + " - not ok");
                        dbWrt.DisConnect();
                        dbWrt.Connect(true, db);
                    }
                }
                Console.WriteLine("");
                System.Threading.Thread.Sleep(750);
            }
        }

        private void doTables(string db)
        {
            DBAccess dbWrt = new DBAccess();
            dbWrt.Connect(true, db);
            DataTable dt = dbWrt.getSchema("Tables");
            ArrayList tables = new ArrayList();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                tables.Add(dr.ItemArray[2].ToString());
            }
            tables.Sort();

            for (int i = 0; i < tables.Count; i++)
            {
                for (int j = 0; j < users.Length; j++)
                {
                    string tmp = string.Format("GRANT  SELECT , UPDATE , INSERT , DELETE ON [dbo].[{0}] TO [{1}]",
                        tables[i].ToString(), users[j]);
                    try
                    {
                        dbWrt.Execute(tmp, true);
                        Console.WriteLine("   " + tables[i].ToString() + " " + users[j] + " - ok");
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("   " + tables[i].ToString() + " " + users[j] + " - not ok");
                        dbWrt.DisConnect();
                        dbWrt.Connect(true, db);
                    }
                }
                Console.WriteLine("");
                System.Threading.Thread.Sleep(750);
            }
        }

        private ArrayList getSimDBNames(string initialArea)
        {
            ArrayList list = new ArrayList();
            DBAccess dbRdr = new Simulator.DBLibrary.DBAccess();
            dbRdr.Connect(false, initialArea);
            DataTable dt = dbRdr.getSchema("Databases");
            int i = 0;
            for (i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                //Console.WriteLine(dr.ItemArray[0].ToString());
                string db = dr.ItemArray[0].ToString().ToUpper();
                if (db.StartsWith("SIMULATOR_"))
                {
                    list.Add(db);
                }
            }
            return list;
        }

        private void schemaTest(string collection)
        {
            DBAccess dbWrt = new Simulator.DBLibrary.DBAccess();
            DBAccess dbRdr = new Simulator.DBLibrary.DBAccess();
            dbRdr.Connect(false, "TE1");
            DataTable dt = dbRdr.getSchema("Databases");
            int i = 0;
            for (i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                Console.WriteLine(dr.ItemArray[0].ToString());
                string db = dr.ItemArray[0].ToString().ToUpper();
                if (db.StartsWith("SIMULATOR_"))
                {
                    string simDB = db.Substring(db.IndexOf("_") + 1);
                    dbWrt.Connect(true, simDB);
                    DataTable simTable = dbWrt.getSchema("Tables");
                    for (int j = 0; j < simTable.Rows.Count; j++)
                    {
                        string t = string.Format("{0}.{1}.{2}", simTable.Rows[j].ItemArray[0],
                            simTable.Rows[j].ItemArray[1],
                            simTable.Rows[j].ItemArray[2]);
                    }
                }
            }
        }

    }
}
