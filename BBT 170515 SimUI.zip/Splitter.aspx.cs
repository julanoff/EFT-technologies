/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using OboutInc.Calendar2;
using Simulator.BackEndSubLib;
/* 
	03-Sep-05	JR	Plagarized Dave's load routines, etc.
 * 
 * 12-Nov-06    JR  Look for the list of banks in the local ApplicationBanks table.
 *                  Added a button so's you can add a ByLogs entry for the splitter. Too bad,
 *                  it would have been nice to do that in the 'add' button instead, but
 *                  there are a couple of gotcha's, the worst one being that the file path
 *                  associated with the first entry ends up being used when you hit the
 *                  'add' button for somebody else down the list in the select box.
 * 
 * 24-Nov-06    JR  When you go into edit mode and the item you're editing has a file
 *                  type of 'ByLogs', dummy up an entry in the file drop-down list that
 *                  says 'ByLogs' and put that first in the list of files to choose from.
 *                  If the splitter itself sees a file type of ByLogs, it ignores any
 *                  file names so in the end it doesn't really matter what the file name
 *                  is. However, it's confusing as hell to see an idi file name in the
 *                  drop-down list along with a file type of ByLogs. Since you can't
 *                  actually enter a name in the drop-down box, we need to add an entry
 *                  so the poor humans - myself included - don't get too confused.
 * 
 * 31-Oct-09    JR  Halloween '09, funny coincidence. For msgutil splits, let's make
 *                  sure the outputfile name has a ".txt" extension on it if the
 *                  human enters a name with no extension at all. In addition, when
 *                  building the default bank dropdown list, let's do it the right
 *                  way: first look in the area's AreaBanks table for values. If
 *                  that table is empty, then go look in the master's ApplicationBanks
 *                  table. I shoulda done it that way all along ...
 */
namespace Simulator
{
    /// <summary>
    /// Summary description for WebForm1.
    /// </summary>
    public partial class SplitForm : System.Web.UI.Page
    {
        protected System.Web.UI.HtmlControls.HtmlInputHidden Hidden1;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (!Page.IsPostBack)
                BindDataGrid();
            if (!ClientScript.IsClientScriptBlockRegistered("confirm"))
            {
                string jsConfirm = @"<script language='javascript'> " +
                    "function confirm_delete() " +
                    "{ return (confirm('Are you sure you want to delete this item?')); }" +
                    "</script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "confirm", jsConfirm);
            }
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DataGrid1.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.ItemCommands);
            this.DataGrid1.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Cancel);
            this.DataGrid1.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Edit);
            this.DataGrid1.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Update);
            this.DataGrid1.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Delete);
            this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.ItemBound);

        }
        #endregion


        void DataGrid_Edit(Object sender, DataGridCommandEventArgs e)
        {
            DataGrid1.EditItemIndex = e.Item.ItemIndex;
            BindDataGrid();
        }

        void DataGrid_Cancel(Object sender, DataGridCommandEventArgs e)
        {
            // Set the EditItemIndex property to the index of the item clicked
            // in the DataGrid control to enable editing for that item. Be sure
            // to rebind the DateGrid to the data source to refresh the control.
            DataGrid1.EditItemIndex = -1;
            BindDataGrid();
        }

        protected void CleanupClick(object sender, System.EventArgs e)
        {
            string Cmd = string.Format("delete from SplitterControl where ProcessState = 'P'");
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception)
            {
            }
            finally
            {
                Connection.DisConnect();
            }

        }
        protected void AddByLogsClick(object sender, System.EventArgs e)
        {
            BackEndSubs util = new BackEndSubs();
            string Cmd = string.Format("insert into SplitterControl " +
                 "(ProcessState,InputFileName,InputFilePath,OutputFileName,OutputFilePath," +
                     "FileType,DefaultBank,DefaultLine, NumberLoaded, NumberRead)" +
                     "values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',0,0)",
                     "W", "ByLogs", util.GetRgwLoadFilesDir(), "", "", "ByLogs", "none", "none");

            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception)
            {
                util.logError(Area, "Splitter (UI)", "Exception adding 'ByLogs' to SplitterControl");
            }
            finally
            {
                Connection.DisConnect();
            }

        }

        protected void ReleaseAllClick(object sender, System.EventArgs e)
        {
            string Cmd = string.Format("update SplitterControl set ProcessState = '*' where ProcessState = 'W'");
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception)
            {
            }
            finally
            {
                Connection.DisConnect();
            }

        }

        protected void RefreshClick(object sender, System.EventArgs e)
        {
            BindDataGrid();
        }

        void DataGrid_Update(Object sender, DataGridCommandEventArgs e)
        {
            int edit_errs = 0;
            string errmsg = "Req'd Fields:";
            string UniqueKey = (string)((TextBox)(e.Item.FindControl("UniqueKeyBox"))).Text.Trim();

            string fullFileName = (string)((DropDownList)(e.Item.FindControl("FilePathEdit"))).SelectedItem.Value.Trim();

            // Watch out for path strings that have forward slash as the delimiter.
            // We'll get these with 'ByLogs' entries.
            int LastDelimeter = fullFileName.LastIndexOf(@"\");
            if (LastDelimeter == -1)
                LastDelimeter = fullFileName.LastIndexOf("/");
            LastDelimeter++;

            String FileName = fullFileName.Substring(LastDelimeter);
            String FilePath = fullFileName.Substring(0, LastDelimeter);

            string ProcessState = (string)((DropDownList)(e.Item.FindControl("ProcessStateList"))).SelectedItem.Text.Trim();
            string FileType = (string)((DropDownList)(e.Item.FindControl("FileTypeList"))).SelectedItem.Text.Trim();
            string DefBank = (string)((DropDownList)(e.Item.FindControl("DefBankList"))).SelectedItem.Text.Trim();
            string DefLine = (string)((DropDownList)(e.Item.FindControl("DefLineList"))).SelectedItem.Text.Trim();
            string OutFilePath = (string)((Label)(e.Item.FindControl("OutputPathLbl"))).Text.Trim();
            string OutFileName = (string)((Label)(e.Item.FindControl("OutputFileLbl"))).Text.Trim();
            string Cmd;
            if (FileType.Equals("MsgUtil"))
            {
                if (OutFileName.Equals(""))
                {
                    if (edit_errs > 0)
                        errmsg = errmsg + ",";
                    edit_errs++;
                    errmsg = errmsg + " OutputFile";
                }
                else
                {
                    /*
                     * Let's look at the file name and see if it has an extension.
                     * If not, let's hang ".txt" on the end of the file.
                     */
                    int ptr = OutFileName.IndexOf(".");
                    if (ptr < 0)
                    {
                        OutFileName = OutFileName + ".txt";
                    }
                }
                if (DefBank.Equals("none"))
                {
                    if (edit_errs > 0)
                        errmsg = errmsg + ",";
                    edit_errs++;
                    errmsg = errmsg + "DefaultBank";
                }
                if (DefLine.Equals("none"))
                {
                    if (edit_errs > 0)
                        errmsg = errmsg + ",";
                    edit_errs++;
                    errmsg = errmsg + "DefaultLine";
                }
            }
            if (edit_errs == 0)
            {
                Cmd = string.Format("update splittercontrol set ProcessState='{0}',FileType='{1}'," +
                    "DefaultBank='{2}', DefaultLine='{3}',inputfilename='{4}',inputfilepath='{5}' where UniqueKey='{6}'",
                    ProcessState, FileType, DefBank, DefLine, FileName, FilePath, UniqueKey);
                DBAccess Connection = new DBAccess();
                String Area = (String)HttpContext.Current.Session["CurrentDB"];
                try
                {
                    Connection.Connect(true, Area);
                    Connection.Execute(Cmd, true);
                    DataGrid1.EditItemIndex = -1;
                    BindDataGrid();
                }
                catch (Exception)
                {
                }
                finally
                {
                    Connection.DisConnect();
                }
            }
            else
            {
                ((Label)(e.Item.FindControl("OutputFileLbl"))).Enabled = true;
                ((Label)(e.Item.FindControl("OutputFileLbl"))).Visible = true;

                ((Label)(e.Item.FindControl("OutputFileLbl"))).Text = "You cannot change this to msgutil" +
                    " because it's missing " + errmsg + " Delete it and re-add it";
            }

        }

        private void DataGrid_Delete(object source, DataGridCommandEventArgs e)
        {
            string UniqueKey;
            try
            {
                UniqueKey = (string)((Label)(e.Item.FindControl("UniqueKey"))).Text.Trim();
            }
            catch
            {
                UniqueKey = (string)((TextBox)(e.Item.FindControl("UniqueKeyBox"))).Text.Trim();
            }
            String Cmd = "delete from SplitterControl where uniquekey=" + UniqueKey;
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                DataGrid1.EditItemIndex = -1;
                BindDataGrid();
            }
            catch (Exception)
            {
            }
            finally
            {
                Connection.DisConnect();
            }

        }

        private void ItemBound(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.EditItem)
            {
                string bank;
                DBAccess dbconn;
                dbconn = new DBAccess();
                String Area = (String)HttpContext.Current.Session["CurrentDB"];

                try
                {
                    int nBanksFound = 0;
                    dbconn.Connect(false, Area);

                    String Cmd = "select Bank from AreaBanks";
                    dbconn.OpenDataReader(Cmd);
                    while (dbconn.SQLDR.Read())
                    {
                        if (nBanksFound < 1)
                        {
                            ((DropDownList)e.Item.FindControl("DefBankList")).Items.Add("none");
                        }
                        bank = dbconn.SQLDR["Bank"].ToString().TrimEnd();
                        ((DropDownList)e.Item.FindControl("DefBankList")).Items.Add(bank);
                        nBanksFound++;
                    }
                    if (nBanksFound < 1)
                    {
                        DBAccess MasterReader = new DBAccess();
                        MasterReader.Connect(false, "master");
                        Cmd = "select Bank from ApplicationBanks";
                        MasterReader.OpenDataReader(Cmd);
                        while (MasterReader.SQLDR.Read())
                        {
                            if (nBanksFound < 1)
                            {
                                ((DropDownList)e.Item.FindControl("DefBankList")).Items.Add("none");
                            }
                            bank = MasterReader.SQLDR["Bank"].ToString().TrimEnd();
                            ((DropDownList)e.Item.FindControl("DefBankList")).Items.Add(bank);
                            nBanksFound++;
                        }
                        MasterReader.DisConnect();
                        MasterReader.Dispose();
                    }
                }
                catch 
                {
                }

                //try
                //{
                //    dbconn.Connect(false, Area);
                //    ((DropDownList)e.Item.FindControl("DefBankList")).Items.Add("none");
                //    ((DropDownList)e.Item.FindControl("DefBankList")).Items.Add("cazzo");
                            
                //    //String Cmd = "select Bank from AreaBanks";
                //    String Cmd = "select Bank from ApplicationBanks";
                //    dbconn.OpenDataReader(Cmd);
                //    while (dbconn.SQLDR.Read())
                //    {
                //        bank = dbconn.SQLDR["Bank"].ToString().TrimEnd();
                //        //((DropDownList)e.Item.FindControl("DefBankList")).Items.Add(bank);
                //    }
                //}
                //catch (Exception connEx)
                //{
                //    string x = connEx.Message;
                //}
                finally
                {
                    dbconn.CloseDataReader();
                    dbconn.DisConnect();
                }

                string line;
                int i;
                ((DropDownList)e.Item.FindControl("DefLineList")).Items.Add("none");
                dbconn.Connect(false, Area);
                String Command = "Select LineNameKey from LineNames";
                dbconn.OpenDataReader(Command);
                while (dbconn.SQLDR.Read())
                {
                    // Load up all our known line names as possible choices
                    // in the DefaultLineList. Filter out swfinq, gmdinq, and
                    // the like. We need them to pick a real line name.

                    line = dbconn.SQLDR["LineNameKey"].ToString().TrimEnd();
                    i = line.IndexOf("INQ");
                    if (i < 0)
                    {
                        ((DropDownList)e.Item.FindControl("DefLineList")).Items.Add(line);
                    }
                }

                string ProcessState = ((DataRowView)e.Item.DataItem).Row.ItemArray[1].ToString();
                string InputFileName = ((DataRowView)e.Item.DataItem).Row.ItemArray[2].ToString().TrimEnd();
                string InputFilePath = ((DataRowView)e.Item.DataItem).Row.ItemArray[3].ToString().TrimEnd();
                string OutputFileName = ((DataRowView)e.Item.DataItem).Row.ItemArray[4].ToString().TrimEnd();
                string OutputFilePath = ((DataRowView)e.Item.DataItem).Row.ItemArray[5].ToString().TrimEnd();
                string FileType = ((DataRowView)e.Item.DataItem).Row.ItemArray[6].ToString().TrimEnd();
                string DefBank = ((DataRowView)e.Item.DataItem).Row.ItemArray[7].ToString().TrimEnd();
                string DefLine = ((DataRowView)e.Item.DataItem).Row.ItemArray[8].ToString().TrimEnd();
                DropDownList dl = ((DropDownList)(e.Item.FindControl("FilePathEdit")));
                PopulatePathControl(dl, FileType);
                string fullPathName = ((DataRowView)e.Item.DataItem).Row.ItemArray[3].ToString().Trim() + ((DataRowView)e.Item.DataItem).Row.ItemArray[2].ToString().Trim();
                ListItem li = dl.Items.FindByValue(fullPathName);
                if (li != null)
                {
                    li.Selected = true;
                }
                /*
                 * We're gonna try to set each of the following dropdowns to the value that's in
                 * the message we're editing. However, let's be friendly and catch any exceptions.
                 * I'm testing this today and the dropdown for the default bank doesn't have
                 * a value that matches the item I'm editing and so it throws an exception because
                 * it can't find that value in the dropdown. So, even though you'd think you'd never
                 * see this condition in the real world, you never know. 
                 */

                ((DropDownList)e.Item.FindControl("ProcessStateList")).Items.FindByValue(ProcessState).Selected = true;
                try
                {
                    ((DropDownList)e.Item.FindControl("DefBankList")).Items.FindByValue(DefBank).Selected = true;
                }
                catch {}
                try
                {
                    ((DropDownList)e.Item.FindControl("DefLineList")).Items.FindByValue(DefLine).Selected = true;
                }
                catch { }
                try
                {
                    ((DropDownList)e.Item.FindControl("FileTypeList")).Items.FindByValue(FileType).Selected = true;
                }
                catch { }
            }
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.EditItem)
            {
                Button cancelButton = (Button)e.Item.FindControl("DelButtonId");
                if (cancelButton != null)
                    cancelButton.Attributes.Add("onclick", "return confirm_delete();");
            }
        }

        public void ItemCommands(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
        {
            if (e.CommandName == "AddNewRow")
            {
                Add_on(e);
            }
            string FileName = "";
            string FilePath = "";
            if (e.CommandName == "ConfirmAddRow")
            {
                int edit_errs = 0;
                string errmsg = "Req'd Fields:";
                string ProcessState = (string)((DropDownList)(e.Item.FindControl("ProcessStateListFt"))).SelectedItem.Text.Trim();
                string DefBank = (string)((DropDownList)(e.Item.FindControl("DefBankListFt"))).SelectedItem.Text.Trim();
                string DefLine = (string)((DropDownList)(e.Item.FindControl("DefLineListFt"))).SelectedItem.Text.Trim();
                string FileType = (string)((DropDownList)(e.Item.FindControl("FileTypeListFt"))).SelectedItem.Text.Trim();
                string OutfileName = (string)((TextBox)(e.Item.FindControl("OutputFileFt"))).Text.Trim();
                string OutfilePath = (string)((TextBox)(e.Item.FindControl("OutputPathFt"))).Text.Trim();

                string fullFileName = (string)((DropDownList)(e.Item.FindControl("FilePathAdd"))).SelectedItem.Value.Trim();
                if (fullFileName == null || fullFileName.Trim().Length == 0)
                {
                    edit_errs++;
                    errmsg = errmsg + " Filename";
                }
                else
                {
                    int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
                    FileName = fullFileName.Substring(LastDelimeter);
                    FilePath = fullFileName.Substring(0, LastDelimeter);


                    //				FileName=Request.Params["FileId1"];
                    //				int LastDelimeter=FileName.LastIndexOf(@"\")+1;
                    //				String File=FileName.Substring(LastDelimeter);
                    //				String Path=FileName.Substring(0,LastDelimeter);
                    //				if (!(FileName != null && FileName.Length > 0))
                    //				{
                    //					edit_errs++;
                    //					errmsg = errmsg + " Filename";
                    //				}
                    // For MsgUtil types of splits, they need to provide an output file,
                    // Default Bank and Default Line. 
                    // If you want to be a complete stickler about it, the Default Line might
                    // not be 'required' if, by chance, the msgutil file actually has the line
                    // information in it. Some will, some won't. Let's force them to provide 
                    // a Default Line. If it's not needed by the code it won't be used. My
                    // sense of it is that the vast majority of msgutil files will be missing
                    // the line info.
                    if (FileType.Equals("MsgUtil"))
                    {
                        if (OutfileName.Equals(""))
                        {
                            if (edit_errs > 0)
                                errmsg = errmsg + ",";
                            edit_errs++;
                            errmsg = errmsg + " OutputFile";
                        }
                        else
                        {
                            /*
                             * Let's look at the file name and see if it has an extension.
                             * If not, let's hang ".txt" on the end of the file.
                             */
                            int ptr = OutfileName.IndexOf(".");
                            if (ptr < 0)
                            {
                                OutfileName = OutfileName + ".txt";
                            }
                        }
                        if (DefBank.Equals("none"))
                        {
                            if (edit_errs > 0)
                                errmsg = errmsg + ",";
                            edit_errs++;
                            errmsg = errmsg + "DefaultBank";
                        }
                        if (DefLine.Equals("none"))
                        {
                            if (edit_errs > 0)
                                errmsg = errmsg + ",";
                            edit_errs++;
                            errmsg = errmsg + "DefaultLine";
                        }
                    }
                }
                if (edit_errs == 0)
                {
                    string Cmd = string.Format("insert into SplitterControl " +
                    "(ProcessState,InputFileName,InputFilePath,OutputFileName,OutputFilePath," +
                        "FileType,DefaultBank,DefaultLine)" +
                        "values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')",
                        ProcessState, FileName, FilePath, OutfileName, OutfilePath, FileType, DefBank, DefLine);

                    DBAccess Connection = new DBAccess();
                    String Area = (String)HttpContext.Current.Session["CurrentDB"];
                    try
                    {
                        Connection.Connect(true, Area);
                        Connection.Execute(Cmd, true);
                        DataGrid1.EditItemIndex = -1;
                        BindDataGrid();
                        Add_off(e);
                    }
                    catch (Exception)
                    {
                    }
                    finally
                    {
                        Connection.DisConnect();
                    }

                }
                else
                {
                    ((Label)(e.Item.FindControl("FileNameLabel"))).Visible = true;
                    ((Label)(e.Item.FindControl("FileNameLabel"))).Text = errmsg;
                }
            }
            if (e.CommandName == "CancelAddRow")
            {
                Add_off(e);
            }
        }
        private void Add_on(System.Web.UI.WebControls.DataGridCommandEventArgs e)
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            ((DropDownList)(e.Item.FindControl("ProcessStateListFt"))).Enabled = true;
            ((DropDownList)(e.Item.FindControl("ProcessStateListFt"))).Visible = true;

            ((System.Web.UI.WebControls.WebControl)e.Item.FindControl("FilePathAdd")).Enabled = true;
            ((System.Web.UI.WebControls.WebControl)e.Item.FindControl("FilePathAdd")).Visible = true;

            ((DropDownList)(e.Item.FindControl("FileTypeListFt"))).Enabled = true;
            ((DropDownList)(e.Item.FindControl("FileTypeListFt"))).Visible = true;
            ((DropDownList)(e.Item.FindControl("DefBankListFt"))).Enabled = true;
            ((DropDownList)(e.Item.FindControl("DefBankListFt"))).Visible = true;
            ((DropDownList)(e.Item.FindControl("DefLineListFt"))).Enabled = true;
            ((DropDownList)(e.Item.FindControl("DefLineListFt"))).Visible = true;

            ((TextBox)(e.Item.FindControl("OutputFileFt"))).Enabled = true;
            ((TextBox)(e.Item.FindControl("OutputFileFt"))).Visible = true;

            DBAccess dbRdr;
            dbRdr = new DBAccess();
            dbRdr.Connect(false, Area);
            BackEndSubs util = new BackEndSubs();
            ((TextBox)(e.Item.FindControl("OutputPathFt"))).Enabled = true;
            ((TextBox)(e.Item.FindControl("OutputPathFt"))).Visible = true;
            ((TextBox)(e.Item.FindControl("OutputPathFt"))).Text = util.GetSplitDir(dbRdr) + "  ";

            ((Button)(e.Item.FindControl("btnAddRow"))).Enabled = false;
            ((Button)(e.Item.FindControl("btnAddRow"))).Visible = false;
            ((ImageButton)(e.Item.FindControl("btnConfirm"))).Enabled = true;
            ((ImageButton)(e.Item.FindControl("btnConfirm"))).Visible = true;
            ((ImageButton)(e.Item.FindControl("btnCancel"))).Enabled = true;
            ((ImageButton)(e.Item.FindControl("btnCancel"))).Visible = true;
            ((Label)(e.Item.FindControl("FileNameLabel"))).Visible = false;
            PopulatePathControl(((DropDownList)(e.Item.FindControl("FilePathAdd"))));


            string bank;
            DBAccess dbconn;
            dbconn = new DBAccess();
            try
            {
                int nBanksFound = 0;
                dbconn.Connect(false, Area);

                String Cmd = "select Bank from AreaBanks";
                dbconn.OpenDataReader(Cmd);
                while (dbconn.SQLDR.Read())
                {
                    if (nBanksFound < 1)
                    {
                        ((DropDownList)e.Item.FindControl("DefBankListFt")).Items.Add("none");
                    }
                    bank = dbconn.SQLDR["Bank"].ToString().TrimEnd();
                    ((DropDownList)e.Item.FindControl("DefBankListFt")).Items.Add(bank);
                    nBanksFound++;
                }
                if (nBanksFound < 1)
                {
                    DBAccess MasterReader = new DBAccess();
                    MasterReader.Connect(false, "master");
                    Cmd = "select Bank from ApplicationBanks";
                    MasterReader.OpenDataReader(Cmd);
                    while (MasterReader.SQLDR.Read())
                    {
                        if (nBanksFound < 1)
                        {
                            ((DropDownList)e.Item.FindControl("DefBankListFt")).Items.Add("none");
                        }
                        bank = MasterReader.SQLDR["Bank"].ToString().TrimEnd();
                        ((DropDownList)e.Item.FindControl("DefBankListFt")).Items.Add(bank);
                        nBanksFound++;
                    }
                    MasterReader.DisConnect();
                    MasterReader.Dispose();
                }
            }
            catch (Exception)
            {
            }
            finally
            {
                dbconn.CloseDataReader();
                dbconn.DisConnect();
            }

            string line;
            int i;
            ((DropDownList)e.Item.FindControl("DefLineListFt")).Items.Add("none");
            try
            {
                dbconn.Connect(false, Area);
                String Cmd = "Select LineNameKey from LineNames";
                dbconn.OpenDataReader(Cmd);
                while (dbconn.SQLDR.Read())
                {
                    // Load up all our known line names as possible choices
                    // in the DefaultLineList. Filter out swfinq, gmdinq, and
                    // the like. We need them to pick a real line name.
                    line = dbconn.SQLDR["LineNameKey"].ToString().TrimEnd();
                    i = line.IndexOf("INQ");
                    if (i < 0)
                    {
                        ((DropDownList)e.Item.FindControl("DefLineListFt")).Items.Add(line);
                    }
                }
            }
            catch (Exception)
            {
            }
            finally
            {
                dbconn.CloseDataReader();
                dbconn.DisConnect();
            }

        }

        private void Add_off(System.Web.UI.WebControls.DataGridCommandEventArgs e)
        {
            ((DropDownList)(e.Item.FindControl("ProcessStateListFt"))).Enabled = false;
            ((DropDownList)(e.Item.FindControl("ProcessStateListFt"))).Visible = false;
            //			((Label) (e.Item.FindControl("FileLbl"))).Enabled=false;
            //			((Label) (e.Item.FindControl("FileLbl"))).Visible=false;
            ((DropDownList)(e.Item.FindControl("FilePathAdd"))).Enabled = false;
            ((DropDownList)(e.Item.FindControl("FilePathAdd"))).Visible = false;
            ((Button)(e.Item.FindControl("btnAddRow"))).Enabled = true;
            ((Button)(e.Item.FindControl("btnAddRow"))).Visible = true;
            ((ImageButton)(e.Item.FindControl("btnConfirm"))).Enabled = false;
            ((ImageButton)(e.Item.FindControl("btnConfirm"))).Visible = false;
            ((ImageButton)(e.Item.FindControl("btnCancel"))).Enabled = false;
            ((ImageButton)(e.Item.FindControl("btnCancel"))).Visible = false;
            ((Label)(e.Item.FindControl("FileNameLabel"))).Visible = false;
            ((DropDownList)(e.Item.FindControl("FileTypeListFt"))).Enabled = false;
            ((DropDownList)(e.Item.FindControl("FileTypeListFt"))).Visible = false;
            ((DropDownList)(e.Item.FindControl("DefBankListFt"))).Enabled = false;
            ((DropDownList)(e.Item.FindControl("DefBankListFt"))).Visible = false;
            ((DropDownList)(e.Item.FindControl("DefLineListFt"))).Enabled = false;
            ((DropDownList)(e.Item.FindControl("DefLineListFt"))).Visible = false;
            ((TextBox)(e.Item.FindControl("OutputFileFt"))).Enabled = false;
            ((TextBox)(e.Item.FindControl("OutputFileFt"))).Visible = false;
            ((TextBox)(e.Item.FindControl("OutputPathFt"))).Enabled = false;
            ((TextBox)(e.Item.FindControl("OutputPathFt"))).Visible = false;
        }

        private void BindDataGrid()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);

                String Cmd = "select UniqueKey,ProcessState,InputFileName,InputFilePath," +
                    "OutputFileName,OutputFilePath,FileType,DefaultBank,DefaultLine," +
                    "TimeStarted,TimeEnded,NumberLoaded,NumberRead,replace(InputFilePath,' ','')+replace(InputFileName,' ','') as filename from SplitterControl";
                DataSet ds = Connection.getDataSet(Cmd);
                DataGrid1.DataSource = ds;
                DataGrid1.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Connection.DisConnect();
            }

        }

        private void PopulatePathControl(DropDownList dList)
        {
            PopulatePathControl(dList, "");
        }
        private void PopulatePathControl(DropDownList dList, string fType)
        {
            DBAccess Connection = new DBAccess();
            try
            {
                Connection.Connect(false, (String)HttpContext.Current.Session["CurrentDB"]);
                BackEndSubs util = new BackEndSubs();
                IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
                if (procMgr != null)
                {
                    // If the file type is 'ByLogs', let's dummy up a bylogs file
                    // name to put in the list. It'll be less confusing to the humans
                    // that way. The splitter itself, once it sees a file type of
                    // 'ByLogs', doesn't care what the file name is, it'll go off
                    // and do the split operation out of the msg database. However, it's
                    // confusing to me to see the edit window pop up with an idi file
                    // with type 'ByLogs'. Less confusion the better, eh?

                    if (fType.Equals("ByLogs"))
                    {
                        ListItem firstitem = new ListItem("ByLogs", util.GetRgwLoadFilesDir() + "ByLogs");
                        dList.Items.Add(firstitem);
                    }
                    String targetDir = util.GetMsgDataDir(Connection);
                    DataSet ds = (DataSet)procMgr.getDirectoryList(targetDir);		// change this to appropriate directory
                    foreach (DataTable dt in ds.Tables)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            string fullFileName = row["FileName"].ToString();
                            int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
                            string FileName = fullFileName.Substring(LastDelimeter);
                            ListItem item = new ListItem(FileName, fullFileName);
                            dList.Items.Add(item);
                        }
                    }
                }
            }
            finally
            {
                Connection.DisConnect();
            }
        }

        protected void DataGrid1_SelectedIndexChanged(object sender, System.EventArgs e)
        {
        }


        protected void MyPageChanged(object source, DataGridPageChangedEventArgs e)
        {
            DataGrid1.CurrentPageIndex = e.NewPageIndex;
            BindDataGrid();
        }
    }
}
