/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//using Oracle.DataAccess.Client;
//using Oracle.DataAccess.Types;

using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

using System.Data.SqlClient;
using System.Collections;
using System.Reflection;
using System.Text;
using System.Web.Configuration;
using System.Collections.Generic;
using System.Threading;
using Simulator.RGWSubLib;
using Simulator.BackEndSubLib;
using Simulator.DBLibrary;
using Simulator.EventLogger;
/*

 * 15-Jul-08    JR  We're using the stringarraycompare methodology now. That means
 *                  a change to the format of the table that shows the actual message
 *                  changes. By default, we'll show them the entire message and paint
 *                  the actual changes in red. There's a button that'll let them see
 *                  just the changed rows. They can toggle back and forth between
 *                  the modes.
 * 
 *                  I also got rid of a bunch of unused variables.
 * 
 * 27-Jul-08    JR  More changes, though not so much in here. I did change the font
 *                  size and the size of the results table.
 * 
 * 26-Nov-09    JR  This routine wouldn't work down at STI and the XP error log
 *                  complained about being unable to connect to the sql server. It
 *                  worked here, but not at STI. Yuk, I hate those ... Anyway, after
 *                  some digging I realized that the routine to get the connection
 *                  string was not the same as the routine in the browser (the other
 *                  place where gridview multiview's are used). In the browser it
 *                  was ultimately getting the connection string from web.config; in
 *                  here, I'd hard-wired it to use the system name and it didn't bother
 *                  going to web.config. Yep, works here and not there. Geez.
 *                  
 * 18-Jul-14    JR  Added support for comparing Processing Rules.
 * 
 *                  
 
 */

public partial class CompareResults : System.Web.UI.Page
{

    const string _nullDateValue = "1/1/1";

    private string _area;
    static string _xyz;

    private string _myCompareTable = string.Empty;
    private string _repositoryArea = string.Empty;

    private bool LookInMasterTables = true;
    private bool DoNotLookInMasterTables = false;

    static object _lockPage = new object();
    protected void Page_Load(object sender, EventArgs e)
    {
        SimCache simCache = SimCache.Instance;
        int test = simCache.Count;

        if (!Page.IsPostBack)
        {
            CreateExecutionCache();
            MultiView1.ActiveViewIndex = 1;
            // _DBSelector.SelectedIndex = 1;

            GetStaticDataList();
            GetTableMetaData();
            //_SearchButton.Enabled = true;
            BuildTableList();
            Session["ShowChangesOnly"] = "f";
        }
        BindExecutionList();
    }

    private void GetStaticDataList()
    {
        _area = (string)HttpContext.Current.Session["CurrentDB"];

    }

    private void GetTableMetaData()
    {
        _area = (string)HttpContext.Current.Session["CurrentDB"];
    }

    private void GenerateTableList()
    {
        _area = (string)HttpContext.Current.Session["CurrentDB"];

        string selectedDB = "Local";
        Session["_db"] = selectedDB;

        //bool firstAdded = true;

        SimulatorDataSource.ConnectionString = getConnectionString("Local",
            (string)HttpContext.Current.Session["CurrentDB"]);

        SearchList.DataSourceID = "SimulatorDataSource";

        DBAccess C = new DBAccess();

        StringBuilder cmd = new StringBuilder();
        try
        {
            C.Connect(false, _area);

            string myCmd = "Select * from SimTableList where " +
                " TableType = 'CompareMetaSummary' order by createtime desc, tablename";

            C.OpenDataReader(myCmd);
            int i = 0;

            while (C.SQLDR.Read())
            {
                string tName = C.SQLDR["TableName"].ToString().TrimEnd();

                string selectCmd = "select CmpTableDescription as 'TableDesc', " +
                    "CreateTime as 'CreateTime', TotalMsgs as 'TotalMsgs', " +
                    "deltaMsgs as 'DeltaMsgs', ftr as 'FTR', " +
                    "cdt as 'CDT', dbt as 'DBT', " +
                    "dst as 'DST', text as 'Text', hist as 'Hist', prm as 'PRM', " +
                    "CmpTableName as 'tName' " +
                    "from " + tName;

                if (i == 0)
                    cmd.Append(selectCmd);
                else
                    cmd.Append(" union " + selectCmd);
                i++;
            }
            /*
             * Let's show the newest tables first ...
             */ 
            cmd.Append(" order by createtime desc,tabledesc ");
            string xyz = cmd.ToString();
        }
        catch (Exception ex) { throw ex; }

        SimulatorDataSource.SelectCommand = cmd.ToString();
        Session["SelectCmd"] = cmd.ToString();
        SearchList.DataBind();
    }


    private void GenerateSearchResultSegment(ControlCollection parentControl, ref bool firstAdded)
    {
        foreach (Control pageControl in parentControl)
        {
            string value = "";
            string pageControlName = pageControl.ID;
            if (pageControl is DropDownList)
                value = ((DropDownList)pageControl).SelectedValue;
        }
    }



    protected void BuildTableList()
    {
        GenerateTableList();
        int rowCount = SearchList.Rows.Count;
        if (rowCount > 0)
        {
            SetSelectMenu = "All Tables";
            MultiView1.ActiveViewIndex = 0;
        }
        else
        {
            MsgBox.Text = "No Results Tables found.";
            MsgBox.Visible = true;
        }
    }


    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton trnControl = sender as LinkButton;
        _xyz = trnControl.Text.Trim();
        if (trnControl != null)
        {
            MultiView1.ActiveViewIndex = 1;
            BindCompareTable(_xyz);
            SelectMenu.Visible = true;
            SetSelectMenu = "Trn List";
            SummaryList.PageIndex = 0;
        }
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        LinkButton trnControl = sender as LinkButton;
        string xyz = trnControl.Text.Trim();
        if (trnControl != null)
        {
            MultiView1.ActiveViewIndex = 2;
            BindTrnDetail(xyz);
            SelectMenu.Visible = true;
            SetSelectMenu = "Trn List";
        }
    }

    public string SetSelectMenu
    {
        set
        {
            MenuItemCollection mic = SelectMenu.Items;
            foreach (MenuItem mi in mic)
            {
                if (mi.Text == value)
                    mi.Selected = true;
            }
        }
    }


    private void BindDetailsControl(string trn)
    {
        Session["CurrentTrn"] = trn;
    }
    private void BindCompareTable(string tDescription)
    {
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        string selectedDB = "Local";
        Session["_db"] = selectedDB;
        Session["TableDescription"] = tDescription;
        string tName = string.Empty;

        SimulatorDataSource.ConnectionString = getConnectionString("Local",
            (string)HttpContext.Current.Session["CurrentDB"]);

        SummaryList.DataSourceID = "SimulatorDataSource";

        DBAccess C = new DBAccess();

        StringBuilder cmd = new StringBuilder();
        try
        {
            C.Connect(false, _area);

            string myCmd = string.Format("Select tablename from SimTableList where " +
                " TableType = 'CompareSummary' and description like '{0}'", tDescription);

            C.OpenDataReader(myCmd);

            while (C.SQLDR.Read())
            {
                tName = C.SQLDR["TableName"].ToString().TrimEnd();
            }
            string xyz = cmd.ToString();
        }
        catch (Exception ex) { throw ex; }


        string selectCmd = "select trn as 'Trn', " +
           " ftr as 'FTR', " +
            "cdt as 'CDT', dbt as 'DBT', " +
            "dst as 'DST', text as 'Text', hist as 'Hist', prm as 'PRM' " +
            "from " + tName + " where ndelta > 0";

        MsgBox.Text = tDescription;
        MsgBox.Visible = true;

        SimulatorDataSource.SelectCommand = selectCmd;
        Session["SelectCmd"] = selectCmd;
        SummaryList.DataBind();
    }

    private void BindTrnDetail(string trn)
    {
        Session["CurrentTrn"] = trn;
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        string selectedDB = "Local";
        Session["_db"] = selectedDB;
        string tName = string.Empty;
        //_dbFilter = new StringBuilder();

        Session["_db"] = selectedDB;
        string tDescription = (string)HttpContext.Current.Session["TableDescription"];


        SimulatorDataSource.ConnectionString = getConnectionString("Local",
            (string)HttpContext.Current.Session["CurrentDB"]);

        TrnDetail.DataSourceID = "SimulatorDataSource";

        DBAccess C = new DBAccess();

        StringBuilder cmd = new StringBuilder();
        try
        {
            C.Connect(false, _area);

            string myCmd = string.Format("Select tablename from SimTableList where " +
                " TableType = 'CompareResults' and description like '{0}'", tDescription);

            C.OpenDataReader(myCmd);

            while (C.SQLDR.Read())
            {
                tName = C.SQLDR["TableName"].ToString().TrimEnd();
            }
            string xyz = cmd.ToString();
        }
        catch (Exception ex) { throw ex; }


        /*
         * See if we want to show them just the changed fields or the 
         * entire message.
         */

        string showchanges = Session["ShowChangesOnly"].ToString();
        string selectCmd = "";
        if (showchanges.Equals("f"))
        {
            selectCmd = string.Format("select trn , " +
          " section, fieldname, c, " +
           "oldvalue, newvalue " +
           "from {0} where trn = '{1}' order by compareid ", tName, trn);
        }
        else
        {
            selectCmd = string.Format("select trn , " +
        " section, fieldname, c, " +
         "oldvalue, newvalue " +
         "from {0} where trn = '{1}'and c = '*' order by compareid ", tName, trn);
        }

        /*
         * Normally, this action on the trn string should work. However, I've got
         * a funny test message today and so I might as well make it deal with
         * that one, too.
         */ 
        try
        {
            MsgBox.Text = "Trn:" + trn.Substring(0, 8) + "-" + trn.Substring(8);
        }
        catch
        {
            MsgBox.Text = "Trn:" + trn;
        }
        MsgBox.Visible = true;

        SimulatorDataSource.SelectCommand = selectCmd;
        Session["SelectCmd"] = selectCmd;

        TrnDetail.Width = 800;
        TrnDetail.Font.Size = 8;

        TrnDetail.Visible = true;
        TrnDetail.DataBind();
        ShowChangesOnlyButton.Visible = true;
    }

    private string Extract(object source)
    {
        string Source = source as string;
        if (Source != null)
            return Source;
        return " ";
    }


    protected void HistoryDS_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        SqlDataSourceView dsv = sender as SqlDataSourceView;
        if (dsv != null)
            dsv.SelectCommand = (string)Session["HistoryCmd"];

    }
    protected void SimulatorDataSource_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        SqlDataSourceView dsv = sender as SqlDataSourceView;
        if (dsv != null)
            dsv.SelectCommand = (string)Session["SelectCmd"];
    }

    public void menuItemChanged(object sender, EventArgs e)
    {
        MenuItem mi = ((MenuEventArgs)e).Item as MenuItem;
        bool Visibility = true;
        if (mi != null)
        {
            switch (mi.Value)
            {
                case "AllTables":
                    {
                        Visibility = false;
                        MultiView1.ActiveViewIndex = 0;
                        MsgBox.Visible = false;
                        break;
                    }
                case "TrnList":
                    {
                        Visibility = true;
                        SetSelectMenu = "All Tables";
                        MultiView1.ActiveViewIndex = 1;
                        MsgBox.Text = (string)HttpContext.Current.Session["TableDescription"];
                        MsgBox.Visible = true;
                        break;
                    }
            }
            SelectMenu.Visible = Visibility;
            ShowChangesOnlyButton.Visible = true;
        }
    }

    private bool getTrnComponents(string trn, out string trnNum, out string trnDate)
    {
        char[] delimiter = new char[] { '-' };
        string[] trnDateNum = trn.Split(delimiter);
        trnNum = string.Empty;
        trnDate = string.Empty;
        if (trnDateNum.Length != 2)
            return false;
        string selectedDB = (string)Session["_db"];

        if (selectedDB == "MasterRepository" || selectedDB.StartsWith("Local"))
            trnDate = "'" + trnDateNum[0].Substring(0, 4) + "-" + trnDateNum[0].Substring(4, 2) + "-" + trnDateNum[0].Substring(6, 2) + " 00:00:00.000'";
        else
            trnDate = string.Format("to_date('{0}','YYYYMMDD')", trnDateNum[0]);

        trnNum = trnDateNum[1];
        return true;
    }


    string formatSQLCmd(string table, string filterClause, string trnDateNum)
    {
        string sqlCmd;
        string trnNum, trnDate;
        getTrnComponents(trnDateNum, out trnNum, out trnDate);
        sqlCmd = string.Format("select * from {0} where trn_Date={1} and trn_Number={2} {3} ", table, trnDate, trnNum, filterClause);
        return sqlCmd;
    }



    //private static IDbConnection getDBConnection(string selectedDB, string area)
    private IDbConnection getDBConnection(string selectedDB, string area)
    {
        IDbConnection dbConn;
        string sqlConnectionString = getConnectionString(selectedDB, area);
        if (selectedDB == "MasterRepository" || selectedDB.StartsWith("Local"))
            dbConn = new SqlConnection(sqlConnectionString);
        else
            dbConn = new OracleConnection(sqlConnectionString);
        dbConn.Open();
        return dbConn;
    }

    private static IDbCommand getDBCommand(string SelectedDB, IDbConnection dbConn, string dbCmd)
    {
        if (SelectedDB == "MasterRepository" || SelectedDB.StartsWith("Local"))
            return new SqlCommand(dbCmd, (SqlConnection)dbConn);
        return new OracleCommand(dbCmd, (OracleConnection)dbConn);
    }

    private string getRepositoryConnectionString(string selectedDB, string area)
    {
        string connectionString;
        findRepository(area, selectedDB);

        string currentUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        string systemName = currentUser.Substring(0, currentUser.IndexOf("\\"));

        connectionString = "Data Source=" +
          systemName +
          ";Initial Catalog=Simulator_" +
          _repositoryArea +
          ";Integrated Security=True;";

        return connectionString;
    }





    private string getConnectionString(string selectedDB, string area)
    {
 
        string connectionString = "";
        SimulatorLog eventLog = new SimulatorLog("Simulator");

        if (selectedDB.StartsWith("Local"))
        {
            /*
             * We need to call findRepository here so we can know where our local
             * area message database is. It probably is the same as the local area
             * but it doesn't have to be ...
             */
            findRepository(area, selectedDB);
            connectionString = "Simulator_" + _repositoryArea + "ConnectionString";
        }
        else
        {
            if (selectedDB.Equals("MasterRepository"))
            {
                findRepository(area, selectedDB);
                connectionString = "Simulator_" + _repositoryArea + "ConnectionString";
            }
        }

        ConnectionStringsSection connectionStringsSection =
            WebConfigurationManager.GetSection("connectionStrings") as ConnectionStringsSection;

        if (connectionStringsSection == null)
        {
            throw (new ApplicationException("No Connection String section in web.config"));
        }

        ConnectionStringSettingsCollection connectionStrings = connectionStringsSection.ConnectionStrings;// Get the connectionStrings key,value pairs collection.
        ConnectionStringSettings connectionSettings = connectionStrings[connectionString];
        if (null == connectionSettings)
        {
            throw (new ApplicationException("Cannot find ConnectionString for " + connectionString));
        }

        connectionString = connectionSettings.ConnectionString;
        return connectionString;
    }




    private string getConnectionString_0ld(string selectedDB, string area)
    {
        /*
         * Note that the first time we come here in a session, we're going to
         * be in our local area and the next thing that happens after we return
         * from here will be to look up the info to populate our drop-down boxes;
         * the banks, source codes, all that sort of stuff.
         * 
         */
        string connectionString;


        string currentUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        string systemName = currentUser.Substring(0, currentUser.IndexOf("\\"));

        connectionString = "Simulator_" + area + "ConnectionString";

        if (selectedDB.StartsWith("Local"))
        {
            connectionString = "Data Source=" +
              systemName + 
              ";Initial Catalog=Simulator_" +
              area +
              ";Integrated Security=True;";

            return connectionString;
        }
        if (selectedDB.Equals("MasterRepository"))
        {

            findRepository(area, selectedDB);

            connectionString = "Data Source=" +
              systemName +
              ";Initial Catalog=Simulator_" +
              _repositoryArea +
              ";Integrated Security=True;";

            return connectionString;
        }

        connectionString = "OracleConnectionString";

        ConnectionStringsSection connectionStringsSection =
            WebConfigurationManager.GetSection("connectionStrings") as ConnectionStringsSection;

        if (connectionStringsSection == null)
            throw (new ApplicationException("No Connection String section in web.config"));

        ConnectionStringSettingsCollection connectionStrings = connectionStringsSection.ConnectionStrings;// Get the connectionStrings key,value pairs collection.
        ConnectionStringSettings connectionSettings = connectionStrings[connectionString];
        if (null == connectionSettings)
            throw (new ApplicationException("Cannot find ConnectionString for " + connectionString));

        return connectionSettings.ConnectionString;
    }

    private static string getAppSetting(string key)
    {
        string tmp = System.Configuration.ConfigurationManager.AppSettings[key];
        if (tmp != null)
            return tmp;
        return "";
    }

    private void CreateExecutionCache()
    {
        lock (_lockPage)
        {
            if (Cache["ExecutionCache"] == null)
            {
                Cache["ExecutionCache"] = new SortedList();
            }
        }

    }


    private void BindExecutionList()
    {
        CreateExecutionCache();
        SortedList sl = (SortedList)Cache["ExecutionCache"];

        if (sl != null && sl.Count != 0)
        {
            // ResultsView.DataSource = sl.GetValueList();
            // ResultsView.DataBind();
            // ResultsView.Visible = true;
            // RefreshExecButton.Visible = true;
            //CancelExecButton.Visible = true;
        }
        else
        {
            // ResultsView.Visible = false;
            // RefreshExecButton.Visible = false;
            //  CancelExecButton.Visible = false;
        }
    }

    private void findRepository(string area, string SelectedDB)
    {
        //if (_repositoryArea.Length > 0)
        //  return;
        if (SelectedDB == "MasterRepository")
        {
            BackEndSubs util = new BackEndSubs();
            _repositoryArea = util.GetRgwRepository(_area, LookInMasterTables);
        }
        else
        {
            _repositoryArea = area;
        }
    }
    protected void SummaryList_PageIndexChanged(object sender, EventArgs e)
    {
        BindCompareTable(_xyz);
    }
    protected void SearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        BuildTableList();
    }
    protected void ShowChangesOnlyButton_click(object sender, EventArgs e)
    {
        string showchanges = Session["ShowChangesOnly"].ToString();
        if (showchanges.Equals("f"))
        {
            Session["ShowChangesOnly"] = "t";
            ShowChangesOnlyButton.Text = "Show full message";
        }
        else
        {
            Session["ShowChangesOnly"] = "f";
            ShowChangesOnlyButton.Text = "Show changed fields only";
        }

        BindTrnDetail(Session["CurrentTrn"].ToString());
    }
    protected void TrnDetail_PreRender(object sender, EventArgs e)
    {
        // Plug in the red color for any changed rows.
        int nCells = TrnDetail.Rows[0].Cells.Count;
        for (int i = 0; i < TrnDetail.Rows.Count; i++)
        {
            if (TrnDetail.Rows[i].Cells[3].Text.StartsWith("*"))
            {
                for (int j = 0; j < nCells; j++)
                {
                    TrnDetail.Rows[i].Cells[j].ForeColor = System.Drawing.Color.Red;
                }

            }
        }
    }
}

