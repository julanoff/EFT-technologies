/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Text;
using System.Data;
using System.Xml;
using System.Linq;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Obout.Grid;
using Obout.Interface;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.SimLog;

namespace Simulator
{


/*
 * 
 * Project update page.
 * 
 * 09-Mar-03        Orig.
 * 15-Mar-03    JR  Some tweaks to edits. Mostly in the projects.aspx page, though.
 * 
 */
    public partial class BatchMnt : OboutInc.oboutAJAXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DBAccess connection = new DBAccess();
        String dbname = (String)HttpContext.Current.Session["CurrentDB"];
        string Cmd;
        connection.Connect(false, dbname);
        try
        {
            Cmd = "select '      ' as TabName, '0' as Pk from LocalKeyName union select  replace(tabname, ' ',''), pk from LocalKeyName";
            OboutDropDownList EdtTmplCmptable1 = DataGrid1.Templates[0].Container.FindControl("EdtTmplCmptable") as OboutDropDownList;
            if (connection.OpenDataReader(Cmd))
            {
                EdtTmplCmptable1.DataSource = connection.SQLDR;
                EdtTmplCmptable1.DataTextField = "TabName";
                EdtTmplCmptable1.DataValueField = "TabName";
                EdtTmplCmptable1.DataBind();
            }
        }
        catch (Exception ex) { throw ex; }
        finally
        {
            connection.CloseDataReader();
            connection.DisConnect();
        }

        OboutDropDownList EdtTmplConndb1 = DataGrid1.Templates[0].Container.FindControl("EdtTmplConndb") as OboutDropDownList;

        ListItem item1 = new ListItem("ORA", "ORA");
        EdtTmplConndb1.Items.Add(item1);
        item1 = new ListItem("SQL", "SQL");
        EdtTmplConndb1.Items.Add(item1);

        OboutDropDownList EdtTmplalgorithm1 = DataGrid1.Templates[0].Container.FindControl("EdtTmplalgorithm") as OboutDropDownList;

        item1 = new ListItem("   ", "   ");
        EdtTmplalgorithm1.Items.Add(item1);
        item1 = new ListItem("AMT", "AMT");
        EdtTmplalgorithm1.Items.Add(item1);

        connection.Connect(false, "Master");
        Cmd = "select AreaName from Areas";
        if (connection.OpenDataReader(Cmd))
        {
            try
            {
                OboutDropDownList EdtTmplArea1 = DataGrid1.Templates[0].Container.FindControl("EdtTmplArea") as OboutDropDownList;
                EdtTmplArea1.DataSource = connection.SQLDR;
                EdtTmplArea1.DataTextField = "AreaName";
                EdtTmplArea1.DataValueField = "AreaName";
                EdtTmplArea1.DataBind();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                connection.CloseDataReader();
                connection.DisConnect();
            }

            if (!Page.IsPostBack)
            {
                BindDataGrid();
                HttpContext.Current.Session["EditsAllowed"] = "Y";
                DataGrid1.Visible = true;
            }
            
        }
    }

    protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
    {
        Control ctrl = DataGrid1.Templates[templateIndex].Container.FindControl(controlId);

   //     return ctrl.ClientID;
        return "";
    }

    // this is an async AJAX call. The names of args must be = to the names in JS in .aspx        
    public List<string> unique(string tmpl_name)
    {
//        string tmpl_name = ds.Tables[0].Rows[0][14].ToString();
        List<string> rules = new List<string>();
     //   OboutDropDownList ctrl = (OboutDropDownList)DataGrid1.Templates[0].Container.FindControl("EdtTmplScripttmpl");
        PopulatePathControl(rules, tmpl_name);
        return (rules);
    }
    protected void OnGridRowCreated(object sender, GridRowEventArgs args)
    {
        //DataGrid1.Columns[1].ReadOnly = false;
        // gets called before a row created. It stop each time the row is populated from DB not used
    }

    protected void RebindGrid(object sender, EventArgs e)
    {
        BindDataGrid();
    }

    protected void OnSelectedIndexChanged(object sender, EventArgs e)
    {
        //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
    }

    protected void BindDataGrid()
    {
    	string dbname = (String)HttpContext.Current.Session["CurrentDB"];
	    string fileName = "c:\\Simulator\\"+ dbname.TrimEnd() + "\\feed\\feedall.xml";
        DataSet ds = new DataSet();
        ds.ReadXml(fileName);
        if (ds.HasErrors)
        {
            SimulatorLog _simLog = new SimulatorLog("FTFeeder");
            _simLog.WriteEntry("Errors in feedall.xml. Check the file", EventLogEntryType.Error);
            Simulator.SimLog.log.write(dbname, "Errors in feedall.xml. Check the file", true);
        }

        DataGrid1.DataSource = ds;

        DataGrid1.DataBind();
        string vendor = HttpContext.Current.Session["Vendor"].ToString();

								
        DataGrid1.Visible = true;
    }

    public void DataGrid_Edit(Object sender, GridRecordEventArgs e)
    {
        string Connstr, TrgConnstr, Description, Cmptable, Conndb, Area, Reffile, Amtdelta, Algorithm, Sql,Prefix,Split,Minstowait,Maxperfile,
        Filevaldate, Newvaldate, Show, Changeref, Docompare, Doreplay, Fromdatabase, Todatabase, Scripttmpl;
        DateTime FileTime;

        Show = e.Record["show"].ToString().Trim().ToUpper();
        Changeref = e.Record["changeref"].ToString().Trim().ToUpper();
        Docompare = e.Record["docompare"].ToString().Trim().ToUpper();
        Doreplay = e.Record["doreplay"].ToString().Trim().ToUpper();
        Fromdatabase = e.Record["fromdatabase"].ToString().Trim().ToUpper();
        Todatabase = e.Record["todatabase"].ToString().Trim().ToUpper();
        Scripttmpl = e.Record["scripttmpl"].ToString().TrimEnd();
        Connstr = e.Record["src_connection_string"].ToString().TrimEnd();
        TrgConnstr = e.Record["trg_connection_string"].ToString().TrimEnd();
        Description = e.Record["description"].ToString().Trim().Replace("'", "''");
        Cmptable = e.Record["cmptable"].ToString().Trim();
        Conndb = e.Record["conndb"].ToString().Trim();
        Area = e.Record["area"].ToString().Trim();
        Prefix = e.Record["prefix"].ToString().Trim();
        Split = e.Record["split"].ToString().Trim();
        Minstowait = e.Record["minstowait"].ToString().Trim();
        Maxperfile = e.Record["maxperfile"].ToString().Trim();
        Amtdelta = e.Record["amtdelta"].ToString().Trim();
        Algorithm = e.Record["algorithm"].ToString().Trim();
        Reffile = e.Record["reffile"].ToString().Trim().ToUpper();
        Sql = e.Record["sql"].ToString().Trim().ToUpper().Replace("\r\n"," ");
        Filevaldate = e.Record["filevaldate"].ToString();
        try { FileTime = DateTime.Parse(Filevaldate); }
        catch { Filevaldate = ""; }
        Newvaldate = e.Record["newvaldate"].ToString();
        try { FileTime = DateTime.Parse(Newvaldate); }
        catch { Newvaldate = ""; }
        
        //TimeDelay = testInt(TimeDelay);

        String area = (String)HttpContext.Current.Session["CurrentDB"];
	    StringBuilder thisXml = new StringBuilder();
        thisXml.Length = 0;
      	thisXml.Append("<?xml version=\"1.0\" standalone=\"yes\"?>");
        thisXml.Append("\r\n");
        thisXml.Append("<ourxml>");
        thisXml.Append("\r\n");
        thisXml.Append("<src_connection_string>");
        thisXml.Append(Connstr);
        thisXml.Append("</src_connection_string>");
        thisXml.Append("<trg_connection_string>");
        thisXml.Append(TrgConnstr);
        thisXml.Append("</trg_connection_string>");
        thisXml.Append("\r\n");
        thisXml.Append("<description>");
        thisXml.Append(Description);
        thisXml.Append("</description>");
        thisXml.Append("\r\n");
        thisXml.Append("<conndb>");
        thisXml.Append(Conndb);
        thisXml.Append("</conndb>");
        thisXml.Append("\r\n");
        thisXml.Append("<cmptable>");
        thisXml.Append(Cmptable);
        thisXml.Append("</cmptable>");
        thisXml.Append("\r\n");
        thisXml.Append("<area>");
        thisXml.Append(Area);
        thisXml.Append("</area>");
        thisXml.Append("\r\n");
        thisXml.Append("<amtdelta>");
        thisXml.Append(Amtdelta);
        thisXml.Append("</amtdelta>");
        thisXml.Append("\r\n");
        thisXml.Append("<algorithm>");
        thisXml.Append(Algorithm);
        thisXml.Append("</algorithm>");
        thisXml.Append("\r\n");
        thisXml.Append("<reffile>");
        thisXml.Append(Reffile);
        thisXml.Append("</reffile>");
        thisXml.Append("\r\n");
        thisXml.Append("<split>");
        thisXml.Append(Split);
        thisXml.Append("</split>");
        thisXml.Append("\r\n");
        thisXml.Append("<minstowait>");
        thisXml.Append(Minstowait);
        thisXml.Append("</minstowait>");
        thisXml.Append("\r\n");
        thisXml.Append("<maxperfile>");
        thisXml.Append(Maxperfile);
        thisXml.Append("</maxperfile>");
        thisXml.Append("\r\n");
        thisXml.Append("<filevaldate>");
        thisXml.Append(Filevaldate);
        thisXml.Append("</filevaldate>");
        thisXml.Append("\r\n");
        thisXml.Append("<show>");
        thisXml.Append(Show);
        thisXml.Append("</show>");
        thisXml.Append("\r\n");
        thisXml.Append("<changeref>");
        thisXml.Append(Changeref);
        thisXml.Append("</changeref>");
        thisXml.Append("\r\n");
        thisXml.Append("<docompare>");
        thisXml.Append(Docompare);
        thisXml.Append("</docompare>");
        thisXml.Append("\r\n");
        thisXml.Append("<doreplay>");
        thisXml.Append(Doreplay);
        thisXml.Append("</doreplay>");
        thisXml.Append("\r\n");
        thisXml.Append("<fromdatabase>");
        thisXml.Append(Fromdatabase);
        thisXml.Append("</fromdatabase>");
        thisXml.Append("\r\n");
        thisXml.Append("<todatabase>");
        thisXml.Append(Todatabase);
        thisXml.Append("</todatabase>");
        thisXml.Append("\r\n");
        thisXml.Append("<prefix>");
        thisXml.Append(Prefix);
        thisXml.Append("</prefix>");
        thisXml.Append("\r\n");
        thisXml.Append("<scripttmpl>");
        thisXml.Append(Scripttmpl);
        thisXml.Append("</scripttmpl>");
        thisXml.Append("\r\n");
        thisXml.Append("<newvaldate>");
        thisXml.Append(Newvaldate);
        thisXml.Append("</newvaldate>");
        thisXml.Append("\r\n");
        Sql = Sql.TrimEnd().Replace(">", "&gt;").Replace("<", "&lt;");
        thisXml.Append("<sql>");
        thisXml.Append(Sql);
        thisXml.Append("</sql>");
        thisXml.Append("\r\n");
	    thisXml.Append("</ourxml>");

        DBAccess db = new DBAccess();
        String dbname = (String)HttpContext.Current.Session["CurrentDB"];
	    db.Connect(true, dbname);
        DateTime dt = DateTime.Now;
	    string Cmd=string.Format("insert into BatchQ values " +
			"('{0}','{1}','{2}','D','{3}')",
			"*",
			dt,
			null,
			thisXml.ToString().Replace("'", "''") );
	    db.Execute(Cmd,true);
   // Get batch Id from BatchQ PK (identity filed)
        Cmd = string.Format("select Pk from Batchq where AssignTime = '{0}'", dt);
        db.OpenDataReader(Cmd);
        db.SQLDR.Read();
        int Pk = db.SQLDR.GetInt32(0);
        db.CloseDataReader();
        Cmd = string.Format("insert into BatchDescr values " +
            "('{0}',0,'{1}','{2}','{3}','{4}','{5}','',0,0,0,'{6}')",
            Pk,
            Description,
            "Batch Submitted",
            Connstr,
            TrgConnstr,
            dt, Prefix);
        db.Execute(Cmd, true);
    }

    public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
    {
        //        DataGrid1.EditItemIndex = -1;
        BindDataGrid();
    }
    private string testInt(string num)
    {
        try
        {
            int tst = int.Parse(num);
            return num;
        }
        catch
        {
            return "1";
        }
    }

    public void DataGrid_Insert(object source, GridRecordEventArgs e)
    {
    }
    
    private void PopulatePathControl(List<string> dList, string tmpl_name)
    {
	    Hashtable list = new Hashtable();
        DBAccess Connection = new DBAccess();
        try
        {
            string dbname = (String)HttpContext.Current.Session["CurrentDB"];
        	Connection.Connect(false, dbname);
            BackEndSubs util = new BackEndSubs();
            IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
            if (procMgr != null)
            {
			    string simdir = util.GetAreaRoot(Connection).Replace(dbname,"javascripts").TrimEnd();
            	string FileName =  simdir + "*.tmpl";
                DataSet ds = (DataSet)procMgr.getDirectoryList(simdir);		// change this to appropriate directory
                list.Add("   ", "   ");
                dList.Add("    ");
                foreach (DataTable dt in ds.Tables)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        string fullFileName = row["FileName"].ToString();
                        int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
                        if (LastDelimeter == 0)
                        {
                            LastDelimeter = fullFileName.LastIndexOf(@"/") + 1;
    					}
                        FileName = fullFileName.Substring(LastDelimeter);
                        list.Add(FileName, fullFileName);
                        dList.Add(FileName);
//                        if (FileName == tmpl_name)
  //                          dList.SelectedValue = tmpl_name;
                    }
                }
                //dList.DataSource = list;
                //dList.DataBind();
                //dList.Items.Add(list);
                }
            }
            finally
            {
                Connection.DisConnect();
            }
    	}
    }
}
