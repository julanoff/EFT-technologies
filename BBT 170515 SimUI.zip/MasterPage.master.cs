/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Drawing;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
/*
 * 
 * 13-Oct-06    JR  add some code to 'taskMenuVisible' to check the web config
 *                  file to see which menu buttons to display. At the moment, the
 *                  browser and rgw buttons get this treatment.
 * 
 * 30-Apr-07    JR & JN. Two new functions: FedControl and CompareResults.
 * 
 * 11-Apr-11    JR  We're using Obout controls now. The main menu is built using that.
 *                  The menu functions you see are now conditionalized based on the
 *                  vendor - ACI vs FT.
 * 06-Jun-13	JN  Add analyze results function
 * 16-Nov-2013  JN  Changed key maintenance to new one from FT and renamed old keymaint to comp/res cleanup
 * 
 * 20-Feb-17    JR  Show the 'old' ACI-style compare if the vendor is ACI. If FT, show the new stuff from Citi.
 * 
 */

public partial class MasterPage : System.Web.UI.MasterPage
{
    private bool menuVisible;
    private bool vendorKnown;
    public bool taskMenuVisible
    {
        set
        {
            EasymenuMain.Visible = true;
            string dbname = (String)HttpContext.Current.Session["CurrentDB"];
            TextBox1.Text = dbname;
            menuVisible = true;
        }
        get
        {
            return menuVisible;
        }
    }

    public void setMenuForVendor()
    {
        /*
         * At the moment, all the menu elements are defined in the aspx page. So,
         * we can just make things visible or not depending on who the vendor is.
         * Stay tuned ... we may want to eventually add/remove elements programatically,
         * but for the moment this seems to work.
         */
        BackEndSubs util = new BackEndSubs();

        string Area = "";
        int ii = 0;
        try
        {
            Area = (String)HttpContext.Current.Session["CurrentDB"];
            ii = Area.Length;
        }
        catch { };
        if (ii != 0)
            if (util.GetSimNum(Area))
            {
                EasymenuMain.Visible = true;
                vendorKnown = false;
                return;
            }
        try
        {
            /*
             * All of these controls are visible by default so all you gotta
             * do is disable the ones you don't want to see. No need to enable
             * things, that happens by default.
             */

            vendorKnown = true;

            string vendor = Session["vendor"].ToString().Trim().ToLower();
            string client = Session["client"].ToString().Trim().ToLower();
            if (vendor.StartsWith("ft"))
            {
                //  Browser.Visible = false;  // uncomment to deactivate
                ByLogsControl.Visible = false;
                Compare.Visible = false;
                CmpTableMaintenance.Visible = false;
                Prepare.Visible = false;
                ResTabCleanup.Visible = false;
                RGWMaint.Visible = false;
                RprTrnUpdate.Visible = false;
                Splitter.Visible = false;
                SwfStats.Visible = false;
                VidControl.Visible = false;
                VidStats.Visible = false;
                DBFunctions.Visible = false;
                // AnalyzeResults.Visible = false;   // uncomment to deactivate
                //  BatchStat.Visible = false;		// uncomment to deactivate
            }
            else if (vendor.StartsWith("aci"))
            {
                /*
                 * 29-Aug-16. Some squirrely shit here for the BB&T demo. If we're running 
                 * in TE13, let's show all the old stuff. Any other area, show the new, in-progress
                 * compare screens.
                 * 
                 * 20-Feb-17. Long story short, the 'new' compare functionality is quite FT-specific especially in 
                 * regards to the database structure. So, let's revert back to showing the 'new' stuff if we're in a 
                 * FT environment and showing the 'old' stuff for ACI.
                 */
                /*
                if (Area.ToUpper().Equals("TE13"))
                {
                    Compare.Visible = true;
                    CmpTableMaintenance.Visible = true;
                    Prepare.Visible = true;
                    ResTabCleanup.Visible = true;
                    RGWMaint.Visible = true;
                    BatchControl.Visible = false;
                    BatchStat.Visible = false;
                    BatchMonitor.Visible = false;
                    AnalyzeResults.Visible = false;
                }
                else
                {
                    Compare.Visible = false;
                    CmpTableMaintenance.Visible = false;
                    Prepare.Visible = false;
                    ResTabCleanup.Visible = false;
                    RGWMaint.Visible = false;
                    BatchControl.Visible = true;
                    BatchStat.Visible = false;
                    BatchMonitor.Visible = true;
                    AnalyzeResults.Visible = true;
                }
                 * */

                Compare.Visible = true;
                CmpTableMaintenance.Visible = true;
                Prepare.Visible = true;
                ResTabCleanup.Visible = true;
                RGWMaint.Visible = true;
                BatchControl.Visible = false;
                BatchStat.Visible = false;
                BatchMonitor.Visible = false;
                AnalyzeResults.Visible = false;
            }
            else
            {
                // ACI default if we don't recognize the vendor ...
                BatchControl.Visible = false;
                BatchStat.Visible = false;
                BatchMonitor.Visible = false;
                AnalyzeResults.Visible = false;
            }
        }
        catch
        {
            EasymenuMain.Visible = true;
            vendorKnown = false;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string Area = (String)HttpContext.Current.Session["CurrentDB"];
        string vendor = Session["vendor"].ToString().Trim().ToUpper();
        string zz = Hidden1.Value;
        if (vendorKnown)
        {
            switch (Hidden1.Value)
            {
                case "AckRules":
                    Response.Redirect("ackrule.aspx");
                    break;
                case "AnalyzeResults":
                    Response.Redirect("AnalyzeRes.aspx");
                    break;
                case "Area":
                    Response.Redirect("Area.aspx");
                    break;
                case "BatchControl":
                    Response.Redirect("BatchMnt.aspx");
                    break;
                case "BatchStat":
                    Response.Redirect("BatchStat.aspx");
                    break;
                case "BatchMonitor":
                    Response.Redirect("BatchMonitor.aspx");
                    break;
                case "CompareRelease":
                    Response.Redirect("CompRelease.aspx");
                    break;
                case "Browser":
                    if (vendor == "ACI")
                        Response.Redirect("Browser.aspx");
                    else
                        Response.Redirect("FtBrowser.aspx");
                    break;
                case "ByLogsControl":
                    if (vendor == "ACI")
                    {
                        Response.Redirect("ByLogsLoad.aspx");
                    }
                    else
                    {
                        Response.Redirect("StatResults.aspx");
                    }
                    break;
                case "ChpControl":
                    Response.Redirect("chpcontrol.aspx");
                    break;
                case "CmpTableMaintenance":
                    Response.Redirect("CompareTabMnt.aspx");
                    break;
                case "Compare":
                    Response.Redirect("CompareMsgs.aspx");
                    break;
                case "CompareResults":
                    if (vendor == "ACI")
                    {
                        Response.Redirect("CompareResults.aspx");
                    }
                    else
                    {
                        Response.Redirect("ShowDiffs.aspx");
                    }
                    break;
                case "DBFunctions":
                    Response.Redirect("DBMaint.aspx");
                    break;
                case "Environment":
                    Response.Redirect("area.aspx");
                    break;
                case "Events":
                    Response.Redirect("Events.aspx");
                    break;
                case "FedControl":
                    Response.Redirect("fedcontrol.aspx");
                    break;
                case "Feeders":
                    Response.Redirect("Feeders.aspx");
                    break;

                //case "Help":
                //    Response.Redirect("SimHelp.chm", false);
                //    break;

                case "KeyMaintenance":
                    Response.Redirect("CmpKeysMnt.aspx");
                    break;
                case "ResTabCleanup":
                    Response.Redirect("KeyMaint.aspx");
                    break;
                case "Loader":
                    Response.Redirect("Load.aspx");
                    break;
                case "Links":
                    Response.Redirect("Links.aspx");
                    break;
                case "Maintenance":
                    Response.Redirect("Maint.aspx");
                    break;
                case "Prepare":
                    Response.Redirect("IdiCompPrep.aspx");
                    break;
                case "Processes":
                    Response.Redirect("ProcessList.aspx");
                    break;
                case "Queues":
                    Response.Redirect("Systotals.aspx");
                    break;
                case "RcvAckControl":
                    Response.Redirect("Receiver.aspx");
                    break;
                case "RGWMaint":
                    Response.Redirect("RgwMaint.aspx");
                    break;
                case "RprTrnUpdate":
                    Response.Redirect("RprTrnUpdate.aspx");
                    break;
                case "SimControl":
                    Response.Redirect("SimControlEdit.aspx");
                    break;
                case "Splitter":
                    Response.Redirect("splitter.aspx");
                    break;
                case "SwfStats":
                    Response.Redirect("SwfStat.aspx");
                    break;
                case "VidControl":
                    Response.Redirect("vidcontrol.aspx");
                    break;
                case "VidStats":
                    Response.Redirect("VidStat.aspx");
                    break;


                default:
                    break;
            }
        }
        else
        {
            /*
             * Somehow they got into this routine without knowning the 'vendor'. A timeout would do that,
             * wipe out the session cache in the middle of some other screen such as the brower. Then
             * when you hit a button, you'd come in here not know how to paint the menu buttons.
             * 
             * And while we're at it, let's explicitly send them to the area page.
             * 
             */
            Response.Redirect("area.aspx");
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        string dbname = "";
        //string dbname = (String)HttpContext.Current.Session["CurrentDB"];
        //TextBox1.Text = dbname;
        setMenuForVendor();

        if (!Page.IsPostBack)
        {
            DBAccess m_Connection = new DBAccess();
            try
            {
                dbname = Session["CurrentDB"].ToString();
                TextBox1.Text = dbname;
            }
            catch { }

            ContentPlaceHolder cp = Page.Master.FindControl("ContentPlaceHolder2") as ContentPlaceHolder;
            Label NoActionLabel = cp.FindControl("NoActionLabel") as Label;
            try
            {
                if (dbname.Length > 0)
                {
                    //adjustTaskMenu();
                    taskMenuVisible = true;

                    m_Connection.Connect(false, dbname);
                    String Cmd = "select count(*) from ActionQue";
                    int Count = 0;
                    if (m_Connection.OpenDataReader(Cmd))
                    {
                        if (m_Connection.SQLDR.Read())
                            Count = m_Connection.SQLDR.GetInt32(0);
                        m_Connection.CloseDataReader();
                    }
                    if (Count != 0)
                    {
                        Cmd = "select TimeofAction,ActionId,ActionText,Severity from ActionQue order by timeofaction desc";
                        DataSet ds = m_Connection.getDataSet(Cmd);
                        DataGrid DataGrid2 = new DataGrid();
                        DataGrid2 = cp.FindControl("DataGrid2") as DataGrid;
                        DataGrid2.DataSource = ds;
                        DataGrid2.DataBind();
                        DataGrid2.Visible = true;
                        NoActionLabel.Visible = true;
                        NoActionLabel.ForeColor = Color.Red;
                        NoActionLabel.BackColor = Color.LightSkyBlue;
                        NoActionLabel.Text = "REQUIRED ACTIONS";
                    }
                    else
                    {
                        NoActionLabel.ForeColor = Color.Red;
                        NoActionLabel.BackColor = Color.White;
                        NoActionLabel.Visible = true;
                        NoActionLabel.Text = "No Pending Actions";
                    }
                }
                else
                {
                    EasymenuMain.Visible = false;
                }
            }
            catch
            { }
            finally
            {
                m_Connection.DisConnect();
            }
        }

    }
    protected void TaskMenu_MenuItemClick(object sender, MenuEventArgs e)
    {

        MenuItem mi = ((MenuEventArgs)e).Item as MenuItem;
        string vendor = getAppSetting("Vendor");

        if (mi != null)
        {
            switch (mi.Value)
            {
                //            case "Admin":
                case "Area":
                    Response.Redirect("area.aspx");
                    break;
                case "Processes":
                    Response.Redirect("ProcessList.aspx");
                    break;
                case "Events":
                    Response.Redirect("events.aspx");
                    break;
                case "Feeders":
                    Response.Redirect("Feeders.aspx");
                    break;
                case "Links":
                    Response.Redirect("Links.aspx");
                    break;
                case "SwfStats":
                    Response.Redirect("SwfStat.aspx");
                    break;
                case "Queues":
                    Response.Redirect("Systotals.aspx");
                    break;
                case "RprTrnUpdate":
                    Response.Redirect("RprTrnUpdate.aspx");
                    break;
                case "ChpControl":
                    Response.Redirect("chpcontrol.aspx");
                    break;
                case "FedControl":
                    Response.Redirect("fedcontrol.aspx");
                    break;
                case "VidControl":
                    Response.Redirect("vidcontrol.aspx");
                    break;
                case "VidStats":
                    Response.Redirect("VidStat.aspx");
                    break;
                case "ByLogsControl":
                    Response.Redirect("StatResults.aspx");
                    //                    Response.Redirect("ByLogsLoad.aspx");
                    break;
                case "Loader":
                    Response.Redirect("Load.aspx");
                    break;
                case "Splitter":
                    Response.Redirect("splitter.aspx");
                    break;
                case "AckRules":
                    Response.Redirect("ackrule.aspx");
                    break;
                case "AckRuleOld":
                    Response.Redirect("ackruleold.aspx");
                    break;
                case "RcvAckControl":
                    Response.Redirect("Receiver.aspx");
                    break;
                case "Maintenance":
                    Response.Redirect("Maint.aspx");
                    break;
                case "DBFunctions":
                    Response.Redirect("DBMaint.aspx");
                    break;
                case "Browser":
                    //Response.Redirect("ShowDiffs.aspx");
                    Response.Redirect("Browser.aspx");
                    break;
                //case "Help":
                //    Response.Redirect("SimHelp.chm", false);
                //    break;
                case "Prepare":
                    Response.Redirect("IdiCompPrep.aspx");
                    break;
                case "Compare":
                    Response.Redirect("CompareMsgs.aspx");
                    break;
                case "AnayzeResults":
                    Response.Redirect("AnalyzeRes.aspx");
                    break;
                case "CompareResults":
                    if (vendor == "ACI")
                        Response.Redirect("CompareResults.aspx");
                    else
                        Response.Redirect("ShowDiffs.aspx");
                    break;
                case "ResTabCleanup":
                    Response.Redirect("KeyMaint.aspx");
                    break;
                case "KeyMaintenance":
                    Response.Redirect("CmpKeysMnt.aspx");
                    break;
                case "CmpTableMaintenance":
                    Response.Redirect("CompareTabMnt.aspx");
                    break;
                case "RGWMaint":
                    Response.Redirect("RgwMaint.aspx");
                    break;
                case "SimControl":
                    Response.Redirect("SimControlEdit.aspx");
                    break;
            }
        }
    }
    private static string getAppSetting(string key)
    {
        string tmp = System.Configuration.ConfigurationManager.AppSettings[key];
        if (tmp != null)
            return tmp.ToUpper();
        return "";
    }

}
