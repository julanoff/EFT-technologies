public class vb_callbackPanels3 
	Inherits OboutInc.oboutAJAXPage
end class
	
