imports System

public class MasterPage 
	inherits System.Web.UI.MasterPage

    protected sub Page_Load(byval sender as object, byval e as EventArgs)
    end sub

end class
