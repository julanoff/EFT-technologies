imports System

public class GridPage 
	inherits OboutInc.oboutAJAXPage

    protected sub Page_Load(byval sender as object, byval e as EventArgs)
    end sub

end class
