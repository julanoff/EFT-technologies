public class vb_updatepanelfrompage3 
	Inherits OboutInc.oboutAJAXPage
end class
	
