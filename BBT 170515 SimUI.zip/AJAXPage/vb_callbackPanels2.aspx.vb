public class vb_callbackPanels2 
	Inherits OboutInc.oboutAJAXPage
end class
	
