imports System
imports System.Web.UI.WebControls
imports obout_ASPTreeView_2_NET

public class vb_updatepanelincontainer2 
	inherits OboutInc.oboutAJAXPage

	protected TreeView as Literal
	
	sub Page_Load(byval sender as object, byval e as EventArgs) 
        dim oTree as obout_ASPTreeView_2_NET.Tree = new obout_ASPTreeView_2_NET.Tree()

        oTree.Add("root", "a0", "obout.com (a0)", true, "Folder.gif", nothing)
        oTree.Add("a0", "a1", "ASP TreeView (a1)", true, "tree.gif", nothing)
        oTree.Add("a1", "a2", "Fast (a2)", true, nothing, nothing)
        oTree.Add("a1", "a3", "Easy (a3)", true, "page.gif", nothing)
        oTree.Add("root", "a4", "Links & Notes since 1998 (a4)", true, "BookY.gif", nothing)
        oTree.Add("root", "a5", "MemoBook.com (a5)", true, "ball_glass_blueS.gif", nothing)

        oTree.FolderIcons = "../TreeView/tree2/Icons"
        oTree.FolderScript = "../TreeView/tree2/script"
        oTree.FolderStyle = "../TreeView/tree2/style/Classic"
        oTree.DragAndDropEnable = false
        
        TreeView.Text = oTree.HTML()
    end sub
end class
