public class cs_updatepanelincontainer1 : OboutInc.oboutAJAXPage
{
	
}