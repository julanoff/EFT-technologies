public class cs_callbackPanels2 : OboutInc.oboutAJAXPage
{
	
}