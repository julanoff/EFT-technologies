using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class cs_Tree_UserControl : System.Web.UI.UserControl
{    
    protected void Page_Load(object sender, EventArgs e)
    {
        obout_ASPTreeView_2_NET.Tree oTree = new obout_ASPTreeView_2_NET.Tree();

		//sql express	
        SqlConnection oConn = new SqlConnection("Server=.\\SQLEXPRESS;AttachDBFilename=|DataDirectory|TreeNodes.mdf;Database=TreeNodes;Trusted_Connection=Yes;");

		//MSSQL Server
		//SqlConnection oConn = new SqlConnection("Driver={SQL Server};Server=localhost;UID=obout_usr;PWD=obout_pwd;Database=obout;");

		//MySql
		//SqlConnection oConn = new SqlConnection("DRIVER={MySQL ODBC 3.51 Driver};Server=localhost;UID=root;PWD=root_pwd;Database=test");

		oConn.Open();
		
		// read the information from the database		
		string sQuery = "SELECT NodeID, ParentID, NodeHTML, NodeIcon, NodeLevel, Expanded FROM treeview ORDER BY NodeLevel ASC";		
		SqlCommand oCommand = new SqlCommand(sQuery);
		oCommand.Connection = oConn;
		SqlDataReader oReader = oCommand.ExecuteReader();

		string sNodeId;
		string sParentId;
		string sHtml;
		string sIcon;
		int iExpanded = 1; // all the nodes will be expanded

		// make a loop through all the records from the database and add them to the TreeView
		while (oReader.Read())
		{
			sNodeId = oReader.GetValue(0).ToString();
			sParentId = oReader.GetValue(1).ToString();
			sHtml = oReader.GetValue(2).ToString();
			sIcon = oReader.GetValue(3).ToString();									
			if (sParentId != "" && sParentId != "NULL")
			{				
				oTree.Add(sParentId, sNodeId, sHtml, iExpanded, sIcon, null);				
			}
			else
			{				
				oTree.AddRootNode(sHtml, true, null);
			}
		}
		oConn.Close();

		// change this to your local TreeIcons folder
		oTree.FolderIcons = "../TreeView/tree2/icons";
        oTree.FolderStyle = "../TreeView/tree2/style/Classic";
        oTree.FolderScript = "../TreeView/tree2/script";

		oTree.ShowIcons = false;

		oTree.Width = "200px";
		oTree.ShowIcons = true;
		oTree.EditNodeEnable = true;
		oTree.DragAndDropEnable = true;
		// Enabling the server-side events
		oTree.EventList = "OnNodeEdit,OnAddNode,OnNodeDrop,OnRemoveNode";
		// Write treeview to your page.
		TreeView.Text = oTree.HTML();
    }
}
