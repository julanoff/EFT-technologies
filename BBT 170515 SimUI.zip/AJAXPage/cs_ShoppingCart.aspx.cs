using System;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;

public class cs_ShoppingCart : OboutInc.oboutAJAXPage
{
	protected Literal Category;
	protected DataList basket;
	protected DataList productList;
	
	protected void Page_Load(object sender, EventArgs e)
    {
if (!IsCallback && !IsPostBack)
		{
			LoadBasket();
			LoadCategory(1);
		}
		if (!IsCallback)
		{
			obout_ASPTreeView_2_NET.Tree oTree = new obout_ASPTreeView_2_NET.Tree();
	
			OleDbConnection oConn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + System.Web.HttpContext.Current.Server.MapPath("../App_Data/Products.mdb"));
			oConn.Open();
			
			// read the information from the database		
			string sQuery = "SELECT NodeID, ParentID, NodeHTML, NodeIcon, NodeLevel, Expanded FROM Category ORDER BY NodeLevel ASC";		
			OleDbCommand oCommand = new OleDbCommand(sQuery);
			oCommand.Connection = oConn;
			OleDbDataReader oReader = oCommand.ExecuteReader();
	
			string sNodeId;
			string sParentId;
			string sHtml;
			string sIcon;
			int iExpanded = 1; // all the nodes will be expanded
	
			// make a loop through all the records from the database and add them to the TreeView
			while (oReader.Read())
			{
				sNodeId = oReader.GetValue(0).ToString();
				sParentId = oReader.GetValue(1).ToString();
				sHtml = oReader.GetValue(2).ToString();
				sIcon = oReader.GetValue(3).ToString();									
				if (sParentId != "" && sParentId != "NULL")
				{				
					oTree.Add(sParentId, sNodeId, sHtml, iExpanded, sIcon, null);				
				}
				else
				{				
					oTree.AddRootNode(sHtml, true, null);
				}
			}
			oTree.SelectedId = "node1_1";
			oConn.Close();
	
			// change this to your local TreeIcons folder
            oTree.FolderIcons = "../TreeView/tree2/icons";
            oTree.FolderScript = "../TreeView/tree2/script";
            oTree.FolderStyle = "../TreeView/tree2/style/web";
	
			oTree.ShowIcons = false;
			oTree.Width = "100px";
			oTree.ShowIcons = true;
			oTree.EditNodeEnable = false;
			oTree.DragAndDropEnable = false;
			
			// Enabling the server-side events
			oTree.EventList = "";
			
			// Write treeview to your page.
			Category.Text = oTree.HTML();
		}
	}
	
	// load the basket from session object and populate the datalist
	public bool LoadBasket() {
		string totalPrice = "0";
		
		if (Session["Basket"] != null) {
			if (((ArrayList)Session["Basket"]).Count > 0) {
				OleDbConnection oleDBConnetion = new OleDbConnection();
				oleDBConnetion.ConnectionString = 
					"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Server.MapPath("../App_Data/Products.mdb") + "; User Id=; Password=";
		
				// gets the datasource for the emails list
				OleDbCommand oleDBCommand = new OleDbCommand();
				oleDBCommand.Connection = oleDBConnetion;
				
				string query = "SELECT ProductID, ProductName, ProductImage, ProductShortDescription, ProductPrice FROM Products where ";
				for (int index = 0; index < ((ArrayList)Session["Basket"]).Count; index++)
				{
					if (index == 0)
						query += " ProductID = " + ((ArrayList)Session["Basket"])[index];
					else
						query += " or ProductID = " + ((ArrayList)Session["Basket"])[index];
				}
							
				oleDBCommand.CommandText = query;
		
				OleDbDataReader dataReader;
				oleDBConnetion.Open();				
				dataReader = oleDBCommand.ExecuteReader();
				basket.DataSource = dataReader;
				basket.DataBind();
				dataReader.Close();
				
				
				// calculate total price
				string query2 = "SELECT sum(ProductPrice) FROM Products where ";
				for (int index = 0; index < ((ArrayList)Session["Basket"]).Count; index++)
				{
					if (index == 0)
						query2 += " ProductID = " + ((ArrayList)Session["Basket"])[index];
					else
						query2 += " or ProductID = " + ((ArrayList)Session["Basket"])[index];
				}

				OleDbCommand oleDBCommand2 = new OleDbCommand();
				oleDBCommand2.Connection = oleDBConnetion;
				oleDBCommand2.CommandText = query2;
		
				totalPrice = oleDBCommand2.ExecuteScalar().ToString();
				
				oleDBConnetion.Close();
			}
		}
		
		ExecOnLoad("UpdateTotalPrice('" + totalPrice + "')");
		
		return true;
	}
	
	public int selectedCategoryID = 0;
	
	private void LoadCategory(int CategoryID) {
		OleDbConnection oleDBConnetion = new OleDbConnection();
		oleDBConnetion.ConnectionString = 
			"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Server.MapPath("../App_Data/Products.mdb") + "; User Id=; Password=";

		// gets the datasource for the emails list
		OleDbCommand oleDBCommand = new OleDbCommand();
		oleDBCommand.Connection = oleDBConnetion;
		oleDBCommand.CommandText = "SELECT ProductID, ProductName, ProductImage, ProductShortDescription, ProductPrice FROM Products where CategoryID = " + CategoryID + "";

		OleDbDataReader dataReader;
		oleDBConnetion.Open();				
		dataReader = oleDBCommand.ExecuteReader();
		productList.DataSource = dataReader;
		productList.DataBind();
		dataReader.Close();
		
		oleDBConnetion.Close();
	}
	
	// add a new product to the session basket
	// Qty should also be processed
	public bool AddProductToBasket(int ProductID, int Qty) {
		if (Session["Basket"] == null)
			Session["Basket"] = new ArrayList();
			
		if (!((ArrayList)Session["Basket"]).Contains(ProductID)) {
			((ArrayList)Session["Basket"]).Add(ProductID);
			return true;
		}
		
		return false;
	}
	
	// remove product from the session basket
	public bool RemoveProductFromBasket(int ProductID) {
		((ArrayList)Session["Basket"]).Remove(ProductID);
		
		return true;
	}

	protected bool panelProductsList_OnBeforePanelUpdate(string panelId, string containerId)
	{
		LoadCategory(Int32.Parse(this.UpdatePanelParams["CategoryID"].ToString()));
		
		return true;
	}
	
	protected bool panelBasket_OnBeforePanelUpdate(string panelId, string containerId)
	{
		if (this.UpdatePanelParams["AddProduct"] != null)
		{
			bool addProduct = Boolean.Parse(this.UpdatePanelParams["AddProduct"].ToString());
			int ProductID = Int32.Parse(this.UpdatePanelParams["ProductID"].ToString());
			
			if (addProduct)
			{
				int Qty = Int32.Parse(this.UpdatePanelParams["Qty"].ToString());
				AddProductToBasket(ProductID, Qty);
			}
			else 
			{
				RemoveProductFromBasket(ProductID);
			}
		}
		
		LoadBasket();
		
		return true;
	}

protected void productList_OnItemDataBound(object sender, DataListItemEventArgs e)
	{
		if (e.Item.ItemType != ListItemType.Header && e.Item.ItemType != ListItemType.Footer)
		{
			DropDownList itemsNumberList = e.Item.FindControl("itemsNumberList") as DropDownList;
			HyperLink linkAddToBasket = e.Item.FindControl("linkAddToBasket") as HyperLink;
			String ProductID = ((DbDataRecord)e.Item.DataItem)["ProductID"].ToString();
			linkAddToBasket.NavigateUrl = "javascript:AddToBasket(" + ProductID + ", \"" + itemsNumberList.ClientID + "\")";
		}
	}
}