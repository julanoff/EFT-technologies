public class vb_showalert 
	Inherits OboutInc.oboutAJAXPage

	public sub ServerShowAlert() 
		' this will show an alert at client side
		ShowAlert("This alert was sent by server")
	end sub
end class