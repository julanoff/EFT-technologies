using obout_ASPTreeView_2_NET;
using System;
using System.IO;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Web.UI.WebControls;

public class cs_FileBrowser : OboutInc.oboutAJAXPage
{
	protected Label TreeView;
	protected Obout.Grid.Grid gridDir;
	string DefaultFolder;
	int expandedLevel = 0;
	
	void Page_Load(object sender, EventArgs e) {

		//DefaultFolder = "c:\\oboutSuite\\AJAXPage\\resources\\FileBrowser\\";
		DefaultFolder = Server.MapPath("resources/FileBrowser/");
		
		ThrowExceptionsAtClient = false;
		ShowErrorsAtClient = false;
		
		LoadTreeView();
		
		// set default initial directory
		if (!IsPostBack)
		{
			SelectDir(DefaultFolder);
		}
    }
	
	private void LoadTreeView()
	{
		obout_ASPTreeView_2_NET.Tree oTree = new obout_ASPTreeView_2_NET.Tree();
		oTree.id = "tree_0";
		string ParentID = "root";
	
		oTree.AddRootNode("<span style='cursor:pointer'>File Browser</span>", null);

		DirectoryInfo rootFolder = new DirectoryInfo(DefaultFolder); 
		LoadDirRecursive(ParentID, rootFolder, oTree);

		oTree.Width = "150px";
		oTree.DragAndDropEnable = false;
		oTree.KeyNavigationEnable = true;
		oTree.SelectedEnable = true;
		oTree.SelectedId = "root_tree_0";
		oTree.EventList = "OnNodeSelect";
		
		oTree.FolderIcons = "../TreeView/tree2/icons";		
		oTree.FolderScript = "../TreeView/tree2/script";
		oTree.FolderStyle = "../TreeView/tree2/style/Explorer";
		
		TreeView.Text = oTree.HTML();            
	}
	
	private void LoadDirRecursive(string ParentID, DirectoryInfo rootFolder, obout_ASPTreeView_2_NET.Tree oTree)
	{
		string nodeId;
		expandedLevel++;
		Hashtable oAdditionalInfo;
		
		foreach (DirectoryInfo dir in rootFolder.GetDirectories()) 
		{
			bool expanded = true;
			if (expandedLevel >= 15)
				expanded = false;
				
			// tree id will be unique
			nodeId = Guid.NewGuid().ToString();
			
			// aditional data on the tree node doesn't support \ char, use | instead
			oAdditionalInfo = new Hashtable();
            oAdditionalInfo["DirectoryPath"] = dir.FullName.Replace("\\", "|");
			
			string textDirName = "<span style='cursor:pointer'>" + dir.Name + "</span>";
			oTree.Add(ParentID, nodeId , textDirName, expanded, "folder.gif", null, oAdditionalInfo);
			
			LoadDirRecursive(nodeId, new DirectoryInfo(rootFolder + "/" + dir.Name), oTree);
		}
	}
	
	public void SelectDir(string dirID)
	{
		// replace back from | to \ char (path delimiter)
		dirID = dirID.Replace("|", "\\\\");
		
		DataSet dsDir = new DataSet();
		dsDir.Tables.Add(new DataTable());
		dsDir.Tables[0].Columns.Add(new DataColumn("name", System.Type.GetType("System.String")));
		dsDir.Tables[0].Columns.Add(new DataColumn("size", System.Type.GetType("System.Int32")));
		dsDir.Tables[0].Columns.Add(new DataColumn("type", System.Type.GetType("System.String")));
		dsDir.Tables[0].Columns.Add(new DataColumn("datemodified", System.Type.GetType("System.String")));
		dsDir.Tables[0].Columns.Add(new DataColumn("imageType", System.Type.GetType("System.String")));
		
		DirectoryInfo rootFolder = new DirectoryInfo(dirID);
		
		foreach (DirectoryInfo dir in rootFolder.GetDirectories()) 
		{
			string dirName = dir.Name;
			string dirDateTime = dir.LastAccessTime.ToString("d/M/yyyy h:m:s tt");
			string dirImageType = "Folder";
			dsDir.Tables[0].Rows.Add(new object[] {dirName, 0, "File Folder", dirDateTime, dirImageType});
		}
		
		foreach (FileInfo file in rootFolder.GetFiles()) 
		{
			string fileName = file.Name;
			string fileSize = file.Length.ToString();
			string fileType = file.Extension.Replace(".", "");
			string fileImageType = "File";
			string fileDateTime = file.LastAccessTime.ToString("d/M/yyyy h:m:s tt");
			
			dsDir.Tables[0].Rows.Add(new object[] {fileName, fileSize, fileType, fileDateTime, fileImageType});
		}
		
		gridDir.DataSource = dsDir;
		gridDir.DataBind();
	}
	
	public bool cpDir_OnBeforePanelUpdate(string panelId, string containerId)
	{
		if (this.UpdatePanelParams["dirID"] != null)
			SelectDir(this.UpdatePanelParams["dirID"].ToString());
		else
			SelectDir(DefaultFolder);
		
		return true;
	}
}