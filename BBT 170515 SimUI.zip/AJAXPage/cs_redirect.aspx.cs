public class cs_redirect : OboutInc.oboutAJAXPage
{
	public void ServerRedirect()
	{
		Redirect("http://www.obout.com");
	}
}