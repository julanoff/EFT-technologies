public class cs_updatepanelfrompage1 : OboutInc.oboutAJAXPage
{
	
}