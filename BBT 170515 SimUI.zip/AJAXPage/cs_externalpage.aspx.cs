public class cs_externalpage : OboutInc.oboutAJAXPage
{
	public string DoExternalCallback()
	{
		return "external callback result";
	}
}