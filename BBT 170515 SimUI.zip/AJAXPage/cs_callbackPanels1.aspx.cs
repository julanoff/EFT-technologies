public class cs_callbackPanels1 : OboutInc.oboutAJAXPage
{
	
}