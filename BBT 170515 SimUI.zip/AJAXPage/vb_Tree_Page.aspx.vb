imports System

public partial class vb_Tree_Page 
	inherits OboutInc.oboutAJAXPage

    protected sub Page_Load(byval sender as object, byval e as EventArgs)
    end sub
        
end class
