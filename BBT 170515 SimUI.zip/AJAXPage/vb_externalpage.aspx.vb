public class vb_externalpage 
	inherits OboutInc.oboutAJAXPage

	public function DoExternalCallback() as string
		return "external callback result"
	end function
end class