public class cs_callbackPanels3 : OboutInc.oboutAJAXPage
{
	
}