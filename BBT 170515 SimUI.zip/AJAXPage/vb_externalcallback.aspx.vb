public class vb_externalcallback 
	inherits OboutInc.oboutAJAXPage

	public function DoCallback() as string
		return "callback result"
	end function
end class