public class cs_externalcallback : OboutInc.oboutAJAXPage
{
	public string DoCallback()
	{
		return "callback result";
	}
}