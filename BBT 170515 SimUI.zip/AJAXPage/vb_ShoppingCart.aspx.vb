imports System
imports System.Web.UI.WebControls
imports System.Collections
imports System.Data
imports System.Data.Common
imports System.Data.OleDb

Public Class vb_ShoppingCart
    Inherits OboutInc.oboutAJAXPage

    Protected Category As Literal
    Protected basket As DataList
    Protected productList As DataList

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)

        if Not IsCallback and not IsPostBack		
			LoadBasket()
			LoadCategory(1)
	End If
	
        If Not IsCallback Then

            Dim oTree As obout_ASPTreeView_2_NET.Tree = New obout_ASPTreeView_2_NET.Tree()

            Dim oConn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + System.Web.HttpContext.Current.Server.MapPath("../App_Data/Products.mdb"))
            oConn.Open()

            ' read the information from the database		
            Dim sQuery As String = "SELECT NodeID, ParentID, NodeHTML, NodeIcon, NodeLevel, Expanded FROM Category ORDER BY NodeLevel ASC"
            Dim oCommand As OleDbCommand = New OleDbCommand(sQuery)
            oCommand.Connection = oConn
            Dim oReader As OleDbDataReader = oCommand.ExecuteReader()

            Dim sNodeId As String
            Dim sParentId As String
            Dim sHtml As String
            Dim sIcon As String
            Dim iExpanded As Int32 = 1 ' all the nodes will be expanded

            ' make a loop through all the records from the database and add them to the TreeView
            While oReader.Read()

                sNodeId = oReader.GetValue(0).ToString()
                sParentId = oReader.GetValue(1).ToString()
                sHtml = oReader.GetValue(2).ToString()
                sIcon = oReader.GetValue(3).ToString()
                If sParentId <> "" And sParentId <> "NULL" Then
                    oTree.Add(sParentId, sNodeId, sHtml, iExpanded, sIcon, Nothing)
                Else
                    oTree.AddRootNode(sHtml, True, Nothing)
                End If
            End While
            oTree.SelectedId = "node1_1"
            oConn.Close()

            ' change this to your local TreeIcons folder
            oTree.FolderIcons = "../TreeView/tree2/icons"
            oTree.FolderScript = "../TreeView/tree2/script"
            oTree.FolderStyle = "../TreeView/tree2/style/web"

            oTree.ShowIcons = False
            oTree.Width = "100px"
            oTree.ShowIcons = True
            oTree.EditNodeEnable = False
            oTree.DragAndDropEnable = False

            ' Enabling the server-side events
            oTree.EventList = ""

            ' Write treeview to your page.
            Category.Text = oTree.HTML()
        End If
    End Sub

    ' load the basket from session object and populate the datalist
    Public Function LoadBasket() As Boolean
        Dim totalPrice As String = "0"

        If Not Session("Basket") Is Nothing Then

            If CType(Session("Basket"), ArrayList).Count > 0 Then

                Dim oleDBConnetion As OleDbConnection = New OleDbConnection()
                oleDBConnetion.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Server.MapPath("../App_Data/Products.mdb") + "; User Id=; Password="

                ' gets the datasource for the emails list
                Dim oleDBCommand As OleDbCommand = New OleDbCommand()
                oleDBCommand.Connection = oleDBConnetion

                Dim query As String = "SELECT ProductID, ProductName, ProductImage, ProductShortDescription, ProductPrice FROM Products where "

                Dim index As Int32
                For index = 0 To CType(Session("Basket"), ArrayList).Count - 1 Step 1
                    If index = 0 Then
                        query += " ProductID = " + CType(Session("Basket"), ArrayList)(index).ToString()
                    Else
                        query += " or ProductID = " + CType(Session("Basket"), ArrayList)(index).ToString()
                    End If
                Next



                oleDBCommand.CommandText = query

                Dim dataReader As OleDbDataReader
                oleDBConnetion.Open()
                dataReader = oleDBCommand.ExecuteReader()
                basket.DataSource = dataReader
                basket.DataBind()
                dataReader.Close()

                ' calculate total price
                Dim query2 As String = "SELECT sum(ProductPrice) FROM Products where "
                For index = 0 To CType(Session("Basket"), ArrayList).Count - 1 Step 1
                    If index = 0 Then
                        query2 += " ProductID = " + CType(Session("Basket"), ArrayList)(index).ToString()
                    Else
                        query2 += " or ProductID = " + CType(Session("Basket"), ArrayList)(index).ToString()
                    End If
                Next

                Dim oleDBCommand2 As OleDbCommand = New OleDbCommand()
                oleDBCommand2.Connection = oleDBConnetion
                oleDBCommand2.CommandText = query2

                totalPrice = oleDBCommand2.ExecuteScalar().ToString()

                oleDBConnetion.Close()
            End If
        End If

        ExecOnLoad("UpdateTotalPrice('" + totalPrice + "')")

        Return True
    End Function

    Public selectedCategoryID As Int32 = 0

    Private Sub LoadCategory(Byval CategoryID As Int32)
        Dim oleDBConnetion As OleDbConnection = New OleDbConnection()
        oleDBConnetion.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Server.MapPath("../App_Data/Products.mdb") + "; User Id=; Password="

        ' gets the datasource for the emails list
        Dim oleDBCommand As OleDbCommand = New OleDbCommand()
        oleDBCommand.Connection = oleDBConnetion
        oleDBCommand.CommandText = "SELECT ProductID, ProductName, ProductImage, ProductShortDescription, ProductPrice FROM Products where CategoryID = " + CategoryID.ToString() + ""

        Dim dataReader As OleDbDataReader
        oleDBConnetion.Open()
        dataReader = oleDBCommand.ExecuteReader()
        productList.DataSource = dataReader
        productList.DataBind()
        dataReader.Close()

        oleDBConnetion.Close()
    End Sub

    ' add a new product to the session basket
    ' Qty should also be processed
    Public Function AddProductToBasket(ByVal ProductID As Int32, ByVal Qty As Int32) As Boolean

        If Session("Basket") Is Nothing Then
            Session("Basket") = New ArrayList()
        End If

        If Not CType(Session("Basket"), ArrayList).Contains(ProductID) Then
            CType(Session("Basket"), ArrayList).Add(ProductID)
            Return True
        End If

        Return False
    End Function

    ' remove product from the session basket
    Public Function RemoveProductFromBasket(ByVal ProductID As Int32) As Boolean

        CType(Session("Basket"), ArrayList).Remove(ProductID)

        Return True
    End Function

        protected function panelProductsList_OnBeforePanelUpdate(byval panelId as string, byval containerId as string) as boolean
		LoadCategory(Int32.Parse(Me.UpdatePanelParams("CategoryID").ToString()))
		
		return true
end function
	
	protected function panelBasket_OnBeforePanelUpdate(byval panelId as string, byval containerId as string) as boolean
	
		if (not me.UpdatePanelParams("AddProduct") is nothing)

			dim addProduct as boolean = Boolean.Parse(me.UpdatePanelParams("AddProduct").ToString())
			dim ProductID as Int32 = Int32.Parse(me.UpdatePanelParams("ProductID").ToString())
			
			if (addProduct)
				dim Qty as int32 = Int32.Parse(Me.UpdatePanelParams("Qty").ToString())
				AddProductToBasket(ProductID, Qty)
			else 
				RemoveProductFromBasket(ProductID)
                        end if
		end if
		
		LoadBasket()
		
		return true
end function

protected sub productList_OnItemDataBound(byval sender as object, byval e as DataListItemEventArgs)

		if e.Item.ItemType <> ListItemType.Header and e.Item.ItemType <> ListItemType.Footer
		
			dim itemsNumberList as DropDownList = CType(e.Item.FindControl("itemsNumberList"), DropDownList)
			dim linkAddToBasket as HyperLink = CType(e.Item.FindControl("linkAddToBasket"), HyperLink)
			dim ProductID as string = (ctype(e.Item.DataItem, DbDataRecord))("ProductID").ToString()
			linkAddToBasket.NavigateUrl = "javascript:AddToBasket(" + ProductID + ", """ + itemsNumberList.ClientID + """)"
		end if
end sub
End Class