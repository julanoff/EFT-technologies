imports obout_ASPTreeView_2_NET
imports System
imports System.IO
imports System.Data
imports System.Collections
imports System.Data.OleDb
imports System.Web.UI.WebControls

public class FileBrowser 
	Inherits OboutInc.oboutAJAXPage

	protected TreeView as Label
	protected gridDir as Obout.Grid.Grid
	dim DefaultFolder as string 
	dim expandedLevel as int32  = 0
	
	Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)

		'DefaultFolder = "c:\oboutSuite\AJAXPage\resources\FileBrowser\\"
		DefaultFolder = Server.MapPath("resources/FileBrowser/")
		
		ThrowExceptionsAtClient = false
		ShowErrorsAtClient = false
		
		LoadTreeView()
		
		' set default initial directory
		if not IsPostBack
			SelectDir(DefaultFolder)
		End If
		
    End sub
	
	private sub LoadTreeView()
	
		dim oTree as obout_ASPTreeView_2_NET.Tree = new obout_ASPTreeView_2_NET.Tree()
		oTree.id = "tree_0"
		dim ParentID as string = "root"
	
		oTree.AddRootNode("<span style='cursor:pointer'>File Browser</span>", nothing)

		dim rootFolder as DirectoryInfo = new DirectoryInfo(DefaultFolder)
		LoadDirRecursive(ParentID, rootFolder, oTree)

		oTree.Width = "150px"
		oTree.DragAndDropEnable = false
		oTree.KeyNavigationEnable = true
		oTree.SelectedEnable = true
		oTree.SelectedId = "root_tree_0"
		oTree.EventList = "OnNodeSelect"
		
        oTree.FolderIcons = "../TreeView/tree2/icons"
        oTree.FolderScript = "../TreeView/tree2/script"
        oTree.FolderStyle = "../TreeView/tree2/style/Explorer"
		
		TreeView.Text = oTree.HTML()
	end sub
	
	private sub LoadDirRecursive(byval ParentID as string, byval rootFolder as DirectoryInfo, byval oTree as obout_ASPTreeView_2_NET.Tree)
	
		dim nodeId as string
		expandedLevel = expandedLevel + 1
		dim oAdditionalInfo as Hashtable
		
		for each dir as DirectoryInfo in rootFolder.GetDirectories()
		
			dim dirName as string = dir.Name
			dim dirID as string = dirName
			
			dim expanded as boolean = true
			if (expandedLevel >= 15)
				expanded = false
			End if
				
			' tree id will be unique
			nodeId = Guid.NewGuid().ToString()
			
			' aditional data on the tree node doesn't support \ char, use | instead
			oAdditionalInfo = new Hashtable()
			oAdditionalInfo("DirectoryPath") = dir.FullName.Replace("\", "|")
			
			
			dim textDirName as string = "<span style='cursor:pointer'>" + dirName + "</span>"
			oTree.Add(ParentID, nodeId , textDirName, expanded, "folder.gif", nothing, oAdditionalInfo)
			
			LoadDirRecursive(nodeId, new DirectoryInfo(rootFolder.ToString() + "/" + dirName), oTree)
		next
	end sub
	
	' populate grid with directory content
	public sub SelectDir(byval dirID as string)
	
		' replace back from | to \ char (path delimiter)
		dirID = dirID.Replace("|", "\")
		
		dim dsDir as DataSet = new DataSet()
		dsDir.Tables.Add(new DataTable())
		dsDir.Tables(0).Columns.Add(new DataColumn("name", System.Type.GetType("System.String")))
		dsDir.Tables(0).Columns.Add(new DataColumn("size", System.Type.GetType("System.Int32")))
		dsDir.Tables(0).Columns.Add(new DataColumn("type", System.Type.GetType("System.String")))
		dsDir.Tables(0).Columns.Add(new DataColumn("datemodified", System.Type.GetType("System.String")))
		dsDir.Tables(0).Columns.Add(new DataColumn("imageType", System.Type.GetType("System.String")))
		
		dim rootFolder as DirectoryInfo = new DirectoryInfo(dirID)
		
		for each dir as DirectoryInfo in rootFolder.GetDirectories()
		
			dim dirName as string = dir.Name
			dim dirDateTime as string = dir.LastAccessTime.ToString("d/M/yyyy h:m:s tt")
			dim dirImageType as string = "Folder"
			dsDir.Tables(0).Rows.Add(new object() {dirName, 0, "File Folder", dirDateTime, dirImageType})
			
		next
		
		for each file as FileInfo in rootFolder.GetFiles()
		
			dim fileName as string = file.Name
			dim fileSize as string = file.Length.ToString()
			dim fileType as string = file.Extension.Replace(".", "")
			dim fileImageType as string = "File"
			dim fileDateTime as string = file.LastAccessTime.ToString("d/M/yyyy h:m:s tt")
			
			dsDir.Tables(0).Rows.Add(new object() {fileName, fileSize, fileType, fileDateTime, fileImageType})
		next
		
		gridDir.DataSource = dsDir
		gridDir.DataBind()
	end sub

    public function cpDir_OnBeforePanelUpdate(byval panelId as string, byval containerId as string) as boolean
	
		if not me.UpdatePanelParams("dirID") is nothing
			SelectDir(me.UpdatePanelParams("dirID").ToString())
		else
			SelectDir(DefaultFolder)
                end if
		
		return true

	end function
End Class