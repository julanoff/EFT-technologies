public class vb_withmasterpages 
	inherits OboutInc.oboutAJAXPage
end class
    

