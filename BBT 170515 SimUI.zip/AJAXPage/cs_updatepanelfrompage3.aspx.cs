public class cs_updatepanelfrompage3 : OboutInc.oboutAJAXPage
{
	
}