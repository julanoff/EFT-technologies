public class vb_callbackPanels1 
	inherits OboutInc.oboutAJAXPage
end class
	
