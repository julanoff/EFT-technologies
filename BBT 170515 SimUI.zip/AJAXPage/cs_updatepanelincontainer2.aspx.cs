using System;
using System.Web.UI.WebControls;
using obout_ASPTreeView_2_NET;

public class cs_updatepanelincontainer2 : OboutInc.oboutAJAXPage
{
	protected Literal TreeView;
	
	void Page_Load(object sender, EventArgs e) {
        obout_ASPTreeView_2_NET.Tree oTree = new obout_ASPTreeView_2_NET.Tree();

        oTree.Add("root", "a0", "obout.com (a0)", true, "Folder.gif", null);
        oTree.Add("a0", "a1", "ASP TreeView (a1)", true, "tree.gif", null);
        oTree.Add("a1", "a2", "Fast (a2)", true, null, null);
        oTree.Add("a1", "a3", "Easy (a3)", true, "page.gif", null);
        oTree.Add("root", "a4", "Links & Notes since 1998 (a4)", true, "BookY.gif", null);
        oTree.Add("root", "a5", "MemoBook.com (a5)", true, "ball_glass_blueS.gif", null);

        oTree.FolderIcons = "../TreeView/tree2/Icons";
        oTree.FolderScript = "../TreeView/tree2/script";
        oTree.FolderStyle = "../TreeView/tree2/style/Classic";
        oTree.DragAndDropEnable = false;
        
        TreeView.Text = oTree.HTML();
    }
}
