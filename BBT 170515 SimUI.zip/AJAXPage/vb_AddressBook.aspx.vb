imports System
imports System.Data
imports System.Data.OleDb
imports System.Web.UI.WebControls
imports obout_ASPTreeView_2_NET

Public Class vb_AddressBook
    Inherits OboutInc.oboutAJAXPage

    Protected TreeView As Literal
    Protected lContactImage As Literal
    Protected lContactName As Literal
    Protected lContactCompany As Literal
    Protected lContactEmail As Literal
    Protected lContactPhone As Literal
    Protected lContactCell As Literal
    Protected lContactFax As Literal

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Not IsCallback Then

            Dim oTree As obout_ASPTreeView_2_NET.Tree = New obout_ASPTreeView_2_NET.Tree()

            Dim oConn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("../App_Data/AddressBook.mdb"))
            oConn.Open()

            oTree.AddRootNode("Address Book", "folder.gif")

            Dim sQuery As String = "SELECT DepartmentID, DepartmentName FROM Departments ORDER BY DepartmentName ASC"
            Dim oCommand As OleDbCommand = New OleDbCommand(sQuery)
            oCommand.Connection = oConn
            Dim oReader As OleDbDataReader = oCommand.ExecuteReader()

            Dim sDepartmentID As String
            Dim sDepartmentName As String

            Dim sUndraggableNodes As String = ""

            While oReader.Read()

                sDepartmentID = oReader.GetInt32(0).ToString()
                sDepartmentName = oReader.GetValue(1).ToString()

                oTree.Add("root", "oDep_" + sDepartmentID, sDepartmentName, 1, "oInboxF.gif", Nothing)
                If sUndraggableNodes <> "" Then
                    sUndraggableNodes += ","
                End If
                sUndraggableNodes += "oDep_" + sDepartmentID
            End While

            oConn.Close()
            oConn.Open()

            sQuery = "SELECT ContactID, FirstName, LastName, DepartmentID FROM Contacts ORDER BY FirstName ASC, LastName ASC"
            oCommand = New OleDbCommand(sQuery)
            oCommand.Connection = oConn
            Dim oReader2 As OleDbDataReader = oCommand.ExecuteReader()

            Dim sContactId As String
            Dim sFirstName As String
            Dim sLastName As String

            While oReader2.Read()

                sContactId = oReader2.GetInt32(0).ToString()
                sFirstName = oReader2.GetValue(1).ToString()
                sLastName = oReader2.GetValue(2).ToString()
                sDepartmentID = oReader2.GetInt32(3).ToString()

                oTree.Add("oDep_" + sDepartmentID, "oCont_" + sContactId, sFirstName + " " + sLastName, 1, "person.gif", Nothing)
            End While

            oConn.Close()

            oTree.FolderIcons = "../TreeView/tree2/icons"
            oTree.FolderScript = "../TreeView/tree2/script"
            oTree.FolderStyle = "../TreeView/tree2/style/Classic"

            oTree.ShowIcons = False

            oTree.Width = "200px"
            oTree.ShowIcons = True
            oTree.EditNodeEnable = False
            oTree.DragAndDropEnable = False
            oTree.DragDisableId = sUndraggableNodes
            oTree.EventList = "OnNodeSelect,OnNodeDrop"
            ' Write treeview to your page.
            TreeView.Text = oTree.HTML()
        End If

    End Sub

    Public Sub SetContactInformation(ByVal id as Int32)

        Dim sServerResponse As String = ""

        Dim oConn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("../App_Data/AddressBook.mdb"))
        oConn.Open()

        Dim sQuery As String = "SELECT FirstName, LastName, CompanyName, Email, Phone, CellPhone, Fax, Picture FROM Contacts WHERE ContactID = " + id.ToString()
        Dim oCommand As OleDbCommand = New OleDbCommand(sQuery)
        oCommand.Connection = oConn
        Dim oReader As OleDbDataReader = oCommand.ExecuteReader()

        oReader.Read()

        Dim sFirstName As String
        Dim sLastName As String
        Dim sCompanyName As String
        Dim sEmail As String
        Dim sPhone As String
        Dim sCellPhone As String
        Dim sFax As String
        Dim sPicture As String

        sFirstName = oReader.GetString(0)
        sLastName = oReader.GetString(1)
        sCompanyName = oReader.GetString(2)
        sEmail = oReader.GetString(3)
        sPhone = oReader.GetString(4)
        sCellPhone = oReader.GetString(5)
        sFax = oReader.GetString(6)
        sPicture = oReader.GetString(7)

        lContactImage.Text = sPicture
        lContactName.Text = sFirstName + " " + sLastName
        lContactCompany.Text = sCompanyName
        lContactEmail.Text = sEmail
        lContactPhone.Text = sPhone
        lContactCell.Text = sCellPhone
        lContactFax.Text = sFax

        oConn.Close()
    End Sub

    public Function cpContactInfomation_OnBeforePanelUpdate(ByVal panelId As String, ByVal containerId as String) As Boolean
        Dim id as string = UpdatePanelParams("id").ToString()

        SetContactInformation(Int32.Parse(id))

	return true
    End Function

End Class