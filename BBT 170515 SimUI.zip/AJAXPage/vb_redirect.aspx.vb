public class vb_redirect 
	inherits OboutInc.oboutAJAXPage

	public sub ServerRedirect()
		Redirect("http://www.obout.com")
	end sub
	
end class 