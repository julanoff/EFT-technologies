public class cs_updatepanelfrompage2 : OboutInc.oboutAJAXPage
{
	
}
