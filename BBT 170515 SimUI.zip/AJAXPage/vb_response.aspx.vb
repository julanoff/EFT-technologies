imports System
imports System.Data.OleDb
imports System.Web.UI.WebControls
imports System.Collections

public class vb_response 
	inherits OboutInc.oboutAJAXPage

	protected Category as Literal
	protected basket as DataList
	protected productList as DataList
	
	sub Page_Load(byval sender as object, byval e as EventArgs) 
        if not IsCallback
		
			dim oTree as obout_ASPTreeView_2_NET.Tree = new obout_ASPTreeView_2_NET.Tree()
	
			dim oConn as OleDbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + System.Web.HttpContext.Current.Server.MapPath("../App_Data/Products.mdb"))
			oConn.Open()
			
			' read the information from the database		
			dim sQuery as string = "SELECT NodeID, ParentID, NodeHTML, NodeIcon, NodeLevel, Expanded FROM Category ORDER BY NodeLevel ASC"
			dim oCommand as OleDbCommand = new OleDbCommand(sQuery)
			oCommand.Connection = oConn
			dim oReader as OleDbDataReader = oCommand.ExecuteReader()
	
			dim sNodeId as string
			dim sParentId as string
			dim sHtml as string
			dim sIcon as string
			dim iExpanded as Int32 = 1 ' all the nodes will be expanded
	
            ' make a loop through all the records from the database and add them to the TreeView
			while oReader.Read()
				sNodeId = oReader.GetValue(0).ToString()
				sParentId = oReader.GetValue(1).ToString()
				sHtml = oReader.GetValue(2).ToString()
				sIcon = oReader.GetValue(3).ToString()
				if sParentId <> "" and sParentId <> "NULL"
					oTree.Add(sParentId, sNodeId, sHtml, iExpanded, sIcon, nothing)
				else
					oTree.AddRootNode(sHtml, true, nothing)
				end if
			end while
			oConn.Close()
	
			' change this to your local TreeIcons folder
            oTree.FolderIcons = "../TreeView/tree2/icons/"
            oTree.FolderScript = "../TreeView/tree2/script"
            oTree.FolderStyle = "../TreeView/tree2/style/web"
	
			oTree.ShowIcons = false
			oTree.Width = "100px"
			oTree.ShowIcons = true
			oTree.EditNodeEnable = false
			oTree.DragAndDropEnable = false
			
			
			' Enabling the server-side events
			oTree.EventList = "OnNodeSelect,OnNodeDrop"
			
			' Write treeview to your page.
			Category.Text = oTree.HTML()
		end if
		
		if IsCallback
			LoadCategory()
			LoadBasket()
		end if
    end sub
	
	public sub SetCategoryID(byval CategoryID as Int32) 
		GetCategoryContent(CategoryID)
	end sub
	
	' load the basket from session object and populate the datalist
	public function LoadBasket() as boolean
		dim totalPrice as string = "0"
		
		if not Session("Basket") is nothing
			if CType(Session("Basket"), ArrayList).Count > 0
				dim  oleDBConnetion as OleDbConnection = new OleDbConnection()
				oleDBConnetion.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Server.MapPath("../App_Data/Products.mdb") + "; User Id=; Password="
		
				' gets the datasource for the emails list
				dim  oleDBCommand as OleDbCommand = new OleDbCommand()
				oleDBCommand.Connection = oleDBConnetion
				
				dim query as string = "SELECT ProductID, ProductName, ProductImage, ProductShortDescription, ProductPrice FROM Products where "
				dim index as Int32
				for index = 0 to CType(Session("Basket"), ArrayList).Count - 1 Step 1
					if index = 0
						query = query + " ProductID = " + CType(Session("Basket"), ArrayList)(index).ToString()
					else
						query = query + " or ProductID = " + CType(Session("Basket"), ArrayList)(index).ToString()
					end if
				next
							
				oleDBCommand.CommandText = query
		
				dim dataReader as OleDbDataReader
				oleDBConnetion.Open()
				dataReader = oleDBCommand.ExecuteReader()
				basket.DataSource = dataReader
				basket.DataBind()
				dataReader.Close()
				
				' calculate total price
				dim query2 as string = "SELECT sum(ProductPrice) FROM Products where "
				for index = 0 to CType(Session("Basket"), ArrayList).Count - 1 Step 1			
					if index = 0
						query2 = query2 + " ProductID = " + CType(Session("Basket"), ArrayList)(index).ToString()
					else
						query2 = query2 + " or ProductID = " + CType(Session("Basket"), ArrayList)(index).ToString()
					end if
				next

				dim oleDBCommand2 as OleDbCommand = new OleDbCommand()
				oleDBCommand2.Connection = oleDBConnetion
				oleDBCommand2.CommandText = query2
		
				totalPrice = oleDBCommand2.ExecuteScalar().ToString()
				
				oleDBConnetion.Close()
			end if
		end if
		
		ExecOnLoad("UpdateTotalPrice('" + totalPrice + "')")
		
		return true
	end function
	
	public dim selectedCategoryID as int32 = 0
	
	public sub GetCategoryContent(byval CategoryID as Int32) 
		Session("CategoryID") = CategoryID
	end sub
	
	private sub LoadCategory() 
		if Session("CategoryID") is nothing 
			Session("CategoryID") = 1
		end if
		
		dim CategoryID as Int32 = Int32.Parse(Session("CategoryID").ToString())
		
		dim oleDBConnetion as OleDbConnection  = new OleDbConnection()
		oleDBConnetion.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Server.MapPath("../App_Data/Products.mdb") + "; User Id=; Password="

		' gets the datasource for the emails list
		dim oleDBCommand as OleDbCommand  = new OleDbCommand()
		oleDBCommand.Connection = oleDBConnetion
		oleDBCommand.CommandText = "SELECT ProductID, ProductName, ProductImage, ProductShortDescription, ProductPrice FROM Products where CategoryID = " + CategoryID.ToString() + ""

		dim dataReader as OleDbDataReader
		oleDBConnetion.Open()	
		dataReader = oleDBCommand.ExecuteReader()
		productList.DataSource = dataReader
		productList.DataBind()
		dataReader.Close()
		
		oleDBConnetion.Close()
	end sub
	
	' add a new product to the session basket
	public sub AddProductToBasket(byval ProductID as Int32) 
		if Session("Basket") is nothing
			Session("Basket") = new ArrayList()
		end if
			
		if not CType(Session("Basket"), ArrayList).Contains(ProductID)
			CType(Session("Basket"), ArrayList).Add(ProductID)
			return
		end if
		
		' use the response object and change the allowReturn value to false
		' so that the function executed after the callback is done to not be executed 
		ExecBeforeLoad("response.allowReturn = false;alert('The product already exists in the basket!\\n\\nSet response.allowReturn = false to block basket reload. ')")
	end sub
	
	' remove product from the session basket
	public function RemoveProductFromBasket(byval ProductID as Int32) as boolean
		CType(Session("Basket"), ArrayList).Remove(ProductID)
		
		return true
	end function
end class