imports System
imports System.Data.SqlClient

public class vb_Tree_UserControl 
	inherits System.Web.UI.UserControl

    protected sub Page_Load(byval sender as object, byval e as EventArgs)
    
        dim oTree as obout_ASPTreeView_2_NET.Tree = new obout_ASPTreeView_2_NET.Tree()

		'sql express
		Dim oConn As SqlConnection = New SqlConnection("Server=.\SQLEXPRESS;AttachDBFilename=|DataDirectory|TreeNodes.mdf;Database=TreeNodes;Trusted_Connection=Yes;")

		'MSSQL Server
		'dim oConn as SqlConnection = new SqlConnection("Driver={SQL Server};Server=localhost;UID=obout_usr;PWD=obout_pwd;Database=obout;")

		'MySql
		'dim oConn as SqlConnection = new SqlConnection("DRIVER={MySQL ODBC 3.51 Driver};Server=localhost;UID=root;PWD=root_pwd;Database=test")

		oConn.Open()
		
		' read the information from the database		
		dim sQuery as string = "SELECT NodeID, ParentID, NodeHTML, NodeIcon, NodeLevel, Expanded FROM treeview ORDER BY NodeLevel ASC"
		dim oCommand as SqlCommand = new SqlCommand(sQuery)
		oCommand.Connection = oConn
		dim oReader as SqlDataReader = oCommand.ExecuteReader()

		dim sNodeId as string
		dim sParentId as string
		dim sHtml as string
		dim sIcon as string
		dim iExpanded as Int32 = 1 ' all the nodes will be expanded

        ' make a loop through all the records from the database and add them to the TreeView
		while (oReader.Read())
		
			sNodeId = oReader.GetValue(0).ToString()
			sParentId = oReader.GetValue(1).ToString()
			sHtml = oReader.GetValue(2).ToString()
			sIcon = oReader.GetValue(3).ToString()
			if sParentId <> "" and sParentId <> "NULL"
				oTree.Add(sParentId, sNodeId, sHtml, iExpanded, sIcon, nothing)
			else
				oTree.AddRootNode(sHtml, true, nothing)
			end if
		end while
		oConn.Close()

		' change this to your local TreeIcons folder
        oTree.FolderIcons = "../TreeView/tree2/icons"
        oTree.FolderStyle = "../TreeView/tree2/style/Classic"
        oTree.FolderScript = "../TreeView/tree2/script"

		oTree.ShowIcons = false

		oTree.Width = "200px"
		oTree.ShowIcons = true
		oTree.EditNodeEnable = true
		oTree.DragAndDropEnable = true
		' Enabling the server-side events
		oTree.EventList = "OnNodeEdit,OnAddNode,OnNodeDrop,OnRemoveNode"
		' Write treeview to your page.
		TreeView.Text = oTree.HTML()
    end sub
end class
