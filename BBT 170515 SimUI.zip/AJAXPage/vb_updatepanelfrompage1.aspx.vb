public class vb_updatepanelfrompage1 
	Inherits OboutInc.oboutAJAXPage
end class
	
