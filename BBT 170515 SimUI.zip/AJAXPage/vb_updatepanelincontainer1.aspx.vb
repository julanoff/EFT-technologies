public class vb_updatepanelincontainer1 
	Inherits OboutInc.oboutAJAXPage
End Class
	