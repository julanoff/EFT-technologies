public class cs_showalert : OboutInc.oboutAJAXPage
{
	public void ServerShowAlert() {
		// this will show an alert at client side
		ShowAlert("This alert was sent by server");
	}
}