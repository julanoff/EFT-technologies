public class vb_updatepanelfrompage2 
	Inherits OboutInc.oboutAJAXPage
end class
	

