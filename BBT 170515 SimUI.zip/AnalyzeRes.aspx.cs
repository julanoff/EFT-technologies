/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System.Data.SqlClient;
using Obout.Grid;
using Obout.Interface;


/*
 * Results analysis. Show sorted grid with fileds name summary.
 */
namespace Simulator
{
    public partial class AnalyzeRes : OboutInc.oboutAJAXPage
    {
        private static string m_Batchstr;
        private static string m_FldName;
        private static string m_Sval;
        private static string m_Tval;
        private static int m_PageNo;
        private static bool m_localDB = true;
        private OracleConnection m_OraConnection;
        private static string m_connString;
        private static string m_SrcConnName;
        private static string m_TrgConnName;
        private static string m_dbprefix;
        private static string m_vendor;
        DBAccess m_Connection;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                FillBatch();
                m_PageNo = 0;
                m_Sval = m_Tval = "NONE";
                DataGrid1.Visible = false;
            }
            DataGrid2.Visible = false;
            BacktoSummary.Visible = false;
            Excel.Visible = false;
            m_vendor = (String)HttpContext.Current.Session["vendor"];

            if (DataGrid2.SelectedRecords != null)  //when user has choosen a record.
            {
                foreach (Hashtable oRecord in DataGrid2.SelectedRecords)
                {
                    m_FldName = oRecord["FldN"].ToString().TrimEnd();
                    m_Sval = oRecord["Svals"].ToString().TrimEnd();
                    m_Tval = oRecord["Tvals"].ToString().TrimEnd();
                }
                m_PageNo = DataGrid2.CurrentPageIndex;
                DataGrid1.Visible = true;
                DataGrid1.AllowFiltering = true;
                BacktoSummary.Visible = true;
                Excel.Visible = true;
                BindDataGrid1();
            }
        }

        protected void FillBatch()
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            try
            {
                string Cmd = "select '      ' as BatchDescr, '0' as Batchid from BatchDescr union select batchdescr, batchid from BatchDescr where CompId=0";

                if (Connection.OpenDataReader(Cmd))
                {
                    BatchIdsDropdown.DataSource = Connection.SQLDR;
                    BatchIdsDropdown.DataTextField = "BatchDescr";
                    BatchIdsDropdown.DataValueField = "BatchId";
                    BatchIdsDropdown.DataBind();
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
        }
        protected void OnGridRowCreated(object sender, GridRowEventArgs args)
        {
            //DataGrid1.Columns[1].ReadOnly = false;
            // gets called before a row created. It stop each time the row is populated from DB not used
        }

        protected void RebindGrid1(object sender, EventArgs e)
        {
            BindDataGrid1();
        }
        protected void RebindGrid2(object sender, EventArgs e)
        {
            BindDataGrid2();
        }

        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {
            //  when user chooses a mid /trn to show all diff for selected ref
            m_Batchstr = BatchIdsDropdown.SelectedValue;
            string Cmd = string.Format("select * from batchdescr where batchid='{0}'", m_Batchstr);
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            try
            {
                if (Connection.OpenDataReader(Cmd))
                {
                    while (Connection.SQLDR.Read())
                    {
                        Box1.Text = Connection.SQLDR["BatchStatus"].ToString().TrimEnd();
                        Box2.Text = Connection.SQLDR["AreaBefore"].ToString().TrimEnd();
                        Box3.Text = Connection.SQLDR["AreaAfter"].ToString().TrimEnd();
                        Box4.Text = Connection.SQLDR["TimeStart"].ToString();
                        Box5.Text = Connection.SQLDR["TimeStart"].ToString();
                        m_dbprefix = Connection.SQLDR["DbPrefix"].ToString();
                        m_SrcConnName = Connection.SQLDR["AreaBefore"].ToString().TrimEnd();
                        m_TrgConnName = Connection.SQLDR["AreaAfter"].ToString().TrimEnd();
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
            DataGrid2.Visible = true;
            DataGrid1.Visible = false;
            BindDataGrid2();
        }

        protected void DoExcel(object sender, EventArgs e)
        {
            DataGrid1.Visible = true;
            BacktoSummary.Visible = true;
            Excel.Visible = true;
            BindDataGrid1();
        }

        protected void ShowAllBatch(object sender, EventArgs e)
        {
            m_FldName = "";
            DataGrid1.Visible = true;
            BacktoSummary.Visible = true;
            Excel.Visible = true;
            BindDataGrid1();
        }

        protected void SummaryBatch(object sender, EventArgs e)
        {
            //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
            BacktoSummary.Visible = false;
            Excel.Visible = false;
            DataGrid1.Visible = false;
            DataGrid2.Visible = true;
            BindDataGrid2();
        }

        protected void BindDataGrid1()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                string Cmd = "";

                if (m_FldName.Length != 0)
                {
                    string[] pp = m_FldName.Split('-');
                    string Tbl = pp[0].TrimEnd();
                    string Fname = pp[1].Trim();
                    Cmd = string.Format("select refbefore, refafter,Fldname,XmlSet,ValBefore,ValAfter from DiffResults where BatchId={0} and XmlSet = '{1}' and FldName='{2}'", m_Batchstr, Tbl, Fname);
                    if ((m_Sval != "") && (m_Sval != "NONE"))
                        Cmd = Cmd + " and ValBefore not in (" + m_Sval + ")";
                    if ((m_Tval != "") && (m_Tval != "NONE"))
                        Cmd = Cmd + " and ValAfter not in (" + m_Tval + ")";
                }
                else
                    Cmd = string.Format("select refbefore, refafter,Fldname,XmlSet,ValBefore,ValAfter from DiffResults where BatchId={0}", m_Batchstr);

                DataSet ds = Connection.getDataSet(Cmd);
                DataGrid1.DataSource = ds;
                DataGrid1.DataBind();
            }
            catch (Exception e)
            {
                ServerShowAlert1(e.Message);
                //  throw e;
            }
            finally
            {
                Connection.DisConnect();
            }
        }

        protected void BindDataGrid2()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                string Cmd = string.Format("SELECT  FldN , COUNT(FldN) AS Cnt, 'NONE' as Svals, 'NONE' as Tvals FROM ( SELECT  XmlSet + ' - ' + FldName AS [FldN] FROM DiffResults where BatchId='{0}') T1 group by FldN order by Cnt desc", m_Batchstr);
                DataSet ds = Connection.getDataSet(Cmd);
                DataGrid2.DataSource = ds;
                DataGrid2.CurrentPageIndex = m_PageNo;
                DataGrid2.DataBind();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                Connection.DisConnect();
            }
        }
        public void DataGrid_Edit(Object sender, GridRecordEventArgs e)
        {
            // Set the EditItemIndex property to the index of the item clicked
            // in the DataGrid control to enable editing for that item. Be sure
            // to rebind the DataGrid to the data source to refresh the control.
            m_Sval = e.Record["Svals"].ToString().Trim();
            m_Tval = e.Record["Tvals"].ToString().Trim();
            m_FldName = e.Record["FldN"].ToString().TrimEnd();
            m_PageNo = DataGrid2.CurrentPageIndex;
        }
        public void RowDataBound(object sender, GridRowEventArgs e)
        {
            if ((e.Row.RowType == GridRowType.DataRow) && (e.Row.Cells[0].Text == m_FldName))
            {
                e.Row.Cells[2].Text = m_Sval;
                e.Row.Cells[3].Text = m_Tval;
            }
        }
        public void ServerShowAlert1(string msg1)
        {
            // this will show an alert at client side
            string alrt = "alert('" + msg1.Replace("'", "") + " Check one of the specified values.')";
            ExecOnLoad(alrt);
            BacktoSummary.Visible = false;
            Excel.Visible = false;
            DataGrid1.Visible = false;
            DataGrid2.Visible = true;
            BindDataGrid2();
        }
        public void ServerShowAlert2(string msg1)
        {
            // this will show an alert at client side
            ExecOnLoad(msg1);
            BacktoSummary.Visible = false;
            Excel.Visible = false;
            DataGrid2.Visible = false;
            DataGrid1.Visible = true;
            BindDataGrid1();
        }
        public string MakeCmd(string mid, string prfx)
        {
            string cmd;
            if (m_vendor.ToLower().StartsWith("fts"))
            {
                cmd = string.Format("select " +
                            "P_MSG_STS,P_PRIORITY,P_DEPARTMENT,P_OFFICE," +
                            "P_ORIG_MSG_TYPE,P_CDT_MOP,P_ORIG_INSTR_ID,P_END_TO_END_ID,'0' as CHECK_INT,P_ORIG_STTLM_DT," +
                            "P_ORIG_STTLM_CCY,P_ORIG_STTLM_AMT,P_ORIG_STTLM_CCY,P_ORIG_STTLM_AMT,P_ORIG_STTLM_CCY," +
                            "P_ORIG_STTLM_AMT,P_INSTG_AGT_BIC_2AND,P_BASE_AMT,'N' as DEAL_BOOKED,P_DBT_ACCT_CCY," +
                            "P_DBT_AMT,P_DBT_VD,P_DBT_ACCT_CCY,P_DBT_AMT,P_CDT_ACCT_CCY,P_CDT_AMT,P_CDT_VD," +
                            "'RFB' as rfb, 'ORG_BIC' as org_bic, 'ORG_ID' as org_id, 'ORG' as org, 'ORG_ADDR1' as org_addr1, 'ORG_ADDR2' as org_addr2," +
                            "'ORG_ADDR3' as org_addr3, 'OGB_BIC' as ogb_bic, 'OGB_ID' as ogb_id, 'OGB' as ogb, 'OGB_ADDR1' as ogb_addr1, 'OGB_ADDR2' as ogb_addr2," +
                            "'OGB_ADDR3' as ogb_addr3, 'COR_BIC' as cor_bic, 'COR_ID' as cor_id," +
                            "'COR' as cor, 'COR_ADDR1' as cor_addr1, 'COR_ADDR2' as cor_addr2, 'COR_ADDR3' as cor_addr3, 'RCR_BIC' as rcr_bic, " +
                            "'RCR_ID' as rcr_id, 'RCR' as rcr, 'RCR_ADDR1' as rcr_addr1, 'RCR_ADDR2' as rcr_addr2, 'RCR_ADDR3' as rcr_addr3," +
                            "'RCB_BIC' as rcb_bic, 'RCB_ID' as rcb_id, 'RCB' as rcb, 'RCB_ADDR1' as rcb_addr1, 'RCB_ADDR2' as rcb_addr2, 'RCB_ADDR3' as rcb_addr3," +
                            "'SEND_ABA' as send_aba, 'SEND_NAME' as send_name, 'REC_ABA' as rec_aba," +
                            "'REC_NAME' as rec_name, 'IBK_BIC' as ibk_bic, 'IBK_ID' as ibk_id, 'IBK' as ibk, 'IBK_ADDR1' as ibk_addr1, 'IBK_ADDR2' as ibk_addr2," +
                            "'IBK_ADDR3' as ibk_addr3, 'BBK_BIC' as bbk_bic, 'BBK_ID' as bbk_id, 'BBK' as bbk," +
                            "'BBK_ADDR1' as bbk_addr1, 'BBK_ADDR2' as bbk_addr2, 'BBK_ADDR3' as bbk_addr3, " +
                            "'BNF_BIC' as bnf_bic, 'BNF_ID' as bnf_id, 'BNF' as bnf, 'BNF_ADDR1' as bnf_addr1, 'BNF_ADDR2' as bnf_addr2, 'BNF_ADDR3' as bnf_addr3," +
                            "P_DBT_ACCT_NB,P_DBT_ACCT_NB,P_DBT_FEE_ACCT_NB,P_DBT_APPLY_FEE,P_DBT_FEE_PMT_CCY,P_DBT_RATE,P_CDT_ACCT_NB,P_CDT_ACCT_NB," +
                            "P_CDT_FEE_ACCT_NB,P_CDT_APPLY_FEE,P_CDT_FEE_PMT_CCY,'AGENT_FEES' as agent_fees, 'AGENT_FEES_CURRENCY' as agent_fees_currency," +
                            "P_DBT_RATE,P_MID" +
                  " from {0}minf where p_mid = '{1}'", prfx, mid);
            }
            else
            {
                cmd = string.Format("select " +
                    "a.MSG_STATUS, a.PRIORITY, a.DEPARTMENT, a.OFFICE," +
                    "a.ORIG_MT, a.MOP, a.ORIG_REFERENCE, a.LOCAL_REF, a.CHEQUE_INT, a.ORIGVALUEDATE," +
                    "a.ORIG_CURRENCY, a.ORIG_AMOUNT, a.ORIG_INSTRUCT_CURRENCY, a.ORIG_INSTRUCT_AMOUNT, a.OCMT_CURRENCY," +
                    "a.OCMT_AMOUNT, a.ORIG_SENDER, a.BASE_AMOUNT, a.DEAL_BOOKED, a.DBCURRENCY," +
                    "a.DBAMOUNT, a.DRVALUEDATE, a.DBCURRENCY, a.DBAMOUNT, a.CRCURRENCY," +
                    "a.CRAMOUNT, a.VALUE_DATE, b.RFB, b.ORG_BIC, b.ORG_ID, b.ORG, b.ORG_ADDR1, b.ORG_ADDR2," +
                    "b.ORG_ADDR3, b.OGB_BIC, b.OGB_ID, b.OGB, b.OGB_ADDR1, b.OGB_ADDR2, b.OGB_ADDR3, b.COR_BIC, b.COR_ID," +
                    "b.COR, b.COR_ADDR1, b.COR_ADDR2, b.COR_ADDR3, b.RCR_BIC, b.RCR_ID, b.RCR, b.RCR_ADDR1, b.RCR_ADDR2, b.RCR_ADDR3," +
                    "b.RCB_BIC, b.RCB_ID, b.RCB, b.RCB_ADDR1, b.RCB_ADDR2, b.RCB_ADDR3, b.SEND_ABA , b.SEND_NAME, b.REC_ABA  ," +
                    "b.REC_NAME, b.IBK_BIC, b.IBK_ID, b.IBK, b.IBK_ADDR1, b.IBK_ADDR2, b.IBK_ADDR3, b.BBK_BIC, b.BBK_ID, b.BBK," +
                    "b.BBK_ADDR1, b.BBK_ADDR2, b.BBK_ADDR3, b.BNF_BIC, b.BNF_ID, b.BNF, b.BNF_ADDR1, b.BNF_ADDR2, b.BNF_ADDR3, b.ACC_NO," +
                    "b.MP_DB_ACC, b.DB_FEE_ACC, b.DB_FEES , b.DB_FEES_CURRENCY, b.DR_RATE, b.CR_ACC_NO, b.MP_CR_ACC, b.CR_FEE_ACC, b.CR_FEES ," +
                    "b.CR_FEES_CURRENCY, b.AGENT_FEES , b.AGENT_FEES_CURRENCY, b.CR_RATE, a.MID " +
                    "from {0}mif a, {0}mtf1000 b where  a.mid = '{1}' and a.mid=b.mid", prfx, mid);
            }
            return cmd;
        }
        public string[] LoadRecord(string frm, string mid)
        {
            int NoElem = 95;
            string[] sRecord = new string[NoElem];
            string Cmd;
            string prfx;
            string dbname = (String)HttpContext.Current.Session["CurrentDB"];
            if (frm == "1") // Src TRn is being requested
            {
                prfx = m_dbprefix.TrimEnd();
                if (m_SrcConnName.ToLower() != "localdb") // ORA
                {
                    m_localDB = false;
                    string f_name = string.Format("c:\\Simulator\\{0}\\feed\\connstring.xml", dbname);
                    DataSet srctable = new DataSet();
                    srctable.ReadXml(f_name);
                    foreach (DataTable table in srctable.Tables)
                    {
                        foreach (DataRow row in table.Rows)
                        {
                            if (row["uniquename"].ToString() == m_SrcConnName)
                                m_connString = row["connection_string"].ToString().TrimEnd();
                        }
                    }
                }
            }
            else  // Target
            {
                prfx = "";
                if (m_TrgConnName.ToLower() != "localdb") // ORA
                {
                    m_localDB = false;
                    string f_name = string.Format("c:\\Simulator\\{0}\\feed\\connstring.xml", dbname);
                    DataSet srctable = new DataSet();
                    srctable.ReadXml(f_name);
                    foreach (DataTable table in srctable.Tables)
                    {
                        foreach (DataRow row in table.Rows)
                        {
                            if (row["uniquename"].ToString() == m_SrcConnName)
                                m_connString = row["connection_string"].ToString().TrimEnd();
                        }
                    }
                }
            }
            if (m_localDB)
            {
                DBAccess Connection = new DBAccess();
                Connection.Connect(false, dbname);
                Cmd = MakeCmd(mid,prfx);
                try
                {
                    if (Connection.OpenDataReader(Cmd))
                    {
                        if (Connection.SQLDR.Read())
                        {
                            for (int i = 0; i < NoElem; i++)
                            {
                                sRecord[i] = (Connection.SQLDR[i].ToString().Trim());
                            }
                        }
                        else
                        {
                            sRecord[0] = "fail";
                            sRecord[1] = (string.Format("Mid {0} not found.", mid));
                            return sRecord;
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    Connection.CloseDataReader();
                    Connection.DisConnect();
                }
            }
            else
            {
                m_OraConnection = new OracleConnection();
                m_OraConnection.ConnectionString = m_connString;
                m_OraConnection.Open();
                char[] dtype;
                if (m_vendor.ToLower().StartsWith("fts"))
                {
                    dtype = new char[] {'s','n','s','s', 
				    's','s','s','s','s','d', 
				    's','n','s','n','s', 
				    'n','s','n','s','s',
				    'n','d','s','n','s',
				    'n','d','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','n','s','s','s','s',
				    's','s','s','n','s'};
                }
                else
                {
                    dtype = new char[] {'s','s','s','s', 
				    's','s','s','s','s','d', 
				    's','n','s','n','s', 
				    'n','s','n','s','s',
				    'n','d','s','n','s',
				    'n','d','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','s','s','s','s','s','s',
				    's','s','s','s','n','s','s','s','s',
				    's','s','s','n','s'};
                }
                // s- string, n - numeric, d -datetime      
                Cmd = MakeCmd(mid, prfx);
                OracleCommand command = m_OraConnection.CreateCommand();
                command.CommandText = Cmd;
                OracleDataReader reader;
                try { reader = command.ExecuteReader(); }
                catch (Exception ex) { throw ex; }
                if (reader.Read())
                {
                    for (int i = 0; i < NoElem; i++)
                    {
                        if (dtype[i] == 'n')
                            try { sRecord[i] = reader.GetDecimal(i).ToString(); }
                            catch (Exception) { sRecord[i] = " "; }
                        else
                            if (dtype[i] == 'd')
                                try { sRecord[i] = reader.GetDateTime(i).ToString(); }
                                catch (Exception) { sRecord[i] = " "; }
                            else
                                try { sRecord[i] = reader.GetString(i).ToString(); }
                                catch (Exception) { sRecord[i] = " "; }
                    }
                }
                else
                {
                    sRecord[0] = "fail";
                    sRecord[1] = (string.Format("Mid {0} not found.", mid));
                    return sRecord;
                }

                command.Dispose();
                m_OraConnection.Close();
                m_OraConnection.Dispose();
            }
            if (m_vendor.ToLower().StartsWith("fts"))
                Cmd = "select username, status, module_id as description from " + prfx + "newjournal where mid = '" + mid + "'";
            else
                Cmd = "select username, status, description from " + prfx + "newjournal where mid = '" + mid + "'";

            if (m_localDB)
            {
                m_Connection = new DBAccess();
                SqlConnection conn = new SqlConnection(m_Connection.GetConnString(dbname));
                conn.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand(Cmd, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    History.DataSource = reader;
                    History.DataBind();
                    UpdatePanel("HistPanel");
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    m_Connection.DisConnect();
                    conn.Dispose();
                }
            }
            else
            {
                m_OraConnection = new OracleConnection();
                m_OraConnection.ConnectionString = m_connString;
                m_OraConnection.Open();
                OracleCommand command = m_OraConnection.CreateCommand();
                command.CommandText = Cmd;
                OracleDataReader reader;

                try
                {
                    reader = command.ExecuteReader();
                    History.DataSource = reader;
                    History.DataBind();
                    UpdatePanel("HistPanel");
                }
                catch (Exception ex) { throw ex; }
                command.Dispose();
                m_OraConnection.Close();
                m_OraConnection.Dispose();

            }
            return sRecord;
        }
    }
}
