/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Text;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
/*
 *   
 * 13-Oct-08    JR  Let them dump the local area, too. Add that as a function.
 * 
 */

namespace Simulator
{
    /// <summary>
    /// Summary description for Maint.
    /// </summary>
    public partial class Maint : System.Web.UI.Page
    {

        protected void Page_Load(object sender, System.EventArgs e)
        {
            // Put user code to initialize the page here
            if (!Page.IsPostBack)
            {
                LoadCheckList();
            }
            if (!ClientScript.IsClientScriptBlockRegistered("confirm"))
            {
                string jsConfirm = @"<script language='javascript'> " +
                    "function confirm_delete() " +
                    "{ return (confirm('Are you sure you want to perform this function?')); }" +
                    "</script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "confirm", jsConfirm);
            }
        }

        private void LoadCheckList()
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            ArrayList values = new ArrayList();
            values.Add("Select the procedure");
            values.Add("Create New Environment");
            values.Add("Create New Configuration XML file");
            values.Add("Load New Configuration");
            values.Add("Dump Master Configuration");
            values.Add(string.Format("Dump Local Area ({0}) Configuration", Area));
            //CheckBoxList1.Rows = values.Count;
            DropDownList1.DataSource = values;
            DropDownList1.ClearSelection();
            DropDownList1.Visible = true;

            DropDownList1.DataBind();
            Label1.Visible = false;
            Label2.Visible = false;
            TextBox1.Visible = false;
            ExecButton.Attributes.Add("onclick", "return confirm_delete();");
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion

        protected void ExecButtonClick(object sender, System.EventArgs e)
        {
            BackEndSubs util = new BackEndSubs();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            string text = string.Empty;
            int n = 0;
            Label1.Text = "You chose: ";

            for (int i = 0; i < DropDownList1.Items.Count; i++)
            {
                if (DropDownList1.Items[i].Selected)
                {
                    text = DropDownList1.Items[i].Text;

                    n++;
                    if (n == 1)
                        Label1.Text += text;
                    else
                        Label1.Text += ", " + text;

                    Label1.Visible = true;

                    try
                    {

                        if (text.Equals("Create New Environment"))
                        {
                            CreateDatabase createDB = new CreateDatabase();
                            createDB.CalledFrom = "UI";
                            int status = createDB.newDB(TextBox1.Text);
                            if (status > 0)
                            {
                                Label1.Text = "New Database created: Simulator_" + TextBox1.Text;
                                Label1.ForeColor = Color.Black;
                                Label1.BackColor = Color.Wheat;
                            }
                            else
                            {
                                Label1.Text = "Error: " + createDB.ErrMsg;
                                Label1.ForeColor = Color.Red;
                                Label1.BackColor = Color.WhiteSmoke;
                            }

                            TextBox1.Text = String.Empty;
                        }

                        if (text.Equals("Create New Configuration XML file"))
                        {
                            ExecButton.Visible = false;
                            Button1.Visible = true;
                            Button1.Text = "Continue";
                            TextBox2.Visible = true;
                            TextBox2.Wrap = true;
                            TextBox2.BackColor = Color.Beige;
                            TextBox2.Text =
                            " You have chosen to create a new configuration file for area " + TextBox1.Text + ".\n" +
                            " To complete this operation you need the following data files from MTS: \n" +
                            " 1. " + TextBox1.Text + "_rmt.all \n" +
                            " 2. " + TextBox1.Text + "_cfg_tab.dat\n" +
                            " 3. " + TextBox1.Text + "_bank_list.txt\n" +
                            " 4. " + TextBox1.Text + "_mts.cfg\n" +
                            " All these files MUST be present in the Simulator\\" + TextBox1.Text + "\\ folder. \n" +
                            " See the User Manual about the information how to create those files";
                            

                            //Response.Write("<script>window.open(\"CfgMaint.aspx\")</script>");
                        }

                        if (text.Equals("Load New Configuration"))
                        {
                            LoadConfig lCfg = new LoadConfig(TextBox1.Text);
                            string[] args = new string[2];
                            args[0] = TextBox1.Text;
                            args[1] = "INIT";
                            lCfg.load(args);
                            lCfg.close();
                            //BackEndSubs util = new BackEndSubs();
                            util.logInfo(Area, "LoadConfig (UI)", "New configuration loaded");
                            TextBox1.Text = String.Empty;
                        }

                        if (text.Equals("Dump Master Configuration"))
                        {
                            dumpMaster(Area);
                        } 

                        if (text.StartsWith("Dump Local Area"))
                        {
                            BaselineConfig bCfg = new BaselineConfig();
                            bCfg.dumpConfiguration(Area);
                        }
                    }

                    catch (Exception) { util.logError(Area, "UI", " exception on command: " + text); }
                    finally
                    {
                        //dbWriter.DisConnect();
                    }
                }
            }
            DropDownList1.ClearSelection();
        }

        private void dumpMaster(string Area)
        {
            // The namespace and tablespace values below *MUST* match
            // the actual table names in the database. You'll be sorry
            // if you don't do this ;-)

            DataSet BigEnchalada = new DataSet("Configuration");

            DBAccess dbRdr = new DBAccess();
            dbRdr.Connect(true, Area);
            DBAccess MasterdbRdr = new DBAccess();

            try
            {
                MasterdbRdr.Connect(false, "Master");
                DataSet ds = MasterdbRdr.getDataSet("Select * from MasterControl");
                DataTable MasterControl = ds.Tables[0].Copy();
                MasterControl.Namespace = "MasterControl";
                MasterControl.TableName = "MasterControl";
                BigEnchalada.Tables.Add(MasterControl);
                ds.Dispose();
            }
            catch { };

            try
            {
                MasterdbRdr.Connect(false, "Master");
                DataSet ds = MasterdbRdr.getDataSet("Select * from ApplicationBanks");
                DataTable ApplicationBanks = ds.Tables[0].Copy();
                ApplicationBanks.Namespace = "ApplicationBanks";
                ApplicationBanks.TableName = "ApplicationBanks";
                BigEnchalada.Tables.Add(ApplicationBanks);
                ds.Dispose();
            }
            catch { };

            try
            {
                MasterdbRdr.Connect(false, "Master");
                DataSet ds = MasterdbRdr.getDataSet("Select * from SplitterFileTypes");
                DataTable SplitterFileTypes = ds.Tables[0].Copy();
                SplitterFileTypes.Namespace = "SplitterFileTypes";
                SplitterFileTypes.TableName = "SplitterFileTypes";
                BigEnchalada.Tables.Add(SplitterFileTypes);
                ds.Dispose();
            }
            catch { };

            //
            // Write the new config file.
            //
            BackEndSubs util = new BackEndSubs();
            string cfgName = string.Format("c:\\Simulator\\Master_Config_{0}.xml",
                util.GetTimestampTag());
            BigEnchalada.WriteXml(cfgName);
            BigEnchalada.Dispose();
            dbRdr.Dispose();
        }
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label2.Visible = true;
            TextBox1.Visible = true;
            StringBuilder Jscript = new StringBuilder();
            Jscript.Append("<script language='Javascript'> function setfocus(){");
            Jscript.Append("document.getElementById(\"" +
            TextBox1.ClientID + "\").focus();");
            Jscript.Append("} window.onload = setfocus;</script>");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "setfocus", Jscript.ToString());

        }
        protected void ButtonClick(object sender, EventArgs e)
        {
            if (Button1.Text == "Try Again")
            {
                Button1.Visible = false;
                ExecButton.Visible = true;
                TextBox2.Text = string.Empty;
                TextBox2.ForeColor = Color.Black;
                TextBox2.Visible = false;
                Label1.Text = "";
                return;
            }
            if (Button1.Text == "Confirm")
            {
                string[] WordArray;
                WordArray = TextBox2.Text.Split('/');
                string AppName = WordArray[1];
                string FedAba = WordArray[3];
                string ChpAba = WordArray[5];
                string Host = WordArray[7];
                string FileName = "c:/Simulator/Gen_Info.txt";
                StreamWriter sWrt;
			    FileStream file1 = new FileStream(FileName, FileMode.Create, FileAccess.Write);            
			    sWrt = new StreamWriter(file1);
                sWrt.Write("ApplicationName/" + AppName + "/\n");
			    sWrt.Write("FedABA/" + FedAba + "/\n");
			    sWrt.Write("ChipsABA/" + ChpAba + "/\n");
			    sWrt.Write("HostName/" + Host + "/");
                sWrt.Flush();
                sWrt.Close();
            }
            else
            {
                int ErrNo = 0;
                TextBox2.Text = string.Empty;
                // Check to see if all necessary files are present.
                string m_dirname = "c:/Simulator/" + TextBox1.Text + "/";
                string FileList = "bank_list.txt/cfg_tab.dat/mts.cfg/rmt.all";
                FileStream file;
                string[] WordArray;
                WordArray = FileList.Split('/');
                foreach (string fn in WordArray)
                {
                    string FileName = m_dirname + TextBox1.Text + "_" + fn;
                    try
                    {
                        file = new FileStream(FileName, FileMode.Open, FileAccess.Read);
                    }
                    catch
                    {
                        ErrNo++;
                        TextBox2.Text += TextBox1.Text + "_" + fn + " does not exist\n";
                    }
                }
                if (ErrNo > 0)
                {
                    TextBox2.ForeColor = Color.Red;
                    TextBox2.Text += "Copy the missing files and try again.";
                    Button1.Text = "Try Again";
                    return;
                }
                string FileName1 = "c:/Simulator/Gen_Info.txt";
                try
                {
                    file = new FileStream(FileName1, FileMode.Open, FileAccess.Read);
                }
                catch
                {
                    TextBox2.ForeColor = Color.Blue;
                    TextBox2.BackColor = Color.Beige;
                    TextBox2.ReadOnly = false;
                    TextBox2.Text = "Your General Information is missing. You need to answer a few questions.\n" +
                        "Please, type your answers between the slashes\n" +
                        "   \n" +
                        "The name of the application is - /QA Simulator/ \n" +
                        "Your FedAba number - /000000000/ \n" +
                        "Your Chips Aba number - /0000/ \n" +
                        "The HostName of the MTS development Box - /xxxxxxx/  \n";
                    Button1.Text = "Confirm";
                    Button1.ForeColor = Color.Red;
                    return;
                }
            }
 
            CreateXmlFile MakeCfg = new CreateXmlFile();
            MakeCfg.CreateXml(TextBox1.Text, "ALL", "");
            TextBox2.Text = string.Empty;
            TextBox2.ForeColor = Color.Black;
            TextBox2.Visible = false;
            Button1.Visible = false;
            ExecButton.Visible = true;

        }
    }
}
