/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
using System.Xml;
using System.Xml.XPath;
/*
 Area Config File maintenance.
 *                  
 * 
 */

namespace Simulator
{
    /// <summary>
    /// Summary description for Maint.
    /// </summary>
    public partial class Maint : System.Web.UI.Page
    {

        protected void Page_Load(object sender, System.EventArgs e)
        {
            // Put user code to initialize the page here
            if (!Page.IsPostBack)
            {
                XPathDocument doc = new XPathDocument(this.MapPath("Q330602.xml"));
                XmlDocument dom = new XmlDocument();
                dom.Load("c:/inetpub/wwwroot/simulator/Q330602.xml");
                TextBox1.Text = dom.ToString();
                //dom.Save("c:/inetpub/wwwroot/simulator/pretty.xml");                
                /*
                XslCompiledTransform transform = new XslCompiledTransform();
                XsltSettings settings = new XsltSettings(false,true);
                settings.EnableScript = true;
                transform.Load(this.MapPath("DotNet.xslt"), settings, null);
                // Transform XML data.
                transform.Transform(doc, null, Response.OutputStream);*/
            }
        }

         #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion
  
        private void dumpMaster(string Area)
        {
            // The namespace and tablespace values below *MUST* match
            // the actual table names in the database. You'll be sorry
            // if you don't do this ;-)

            DataSet BigEnchalada = new DataSet("Configuration");

            DBAccess dbRdr = new DBAccess();
            dbRdr.Connect(true, Area);
            DBAccess MasterdbRdr = new DBAccess();

            try
            {
                MasterdbRdr.Connect(false, "Master");
                DataSet ds = MasterdbRdr.getDataSet("Select * from MasterControl");
                DataTable MasterControl = ds.Tables[0].Copy();
                MasterControl.Namespace = "MasterControl";
                MasterControl.TableName = "MasterControl";
                BigEnchalada.Tables.Add(MasterControl);
                ds.Dispose();
            }
            catch { };

            try
            {
                MasterdbRdr.Connect(false, "Master");
                DataSet ds = MasterdbRdr.getDataSet("Select * from ApplicationBanks");
                DataTable ApplicationBanks = ds.Tables[0].Copy();
                ApplicationBanks.Namespace = "ApplicationBanks";
                ApplicationBanks.TableName = "ApplicationBanks";
                BigEnchalada.Tables.Add(ApplicationBanks);
                ds.Dispose();
            }
            catch { };

            try
            {
                MasterdbRdr.Connect(false, "Master");
                DataSet ds = MasterdbRdr.getDataSet("Select * from SplitterFileTypes");
                DataTable SplitterFileTypes = ds.Tables[0].Copy();
                SplitterFileTypes.Namespace = "SplitterFileTypes";
                SplitterFileTypes.TableName = "SplitterFileTypes";
                BigEnchalada.Tables.Add(SplitterFileTypes);
                ds.Dispose();
            }
            catch { };

            //
            // Write the new config file.
            //
            BackEndSubs util = new BackEndSubs();
            string cfgName = string.Format("c:\\Simulator\\Master_Config_{0}.xml",
                util.GetTimestampTag());
            BigEnchalada.WriteXml(cfgName);
            BigEnchalada.Dispose();
            dbRdr.Dispose();
        }
        protected void ExecButtonClick(object sender, EventArgs e)
        {

        }
}
}
