/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using Obout.Grid;
using OboutInc.Calendar2;
using Obout.Interface;
using Simulator.DBLibrary;

using Simulator.BackEndSubLib;

namespace Simulator
{

    public partial class Load : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindDataGridFirstTime();
                HttpContext.Current.Session["EditsAllowed"] = "Y";
            }
            LoaderGrid.Visible = true;
        }


        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = LoaderGrid.Templates[templateIndex].Container.FindControl(controlId);

            return ctrl.ClientID;
        }


        protected void OnGridRowCreated(object sender, GridRowEventArgs args)
        {
            //int z = 666;
            //LoaderGrid.Columns[1].ReadOnly = false;
            // gets called before a row created. It stop each time the row is populated from DB not used
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }

        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {
            //int zzz = 666;
            //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
        }

        protected void BindDataGridFirstTime()
        {
            DataSet ds = new DataSet();
            LoaderGrid.DataSource = ds;
            try
            {
                //LoaderGrid.DataBind();
            }
            catch
            {
            }
            LoaderGrid.ClearPreviousDataSource();
            string skin = LoaderGrid.SkinID;
            BindDataGrid();
        }
        protected void BindDataGrid()
        {

            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            Connection.Connect(false, dbname);
            try
            {
                LoaderGrid.Dispose();
                /*
                 * We can't compress the spaces out of the file name or the path
                 * now that TestAWire is putting stuff into this table.
                 */
                Connection.Connect(false, dbname);
                String Cmd = "select FilePath,FileName,LastTrn,TimelyDlv,nLoad, " +
                    " FileValueDate=convert(varchar(20),FileValueDate,1), " +
                    " NewValueDate=convert(varchar(20),NewValueDate,1)," +
                    " AssignTime, " +
                    " LoadTime, " +
                    " ProcessState, NumberLoaded,UniqueKey,nLoadAlgorithm,AmtDelta ," +
                    //" replace(FilePath,'*','*')+replace(FileName,'*','*') as FullPath from LoaderControl";

                " FileName as FullPath from LoaderControl";
                DataSet ds = Connection.getDataSet(Cmd);
                LoaderGrid.DataSource = ds;

                OboutDropDownList ctrl = (OboutDropDownList)LoaderGrid.Templates[0].Container.FindControl("EdtTmplPath");
                PopulatePathControl(ctrl);
                LoaderGrid.DataBind();
                Connection.DisConnect();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                Connection.DisConnect();
            }
        }

        public void DataGrid_Select(Object sender, GridRecordEventArgs e)
        {
            //int j = 666;
        }
        public void DataGrid_Edit(Object sender, GridRecordEventArgs e)
        {
            DateTime? FileTime, NewTime;
            string UniqueKey = e.Record["UniqueKey"].ToString();

            string ProcessState = e.Record["ProcessState"].ToString();
            string FullPath = e.Record["FullPath"].ToString();
            string FileValueDate = e.Record["FileValueDate"].ToString();
            try { FileTime = DateTime.Parse(FileValueDate); }
            catch { FileValueDate = "NULLTIME"; }
            string NewValueDate = e.Record["NewValueDate"].ToString();
            try { NewTime = DateTime.Parse(NewValueDate); }
            catch { NewValueDate = "NULLTIME"; }
            string nLoadAlgorithm = e.Record["nLoadAlgorithm"].ToString();
            string AmtDelta = e.Record["AmtDelta"].ToString();
            string NoTimes = e.Record["nLoad"].ToString();

            string Cmd = string.Format("update LoaderControl set ProcessState='{0}', " +
                    "FileValueDate='{1}',NewValueDate='{2}', " +
                    "nLoadAlgorithm='{3}',AmtDelta='{4}',NLoad='{6}' " +
                    " where UniqueKey='{5}'",
                    ProcessState, FileValueDate, NewValueDate, nLoadAlgorithm, AmtDelta, UniqueKey, NoTimes);
            Cmd = Cmd.Replace("'NULLTIME'", "NULL");
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);
            connection.Execute(Cmd, true);

            BindDataGrid();
        }

        public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
        {
            //        LoaderGrid.EditItemIndex = -1;
            BindDataGrid();
        }

        public void DataGrid_Insert(object source, GridRecordEventArgs e)
        {
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);

            BackEndSubs util = new BackEndSubs();
            String FilePath = util.GetSplitDir(connection);

            string UniqueKey;

            UniqueKey = e.Record["UniqueKey"].ToString();
            DateTime? FileTime, NewTime;

            string ProcessState = e.Record["ProcessState"].ToString();
            string FileName = e.Record["FullPath"].ToString();
            string FileValueDate = e.Record["FileValueDate"].ToString();
            try { FileTime = DateTime.Parse(FileValueDate); }
            catch { FileValueDate = "NULLTIME"; }
            string NewValueDate = e.Record["NewValueDate"].ToString();
            try { NewTime = DateTime.Parse(NewValueDate); }
            catch { NewValueDate = "NULLTIME"; }
            string nLoadAlgorithm = e.Record["nLoadAlgorithm"].ToString();
            string AmtDelta = e.Record["AmtDelta"].ToString();
            string NoLoad = e.Record["nLoad"].ToString();

            string Cmd = string.Format("insert into LoaderControl " +
            "(ProcessState, FileName, FilePath, FileValuedate, NewValueDate, " +
            " AmtDelta, nLoadAlgorithm, NumberLoaded,LastTrn,TimelyDlv,nLoad,AssignTime) " +
            " values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','0','0000000000000000','N','{7}','{8}') ",
             ProcessState,
             FileName,
             FilePath,
             FileValueDate,
             NewValueDate,
             AmtDelta,
             nLoadAlgorithm,
             NoLoad, DateTime.Now);
            Cmd = Cmd.Replace("'NULLTIME'", "NULL");


            connection.Execute(Cmd, true);

            BindDataGrid();
        }

        public void DataGrid_Delete(object source, GridRecordEventArgs e)
        {
            string UniqueKey = "";
            try
            {
                UniqueKey = (e.Record["UniqueKey"].ToString());
            }
            catch
            {
            }
            String Cmd = "delete from loadercontrol where uniquekey=" + UniqueKey;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                Connection.Execute(Cmd, true);
                //                LoaderGrid.EditItemIndex = -1;
                BindDataGrid();
            }
            catch (Exception)
            {
            }
            finally
            {
                Connection.DisConnect();
                Connection.Dispose();
            }
        }

        private void InitializeComponent()
        {
            //this.LoaderGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.ItemCommands);
            //this.LoaderGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Cancel);
            //this.LoaderGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Edit);
            //this.LoaderGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Update);
            //this.LoaderGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Delete);
            //this.LoaderGrid.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.ItemBound);

        }
        private void PopulatePathControl(OboutDropDownList dList)
        {
            Hashtable list = new Hashtable();
            DBAccess Connection = new DBAccess();
            try
            {
                Connection.Connect(false, (String)HttpContext.Current.Session["CurrentDB"]);
                BackEndSubs util = new BackEndSubs();
                IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
                if (procMgr != null)
                {
                    //	String targetDir="c:\\simulator\\"+(String)HttpContext.Current.Session["CurrentDB"]+"\\splitfiles\\";
                    String targetDir = util.GetSplitDir(Connection);
                    DataSet ds = (DataSet)procMgr.getDirectoryList(targetDir);		// change this to appropriate directory
                    foreach (DataTable dt in ds.Tables)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            string fullFileName = row["FileName"].ToString();
                            int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
                            if (LastDelimeter == 0)
                            {
                                LastDelimeter = fullFileName.LastIndexOf(@"/") + 1;
                            }
                            string FileName = fullFileName.Substring(LastDelimeter);
                            list.Add(FileName, fullFileName);
                            dList.Items.Add(FileName);
                        }
                    }
                    dList.DataSource = list;
                    //dList.Items.Add(list);
                }
            }
            finally
            {
                Connection.DisConnect();
            }
        }
    }
}