/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
//using BasicFrame.WebControls;

namespace Simulator
{
    /// <summary>
    /// Summary description for SwfStat.
    /// </summary>
    public partial class SwfStat : System.Web.UI.Page
    {
        DateTime from_time = DateTime.MinValue, to_time = DateTime.MaxValue;
        int SentSum = 0;
        int RcvSum = 0;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            DBAccess m_Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            if (Calendar1.SelectedDate.Year > 2000)
                from_time = Calendar1.SelectedDate;
            else
                from_time = Convert.ToDateTime("10-Jan-1900");
            if (!Page.IsPostBack && dbname != null)
                BindData();
            if (Calendar2.SelectedDate.Year > 2000)
            {
                to_time = Calendar1.SelectedDate;
                to_time = to_time.AddDays(1);
            }
            else
            {
                to_time = Convert.ToDateTime("10-Jan-2100");
            }
            if (!Page.IsPostBack && dbname != null)
                BindData();
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion
        protected void Refresh_Click(object sender, System.EventArgs e)
        {
            BindData();
        }

        public void ComputeSum(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                e.Item.Cells[2].Text = "Total: ";
                e.Item.Cells[3].Text = String.Format("{0:#,###}", SentSum);
                e.Item.Cells[4].Text = String.Format("{0:#,###}", RcvSum);
            }
        }

        private void BindData()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                string Cmd;
                Cmd = string.Format("select SessionNo,StartTime,EndTime,NoSent,NoReceived from " +
                    "SwfStats where StartTime !< '{0}' and StartTime !> '{1}' and SessionNo LIKE '{2}%' " +
                    "order by StartTime desc", from_time, to_time, TidTextBox.Text);
                DataSet ds = Connection.getDataSet(Cmd);
                DataGrid1.DataSource = ds;

                Cmd = string.Format("select SUM(NoSent) from " +
                "SwfStats where StartTime !< '{0}' and StartTime !> '{1}' and SessionNo LIKE '{2}%'", from_time, to_time, TidTextBox.Text);
                if (Connection.OpenDataReader(Cmd))
                {
                    try
                    {
                        Connection.SQLDR.Read();
                        SentSum = Connection.SQLDR.GetInt32(0);
                    }
                    catch
                    {
                        SentSum = 0;
                    }
                    finally
                    {
                        Connection.CloseDataReader();
                    }
                }
                Cmd = string.Format("select SUM(NoReceived) from " +
                "SwfStats where StartTime !< '{0}' and StartTime !> '{1}' and SessionNo LIKE '{2}%'", from_time, to_time, TidTextBox.Text);
                if (Connection.OpenDataReader(Cmd))
                {
                    try
                    {
                        Connection.SQLDR.Read();
                        RcvSum = Connection.SQLDR.GetInt32(0);
                    }
                    catch
                    {
                        RcvSum = 0;
                    }
                    finally
                    {
                        Connection.CloseDataReader();
                    }
                }

                DataGrid1.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Connection.DisConnect();
            }

            SentSum = 0;
            RcvSum = 0;
        }
        protected void MyPageChanged(object source, DataGridPageChangedEventArgs e)
        {
            DataGrid1.CurrentPageIndex = e.NewPageIndex;
            BindData();
        }
    }
}
