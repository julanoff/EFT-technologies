/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
using OboutInc.Calendar2;
using System.IO;
using System.Text;

/* 

This program is used to update rprfeeder table.
Table:  uniquekey	int
	newtrnnumber	char 16
	oldtrnnumber	char 16
	source		char 3
	value date	date

*/
namespace Simulator
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
    
	public partial class WebForm1 : System.Web.UI.Page
	{

		protected System.Web.UI.HtmlControls.HtmlInputHidden Hidden1;

		protected void Page_Load(object sender, System.EventArgs e)
		{
            TextBox1.Visible = false;
            Button1.Enabled = true;
            TextBox1.Text = "Table has been loaded successfully!";
            if (!Page.IsPostBack) 
    			PopulatePathControl(DropDownList1);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

         private void PopulatePathControl(DropDownList dList)
        {
            DBAccess Connection = new DBAccess();
            try
            {
                Connection.Connect(false, (String)HttpContext.Current.Session["CurrentDB"]);
                BackEndSubs util = new BackEndSubs();
                IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
                if (procMgr != null)
                {
                    //	String targetDir="c:\\simulator\\"+(String)HttpContext.Current.Session["CurrentDB"]+"\\RepairFiles\\";
                    String targetDir = util.GetRepairFilesDir(Connection);
                    DataSet ds = (DataSet)procMgr.getDirectoryList(targetDir);		// change this to appropriate directory
                    foreach (DataTable dt in ds.Tables)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            string fullFileName = row["FileName"].ToString();
                            int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
                            if (LastDelimeter == 0)
                                LastDelimeter = fullFileName.LastIndexOf(@"/") + 1;

                            string FileName = fullFileName.Substring(LastDelimeter);
                            ListItem item = new ListItem(FileName, fullFileName);
                            dList.Items.Add(item);
                        }
                    }
                }
            }
            finally
            {
                Connection.DisConnect();
            }
        }

		private void BindDataGrid()
		{
			DBAccess Connection= new DBAccess();
			String dbname=(String)HttpContext.Current.Session["CurrentDB"];
			Connection.DisConnect();
		}

        protected void Update_click(object sender, EventArgs e)
        {
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
            }
            catch (Exception) { }

            string sel_date;

            string filename = (string) DropDownList1.SelectedItem.Value.TrimEnd();
            FileStream file1 = new FileStream(filename, FileMode.Open, FileAccess.Read);
            StreamReader sw = new StreamReader(file1);// Create a new stream to read from a file
            string line;
            try
            {
            	string Cmd = "truncate table RprFeeder";
            	Connection.Execute(Cmd, true);
                while ((line = sw.ReadLine()) != null)
                {
                    string[] RecArray;
                    RecArray = line.Split(' ');
                    sel_date = cal1.SelectedDate.ToString("M/d/yyyy");
                    Cmd = string.Format("insert into RPRFeeder values ('{0}','{1}','{2}',{3})", RecArray[0], RecArray[2], RecArray[1], sel_date);
                    Connection.Execute(Cmd, true);
                }
                TextBox1.Visible = true;
                Button1.Enabled = false;
            }
            catch (Exception ex)
            {
                TextBox1.Text = "Load fail. Error - " + ex.Message;
                TextBox1.Visible = true;
                Button1.Enabled = false;            
            }
            Connection.DisConnect();
            sw.Close();							// Close StreamReader			
            file1.Close();						// Close file
        }
}
}
