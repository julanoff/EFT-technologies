using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Text;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Web.Caching;
using System.Data.SqlClient;
/// <summary>
/// Summary description for GridDataLayer
/// </summary>
/// 
namespace RGWDataLayer
{
    public class GridDataLayer
{
//    int lastValue = 0;
//    string lastDate = "";
    public GridDataLayer()
    {
    }
    public static ICollection<GridSummaryData> GetTrns(string sortExpression, int maxRows, int startRowIndex, int maximumRows)
    {
        List<GridSummaryData> returnList = new List<GridSummaryData>();
        string dsn;
        //          string targetDB = (string)Session["_db"];
        //        if (targetDB.Equals("Simulator"))
        dsn = ConfigurationManager.ConnectionStrings["Simulator_dev1ConnectionString"].ConnectionString;
        //      else
        //      dsn = ConfigurationManager.ConnectionStrings["OracleConnectionString"].ConnectionString;

        // This assumes SQL Server 2005 with its new ROW_NUMBER function
        // to assist with pagination
        //
        string sqlCommand = string.Format("select top {0} CONVERT ( char(8),trn_date,112)+'-'+convert(char,trn_number) as 'Trn',trn_number,trn_date,bank,currency_code,Amount,Source_cd,Instr_adv_type,in_type_cd+in_subtype as 'MsgType' from  message_t ", maximumRows);

        //           if (startRowIndex >= 0)
        //              sqlCommand += " where trn_date 
        sqlCommand += " order by trn_date,trn_number,bank";
        using (SqlConnection conn = new SqlConnection(dsn))
        using (SqlCommand cmd = new SqlCommand(sqlCommand, conn))
        {
            conn.Open();
            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                returnList.Add(new GridSummaryData(r.GetString(0), r.GetInt32(1), r.GetDateTime(2),
                        r.GetString(3), r.GetString(4), r.GetDecimal(5), r.GetString(6), r.GetString(7), r.GetString(8)));
//                lastValue = r.GetInt32(1);
//                lastDate = r.GetString(2);
            }
            //                Cache["lastTrnSearched"]=string.Format("trn_date={0},trn_number={1}",r.GetString(2),r.GetString(1));
        }

        return returnList;
    }

    public static ICollection<GridSummaryData> GetTrnList(string dsnString, ref string SessionVar, string sortExpression, int maxRows, int startRowIndex, int maximumRows)
    {
/*
 * 
*/
        List<GridSummaryData> returnList = new List<GridSummaryData>();
        string dsn;
        string sqlCommand;
        if (dsnString.Equals("Simulator"))
        {
            dsn = ConfigurationManager.ConnectionStrings["Simulator_dev1ConnectionString"].ConnectionString;
            sqlCommand = string.Format("SELECT TOP {0} trn_number,trn_date,bank,currency_code,Amount,Source_cd,Instr_adv_type,in_type_cd,in_subtype " +
            "FROM  (SELECT TOP {1} trn_number,trn_date,bank,currency_code,Amount,Source_cd,Instr_adv_type,in_type_cd,in_subtype " +
                "from  message_t AS T1 ORDER BY TRN_DATE DESC,TRN_NUMBER DESC,BANK DESC) " +
                    "AS T2 ORDER BY TRN_DATE ASC,TRN_NUMBER ASC,BANK ASC", maximumRows, maximumRows+startRowIndex);
        }
        else
        {
            int endRowIndex=maximumRows+startRowIndex;
//            SELECT product, descr, email
//FROM (select product, descr, email from products order by product )
//WHERE ROWNUM <= 10 
             dsn = ConfigurationManager.ConnectionStrings["OracleConnectionString"].ConnectionString;
             sqlCommand = string.Format("SELECT trn_number,trn_date,bank,currency_code,Amount,Source_cd,Instr_adv_type,in_type_cd,in_subtype " +
             "FROM  (select rownum RN,trn_number,trn_date,bank,currency_code,Amount,Source_cd,Instr_adv_type,in_type_cd,in_subtype " +
                 "from  message_t where rownum < {0}) where RN between {1} and {2} ", startRowIndex,startRowIndex,endRowIndex);
         }     
        // This assumes SQL Server 2005 with its new ROW_NUMBER function
        // to assist with pagination
        //
//         string sqlCommand = string.Format("select top {0} CONVERT ( char(8),trn_date,112)+'-'+convert(char,trn_number) as 'Trn',trn_number,trn_date,bank,currency_code,Amount,Source_cd,Instr_adv_type,in_type_cd+in_subtype as 'MsgType' from  message_t ", maximumRows);

        //           if (startRowIndex >= 0)
        //              sqlCommand += " where trn_date 
        sqlCommand += " order by trn_date,trn_number,bank";
        using (SqlConnection conn = new SqlConnection(dsn))
        using (SqlCommand cmd = new SqlCommand(sqlCommand, conn))
        {
            conn.Open();
            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                returnList.Add(new GridSummaryData(r.GetString(0), r.GetInt32(1), r.GetDateTime(2),
                        r.GetString(3), r.GetString(4), r.GetDecimal(5), r.GetString(6), r.GetString(7), r.GetString(8)));
                SessionVar = r.GetDateTime(2).ToShortDateString(); 
//                lastValue = r.GetInt32(1);
  //              lastDate = r.GetString(2);
            }
            //                Cache["lastTrnSearched"]=string.Format("trn_date={0},trn_number={1}",r.GetString(2),r.GetString(1));
        }

        return returnList;
    }
    
    
    public static int GetMessageCount(string dsnString, string SessionVar,string sortExpression, int maxRows, int startRowIndex,int maximumRows)
        {
            int ret = -1;
            string dsn = ConfigurationManager.ConnectionStrings["Simulator_dev1ConnectionString"].ConnectionString;
            string sqlCommand = "SELECT COUNT(*) FROM message_t";
            try
            {
                using (SqlConnection conn = new SqlConnection(dsn))
                using (SqlCommand cmd = new SqlCommand(sqlCommand, conn))
                {
                    conn.Open();
                    ret = (int)cmd.ExecuteScalar();
                }
            }
            catch { }
            return ret;
        }
    }
}