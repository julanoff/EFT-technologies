using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for SimCache
/// </summary>
public sealed class SimCache
{
    private static readonly SimCache m_simCache= new SimCache();
    private int m_Count = 0;
    private SimCache()                                  // cannot be instantiated
    {
    }
    public static SimCache Instance
    {
        get { return m_simCache; }
    }
    public int Count 
    {
        get{return m_Count;}
        set {m_Count+=value;}       
    }


}

