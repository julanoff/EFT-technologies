/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using Obout.Grid;
using OboutInc.Calendar2;
using Obout.Interface;
using Simulator.DBLibrary;

using Simulator.BackEndSubLib;

namespace Simulator
{

    public partial class CompareTabMnt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindDataGridFirstTime();
                HttpContext.Current.Session["EditsAllowed"] = "Y";
            }
            Grid1.Visible = true;
        }


        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = Grid1.Templates[templateIndex].Container.FindControl(controlId);

            return ctrl.ClientID;
        }


        protected void OnGridRowCreated(object sender, GridRowEventArgs args)
        {
            //int z = 666;
            //LoaderGrid.Columns[1].ReadOnly = false;
            // gets called before a row created. It stop each time the row is populated from DB not used
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }

        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {
            //int zzz = 666;
            //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
        }

        protected void BindDataGridFirstTime()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            Connection.Connect(false, dbname);
            // string Description;
            // string TableName;
            try
            {
                string Cmd = "select * from SimTableList where TableType = 'Compare'";

                if (Connection.OpenDataReader(Cmd))
                {
                    OboutDropDownList EdtTmplSrcTable = Grid1.Templates[0].Container.FindControl("EdtTmplSrcTable") as OboutDropDownList;
                    EdtTmplSrcTable.DataSource = Connection.SQLDR;
                    EdtTmplSrcTable.DataTextField = "Description";
                    EdtTmplSrcTable.DataValueField = "TableName";
                    EdtTmplSrcTable.DataBind();
                    Connection.CloseDataReader();
                }
                if (Connection.OpenDataReader(Cmd))
                {
                    OboutDropDownList EdtTmplTrgTable = Grid1.Templates[0].Container.FindControl("EdtTmplTrgTable") as OboutDropDownList;
                    EdtTmplTrgTable.DataSource = Connection.SQLDR;
                    EdtTmplTrgTable.DataTextField = "Description";
                    EdtTmplTrgTable.DataValueField = "TableName";
                    EdtTmplTrgTable.DataBind();
                }
                Connection.CloseDataReader();

                Cmd = "select * from LocalKeyName";

                if (Connection.OpenDataReader(Cmd))
                {
                    OboutDropDownList EdtTmplKeyTable = Grid1.Templates[0].Container.FindControl("EdtTmplKeyTable") as OboutDropDownList;
                    EdtTmplKeyTable.DataSource = Connection.SQLDR;
                    EdtTmplKeyTable.DataTextField = "TabDesc";
                    EdtTmplKeyTable.DataValueField = "TabDesc";
                    EdtTmplKeyTable.DataBind();
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }

            Grid1.ClearPreviousDataSource();
            string skin = Grid1.SkinID;
            BindDataGrid();
        }

        protected void CleanupClick(object sender, System.EventArgs e)
        {
            string Cmd = string.Format("delete from CompareControl where ProcessState = 'P'");
            DBAccess Connection = new DBAccess();
            try
            {
                String Area = (String)HttpContext.Current.Session["CurrentDB"];
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.DisConnect();
            }
            BindDataGrid();
        }

        protected void ReleaseAllClick(object sender, System.EventArgs e)
        {
            string Cmd = string.Format("update CompareControl set ProcessState = '*' " +
                "where ProcessState = 'W'");
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.DisConnect();
            }

            BindDataGrid();
        }

        protected void RefreshClick(object sender, System.EventArgs e)
        {
            BindDataGrid();
        }

        void DataGrid_Update(Object sender, DataGridCommandEventArgs e)
        {
            string UniqueKey = (string)((TextBox)(e.Item.FindControl("UniqueKeyBox"))).Text.Trim();
            string ProcessState = (string)((DropDownList)(e.Item.FindControl("ProcessStateList"))).SelectedItem.Text.Trim();
            string Table1 = (string)((DropDownList)(e.Item.FindControl("EdtTmplSrcTable"))).SelectedItem.Text.Trim();
            string Table2 = (string)((DropDownList)(e.Item.FindControl("EdtTmplTrgTable"))).SelectedItem.Text.Trim();
            string Filter = (string)((DropDownList)(e.Item.FindControl("EdtTmplKeyTable"))).SelectedItem.Text.Trim();
            string Cmd;

            Cmd = string.Format("update CompareControl set ProcessState='{0}',Table1='{1}'," +
                "Table2='{2}', Filter='{3}' where UniqueKey='{4}'",
                ProcessState, Table1, Table2, Filter, UniqueKey);
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.DisConnect();
            }

        }

        protected void BindDataGrid()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            Connection.Connect(false, dbname);
            try
            {
                Grid1.Dispose();
                Connection.Connect(false, dbname);
                String Cmd = "select UniqueKey,ProcessState,Table1,Table2,Filter from CompareControl";
                DataSet ds = Connection.getDataSet(Cmd);
                Grid1.DataSource = ds;
                Grid1.DataBind();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                Connection.DisConnect();
            }
        }

        public void DataGrid_Select(Object sender, GridRecordEventArgs e)
        {
            //int j = 666;
        }

        public void DataGrid_Update(Object sender, GridRecordEventArgs e)
        {
            string UniqueKey = e.Record["UniqueKey"].ToString();
            string ProcessState = e.Record["ProcessState"].ToString();
            string SrcTable = e.Record["Table1"].ToString();
            string TrgTable = e.Record["Table2"].ToString();
            string KeyTable = e.Record["Filter"].ToString();
            string Cmd = string.Format("update CompareControl set ProcessState='{0}',Table1='{1}'," +
            "Table2='{2}', Filter='{3}' where UniqueKey='{4}'",
            ProcessState, SrcTable, TrgTable, KeyTable, UniqueKey);
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);
            connection.Execute(Cmd, true);
            BindDataGrid();
        }

        public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
        {
            //        Grid1.EditItemIndex = -1;
            BindDataGrid();
        }

        public void DataGrid_Insert(object source, GridRecordEventArgs e)
        {
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);

            string UniqueKey;
            UniqueKey = e.Record["UniqueKey"].ToString();
            string ProcessState = e.Record["ProcessState"].ToString();
            string SrcTable = e.Record["Table1"].ToString();
            string TrgTable = e.Record["Table2"].ToString();
            string KeyTable = e.Record["Filter"].ToString();

            string Cmd = string.Format("insert into CompareControl (ProcessState,Table1,Table2,Filter) " +
                " values ('{0}','{1}','{2}','{3}')",
                ProcessState, SrcTable, TrgTable, KeyTable);
            connection.Execute(Cmd, true);
            BindDataGrid();
        }

        public void DataGrid_Delete(object source, GridRecordEventArgs e)
        {
            string UniqueKey = "";
            try
            {
                UniqueKey = (e.Record["UniqueKey"].ToString());
            }
            catch
            {
            }
            string Cmd = "delete from CompareControl where uniquekey=" + UniqueKey;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, dbname);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception)
            {
            }
            finally
            {
                Connection.DisConnect();
                Connection.Dispose();
            }
        }

        private void InitializeComponent()
        {
            //this.Grid1.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.ItemCommands);
            //this.Grid1.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Cancel);
            //this.Grid1.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Edit);
            //this.Grid1.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Update);
            //this.Grid1.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Delete);
            //this.Grid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.ItemBound);

        }
    }
}