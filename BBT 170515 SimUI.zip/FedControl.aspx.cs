/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Text.RegularExpressions;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
namespace Simulator
/*
 * 01-Sep-08    JR  Protect against throwing an exception if the FedControl table
 *                  is empty.
 */
{
    /// <summary>
    /// Summary description for Events.
    /// </summary>
    public partial class FedControl : System.Web.UI.Page
    {

        protected void Page_Load(object sender, System.EventArgs e)
        {
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            if (!Page.IsPostBack && dbname != null)
                BindData();
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion

        private void BindData()
        {
            DBAccess m_Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            m_Connection.Connect(false, dbname);
            string Cmd = "select CycleDate, OpenBal, DebitCap, FundsColl, GenOmad, ChangeCdate, CheckDups, CheckGaps from FedControl";
            try
            {
                if (m_Connection.OpenDataReader(Cmd))
                {
                    if (m_Connection.SQLDR.HasRows)
                    {
                        m_Connection.SQLDR.Read();
                        DateTime ValDate = m_Connection.SQLDR.GetDateTime(0);
                        //BasicFrame.WebControls.BasicDatePicker bdp;
                        //bdp = ((BasicFrame.WebControls.BasicDatePicker)this.Basicdatepicker1);

                        Calendar1.SelectedDate = ValDate;
                        decimal OpenBal = m_Connection.SQLDR.GetDecimal(1);
                        TextBox1.Text = string.Format("{0:c}", OpenBal);
                        decimal DebitCap = m_Connection.SQLDR.GetDecimal(2);
                        TextBox2.Text = string.Format("{0:c}", DebitCap);
                        decimal FundsColl = m_Connection.SQLDR.GetDecimal(3);
                        TextBox3.Text = string.Format("{0:c}", FundsColl);
                        string GenOmad = m_Connection.SQLDR[4].ToString().TrimEnd();
                        ListItem li = DropDownList2.Items.FindByValue(GenOmad);
                        if (li != null)
                            li.Selected = true;
                        string New_day = m_Connection.SQLDR[5].ToString().TrimEnd();
                        li = DropDownList3.Items.FindByValue(New_day);
                        if (li != null)
                            li.Selected = true;
                        string CheckDups = m_Connection.SQLDR[6].ToString().TrimEnd();
                        li = DropDownList1.Items.FindByValue(CheckDups);
                        if (li != null)
                            li.Selected = true;
                        string CheckGaps = m_Connection.SQLDR[7].ToString().TrimEnd();
                        li = DropDownList4.Items.FindByValue(CheckGaps);
                        if (li != null)
                            li.Selected = true;
                    }
                }
            }
            catch (Exception er) { throw er; }
            finally
            {
                m_Connection.DisConnect();
            }

        }

        protected void Basicdatepicker1_SelectionChanged(object sender, System.EventArgs e)
        {
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;
        }


        protected void CancelButton_click(object sender, System.EventArgs e)
        {
        }

        protected void Confirm_Click(object sender, System.EventArgs e)
        {
            DateTime sel_date = DateTime.Today;
            decimal OpenBal, DebitCap, FundsColl;
            if (Calendar1.SelectedDate.Year > 2000)
                sel_date = Calendar1.SelectedDate;
            if (TextBox1.Text.StartsWith("$"))
                OpenBal = Convert.ToDecimal(TextBox1.Text.Substring(1)); //get rid of $ in front
            else
                OpenBal = Convert.ToDecimal(TextBox1.Text);
            if (TextBox2.Text.StartsWith("$"))
                DebitCap = Convert.ToDecimal(TextBox2.Text.Substring(1)); //get rid of $ in front
            else
                DebitCap = Convert.ToDecimal(TextBox2.Text);
            if (TextBox3.Text.StartsWith("$"))
                FundsColl = Convert.ToDecimal(TextBox3.Text.Substring(1)); //get rid of $ in front
            else
                FundsColl = Convert.ToDecimal(TextBox3.Text);
            string GenOmad = this.DropDownList2.SelectedValue.ToString();
            string New_day = this.DropDownList3.SelectedValue.ToString();
            string CheckDups = this.DropDownList1.SelectedValue.ToString();
            string CheckGaps = this.DropDownList4.SelectedValue.ToString();
            string Cmd = string.Format("update FedControl set CycleDate='{0}', GenOmad='{1}'," +
                "CheckDups='{2}', CheckGaps='{3}', ChangeCDate='{4}', OpenBal={5}, DebitCap={6}, FundsColl={7}",
                sel_date, GenOmad, CheckDups, CheckGaps, New_day, OpenBal, DebitCap, FundsColl);
            DBAccess m_Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            SimLog.log.write(dbname, "Fed Control update: " + Cmd + "\n");
            m_Connection.Connect(true, dbname);
            m_Connection.Execute(Cmd, true);
            if (New_day == "Y")
            {
                SimLog.log.write(dbname, "Fed Control - new day");
                //  New is declared. We need to clean up PSNQueue, ResolverQ, Amount Tables, Set Seq #s to 1.
                Cmd = string.Format("truncate table IMAD");
                try
                {
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("update FedControl Set OpenBal=0, DebitCap=0, FundsColl=0");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("update LinkControl Set NextSeqNo=1, OutSeqNo=1 where Source='FED'");
                    m_Connection.Execute(Cmd, true);
                }
                catch (Exception ex)
                {
                    m_Connection.RecordEvent(1, "FedControl", ex.Message.TrimEnd(), dbname);
                }
                finally
                { }
            }
            m_Connection.DisConnect();
        }

        protected void GenSSN_changed(object sender, System.EventArgs e)
        {
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;
        }

        protected void NewDay_changed(object sender, System.EventArgs e)
        {
            //  Add check for chips links are up. Issue an error and disallow new day
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;

        }

        protected void Act_changed(object sender, System.EventArgs e)
        {
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;
        }
        protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }
        protected void ChkDups_changed(object sender, EventArgs e)
        {
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;
        }
        protected void ChkGaps_changed(object sender, EventArgs e)
        {
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;
        }
    }
}
