/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//using Oracle.DataAccess.Client;
//using Oracle.DataAccess.Types;

using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

using System.Data.SqlClient;
using System.Collections;
using System.Reflection;
using System.Text;
using System.Web.Configuration;
using System.Collections.Generic;
using System.Threading;
using Simulator.RGWSubLib;
using Simulator.BackEndSubLib;
using System.Security.Principal;
using Simulator.EventLogger;

/*
    02-Jul-06   JR  Fix the _dataFilters array so histories are ordered the way we need them.
    09-Jul-06   JR  Bunch of tweaks. Put the default RGW database area into web.cfg. Give the humans
                    some more choices: 1.) split the messages and load them into a compare table in
                    one operation 2.) just split the traffic 3.) just load the compare table.
 * 
    16-July-06  JR  Change the table names to take off the "_T" extension. This is how the IntraNet
                    views are named. In theory, we should look at the views rather than the underlying
                    tables because, allegedly, the views will only show the latest rows while the "_T"
                    tables could hold all the rows ever seen, including any expired rows. It depends
                    on how a bank has it set up at their site. For BofA, for example, it doesn't matter
                    because they delete any expired rows from the "_T" tables. Stay tuned, there's 
                    probably a gotcha in here somewhere.
 
                    I also tried to see what I could do about what appears to be some sort of memory leak
                    in here. When attempting to fetch all the traffic out of RGW (260k msgs in today's
                    db), I get windows virtual address space warnings and the database read times out.
 * 
 * 28-Oct-06    JR  There's still a bit of mish-mosh over 'rgwArea' vs 'area'. There were a couple of
 *                  residual bugs in the file xfer code. The basic idea is that the actual rgw database
 *                  could/can be somewhere other than in out local area: could be the banks 'real' rgw
 *                  database, it could be a simulator-wide database, it could be local to this area.
 *                  Gotta keep 'em straight.
 * 
 * 29-Oct-06    JR  A bunch of code to fetch entry msgs and load them into the right feeder table. I
 *                  basically cloned Dave's threading routines but subverted them specifically for the
 *                  entry stuff. A bit of overkill perhaps, but if the entry searching & fetching somehow
 *                  involve more than just one table (the message) table, it might come in handy. We'll see.
 * 
 *  5-Nov-06    JR  Some more tweaks to the fetching of entry messages. We need more fields and
 *                  some of the info comes out of the debit table.
 * 
 * 12-Nov-06    JR  When fetching entry messages, order by rcv_time.
 * 
 *    Jan-07    DM  A number of tweaks.
 * 
 * 03-Feb-07    JR  Change how the browser figures out where to get data from and where it will
 *                  load compare table info. We used to get that out of web.cfg, but now let's
 *                  get that from SimulatorControl field(s). Put a 10 minute timeout on the
 *                  initial database read.
 * 
 *  3-Mar-07    JR  Put a 2 minute timeout on ProcessCmdThread. Let's see if that helps when
 *                  getting and splitting an entire db's worth of traffic.
 * 
 * 11-Mar-07    JR  Bunch of tweaks. Basically, I'm trying to make the construction of the connection
 *                  strings not rely on entries in web config. We want to be able to connect either to
 *                  the real RGW database, or to our MasterDataRepository, or to the set of message
 *                  tables local to the current area. And, we will potentially want to have more than
 *                  one MDR database on the simulator machine and each area can decide which MDR to 
 *                  use. It's way too combersome to add all those different connection strings into
 *                  web config, thank you very much, so I built some logic in here and in backendsubs
 *                  to deal with all of that. 
 * 
 * Oct-08       DM  On-site at STI. We're now getting the connection strings from web.config.
 * 
 * 10-Oct-08    JR  I loaded up STI's data and found that drilling down into a message wouldn't show
 *                  the history. A bit of a tip of the iceberg it turns out. When we come in here we
 *                  need to make sure we call the routines in BackEndSubs to tell us what database to
 *                  use for our 'local' area and for the 'master repository'. Usually I would expect
 *                  the local repository area to be the same as the local area itself, but there's no
 *                  rule that says that *has* to be & there's a mechanism that lets the humans define
 *                  (override, really) what the local rgw repository is. We *always* have to find
 *                  the location of the 'master repository'. Anyway, it seems to be working better now.
 *
 * 29-Oct-08    JR  When we get the connection string for the 'LocalRepository', we need to test for
 *                  it correctly. Duh.
 * 
 * 19-Nov-08    JR  We'll now load the source drop-down with the entry sources as well. If the
 *                  humans pick the load entry button, we'll look at the source they chose. If
 *                  they picked one of the entry sources, we'll use just that one source
 *                  for our logic. If they didn't pick a source, we'll use *all* the entry
 *                  sources in our select statement.
 * 
 * 20-Nov-08    JR  The select statement for loading entry sources needs a parenthesis around
 *                  the part that selects the sources, otherwise those naked "or" statements
 *                  cause the lookup to ignore any of the other parameters - amount, date, etc.
 * 
 * 17-Oct-10    JR  Added some more logging in the entry loader piece. Let's report when we
 *                  skip a trn. Let's report how many msgs we got from where and what database
 *                  we loaded them into.
 * 
 * 24-Oct-10   JR  In the process of digging thru STI's issues with load entry, I saw that
 *                  a lot of the time you couldn't drill down into a message in the browser
 *                  and the browser would throw an exception on the datareader in the
 *                  BindDetailsControl routine. I put a try/catch on that and will display
 *                  an error msg on the top of the page if the browser's unable to drill
 *                  down.
 * 
 *                  And now I see what they were doing at STI. If you do the 'load for
 *                  splitting only' function the code will only load messge, text,
 *                  and history; no debit or credit set. And that, ladies and gentlemen,
 *                  is where the trap for the load entry and browser drill-down functions
 *                  is set. Good to know. Ps, I got that when Barry at STI send me
 *                  the load files he had, only the message, text, and history files
 *                  had a filename of *.done...
 *                  
 * 12-Jun-11    JR  I added the ability to find a msg based on its having been on a particular
 *                  queue. This lets you find all the Feds that went to ofac, for example.
 *                  Don't forget to put an index on message_hist.que_line_id ;-)
 *                  
 * 18-Jul-14    JR  Add the Message_pr_prm table to the list of tables that comprise the compare info.
 * 
 * 10-Nov-14    JR  Changes to support the outbound text functionality we're adding. When loading the
 *                  compare table, we have more data to worry about, the stuff from mts_rcv_text; we'll
 *                  populate that table and pass it into the xmlformat routine who will chew on it.
 *                  
 * 04-Apr-15    JR  STI is running MTS 5.0 now and so the select statement when you drill down into a message
 *                  needs to know about that version of MTS. Actually, more specifically, the construction of
 *                  the select statement for MTS 2.0 doesn't work in the higher versions of MTS and the browser
 *                  code figured anything not MTS 3.0 was MTS 2.0. Now, it will construct the same select
 *                  statement for MTS 3.0, MTS 4.0, and MTS 5.0. 
 
 */

public partial class RGWBrowser : System.Web.UI.Page
{
    private TableMetaData<ArrayList> _columnList;
    private TableMetaData<ColumnMetaData<string, string>> _columnTypeList;
    private readonly string[] _sourceTables = { "MESSAGE", "MESSAGE_DR", "MESSAGE_CR" };
    //private readonly string[] _dataTables = { "MESSAGE", "MESSAGE_HIST", "MESSAGE_TEXT", "MESSAGE_DR", "MESSAGE_CR", "MESSAGE_DEST", "MESSAGE_PR_PVL", "MTS_RCV_TEXT" };
    private readonly string[] _dataTables = { "MESSAGE", "MESSAGE_HIST", "MESSAGE_TEXT", "MESSAGE_DR", "MESSAGE_CR", "MESSAGE_DEST", "MESSAGE_PR_PVL" };
   
    /*
     * this is the original set of filters. We're only looking at the inbound text info in this query.
     * private readonly string[] _dataFilters = { " ", " order by hist_no, sub_hist_no ", " and Text_Type='I' order by sequence_no ", " ", " ", " order by dst_ordinal ", " order by Prparm_id" };
     * 
    */
    private readonly string[] _dataFilters = { " ", " order by hist_no, sub_hist_no ", "  order by text_type, sequence_no ", " ", " ", " order by dst_ordinal ", " order by Prparm_id", "order by RefString" };


    private readonly string[] _entryTables = { "MESSAGE" };
    private readonly string[] _entryFilters = { " order by rcv_date, rcv_time " };

    private StringBuilder _dbCommand;
    private StringBuilder _dbFilter;
    const string _nullDateValue = "1/1/1";
    bool _useDRTable = false;
    bool _useCRTable = false;
    bool _useHistTable = false;
    string _threadConnectionString;
    string _threadCommand;
    string _threadSelectedDB;
    private bool _deferredTransfer;
    private string _amtDelta;
    private string _timeDelta;
    private string _algorithm;
    private string _area;
    private string _loadCompare;
    private bool _doSplit = true;
    private string _sourceCode;

    private string _qName = string.Empty;
    private string _myCompareTable = string.Empty;
    private string _repositoryArea = string.Empty;

    private bool LookInMasterTables = true;
    private bool DoNotLookInMasterTables = false;

    //private bool rgwIsLocal = true;
    //private string rgwVersion = "";

    static object _lockPage = new object();
    protected void Page_Load(object sender, EventArgs e)
    {
        SimCache simCache = SimCache.Instance;
        int test = simCache.Count;

        if (!Page.IsPostBack)
        {
            CreateExecutionCache();
            MultiView1.ActiveViewIndex = 0;
            _DBSelector.SelectedIndex = 1;

            GetStaticDataList();
            GetTableMetaData();
            _SearchButton.Enabled = true;
            _TransferLoadButton.Enabled = true;
            _TransferImmediateSetupButton.Enabled = true;
            _TransferButton.Enabled = true;
            _LoadOnlyButton.Enabled = true;
            _LoadEntryButton.Enabled = true;
        }
        BindExecutionList();
    }

    private void GetStaticDataList()
    {
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        String Cmd = string.Format("select '      ' as Bank from AreaBanks " +
                "union select  replace(BANK,' ','') from AreaBanks");
        using (SqlCommand command = new SqlCommand(Cmd, (SqlConnection)getDBConnection("Local", _area)))
        {
            Bank.DataSource = command.ExecuteReader(CommandBehavior.CloseConnection);
            Bank.DataBind();
        }
        // Load the entry sources, too.
        Cmd = string.Format("select '      ' as Source from AreaSources " +
                "union select replace(Source,' ','') from AreaSources " +
                "union select replace(Source,' ','') from entrySources");
        using (SqlCommand command = new SqlCommand(Cmd, (SqlConnection)getDBConnection("Local", _area)))
        {
            Source_cd.DataSource = command.ExecuteReader(CommandBehavior.CloseConnection);
            Source_cd.DataBind();
        }

        Cmd = string.Format("select '   ' as AdvType from AreaAdvTypes " +
                "union select  AdvType from AreaAdvTypes");
        using (SqlCommand command = new SqlCommand(Cmd, (SqlConnection)getDBConnection("Local", _area)))
        {
            instr_adv_type.DataSource = command.ExecuteReader(CommandBehavior.CloseConnection);
            instr_adv_type.DataBind();
        }

        Cmd = string.Format("select '   ' as TranType from AreaTranTypes " +
        "union select  TranType from AreaTranTypes");
        using (SqlCommand command = new SqlCommand(Cmd, (SqlConnection)getDBConnection("Local", _area)))
        {
            Tran_Type.DataSource = command.ExecuteReader(CommandBehavior.CloseConnection);
            Tran_Type.DataBind();
        }
        BackEndSubs util = new BackEndSubs();
        CompareTableName.Text = util.GetDefaultCompareTable(_area, true);
    }

    private void GetTableMetaData()
    {
        _columnList = new TableMetaData<ArrayList>();
        _columnTypeList = new TableMetaData<ColumnMetaData<string, string>>();
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        foreach (string Table in _sourceTables)
        {
            ArrayList columnEntry = new ArrayList();
            ColumnMetaData<string, string> columnTypeEntry = new ColumnMetaData<string, string>();
            string dbCommand = string.Format("SELECT  c.name as 'ColumnName',UPPER(t.name) AS 'Type' FROM syscolumns c WITH (NOLOCK) INNER JOIN systypes t WITH (NOLOCK) ON c.xusertype = t.xusertype INNER JOIN sysobjects o WITH (NOLOCK) ON c.id = o.id WHERE o.name  = '{0}'", Table);
            using (SqlCommand command = new SqlCommand(dbCommand, (SqlConnection)getDBConnection("MasterRepository", _area)))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string columnName = ((string)reader[0]).ToLower();
                        string columnType = ((string)reader[1]).ToLower();
                        columnEntry.Add(columnName);
                        columnTypeEntry.Add(columnName, columnType);
                    }
                }
                _columnList.Add(columnEntry);
                _columnTypeList.Add(columnTypeEntry);
            }
        }

        Session["_columnList"] = _columnList;
        Session["_columnTypeList"] = _columnTypeList;
    }

    private void GenerateSearchResultList()
    {
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        ControlCollection formControl = Table1.Controls;
        string selectedDB = _DBSelector.SelectedValue;
        Session["_db"] = selectedDB;
        bool rgwIsLocal = (bool)Session["rgwIsLocal"];

        bool firstAdded = true;
        _dbFilter = new StringBuilder();
        GenerateSearchResultSegment(formControl, ref firstAdded);
        if (!firstAdded)         // if something was added
        {
            //if (selectedDB.Equals("MasterRepository") || selectedDB.StartsWith("Local"))
            if (rgwIsLocal)
            {
                // We're here doing searches. The way this was written, it was hardwired to look only
                // in the master repository database. Argh ... that may be the way it'll be used most of
                // the time. But 100% of the time? No. Let's fix that.

                // The original code would only search for the first 50 rows. We need to return
                // *all* the stuff we find, so I took that part out. I also want the search to
                // return the trn's in order so I put an 'order by' on the search. This screwed up
                // the 'distinct' part of the 'select distinct' statement so I took out the 'distinct'
                // part. We should be ok since we're going against the RGW views - message vs message_t -
                // so there shouldn't be any dupes on rows for a given trn. Besides, Inet is going to
                // change things so the old (expired) rows get whacked from the rgw tables in one of
                // the upcoming releases. (3.0? I forget).

                // June 2011. I put in some code to look for msgs that were on a particular queue
                // so you can, for example, find all the Feds that went to ofac. Trouble is, if a msg
                // went to a couple of ofac queues, it would end up in the result set a couple of 
                // times. So, I had to restore the 'distinct' qualifier, but now I can't order by
                // the message date/trn_number, I have to order by the 'trn' variable that's constructed
                // in the 'convert' part of the select below. That's less than ideal because I can't
                // for the life of me figure out how to get the trn number to have leading zeros and
                // that means the 'order by' puts all the trn's that have '1' as the starting digit
                // before the trn's that have '2' as the starting digit - in other words, trn
                // 20110613-12345 shows up in the list before trn 201106013-2. Yuk. 
                // Ok, it's better to have the functionality to search for a queue than to have the
                // list in the right order ... stay tuned.

                // Jun-2013. Dug a little deeper and found how to get the leading zeros on the
                // trn number. Yeah !!! 

                SimulatorDataSource.ConnectionString = getConnectionString(selectedDB,
                    (string)HttpContext.Current.Session["CurrentDB"]);

                SearchList.DataSourceID = "SimulatorDataSource";

                /*
                string dbCmd = "select distinct (CONVERT(varchar(10),message.trn_date, 112)+'-'+convert(varchar(8),message.trn_number)) as 'Trn', " +
                    "message.bank,message.currency_code as 'Currency'," +
                    "message.Amount,message.Source_cd as 'Source', " +
                    "message.Instr_adv_type as 'AdvType'," +
                    "message.in_type_cd+message.in_subtype as 'MsgType' from message ";
                */

                string dbCmd = "select distinct (CONVERT(varchar(10),message.trn_date, 112)+'-'+right('00000000' + cast(message.trn_number as varchar),8)) as 'Trn', " +
                    "message.bank,message.currency_code as 'Currency'," +
                    "message.Amount,message.Source_cd as 'Source', " +
                    "message.Instr_adv_type as 'AdvType'," +
                    "message.in_type_cd+message.in_subtype as 'MsgType' from message ";

                if (_useDRTable)
                {
                    dbCmd += "inner join message_DR on message_DR.trn_date=message.trn_date and " +
                        "message_DR.trn_number=message.trn_number ";
                }
                if (_useCRTable)
                {
                    dbCmd += "inner join message_CR on message_CR.trn_date=message.trn_date and " +
                        "message_CR.trn_number=message.trn_number ";
                }
                if (_useHistTable)
                {
                    //dbCmd += "inner join message_hist on message_hist.trn_date=message.trn_date and " +
                    //    "message_hist.trn_number=message.trn_number ";
                    dbCmd += ", message_hist ";
                }
                dbCmd += " where ";
                _dbCommand = new StringBuilder(dbCmd + _dbFilter.ToString() + " order by Trn");

                SimulatorDataSource.SelectCommand = _dbCommand.ToString();
                string z = _dbCommand.ToString();
            }
            else
            {
                SearchList.DataSourceID = "RGWDataSource";
                string dbCmd = "select distinct concat(concat(to_char(message.trn_date,'YYYYMMDD'),'-'),message.trn_number) as Trn," +
                    "message.bank,message.currency_code as Currency,message.Amount ," +
                    "message.Source_cd as Source,message.Instr_adv_type as AdvType," +
                    "concat(message.in_type_cd,message.in_subtype) as MsgType from message ";
                if (_useDRTable)
                {
                    dbCmd += "inner join message_dr on message_dr.trn_date=message.trn_date and message_dr.trn_number=message.trn_number ";
                }
                if (_useCRTable)
                {
                    dbCmd += "inner join message_cr on message_cr.trn_date=message.trn_date and message_cr.trn_number=message.trn_number ";
                }
                if (_useHistTable)
                {
                    dbCmd += "inner join message_hist on message_hist.trn_date=message.trn_date and " +
                        "message_hist.trn_number=message.trn_number ";
                }
                dbCmd += " where ";

                _dbCommand = new StringBuilder(dbCmd + _dbFilter.ToString() + " order by Trn");

                RGWDataSource.SelectCommand = _dbCommand.ToString();
            }
            SearchList.DataBind();
            Session["SelectCmd"] = _dbCommand.ToString();
        }
    }


    private void GenerateSearchResultSegment(ControlCollection parentControl, ref bool firstAdded)
    {
        foreach (Control pageControl in parentControl)
        {
            string value = "";
            string pageControlName = pageControl.ID;
            if (pageControl is DropDownList)
            {
                value = ((DropDownList)pageControl).SelectedValue;
            }
            else
            {
                if (pageControl is TextBox)
                {
                    if (pageControlName.Equals("__trn") && ((TextBox)pageControl).Text.Trim() != string.Empty)
                    {
                        string trnNum;
                        string trnDate;
                        if (getTrnComponents(((TextBox)pageControl).Text, out trnNum, out trnDate))
                        {
                            if (!firstAdded)
                                _dbFilter.Append(" and ");
                            firstAdded = false;
                            _dbFilter.Append("message.trn_Number=" + trnNum + " and message.trn_Date=" + trnDate);
                            continue;
                        }
                    }

                    if (pageControlName.StartsWith("Qname") || pageControlName.StartsWith("Queue"))
                    {
                        if (((TextBox)pageControl).Text.Trim() != string.Empty)
                        {
                            _qName = ((TextBox)pageControl).Text.Trim();
                            _useHistTable = true;
                            string qSql = string.Format(" and (message_hist.que_line_id like '%{0}%')", _qName);

                            qSql = sqlHistoryQueryBuilder(_qName);
                            _dbFilter.Append(qSql);
                            firstAdded = false;
                            _useHistTable = true;
                        }
                        continue;
                    }

                    if (pageControlName.Equals("CompareTableName"))
                    {
                        /*
                         * See what table name to use for stashing the xml compare info into.
                         * Take out any spaces, too. Otherwise we croak later on trying
                         * to read the table.
                         * 
                         * Turn any dashes into underscores, too.
                         */
                        if (((TextBox)pageControl).Text.Trim() != string.Empty)
                        {
                            _myCompareTable = ((TextBox)pageControl).Text.Trim();
                            _myCompareTable = _myCompareTable.Replace(" ", "");
                            _myCompareTable = _myCompareTable.Replace("-", "_");
                        }
                        continue;
                    }
                    value = ((TextBox)pageControl).Text;
                }/*
                else
                    if (pageControl is BasicFrame.WebControls.BasicDatePicker)
                    {
                        DateTime controlDate = ((BasicFrame.WebControls.BasicDatePicker)pageControl).SelectedDate;
                        value = BasicFrame.WebControls.BasicDatePicker.FormatDate(controlDate, "M/d/yyyy");
                        if (value.Equals(_nullDateValue))
                        {
                            value = "";
                        }
                        else
                        {
                            bool rgwIsLocal = (bool)Session["rgwIsLocal"];

                            if (!((string)Session["_db"]).Equals("MasterRepository") && !((string)Session["_db"]).StartsWith("Local"))
                            {
                                string dateValue = BasicFrame.WebControls.BasicDatePicker.FormatDate(controlDate, "yyyyMMdd");
                                value = string.Format("to_date('{0}','yyyymmdd')", dateValue);
                            }
                        }
                    }*/
                else
                {
                     if (pageControl is ASP.datetimecontrol_ascx)
                       // if (pageControl is datetimecontrol_ascx)
                        ProcessDateRangeControl(pageControl.Controls, ref firstAdded);
                    else
                    {
                        if (pageControl is ASP.amountrangecontrol_ascx)
                            ProcessAmountRangeControl(pageControl.Controls, ref firstAdded);
                        else
                            GenerateSearchResultSegment(pageControl.Controls, ref firstAdded);
                    }
                }
            }
            try
            {
                string z = pageControlName;
                string cazzo = z;
            }
            catch { }
            value = value.Trim();
            if (value.Length != 0)
            {
                string _operator = "=";
                if (pageControlName.StartsWith("_"))
                {
                    string pcName = pageControlName.Substring(1);
                    try
                    {
                        pageControlName = pcName.Substring(pcName.IndexOf("_") + 1);
                        switch (pcName.Substring(0, 2))
                        {
                            case "ge":
                                _operator = ">=";
                                break;
                            case "gt":
                                _operator = ">";
                                break;
                            case "le":
                                _operator = "<=";
                                break;
                            case "lt":
                                _operator = "<";
                                break;
                            case "eq":
                                _operator = "=";
                                break;
                            case "li":
                                _operator = " like ";
                                value += "%";
                                break;
                        }
                    }
                    catch (System.ArgumentOutOfRangeException)
                    {
                        throw (new ApplicationException("Bad naming format for page control. If it starts with escape '_' char, it must have another closing '_'. ok?" + pageControlName));// write something out so developer can see what he did wrong
                    }
                }
                string columnType = _columnTypeList[0][pageControlName.ToLower()];
                if (columnType == null)
                {
                    columnType = _columnTypeList[1][pageControlName.ToLower()];
                    if (columnType != null)
                    {
                        _useDRTable = true;
                        pageControlName = "message_dr." + pageControlName;
                    }
                    else
                    {
                        columnType = _columnTypeList[2][pageControlName.ToLower()];
                        if (columnType != null)
                        {
                            _useCRTable = true;
                            pageControlName = "message_cr." + pageControlName;
                        }
                        else
                            if (pageControlName == "MsgType")
                            {
                                columnType = "varchar";
                            }
                    }
                }
                else
                {
                    pageControlName = "message." + pageControlName;
                }

                if (columnType != null)
                {
                    if (!firstAdded)
                    {
                        _dbFilter.Append(" and ");
                    }
                    firstAdded = false;
                    char delimeter = ' ';
                    if (columnType.Equals("char") || columnType.Equals("varchar"))
                    {
                        delimeter = '\'';
                    }
                    //
                    // Jan, 2011. This probably used to work with 'MsgType', but in getting ready
                    // for the PNC demo I saw that the browser wouldn't find Swift 103's. The
                    // pageControlName is actually 'message.MsgType'. So, there it is.
                    //
                    if (pageControlName.Equals("message.MsgType"))       // hack
                    {
                        string type = "0";
                        string subtype = value;
                        if (value.Length == 3)
                        {
                            type = value.Substring(0, 2);
                            subtype = value.Substring(2);
                        }
                        _dbFilter.Append("message.in_type_cd='" + type + "' and message.in_subtype='" + subtype + "' ");
                    }
                    else
                    {
                        _dbFilter.Append(pageControlName + _operator + delimeter + value + delimeter);
                    }
                }
            }
        }
    }
    protected void setupRgwFlags()
    {
        BackEndSubs util = new BackEndSubs();
        Session["rgwVersion"] = util.GetRgwVersion((string)HttpContext.Current.Session["CurrentDB"]);
        Session["rgwXmlFile"] = util.GetRgwXmlKeyFile((string)HttpContext.Current.Session["CurrentDB"]);
        if (_DBSelector.SelectedValue.ToUpper().Equals("MASTERREPOSITORY") || _DBSelector.SelectedValue.ToUpper().StartsWith("LOCAL"))
        {
            Session["rgwIsLocal"] = true;
        }
        else
        {
            Session["rgwIsLocal"] = false;
        }
    }

    protected void _SearchButton_Click(object sender, EventArgs e)
    {
        _columnList = (TableMetaData<ArrayList>)Session["_columnList"];
        _columnTypeList = (TableMetaData<ColumnMetaData<string, string>>)Session["_columnTypeList"];
        setupRgwFlags();

        GenerateSearchResultList();
        int rowCount = SearchList.Rows.Count;
        if (rowCount > 0)
        {
            InfoLabel.Visible = false;
            SetSelectMenu = "List";
            MultiView1.ActiveViewIndex = 1;
        }
        else
        {
            InfoLabel.Text = "No Messages found with this criteria. Please try again";
            InfoLabel.Visible = true;
        }
    }

    private void ProcessDateRangeControl(ControlCollection parentControl, ref bool firstAdded)
    {
        SortedList<string, Control> controlList = new SortedList<string, Control>();

        foreach (Control pageControl in parentControl)
        {
            if (pageControl.ID != null)
                controlList.Add(pageControl.ID, pageControl);
        }


        DateTime controlDate = ((OboutInc.Calendar2.Calendar)controlList["_ge_date"]).SelectedDate;
        string dateValue = Calendar1.SelectedDate.ToShortDateString(); // BasicFrame.WebControls.BasicDatePicker.FormatDate(controlDate, "yyyyMMdd");
        if (!dateValue.Equals(_nullDateValue))
        {
            if (!firstAdded)
            {
                _dbFilter.Append(" and ");
            }
            firstAdded = false;
            bool rgwIsLocal = (bool)Session["rgwIsLocal"];

            //if (((string)Session["_db"]).Equals("MasterRepository") || ((string)Session["_db"]).StartsWith("Local"))
            if (rgwIsLocal)
            {
                _dbFilter.Append("(CONVERT(varchar(10),rcv_date, 112)+rcv_time) >= '" + dateValue + ((TextBox)controlList["_ge_hour"]).Text + ":" + ((TextBox)controlList["_ge_minute"]).Text + ":" + ((TextBox)controlList["_ge_second"]).Text + "' and ");
                controlDate = ((OboutInc.Calendar2.Calendar)controlList["_le_date"]).SelectedDate;
                dateValue = controlDate.ToString("yyyyMMdd");
                _dbFilter.Append("(CONVERT(varchar(10),rcv_date, 112)+rcv_time) <= '" + dateValue + ((TextBox)controlList["_le_hour"]).Text + ":" + ((TextBox)controlList["_le_minute"]).Text + ":" + ((TextBox)controlList["_le_second"]).Text + "' ");
            }
            else
            {
                _dbFilter.Append("CONCAT(TO_CHAR(rcv_date,'YYYYMMDD'),rcv_time) >= '" + dateValue + ((TextBox)controlList["_ge_hour"]).Text + ":" + ((TextBox)controlList["_ge_minute"]).Text + ":" + ((TextBox)controlList["_ge_second"]).Text + "' and ");
                controlDate = ((OboutInc.Calendar2.Calendar)controlList["_le_date"]).SelectedDate;
                dateValue = controlDate.ToString("yyyyMMdd");
                _dbFilter.Append("CONCAT(TO_CHAR(rcv_date,'YYYYMMDD'),rcv_time) <= '" + dateValue + ((TextBox)controlList["_le_hour"]).Text + ":" + ((TextBox)controlList["_le_minute"]).Text + ":" + ((TextBox)controlList["_le_second"]).Text + "' ");
            }
        }
    }
    private void ProcessAmountRangeControl(ControlCollection parentControl, ref bool firstAdded)
    {
        System.Collections.Generic.SortedList<string, Control> controlList = new System.Collections.Generic.SortedList<string, Control>();
        foreach (Control pageControl in parentControl)
        {
            if (pageControl.ID != null)
                controlList.Add(pageControl.ID, pageControl);
        }
        string amountValue = ((TextBox)controlList["_ge1_amount"]).Text;
        if (amountValue.Trim().Length > 0)
        {
            if (!firstAdded)
            {
                _dbFilter.Append(" and ");
            }
            firstAdded = false;
            _dbFilter.Append("message.amount >= " + amountValue);
        }
        amountValue = ((TextBox)controlList["_le1_amount"]).Text;
        if (amountValue.Trim().Length > 0)
        {
            if (!firstAdded)
            {
                _dbFilter.Append(" and ");
            }
            firstAdded = false;
            _dbFilter.Append("message.amount <= " + amountValue);
        }

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton trnControl = sender as LinkButton;
        if (trnControl != null)
        {
            MultiView1.ActiveViewIndex = 2;
            bool lookupOk = BindDetailsControl(trnControl.Text);
            if (lookupOk)
            {
                SelectMenu.Visible = true;
                SetSelectMenu = "Summary";
                SearchList_TextBox.Visible = false;
            }
            else
            {
                MultiView1.ActiveViewIndex = 1;
            }
        }
    }

    public string SetSelectMenu
    {
        set
        {
            MenuItemCollection mic = SelectMenu.Items;
            foreach (MenuItem mi in mic)
            {
                if (mi.Text == value)
                    mi.Selected = true;
            }
        }
    }


    private bool BindDetailsControl(string trn)
    {
        Session["CurrentTrn"] = trn;
        string rgwVersion = Session["rgwVersion"].ToString();

        /*
         * At the present time - July, 09 - the code below works for all the versions of the 
         * RGW tables we have. If we find we need to, for example, display some of the new
         * message fields that we see in MTS 3.0, we'll have to filddle with the select
         * statement, *and* we'll have to conditionalize this code below so we can unpack
         * the new fields. For the moment, though, we don't have to do anything.
         */
        if (rgwVersion.StartsWith("MTS3"))
        {
            // put the MTS 3.0 specific code here.
        }
        else
        {
            // put the old style code, the stuff below, into here.
        }
        try
        {
            IDataReader dataReader = GetTrnDetails(trn);
            PartyBlock partyBlock = TrnSummaryTable.FindControl("PartyBlock1") as PartyBlock;
            partyBlock.SetProperties("Dbt Party:", dataReader["Dbt_idtype"], dataReader["Dbt_ID"], dataReader["Dbt_name1"], dataReader["Dbt_name_2"], dataReader["Dbt_name_3"]);
            partyBlock = TrnSummaryTable.FindControl("PartyBlock2") as PartyBlock;
            partyBlock.SetProperties("Cdt Party:", dataReader["Cdt_idtype"], dataReader["Cdt_ID"], dataReader["Cdt_name1"], dataReader["Cdt_name2"], dataReader["Cdt_name3"]);
            partyBlock = TrnSummaryTable.FindControl("PartyBlock3") as PartyBlock;
            partyBlock.SetProperties("Sender:", dataReader["SBK_IDTYPE"], dataReader["SBK_ID"], dataReader["SBK_NAME1"], dataReader["SBK_NAME2"], dataReader["SBK_NAME3"]);
            partyBlock = TrnSummaryTable.FindControl("PartyBlock4") as PartyBlock;
            partyBlock.SetProperties("Intermediary:", dataReader["IBK_IDTYPE"], dataReader["IBK_ID"], dataReader["IBK_NAME1"], dataReader["IBK_NAME2"], dataReader["IBK_NAME3"]);
            partyBlock = TrnSummaryTable.FindControl("PartyBlock5") as PartyBlock;
            partyBlock.SetProperties("Originator:", dataReader["OBK_IDTYPE"], dataReader["OBK_ID"], dataReader["OBK_NAME1"], dataReader["OBK_NAME2"], dataReader["OBK_NAME3"]);
            partyBlock = TrnSummaryTable.FindControl("PartyBlock6") as PartyBlock;
            partyBlock.SetProperties("Bnp Bank:", dataReader["BBK_IDTYPE"], dataReader["BBK_ID"], dataReader["BBK_NAME1"], dataReader["BBK_NAME2"], dataReader["BBK_NAME3"]);
            partyBlock = TrnSummaryTable.FindControl("PartyBlock7") as PartyBlock;
            partyBlock.SetProperties("Originator:", dataReader["ORP_IDTYPE"], dataReader["ORP_ID"], dataReader["ORP_NAME1"], dataReader["ORP_NAME2"], dataReader["ORP_NAME3"]);
            partyBlock = TrnSummaryTable.FindControl("PartyBlock8") as PartyBlock;
            partyBlock.SetProperties("Beneficiary:", dataReader["BNP_IDTYPE"], dataReader["BNP_ID"], dataReader["BNP_NAME1"], dataReader["BNP_NAME2"], dataReader["BNP_NAME3"]);
            partyBlock = TrnSummaryTable.FindControl("CdtAdvice") as PartyBlock;
            partyBlock.SetProperties("Special Instructions:", "", "", dataReader["CDT_SPC_INST1"], dataReader["CDT_SPC_INST2"], dataReader["CDT_SPC_INST3"]);

            SndRef.Text = Extract(dataReader["SBK_REF_NUM"]);
            OrigBnf.Text = Extract(dataReader["ORP_BEN_INF1"]);
            OBRef.Text = Extract(dataReader["OBK_REF_NUM"]);
            OrigRef.Text = Extract(dataReader["ORP_REF_NUM"]);
            BBI.Text = Extract(dataReader["bene_inst1"]);

            TrnData.Text = trn;

            SourceData.Text = Extract(dataReader["SOURCE_CD"]);
            CurData.Text = Extract(dataReader["CURRENCY_CODE"]);
            ValueData.Text = Extract(dataReader["VALUEDATE"]);
            AmountData.Text = Extract(dataReader["AMT"]);
            AdviceTypeData.Text = Extract(dataReader["INSTR_ADV_TYPE"]);
            SenderRefData.Text = Extract(dataReader["SBK_REF_NUM"]);
            CreatedData.Text = Extract(dataReader["INSTDATE"]);
            SenderId.Text = Extract(dataReader["NETWORK_SND_IDTYPE"]) + "/" + Extract(dataReader["NETWORK_SND_ACC"]);
            string LabelStyle = "<TD style='background-color: LavenderBlush;color:blue;'>";
            string ContentStyle = "<TD style='background-color:white ;color:black;font-weight: bold;'>";
            string graySpace = ContentStyle + "&nbsp;</td>";
            Charges.Text = "<TABLE BORDER='0' vspace='0' cellspacing='1'><TR>" + LabelStyle + "Debit:</TD>" + graySpace + ContentStyle + Extract(dataReader["DBT_CHRG"]) + "</TD>" + graySpace +
                LabelStyle + "Credit:</TD>" + graySpace + ContentStyle + Extract(dataReader["CDT_CHRG"]) + "</TD>" + graySpace +
                LabelStyle + "STP:</TD>" + graySpace + ContentStyle + Extract(dataReader["STRAIGHT_THRU"]) + "</TD>" + graySpace +
                LabelStyle + "Commission:</TD>" + graySpace + ContentStyle + Extract(dataReader["COMMISSION"]) + "</TD>" + graySpace +
                LabelStyle + "Cable:</TD>" + graySpace + ContentStyle + Extract(dataReader["CBL_CHARGE"]) + "</TD></TR></TABLE>";
            FedImad.Text = Extract(dataReader["FED_IMAD"]);
            ChipsSSN.Text = Extract(dataReader["CHP_SSN_6"]);
            SwiftMIR.Text = Extract(dataReader["SWF_IN_MIR"]);
            MsgTypeData.Text = Extract(dataReader["msgtype"]);
            /*
             * DBT_CHRG,CDT_CHRG,COMMISSION,CBL_CHARGE,WIRE_TYPE
            CDT_CHRG
            COMMISSION
            CBL_CHARGE
        
            STRAIGHT_THRU
            NETWORK_SND_IDTYPE

             * */
            return true;
        }
        catch (Exception e)
        {
            string info = e.Message.ToString();
            SearchList_TextBox.Visible = true;
            SearchList_TextBox.Text = "Insufficient data to browse " + trn + " - did you load for splitting only?";
            return false;
        }
    }

    private string Extract(object source)
    {
        string Source = source as string;
        if (Source != null)
            return Source;
        return " ";
    }
    private IDataReader GetTrnDetails(string trn)
    {
        string trnNum, trnDate;
        getTrnComponents(trn, out trnNum, out trnDate);
        string rgwVersion = Session["rgwVersion"].ToString();

        string selectCmd = getTrnSelectCmd(trnDate, trnNum, (string)Session["_db"], (string)Session["rgwVersion"]);
        string historyCmd = "SELECT BANK,QUE_LINE_ID,DATE_TIME,OPR_INITIALS AS OPERATOR,DETAILS FROM MESSAGE_HIST " +
            " WHERE TRN_DATE=" + trnDate + " and trn_number=" + trnNum + " ORDER BY HIST_NO,SUB_HIST_NO";

        IDataReader dataReader;

        _area = (string)HttpContext.Current.Session["CurrentDB"];

        if (_DBSelector.SelectedValue.Equals("MasterRepository") || _DBSelector.SelectedValue.StartsWith("Local"))
        {
            SqlCommand dbSqlCommand = new SqlCommand(selectCmd, (SqlConnection)getDBConnection(_DBSelector.SelectedValue, _area));
            dataReader = dbSqlCommand.ExecuteReader();

            // Make sure we override the hard-coded value in the browser.aspx page. We have to 
            // look for the history in the right database.
            HistoryDS.ConnectionString = getConnectionString(_DBSelector.SelectedValue, _area);
            HistoryList.DataSourceID = "HistoryDS";
            HistoryDS.SelectCommand = historyCmd;
        }
        else
        {
            OracleCommand dbSqlCommand = new OracleCommand(selectCmd, (OracleConnection)getDBConnection("Oracle", _area));
            dataReader = dbSqlCommand.ExecuteReader();
            HistoryList.DataSourceID = "RGWDataSource";
            RGWDataSource.SelectCommand = historyCmd;
        }
        HistoryList.DataBind();
        dataReader.Read();
        BindTextView("Input Text", trn);
        return dataReader;
    }

    private string getTrnSelectCmd(string trnDate, string trnNumber, string db, string rgwVersion)
    {
        string selectCmd = "";
        bool rgwIsLocal = (bool)Session["rgwIsLocal"];

        string majorRgwVersion = rgwVersion.Substring(0, rgwVersion.IndexOf("."));
        switch (majorRgwVersion)
        {

            case "MTS3":
            case "MTS4":
            case "MTS5":
                {
                    if (rgwIsLocal)
                    {
                        selectCmd = "select top 1 bank,loc,incoming_ref,convert(varchar(12),pay_date,103) as 'valuedate', " +
                            "pay_time,convert(varchar(12), " +
                            "inst_date,103)+' '+inst_time as 'instdate',tran_type,repetitive_id,source_cd," +
                            "instr_adv_type,type_cd,subtype, " +
                            "in_type_cd+in_subtype as 'msgtype',straight_thru,network_snd_idtype,network_snd_acc," +
                            " convert(varchar(20),amount) as 'amt', " +
                            "currency_code,fed_imad,fed_omad,fed_isn,fed_osn,swf_isn,swf_osn,chp_ssn_6,chp_osn," +
                            "swf_in_mir,swf_out_mir," +
                            "dbt_idtype,dbt_id, dbt_name1,dbt_name_2,dbt_name_3," +
                            "sbk_idtype,sbk_id,sbk_name1,sbk_name2,sbk_name3,sbk_ref_num, " +
                            "obk_idtype,obk_id,obk_name1,obk_name2,obk_name3,obk_ref_num, " +
                            "orp_idtype,orp_id,orp_name1,orp_name2,orp_name3,orp_ref_num, " +
                            "ins_id,ins_name1,ins_name2,ins_name3," +
                            "cdt_idtype,cdt_id,cdt_name1,cdt_name2,cdt_name3, " +
                            "bbk_idtype,bbk_id,bbk_name1,bbk_name2,bbk_name3, " +
                            "bnp_idtype,bnp_id,bnp_name1,bnp_name2,bnp_name3," +
                            "ibk_idtype,ibk_id,ibk_name1,ibk_name2,ibk_name3, " +
                            "ib1_idtype,ib1_ib1_id,ib1_name1,ib1_name2,ib1_name3," +
                            "orp_ben_inf1,orp_ben_inf2,orp_ben_inf3,orp_ben_inf4, " +
                            "cdt_spc_inst1,cdt_spc_inst2,cdt_spc_inst3,bene_inst1," +
                            "dbt_chrg,cdt_chrg,commission,cbl_charge,wire_type from message " +
                            "inner join message_dr on message.trn_date=message_dr.trn_date and " +
                            "message.trn_number=message_dr.trn_number " +
                            "inner join message_cr on message_dr.trn_date=message_cr.trn_date and " +
                            "message_dr.trn_number= message_cr.trn_number  " +
                            " where message.trn_number=" + trnNumber + " and message_cr.trn_date=" + trnDate;
                    }
                    else
                    {
                        selectCmd = "select bank,loc,incoming_ref,to_char(pay_date,'yyyy-mm-dd') as valuedate,pay_time," +
                            "concat(to_char(inst_date,'yyyy-mm-dd'),inst_time) as instdate,tran_type,repetitive_id,source_cd," +
                            "instr_adv_type,type_cd,subtype,concat(in_type_cd,in_subtype) as msgtype,straight_thru," +
                            "network_snd_idtype,network_snd_acc,to_char(amount,'999,999,999,999.99') as amt," +
                            "currency_code,fed_imad,fed_omad,fed_isn,fed_osn,swf_isn,swf_osn,chp_ssn_6,chp_osn," +
                            "swf_in_mir,swf_out_mir," +
                            "dbt_idtype,dbt_id,dbt_name1,dbt_name_2,dbt_name_3," +
                            "sbk_idtype,sbk_id,sbk_name1,sbk_name2,sbk_name3,sbk_ref_num," +
                            "obk_idtype,obk_id,obk_name1,obk_name2,obk_name3,obk_ref_num," +
                            "orp_idtype,orp_id,orp_name1,orp_name2,orp_name3,orp_ref_num," +
                            "ins_id,ins_name1,ins_name2,ins_name3," +
                            "cdt_idtype,cdt_id,cdt_name1,cdt_name2,cdt_name3," +
                            "bbk_idtype,bbk_id,bbk_name1,bbk_name2,bbk_name3," +
                            "bnp_idtype,bnp_id,bnp_name1,bnp_name2,bnp_name3," +
                            "ibk_idtype,ibk_id,ibk_name1,ibk_name2,ibk_name3," +
                            "ib1_idtype,ib1_ib1_id,ib1_name1,ib1_name2,ib1_name3," +
                            "orp_ben_inf1,orp_ben_inf2,orp_ben_inf3,orp_ben_inf4," +
                            "cdt_spc_inst1,cdt_spc_inst2,cdt_spc_inst3,bene_inst1," +
                            "dbt_chrg,cdt_chrg,commission,cbl_charge,wire_type from message " +
                            "inner join message_dr on message.trn_date=message_dr.trn_date and " +
                            "message.trn_number=message_dr.trn_number " +
                            "inner join message_cr on message_dr.trn_date=message_cr.trn_date and " +
                            "message_dr.trn_number= message_cr.trn_number " +
                            " where message_cr.trn_number=" + trnNumber + " and message_cr.trn_date=" + trnDate + " and rownum <2";
                    }
                    break;
                }
            default:
                {
                    /*
                      * Older style RGW select here. MTS 2.0 and MTS 1.2.
                      * 
                      * And the joke here, if you want to call it that is that the item that broke the
                      * browser at STI is the select of the bbk_id_overflow field which doesn't exist
                      * in MTS 3.0. The joke is that we were selecting it but never using it anywhere.
                      * 
                      */
                    //if (db.ToUpper().Equals("MASTERREPOSITORY") || db.ToUpper().StartsWith("LOCAL"))
                    if (rgwIsLocal)
                    {
                        selectCmd = "select top 1 bank,loc,incoming_ref,convert(varchar(12),pay_date,103) as 'valuedate', " +
                        "pay_time,convert(varchar(12), " +
                        "inst_date,103)+' '+inst_time as 'instdate',tran_type,repetitive_id,source_cd," +
                        "instr_adv_type,type_cd,subtype, " +
                        "in_type_cd+in_subtype as 'msgtype',straight_thru,network_snd_idtype,network_snd_acc," +
                        " convert(varchar(20),amount) as 'amt', " +
                        "currency_code,fed_imad,fed_omad,fed_isn,fed_osn,swf_isn,swf_osn,chp_ssn_6,chp_osn," +
                        "swf_in_mir,swf_out_mir," +
                        "dbt_idtype,dbt_id, dbt_name1,dbt_name_2,dbt_name_3," +
                        "sbk_idtype,sbk_id,sbk_name1,sbk_name2,sbk_name3,sbk_ref_num, " +
                        "obk_idtype,obk_id,obk_name1,obk_name2,obk_name3,obk_ref_num, " +
                        "orp_idtype,orp_id,orp_name1,orp_name2,orp_name3,orp_ref_num, " +
                        "ins_id,ins_name1,ins_name2,ins_name3," +
                        "cdt_idtype,cdt_id,cdt_name1,cdt_name2,cdt_name3, " +
                        "bbk_idtype,bbk_id,bbk_id_overflow,bbk_name1,bbk_name2,bbk_name3, " +
                        "bnp_idtype,bnp_id,bnp_name1,bnp_name2,bnp_name3," +
                        "ibk_idtype,ibk_id,ibk_name1,ibk_name2,ibk_name3, " +
                        "ib1_idtype,ib1_ib1_id,ib1_name1,ib1_name2,ib1_name3," +
                        "orp_ben_inf1,orp_ben_inf2,orp_ben_inf3,orp_ben_inf4, " +
                        "cdt_spc_inst1,cdt_spc_inst2,cdt_spc_inst3,bene_inst1," +
                        "dbt_chrg,cdt_chrg,commission,cbl_charge,wire_type from message " +
                        "inner join message_dr on message.trn_date=message_dr.trn_date and " +
                        "message.trn_number=message_dr.trn_number " +
                        "inner join message_cr on message_dr.trn_date=message_cr.trn_date and " +
                        "message_dr.trn_number= message_cr.trn_number  " +
                        " where message.trn_number=" + trnNumber + " and message_cr.trn_date=" + trnDate;
                    }
                    else
                    {
                        selectCmd = "select bank,loc,incoming_ref,to_char(pay_date,'yyyy-mm-dd') as valuedate,pay_time," +
                            "concat(to_char(inst_date,'yyyy-mm-dd'),inst_time) as instdate,tran_type,repetitive_id,source_cd," +
                            "instr_adv_type,type_cd,subtype,concat(in_type_cd,in_subtype) as msgtype,straight_thru," +
                            "network_snd_idtype,network_snd_acc,to_char(amount,'999,999,999,999.99') as amt," +
                            "currency_code,fed_imad,fed_omad,fed_isn,fed_osn,swf_isn,swf_osn,chp_ssn_6,chp_osn," +
                            "swf_in_mir,swf_out_mir," +
                            "dbt_idtype,dbt_id,dbt_name1,dbt_name_2,dbt_name_3," +
                            "sbk_idtype,sbk_id,sbk_name1,sbk_name2,sbk_name3,sbk_ref_num," +
                            "obk_idtype,obk_id,obk_name1,obk_name2,obk_name3,obk_ref_num," +
                            "orp_idtype,orp_id,orp_name1,orp_name2,orp_name3,orp_ref_num," +
                            "ins_id,ins_name1,ins_name2,ins_name3," +
                            "cdt_idtype,cdt_id,cdt_name1,cdt_name2,cdt_name3," +
                            "bbk_idtype,bbk_id,bbk_id_overflow,bbk_name1,bbk_name2,bbk_name3," +
                            "bnp_idtype,bnp_id,bnp_name1,bnp_name2,bnp_name3," +
                            "ibk_idtype,ibk_id,ibk_name1,ibk_name2,ibk_name3," +
                            "ib1_idtype,ib1_ib1_id,ib1_name1,ib1_name2,ib1_name3," +
                            "orp_ben_inf1,orp_ben_inf2,orp_ben_inf3,orp_ben_inf4," +
                            "cdt_spc_inst1,cdt_spc_inst2,cdt_spc_inst3,bene_inst1," +
                            "dbt_chrg,cdt_chrg,commission,cbl_charge,wire_type from message " +
                            "inner join message_dr on message.trn_date=message_dr.trn_date and " +
                            "message.trn_number=message_dr.trn_number " +
                            "inner join message_cr on message_dr.trn_date=message_cr.trn_date and " +
                            "message_dr.trn_number= message_cr.trn_number " +
                            " where message_cr.trn_number=" + trnNumber + " and message_cr.trn_date=" + trnDate + " and rownum <2";
                    }
                    break;
                }

        }

        //if (rgwVersion.StartsWith("MTS3"))
        //{
        //    /*
        //     * MTS 3.0 RGW tables here ...
        //     * 
        //     * 
        //     * Note, there are some new fields in Message that we're not looking at. Yet. Time will 
        //     * tell if we should include them or not, but here's the list of them:
        //     * 
        //            "[POSTAL_CODE_OVR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[RPR_FLG]  [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[EXC_FLG]  [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[IMPOSED_AMOUNT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[GLOBAL_CREDIT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[PAYMNT_FUNDING_IND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[PAYMNT_ASYNCH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[PAYMNT_RESP_TIME] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[MON_PER_INTERCEPT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[MON_PER_LOG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[SMPL_WRHS_INDICATOR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[ENT_REF_SYS_VEC] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[WRHS_REF_SYS_VEC] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[REF_CALL_VECTOR] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[SMPL_PYMT_FORMAT] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[CONTAINER_REJ_REASON] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[UNIQUE_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[SRGW_EXPORT_SERIAL] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        //            "[MSGTYPE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        //     */
        //    if (rgwIsLocal)
        //    {
        //        selectCmd = "select top 1 bank,loc,incoming_ref,convert(varchar(12),pay_date,103) as 'valuedate', " +
        //            "pay_time,convert(varchar(12), " +
        //            "inst_date,103)+' '+inst_time as 'instdate',tran_type,repetitive_id,source_cd," +
        //            "instr_adv_type,type_cd,subtype, " +
        //            "in_type_cd+in_subtype as 'msgtype',straight_thru,network_snd_idtype,network_snd_acc," +
        //            " convert(varchar(20),amount) as 'amt', " +
        //            "currency_code,fed_imad,fed_omad,fed_isn,fed_osn,swf_isn,swf_osn,chp_ssn_6,chp_osn," +
        //            "swf_in_mir,swf_out_mir," +
        //            "dbt_idtype,dbt_id, dbt_name1,dbt_name_2,dbt_name_3," +
        //            "sbk_idtype,sbk_id,sbk_name1,sbk_name2,sbk_name3,sbk_ref_num, " +
        //            "obk_idtype,obk_id,obk_name1,obk_name2,obk_name3,obk_ref_num, " +
        //            "orp_idtype,orp_id,orp_name1,orp_name2,orp_name3,orp_ref_num, " +
        //            "ins_id,ins_name1,ins_name2,ins_name3," +
        //            "cdt_idtype,cdt_id,cdt_name1,cdt_name2,cdt_name3, " +
        //            "bbk_idtype,bbk_id,bbk_name1,bbk_name2,bbk_name3, " +
        //            "bnp_idtype,bnp_id,bnp_name1,bnp_name2,bnp_name3," +
        //            "ibk_idtype,ibk_id,ibk_name1,ibk_name2,ibk_name3, " +
        //            "ib1_idtype,ib1_ib1_id,ib1_name1,ib1_name2,ib1_name3," +
        //            "orp_ben_inf1,orp_ben_inf2,orp_ben_inf3,orp_ben_inf4, " +
        //            "cdt_spc_inst1,cdt_spc_inst2,cdt_spc_inst3,bene_inst1," +
        //            "dbt_chrg,cdt_chrg,commission,cbl_charge,wire_type from message " +
        //            "inner join message_dr on message.trn_date=message_dr.trn_date and " +
        //            "message.trn_number=message_dr.trn_number " +
        //            "inner join message_cr on message_dr.trn_date=message_cr.trn_date and " +
        //            "message_dr.trn_number= message_cr.trn_number  " +
        //            " where message.trn_number=" + trnNumber + " and message_cr.trn_date=" + trnDate;
        //    }
        //    else
        //    {
        //        selectCmd = "select bank,loc,incoming_ref,to_char(pay_date,'yyyy-mm-dd') as valuedate,pay_time," +
        //            "concat(to_char(inst_date,'yyyy-mm-dd'),inst_time) as instdate,tran_type,repetitive_id,source_cd," +
        //            "instr_adv_type,type_cd,subtype,concat(in_type_cd,in_subtype) as msgtype,straight_thru," +
        //            "network_snd_idtype,network_snd_acc,to_char(amount,'999,999,999,999.99') as amt," +
        //            "currency_code,fed_imad,fed_omad,fed_isn,fed_osn,swf_isn,swf_osn,chp_ssn_6,chp_osn," +
        //            "swf_in_mir,swf_out_mir," +
        //            "dbt_idtype,dbt_id,dbt_name1,dbt_name_2,dbt_name_3," +
        //            "sbk_idtype,sbk_id,sbk_name1,sbk_name2,sbk_name3,sbk_ref_num," +
        //            "obk_idtype,obk_id,obk_name1,obk_name2,obk_name3,obk_ref_num," +
        //            "orp_idtype,orp_id,orp_name1,orp_name2,orp_name3,orp_ref_num," +
        //            "ins_id,ins_name1,ins_name2,ins_name3," +
        //            "cdt_idtype,cdt_id,cdt_name1,cdt_name2,cdt_name3," +
        //            "bbk_idtype,bbk_id,bbk_name1,bbk_name2,bbk_name3," +
        //            "bnp_idtype,bnp_id,bnp_name1,bnp_name2,bnp_name3," +
        //            "ibk_idtype,ibk_id,ibk_name1,ibk_name2,ibk_name3," +
        //            "ib1_idtype,ib1_ib1_id,ib1_name1,ib1_name2,ib1_name3," +
        //            "orp_ben_inf1,orp_ben_inf2,orp_ben_inf3,orp_ben_inf4," +
        //            "cdt_spc_inst1,cdt_spc_inst2,cdt_spc_inst3,bene_inst1," +
        //            "dbt_chrg,cdt_chrg,commission,cbl_charge,wire_type from message " +
        //            "inner join message_dr on message.trn_date=message_dr.trn_date and " +
        //            "message.trn_number=message_dr.trn_number " +
        //            "inner join message_cr on message_dr.trn_date=message_cr.trn_date and " +
        //            "message_dr.trn_number= message_cr.trn_number " +
        //            " where message_cr.trn_number=" + trnNumber + " and message_cr.trn_date=" + trnDate + " and rownum <2";
        //    }
        //}
        //else
        //{
        //    /*
        //     * Older style RGW select here. MTS 2.0 and MTS 1.2.
        //     * 
        //     * And the joke here, if you want to call it that is that the item that broke the
        //     * browser at STI is the select of the bbk_id_overflow field which doesn't exist
        //     * in MTS 3.0. The joke is that we were selecting it but never using it anywhere.
        //     * 
        //     */
        //    //if (db.ToUpper().Equals("MASTERREPOSITORY") || db.ToUpper().StartsWith("LOCAL"))
        //    if (rgwIsLocal)
        //    {
        //        selectCmd = "select top 1 bank,loc,incoming_ref,convert(varchar(12),pay_date,103) as 'valuedate', " +
        //        "pay_time,convert(varchar(12), " +
        //        "inst_date,103)+' '+inst_time as 'instdate',tran_type,repetitive_id,source_cd," +
        //        "instr_adv_type,type_cd,subtype, " +
        //        "in_type_cd+in_subtype as 'msgtype',straight_thru,network_snd_idtype,network_snd_acc," +
        //        " convert(varchar(20),amount) as 'amt', " +
        //        "currency_code,fed_imad,fed_omad,fed_isn,fed_osn,swf_isn,swf_osn,chp_ssn_6,chp_osn," +
        //        "swf_in_mir,swf_out_mir," +
        //        "dbt_idtype,dbt_id, dbt_name1,dbt_name_2,dbt_name_3," +
        //        "sbk_idtype,sbk_id,sbk_name1,sbk_name2,sbk_name3,sbk_ref_num, " +
        //        "obk_idtype,obk_id,obk_name1,obk_name2,obk_name3,obk_ref_num, " +
        //        "orp_idtype,orp_id,orp_name1,orp_name2,orp_name3,orp_ref_num, " +
        //        "ins_id,ins_name1,ins_name2,ins_name3," +
        //        "cdt_idtype,cdt_id,cdt_name1,cdt_name2,cdt_name3, " +
        //        "bbk_idtype,bbk_id,bbk_id_overflow,bbk_name1,bbk_name2,bbk_name3, " +
        //        "bnp_idtype,bnp_id,bnp_name1,bnp_name2,bnp_name3," +
        //        "ibk_idtype,ibk_id,ibk_name1,ibk_name2,ibk_name3, " +
        //        "ib1_idtype,ib1_ib1_id,ib1_name1,ib1_name2,ib1_name3," +
        //        "orp_ben_inf1,orp_ben_inf2,orp_ben_inf3,orp_ben_inf4, " +
        //        "cdt_spc_inst1,cdt_spc_inst2,cdt_spc_inst3,bene_inst1," +
        //        "dbt_chrg,cdt_chrg,commission,cbl_charge,wire_type from message " +
        //        "inner join message_dr on message.trn_date=message_dr.trn_date and " +
        //        "message.trn_number=message_dr.trn_number " +
        //        "inner join message_cr on message_dr.trn_date=message_cr.trn_date and " +
        //        "message_dr.trn_number= message_cr.trn_number  " +
        //        " where message.trn_number=" + trnNumber + " and message_cr.trn_date=" + trnDate;
        //    }
        //    else
        //    {
        //        selectCmd = "select bank,loc,incoming_ref,to_char(pay_date,'yyyy-mm-dd') as valuedate,pay_time," +
        //            "concat(to_char(inst_date,'yyyy-mm-dd'),inst_time) as instdate,tran_type,repetitive_id,source_cd," +
        //            "instr_adv_type,type_cd,subtype,concat(in_type_cd,in_subtype) as msgtype,straight_thru," +
        //            "network_snd_idtype,network_snd_acc,to_char(amount,'999,999,999,999.99') as amt," +
        //            "currency_code,fed_imad,fed_omad,fed_isn,fed_osn,swf_isn,swf_osn,chp_ssn_6,chp_osn," +
        //            "swf_in_mir,swf_out_mir," +
        //            "dbt_idtype,dbt_id,dbt_name1,dbt_name_2,dbt_name_3," +
        //            "sbk_idtype,sbk_id,sbk_name1,sbk_name2,sbk_name3,sbk_ref_num," +
        //            "obk_idtype,obk_id,obk_name1,obk_name2,obk_name3,obk_ref_num," +
        //            "orp_idtype,orp_id,orp_name1,orp_name2,orp_name3,orp_ref_num," +
        //            "ins_id,ins_name1,ins_name2,ins_name3," +
        //            "cdt_idtype,cdt_id,cdt_name1,cdt_name2,cdt_name3," +
        //            "bbk_idtype,bbk_id,bbk_id_overflow,bbk_name1,bbk_name2,bbk_name3," +
        //            "bnp_idtype,bnp_id,bnp_name1,bnp_name2,bnp_name3," +
        //            "ibk_idtype,ibk_id,ibk_name1,ibk_name2,ibk_name3," +
        //            "ib1_idtype,ib1_ib1_id,ib1_name1,ib1_name2,ib1_name3," +
        //            "orp_ben_inf1,orp_ben_inf2,orp_ben_inf3,orp_ben_inf4," +
        //            "cdt_spc_inst1,cdt_spc_inst2,cdt_spc_inst3,bene_inst1," +
        //            "dbt_chrg,cdt_chrg,commission,cbl_charge,wire_type from message " +
        //            "inner join message_dr on message.trn_date=message_dr.trn_date and " +
        //            "message.trn_number=message_dr.trn_number " +
        //            "inner join message_cr on message_dr.trn_date=message_cr.trn_date and " +
        //            "message_dr.trn_number= message_cr.trn_number " +
        //            " where message_cr.trn_number=" + trnNumber + " and message_cr.trn_date=" + trnDate + " and rownum <2";
        //    }
        //}
        return selectCmd;
    }

    protected void HistoryDS_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        SqlDataSourceView dsv = sender as SqlDataSourceView;
        if (dsv != null)
            dsv.SelectCommand = (string)Session["HistoryCmd"];

    }
    protected void SimulatorDataSource_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        SqlDataSourceView dsv = sender as SqlDataSourceView;
        if (dsv != null)
        {
            dsv.SelectCommand = (string)Session["SelectCmd"];
        }
    }

    public void menuItemChanged(object sender, EventArgs e)
    {
        MenuItem mi = ((MenuEventArgs)e).Item as MenuItem;
        bool Visibility = true;
        if (mi != null)
        {
            switch (mi.Text)
            {
                case "Search":
                    {
                        Visibility = false;
                        MultiView1.ActiveViewIndex = 0;
                        break;
                    }
                case "List":
                    {
                        Visibility = false;
                        MultiView1.ActiveViewIndex = 1;
                        break;
                    }
                case "Summary":
                    {
                        MultiView1.ActiveViewIndex = 2;
                        break;
                    }
                case "History":
                    {
                        MultiView1.ActiveViewIndex = 3;
                        break;
                    }
                case "Text":
                default:
                    {
                        MultiView1.ActiveViewIndex = 4;
                        break;
                    }
            }
            SelectMenu.Visible = Visibility;
        }
    }

    private bool getTrnComponents(string trn, out string trnNum, out string trnDate)
    {
        char[] delimiter = new char[] { '-' };
        string[] trnDateNum = trn.Split(delimiter);
        trnNum = string.Empty;
        trnDate = string.Empty;
        if (trnDateNum.Length != 2)
            return false;
        string selectedDB = (string)Session["_db"];
        bool rgwIsLocal = (bool)Session["rgwIsLocal"];


        if (selectedDB == "MasterRepository" || selectedDB.StartsWith("Local"))
            trnDate = "'" + trnDateNum[0].Substring(0, 4) + "-" + trnDateNum[0].Substring(4, 2) + "-" + trnDateNum[0].Substring(6, 2) + " 00:00:00.000'";
        else
            trnDate = string.Format("to_date('{0}','YYYYMMDD')", trnDateNum[0]);

        trnNum = trnDateNum[1];
        return true;
    }



    private IList<string> getTextList(string trn, string Type)
    {
        string trnNum, trnDate;
        getTrnComponents(trn, out trnNum, out trnDate);
        NamedList<string> nl = (NamedList<string>)Cache["TRNTEXT-" + Type];     // see if this is in the cache
        if (nl != null)
        {
            if (nl.Name == trn)
                return nl.namedList;
        }
        nl = new NamedList<string>(trn);
        string selectCmd = "select MESSAGE_TEXT from message_text where TRN_DATE= " + trnDate +
            " and trn_number=" + trnNum + " and text_type='" + Type + "' order by DST_ORDINAL,sequence_no";
        IDataReader dataReader;
        string selectedDB = (string)Session["_db"];
        bool rgwIsLocal = (bool)Session["rgwIsLocal"];

        if (selectedDB.Equals("MasterRepository") || selectedDB.StartsWith("Local"))
        {
            SqlCommand dbSqlCommand = new SqlCommand(selectCmd, (SqlConnection)getDBConnection(selectedDB, _area));
            dataReader = dbSqlCommand.ExecuteReader();
        }
        else
        {
            OracleCommand dbSqlCommand = new OracleCommand(selectCmd, (OracleConnection)getDBConnection("Oracle", _area));
            dataReader = dbSqlCommand.ExecuteReader();
        }
        while (dataReader.Read())
            nl.namedList.Add(((string)dataReader[0]));
        if (nl.namedList.Count == 0)
            nl.namedList.Add("No text of this type");

        Cache["TRNTEXT-" + Type] = nl;      // add to the cache
        return nl.namedList;
    }

    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {
        MenuItem mi = ((MenuEventArgs)e).Item as MenuItem;
        string trn = (string)Session["CurrentTrn"];
        if (mi != null)
            BindTextView(mi.Text, trn);
    }

    private void BindTextView(string textBlock, string trn)
    {
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        switch (textBlock)
        {
            case "Input Text":
                TextGridView.DataSource = getTextList(trn, "I");
                break;
            case "Output Text":
                TextGridView.DataSource = getTextList(trn, "O");
                break;
            case "Debit Confirm":
                TextGridView.DataSource = getTextList(trn, "D");
                break;
            case "Credit Confirm":
                TextGridView.DataSource = getTextList(trn, "C");
                break;
        }
        TextGridView.DataBind();
    }

    protected void _TransferButton_Click(object sender, EventArgs e)
    {
        BackEndSubs util = new BackEndSubs();
        string area = (string)HttpContext.Current.Session["CurrentDB"];
        util.logInfo(area, "Browser", "Transfer started");
        setupRgwFlags();
        _deferredTransfer = true;
        _loadCompare = "N";
        startTransferThread();
    }

    protected void _TransferLoadButton_Click(object sender, EventArgs e)
    {
        BackEndSubs util = new BackEndSubs();
        string area = (string)HttpContext.Current.Session["CurrentDB"];
        util.logInfo(area, "Browser", "Transfer and load started");
        setupRgwFlags();
        _deferredTransfer = true;
        _loadCompare = "Y";
        startTransferThread();
    }

    protected void _LoadOnlyButton_Click(object sender, EventArgs e)
    {
        BackEndSubs util = new BackEndSubs();
        string area = (string)HttpContext.Current.Session["CurrentDB"];
        util.logInfo(area, "Browser", "Transfer Load only started");
        setupRgwFlags();
        _deferredTransfer = true;
        _loadCompare = "Y";
        _doSplit = false;
        startTransferThread();
    }

    protected void _LoadEntryButton_Click(object sender, EventArgs e)
    {
        BackEndSubs util = new BackEndSubs();
        string area = (string)HttpContext.Current.Session["CurrentDB"];
        util.logInfo(area, "Browser EntLdr", "Load Entry started");
        setupRgwFlags();
        _deferredTransfer = true;
        startLoadEntryThread();
    }

    // create a worker thread.
    private void startTransferThread()
    {
        _columnList = (TableMetaData<ArrayList>)Session["_columnList"];
        _columnTypeList = (TableMetaData<ColumnMetaData<string, string>>)Session["_columnTypeList"];
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        _threadCommand = GenerateTransferSelectList();

        if (_useHistTable)
        {
            string x = "from message";
            int idx = _threadCommand.IndexOf(x);
            idx += x.Length + 1;

            _threadCommand = _threadCommand.Insert(idx,
                "inner join message_hist on message_hist.trn_date=message.trn_date and " +
                "message_hist.trn_number=message.trn_number ");
        }
        _threadSelectedDB = _DBSelector.SelectedValue;
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        /*
         * We need to get the connection string for the area where the rgw database
         * is. It might not be this local area.
         */
        findRepository(_area, _threadSelectedDB);

        if (_threadCommand != null && _threadCommand.Length > 0)
        {
            _threadConnectionString = getConnectionString(_threadSelectedDB, _repositoryArea);
            SortedList executionCache = (SortedList)Cache["ExecutionCache"];
            Simulator.CacheElement ce = (Simulator.CacheElement)executionCache[_threadConnectionString + _threadCommand];
            if (ce != null)
            {
                ExceptionLabel.Text = string.Format("Transfer already submitted at {0} as id {1}", ce.Issued.ToShortTimeString(), ce.ID);
                ExceptionLabel.Visible = true;
                InfoLabel.Visible = false;
            }
            else
            {
                ce = new Simulator.CacheElement(_threadConnectionString + _threadCommand, DateTime.Now, (string)Session["_db"], _dbFilter.ToString());
                InfoLabel.Text = string.Format("Starting transfer {0} in background", ce.ID);
                InfoLabel.Visible = true;
                ExceptionLabel.Visible = false;
                executionCache.Add(_threadConnectionString + _threadCommand, ce);
                BindExecutionList();

                // Execute the background task
                ce.setThread(new Thread(new ThreadStart(this.transferThread_DoWork)));
                ce.getThread().Start();
            }
        }
    }

    // Executes in its own thread context.

    private void transferThread_DoWork()
    {
        string threadCommand = _threadCommand;                    // transfer to local scope
        string threadConnectionString = _threadConnectionString;
        string threadSelectedDB = _threadSelectedDB;
        string area = _area;
        string algorithm = _algorithm;
        string timeDelta = _timeDelta;
        string amtDelta = _amtDelta;
        bool doCompare = false;
        int msgtype;
        int nMsg;
        //string cmpTable = "RgwCompare";
        BackEndSubs util = new BackEndSubs();

        findRepository(area, threadSelectedDB);

        if (_loadCompare.StartsWith("Y"))
        {
            doCompare = true;
        }
        else
        {
            if (_loadCompare.StartsWith("N"))
            {
                doCompare = false;
            }
            else
            {
                string x;
                x = getAppSetting(area + "RgwLoadCompare");
                if (x.Length == 0)
                {
                    x = getAppSetting("defaultRgwLoadCompare");
                }
                x = x.ToUpper();
                if (x.StartsWith("Y"))
                {
                    doCompare = true;
                }
            }
        }
        if (doCompare)
        {
            if (_myCompareTable.Length == 0)
            {
                _myCompareTable = util.GetDefaultCompareTable(_area, LookInMasterTables);
            }
            if (_myCompareTable.Length == 0)
                _myCompareTable = "RgwCompare";
        }

        System.IO.StreamWriter outputStream = null;
        SortedList executionCache = (SortedList)Cache["ExecutionCache"];
        Simulator.CacheElement ce = (Simulator.CacheElement)executionCache[threadConnectionString + _threadCommand];
        try
        {
            // For the moment, the TimeDelta value should be the number
            // of days to move the value date. The underlying routine is
            // expecting to be passed the number of ticks to move the
            // value date.
            int TimeDelta;
            if (!int.TryParse(timeDelta, out TimeDelta))
                TimeDelta = 0;
            long Ticks = TimeDelta * TimeSpan.TicksPerDay;

            /*
             * Stay tuned ... I'm changing the xFmt constructor below to get the area where the
             * compare table(s) go out of Simulator control via this BackEndSub method.
             * What this means is that you can fetch traffic out of the rgwArea (and we 
             * should give them a choice on where that is), but it'll build
             * the comparison tables themselves in the local area.
             */

            //Simulator.RGWSubLib.Grendel g = new Simulator.RGWSubLib.Grendel("cazzo");
            string compareArea = util.GetCompareRgwArea(area, DoNotLookInMasterTables);
            Simulator.RGWSubLib.RgwXmlFormatterV1dot0 xFmt = new RgwXmlFormatterV1dot0(compareArea);
            //Simulator.RGWSubLib.RgwXmlFormatter xFmt = new Simulator.RGWSubLib.RgwXmlFormatter(compareArea);
            Simulator.RGWSubLib.XmlMessage xMsg;
            Simulator.BackEndSubLib.msgType mtype = new Simulator.BackEndSubLib.msgType();

            string trnDateNum;
            int threadCount;
            int tableIndex, index;
            bool logBrower = false;

            nMsg = 0;
            /*
             * The splitter routine below needs to be constructed with the local area. It's being
             * passed datasets or tables so it doesn't have to know where the data came from, but
             * the 'area' in the constructor will control where it creates the output.
            */
            Simulator.RGWSubLib.RgwSplitter rgwSplitter = new Simulator.RGWSubLib.RgwSplitter(area);
            if (logBrower)
            {
                string fName = "C:\\Simulator\\BrowserLog_" + util.GetTimestampTag() + ".txt";
                outputStream = new System.IO.StreamWriter(new System.IO.FileStream(fName, System.IO.FileMode.Create));
                outputStream.WriteLine("Start:  " + DateTime.Now);
                outputStream.Flush();
            }
            /*
             * And here's Jacob's issue of 10/27/06 where the split operation doesn't work.
             * The area param has to be the rgwArea, otherwise it won't find any of the msgs.
             * 5-Mar-07. Not any more. Now it has to be our local area. It'll use the local
             * area to resolve where the repository lives.
             */
            //IDataReader r = new IDataReader();
            using (IDbConnection trnListConn = getDBConnection(threadSelectedDB, area))
            {
                using (IDbCommand command = getDBCommand(threadSelectedDB, trnListConn, threadCommand))
                {
                    // Give 'em a big long time to complete the query. 10 minutes.
                    command.CommandTimeout = 600;
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            trnDateNum = reader.GetString(0);
                            if (logBrower)
                            {
                                outputStream.WriteLine(trnDateNum + "   " + DateTime.Now);
                                outputStream.Flush();
                            }

                            System.Data.DataSet dataSet = new System.Data.DataSet();
                            object lockBlock = new object();
                            Thread[] threadList = new Thread[_dataTables.Length];
                            // need to spawn threads here,since oracle does not appear to support 
                            // command.BeginExecuteReader!
                            threadCount = 0;
                            tableIndex = 0;
                            foreach (string table in _dataTables)
                            {
                                object[] Args = new object[] { 
                                    table, 
                                    formatSQLCmd(table, _dataFilters[tableIndex++], trnDateNum), 
                                    threadSelectedDB, 
                                    dataSet, 
                                    lockBlock };
                                ParameterizedThreadStart ts = new ParameterizedThreadStart(ProcessCmdThread);
                                threadList[threadCount] = new Thread(ts);
                                threadList[threadCount++].Start(Args);
                            }
                            for (index = 0; index < _dataTables.Length; index++)
                                threadList[index].Join();


                            //   dataSet.WriteXml(outputStream);


                            if (_deferredTransfer)
                            {
                                //
                                // Too many choices ... we'll let the humans 1.)split the fetch and
                                // load it into the compare table in the same operation 2.) just split
                                // without loading the compare table 3.) just load the compare table.
                                // Argh ... the xml format stuff needs to know the message type - swift
                                // vs chips and all that - so we need to make sure to get that. The only
                                // mechanism at the moment is buried in the rgw split code.
                                //

                                msgtype = -666;
                                if (_doSplit)
                                {
                                    msgtype = rgwSplitter.split(dataSet);
                                }
                                if (doCompare)
                                {
                                    if (msgtype == -666)
                                    {
                                        msgtype = rgwSplitter.getMsgType(dataSet);
                                    }
                                    try
                                    {
                                        xMsg = xFmt.xmlFmt(msgtype, dataSet);
                                        xFmt.insertXmlMsg(xMsg, _myCompareTable, compareArea);
                                    }
                                    catch (Exception fmtException)
                                    {
                                        outputStream.WriteLine("Done:   " + DateTime.Now + "  " + nMsg + " msgs");
                                        outputStream.Flush();
                                        string message = fmtException.Message;
                                        util.logError(area, "Browser", "UI fmt/insert exception in transfer thread: " + nMsg + ":" + message);
                                    }
                                }
                            }
                            else
                            {
                                // Immediate load directly into the Feeder table.
                                rgwSplitter.load(dataSet, area, amtDelta, Ticks, algorithm);
                            }

                            nMsg++;

                            if ((nMsg % 1000) == 0)
                            {
                                util.logInfo(area, "Browser", "Transfer processed msg #" + nMsg);
                            }

                            ce.Counter += 1;
                            dataSet.Dispose();
                        }
                    }
                }
            }
            if (logBrower)
            {
                outputStream.WriteLine("Done:   " + DateTime.Now + "  " + nMsg + " msgs");
                outputStream.Flush();
            }
            util.logInfo(area, "Browser", "Transfer thread done: " + nMsg + " messages");
            rgwSplitter.byeBye(true);
        }
        catch (Exception ex)
        {
            string message = ex.Message;
            util.logError(area, "Browser", "UI exception in transfer thread: " + message);
        }
        finally
        {
            executionCache.Remove(_threadConnectionString + _threadCommand);
            if (outputStream != null)
                outputStream.Dispose();
        }
    }

    private void startLoadEntryThread()
    {
        _columnList = (TableMetaData<ArrayList>)Session["_columnList"];
        _columnTypeList = (TableMetaData<ColumnMetaData<string, string>>)Session["_columnTypeList"];
        _area = (string)HttpContext.Current.Session["CurrentDB"];
        _threadCommand = GenerateLoadEntrySelectList();
        _threadSelectedDB = _DBSelector.SelectedValue;
        /*
         * We need to get the connection string for the area where the rgw database
         * is. It might not be this local area.
         * 
         * And let's get the rgwarea out of the Simulator tables rather than out
         * of web.cfg.
         */
        findRepository(_area, _threadSelectedDB);

        if (_threadCommand != null && _threadCommand.Length > 0)
        {
            _threadConnectionString = getConnectionString(_threadSelectedDB, _repositoryArea);
            SortedList executionCache = (SortedList)Cache["ExecutionCache"];
            Simulator.CacheElement ce = (Simulator.CacheElement)executionCache[_threadConnectionString + _threadCommand];
            if (ce != null)
            {
                ExceptionLabel.Text = string.Format("Transfer already submitted at {0} as id {1}", ce.Issued.ToShortTimeString(), ce.ID);
                ExceptionLabel.Visible = true;
                InfoLabel.Visible = false;
            }
            else
            {
                ce = new Simulator.CacheElement(_threadConnectionString + _threadCommand, DateTime.Now, (string)Session["_db"], _dbFilter.ToString());
                InfoLabel.Text = string.Format("Starting transfer {0} in background", ce.ID);
                InfoLabel.Visible = true;
                ExceptionLabel.Visible = false;
                executionCache.Add(_threadConnectionString + _threadCommand, ce);
                BindExecutionList();

                // Execute the background task
                Thread backgroundThread = new Thread(new ThreadStart(this.LoadEntryThread_DoWork));
                backgroundThread.Start();
            }
        }
    }

    // Executes in its own thread context.

    private void LoadEntryThread_DoWork()
    {
        string threadCommand = _threadCommand;                    // transfer to local scope
        string threadConnectionString = _threadConnectionString;
        string threadSelectedDB = _threadSelectedDB;
        string area = _area;
        BackEndSubs util = new BackEndSubs();

        int nMsg;

        // First off, find out where the RGW database lives - it might not be in the same 
        // area that we're running in.
        // Let's find out the default behavior for whether or not we load into a compare
        // table on rgw fetches. (This should probably be a UI choice, too.)
        findRepository(area, threadSelectedDB);

        System.IO.StreamWriter outputStream = null;
        SortedList executionCache = (SortedList)Cache["ExecutionCache"];
        Simulator.CacheElement ce = (Simulator.CacheElement)executionCache[threadConnectionString + _threadCommand];
        try
        {
            string trnDateNum;
            bool logBrower = false;
            int threadCount;
            int tableIndex, index;

            nMsg = 0;
            Simulator.RGWSubLib.EntryLoader entldr = new Simulator.RGWSubLib.EntryLoader(area);
            if (logBrower)
            {
                string fName = "C:\\Simulator\\BrowserLog_" + util.GetTimestampTag() + ".txt";
                outputStream = new System.IO.StreamWriter(new System.IO.FileStream(fName, System.IO.FileMode.Create));
                outputStream.WriteLine("Start:  " + DateTime.Now);
                outputStream.Flush();
            }
            util.logInfo(area, "Browser EntLdr", "Load Entry Transfer started");
            using (IDbConnection trnListConn = getDBConnection(threadSelectedDB, _repositoryArea))
            {
                using (IDbCommand command = getDBCommand(threadSelectedDB, trnListConn, threadCommand))
                {
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            trnDateNum = reader.GetString(0);
                            if (logBrower)
                            {
                                outputStream.WriteLine(trnDateNum + "   " + DateTime.Now);
                                outputStream.Flush();
                            }
                            //if (trnDateNum.Equals("20090617-13398"))
                            //{
                            //    int zzz = -5;
                            //}
                            System.Data.DataSet dataSet = new System.Data.DataSet();
                            object lockBlock = new object();
                            Thread[] threadList = new Thread[_entryTables.Length];
                            //
                            // we need to spawn threads here,since oracle does not appear to 
                            // support command.BeginExecuteReader!
                            //
                            threadCount = 0;
                            tableIndex = 0;
                            foreach (string table in _entryTables)
                            {
                                object[] Args = new object[] { table, formatSQLLoadEntryCmd(table, _entryFilters[tableIndex++], trnDateNum), threadSelectedDB, dataSet, lockBlock };
                                ParameterizedThreadStart ts = new ParameterizedThreadStart(ProcessCmdThread);
                                threadList[threadCount] = new Thread(ts);
                                threadList[threadCount++].Start(Args);
                            }
                            for (index = 0; index < _entryTables.Length; index++)
                            {
                                threadList[index].Join();
                            }
                            try
                            {
                                int nRows = entldr.load(dataSet);
                                dataSet.Dispose();
                                if (nRows > 0)
                                {
                                    nMsg++;
                                    if ((nMsg % 1000) == 0)
                                    {
                                        util.logInfo(area, "Browser EntLdr", "Load Entry Transfer processed entry msg # " + nMsg);
                                    }
                                }
                                else
                                {
                                    util.logInfo(area, "Browser EntLdr ", "Load Entry skipped msg # " + trnDateNum);
                                }
                            }
                            catch (Exception entldrException)
                            {
                                util.logError(area, "Browser EntLdr", entldrException.Message.ToString());
                            }
                            ce.Counter += 1;
                        }
                        entldr.dispose();
                        util.logInfo(area, "Browser EntLdr", "Load Entry Transfer finished: loaded " + nMsg + " entry msgs from '" + _repositoryArea + "' into '" + area + "'");
                    }
                }
            }
            if (logBrower)
            {
                outputStream.WriteLine("Done:   " + DateTime.Now + "  " + nMsg + " msgs");
                outputStream.Flush();
            }
        }
        catch (Exception ex)
        {
            string message = ex.Message;
        }
        finally
        {
            executionCache.Remove(_threadConnectionString + _threadCommand);
            if (outputStream != null)
                outputStream.Dispose();
        }
    }


    private string GenerateLoadEntrySelectList()
    {
        ControlCollection formControl = Table1.Controls;
        _dbCommand = new StringBuilder("");
        string selectedDB = _DBSelector.SelectedValue;
        Session["_db"] = selectedDB;
        string entSourcesWhere = "";

        bool addEntryWhereClause = true;
        bool firstAdded = true;
        _dbFilter = new StringBuilder();
        BackEndSubs util = new BackEndSubs();
        ArrayList entSources = util.getEntrySources(_area);
        if (entSources.Contains(Source_cd.SelectedValue.ToString()))
        {
            // They've already picked an entry source ... No need to load up
            // the where clause with the rest of the other entry sources.
            addEntryWhereClause = false;
        }
        else
        {
            int nEntrySources = 0;
            for (int i = 0; i < entSources.Count; i++)
            {
                nEntrySources++;
                if (i > 0)
                    entSourcesWhere += " or source_cd='" + entSources[i] + "'";
                else
                    entSourcesWhere += " (source_cd='" + entSources[i] + "'";
            }
            if (nEntrySources > 0)
            {
                entSourcesWhere += ")";
            }
        }
        GenerateSearchResultSegment(formControl, ref firstAdded);
        if (!firstAdded)         // if something was added to the command
        {
            string dbCmd = "";
            if (selectedDB.Equals("MasterRepository") || selectedDB.StartsWith("Local"))
            {
                dbCmd = "select distinct (CONVERT(varchar(10),message.trn_date, 112)+'-'+convert(varchar(8),message.trn_number)) from message ";
            }
            else
            {
                dbCmd = "select distinct concat(concat(to_char(message.trn_date,'YYYYMMDD'),'-'),message.trn_number) from message ";
            }
            if (_useDRTable)
            {
                dbCmd += "inner join message_dr on message_dr.trn_date=message.trn_date and message_dr.trn_number=message.trn_number ";
            }
            dbCmd += " where ";
            _dbCommand.Append(dbCmd + _dbFilter.ToString());
            if (addEntryWhereClause)
            {
                _dbCommand.Append(" and " + entSourcesWhere);
            }
        }
        else
        {
            if (addEntryWhereClause)
            {
                _dbCommand.Append(" where " + entSourcesWhere);
            }
        }
        return _dbCommand.ToString();
    }


    string formatSQLCmd(string table, string filterClause, string trnDateNum)
    {
        string sqlCmd;
        string trnNum, trnDate;
        getTrnComponents(trnDateNum, out trnNum, out trnDate);
        sqlCmd = string.Format("select * from {0} where trn_Date={1} and trn_Number={2} {3} ", table, trnDate, trnNum, filterClause);
        return sqlCmd;
    }

    string formatSQLLoadEntryCmd(string table, string filterClause, string trnDateNum)
    {
        string sqlCmd;
        string trnNum, trnDate;
        getTrnComponents(trnDateNum, out trnNum, out trnDate);
        //sqlCmd = string.Format("select * from {0} where trn_Date={1} and trn_Number={2} {3} ", 
        //table, trnDate, trnNum, filterClause);

        sqlCmd = string.Format("select message.trn_date, message.trn_number, bank,loc,source_cd," +
            "instr_adv_type,base_amount,rcv_date,rcv_time,dbt_idtype,dbt_id  " +
            " from message " +
            "inner join message_dr on message.trn_date=message_dr.trn_date and message.trn_number=message_dr.trn_number " +
            " where message_dr.trn_number={0} and message_dr.trn_date={1} order by rcv_time",
            trnNum, trnDate, filterClause);

        return sqlCmd;
    }


    private void ProcessCmdThread(object args)
    {
        object[] Args = (object[])args;
        string tableName = (string)Args[0];
        string dbCmd = (string)Args[1];
        string threadSelectedDB = (string)Args[2];
        System.Data.DataSet dataSet = (System.Data.DataSet)Args[3];
        object lockBlock = Args[4];
        if (dbCmd.Contains("MTS_RCV_TEXT"))
        {
            /*
             * This is so bad ... this table doesn't have a trn number or trn date, just a string that
             * contains that info. So, we gotta reconstruct the query ...
             */
            string datestring = dbCmd.Substring(dbCmd.IndexOf("trn_Date='") + 10, 10);
            datestring = datestring.Replace("-", "");

            string trnstring = dbCmd.Substring(dbCmd.IndexOf("trn_Number=") + 11);
            trnstring = trnstring.Substring(0, trnstring.IndexOf(" "));
            string zeros = "00000000";
            trnstring = zeros.Substring(0, 8 - trnstring.Length) + trnstring;
            dbCmd = string.Format("select msgtext from mts_rcv_text where trnref = '{0}{1}'", datestring, trnstring);
        }
        /*
         * House o'cards ... we need to connect to the repository database, wherever
         * that might be at the moment. This routine was unconditionally connecting to
         * our local area's database. Tsk, tsk, we can't have that, lol.
         * 
         * So ... should the target area be a parameter into this call or should we just
         * globally use '_repositoryArea' and count on the initiator having set everything
         * up properly? Let's go with the global solution for the moment.
         */
        //using (IDbConnection trnListConn = getDBConnection(threadSelectedDB, _area))
        using (IDbConnection trnListConn = getDBConnection(threadSelectedDB, _repositoryArea))
        {
            using (IDbCommand command = getDBCommand(threadSelectedDB, trnListConn, dbCmd))
            {
                /*
                 * We're getting timeouts right here when running long-winded fetches
                 * of many thousands of messages; we're fetching all the messages out
                 * of a database so's we can split them. 
                 */
                command.CommandTimeout = 120;
                using (IDataReader reader = command.ExecuteReader())
                {
                    lock (lockBlock)
                    {
                        dataSet.Load(reader, LoadOption.Upsert, new string[] { tableName });
                    }
                    reader.Dispose();
                }
            }
            trnListConn.Dispose();
        }
    }

    private string GenerateTransferSelectList()
    {
        ControlCollection formControl = Table1.Controls;
        _dbCommand = new StringBuilder("");
        string selectedDB = _DBSelector.SelectedValue;
        Session["_db"] = selectedDB;

        bool firstAdded = true;
        _dbFilter = new StringBuilder();

        GenerateSearchResultSegment(formControl, ref firstAdded);
        if (!firstAdded)         // if something was added
        {
            string dbCmd = "";
            if (selectedDB.Equals("MasterRepository") || selectedDB.StartsWith("Local"))
                dbCmd = "select distinct (CONVERT(varchar(10),message.trn_date, 112)+'-'+convert(varchar(8),message.trn_number)) from message ";
            else
                dbCmd = "select distinct concat(concat(to_char(message.trn_date,'YYYYMMDD'),'-'),message.trn_number) from message ";
            if (_useDRTable)
                dbCmd += "inner join message_dr on message_dr.trn_date=message.trn_date and message_dr.trn_number=message.trn_number ";

            dbCmd += " where ";
            _dbCommand.Append(dbCmd + _dbFilter.ToString());
        }
        return _dbCommand.ToString();
    }

    //private static IDbConnection getDBConnection(string selectedDB, string area)
    private IDbConnection getDBConnection(string selectedDB, string area)
    {
        IDbConnection dbConn;
        string sqlConnectionString = getConnectionString(selectedDB, area);
        if (selectedDB == "MasterRepository" || selectedDB.StartsWith("Local"))
            dbConn = new SqlConnection(sqlConnectionString);
        else
            dbConn = new OracleConnection(sqlConnectionString);
        WindowsIdentity current = WindowsIdentity.GetCurrent();
        dbConn.Open();
        return dbConn;
    }

    private static IDbCommand getDBCommand(string SelectedDB, IDbConnection dbConn, string dbCmd)
    {
        if (SelectedDB == "MasterRepository" || SelectedDB.StartsWith("Local"))
            return new SqlCommand(dbCmd, (SqlConnection)dbConn);
        return new OracleCommand(dbCmd, (OracleConnection)dbConn);
    }

    /*
    //private static string getConnectionString(string selectedDB, string area)
        private string getConnectionString_Obsolete(string selectedDB, string area)
    {
        string connectionString;
       
        //string rgwArea = string.Empty;
        //_area = (string)HttpContext.Current.Session["CurrentDB"];
        findRepository(area);
        

        if (selectedDB.Equals("Local"))
            connectionString = "Simulator_" + area + "ConnectionString";
        else
        {
            if (selectedDB.Equals("Simulator"))
                connectionString = "Simulator_" + _repositoryArea + "ConnectionString";
            else
                connectionString = "OracleConnectionString";
        }
        string currentUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

        ConnectionStringsSection connectionStringsSection =
            WebConfigurationManager.GetSection("connectionStrings") as ConnectionStringsSection;

        if (connectionStringsSection == null)
            throw (new ApplicationException("No Connection String section in web.config"));

        ConnectionStringSettingsCollection connectionStrings = connectionStringsSection.ConnectionStrings;// Get the connectionStrings key,value pairs collection.
        ConnectionStringSettings connectionSettings = connectionStrings[connectionString];
        if (null == connectionSettings)
            throw (new ApplicationException("Cannot find ConnectionString for " + connectionString));
        return connectionSettings.ConnectionString;
    }
    */

    private string getRepositoryConnectionString(string selectedDB, string area)
    {
        string connectionString;
        findRepository(area, selectedDB);

        string currentUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        string systemName = currentUser.Substring(0, currentUser.IndexOf("\\"));

        connectionString = "Data Source=" +
          systemName +
          ";Initial Catalog=Simulator_" +
          _repositoryArea +
          ";Integrated Security=True;";

        return connectionString;
    }

    /*
        private string getConnectionString(string selectedDB, string area)
        {
            //         * Note that the first time we come here in a session, we're going to
            //  be in our local area and the next thing that happens after we return
            //  from here will be to look up the info to populate our drop-down boxes;
            //  the banks, source codes, all that sort of stuff.
            //  
            // 
            string connectionString;


            string currentUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            string systemName = currentUser.Substring(0, currentUser.IndexOf("\\"));


    //       Simulator.SimulatorLog eventLog = new Simulator.SimulatorLog("Simulator");
    //	eventLog.FatalMsg("CU="+currentUser+"systemname="+systemName);


            connectionString = "Simulator_" + area + "ConnectionString";

            if (selectedDB.StartsWith("Local"))
            {
                connectionString = "Data Source=" +
                  systemName +
                  ";Initial Catalog=Simulator_" +
                  area +
                  ";Integrated Security=True;";
    //	eventLog.FatalMsg("CU="+currentUser+"systemname="+systemName+"Connection="+connectionString);


                return connectionString;
            }
            if (selectedDB.Equals("MasterRepository"))
            {

                findRepository(area, selectedDB);

                connectionString = "Data Source=" +
                  systemName +
                  ";Initial Catalog=Simulator_" +
                  _repositoryArea +
                  ";Integrated Security=True;";

                return connectionString;
            }

            connectionString = "OracleConnectionString";

            ConnectionStringsSection connectionStringsSection =
                WebConfigurationManager.GetSection("connectionStrings") as ConnectionStringsSection;

            if (connectionStringsSection == null)
                throw (new ApplicationException("No Connection String section in web.config"));

            ConnectionStringSettingsCollection connectionStrings = connectionStringsSection.ConnectionStrings;// Get the connectionStrings key,value pairs collection.
            ConnectionStringSettings connectionSettings = connectionStrings[connectionString];
            if (null == connectionSettings)
                throw (new ApplicationException("Cannot find ConnectionString for " + connectionString));

            return connectionSettings.ConnectionString;
        }
    */

    private string getConnectionString(string selectedDB, string area)
    {
        /*
         * Note that the first time we come here in a session, we're going to
         * be in our local area and the next thing that happens after we return
         * from here will be to look up the info to populate our drop-down boxes;
         */
        string connectionString = "OracleConnectionString";
        SimulatorLog eventLog = new SimulatorLog("Simulator");


        if (selectedDB.StartsWith("Local"))
        {
            /*
             * We need to call findRepository here so we can know where our local
             * area message database is. It probably is the same as the local area
             * but it doesn't have to be ...
             * There might be a bug down the road on this since we come here to populate
             * our drop-downs in the browser when we first enter. This means that if the
             * local message repository area isn't the same as the local area, we'll populate 
             * the drop-downs with what we find in that "other" area. Stay tuned
             */
            findRepository(area, selectedDB);
            connectionString = "Simulator_" + _repositoryArea + "ConnectionString";
        }
        else
        {
            if (selectedDB.Equals("MasterRepository"))
            {
                findRepository(area, selectedDB);
                connectionString = "Simulator_" + _repositoryArea + "ConnectionString";
            }
        }

        //	eventLog.FatalMsg("The connection string is:"+connectionString);

        ConnectionStringsSection connectionStringsSection =
            WebConfigurationManager.GetSection("connectionStrings") as ConnectionStringsSection;

        if (connectionStringsSection == null)
        {
            throw (new ApplicationException("No Connection String section in web.config"));
        }

        ConnectionStringSettingsCollection connectionStrings = connectionStringsSection.ConnectionStrings;// Get the connectionStrings key,value pairs collection.
        ConnectionStringSettings connectionSettings = connectionStrings[connectionString];
        if (null == connectionSettings)
        {
            throw (new ApplicationException("Cannot find ConnectionString for " + connectionString));
        }

        string dsn = connectionSettings.ConnectionString;
        //	eventLog.FatalMsg("The dsn string is:"+dsn);
        return dsn;
    }

    private static string getAppSetting(string key)
    {
        string tmp = System.Configuration.ConfigurationManager.AppSettings[key];
        if (tmp != null)
            return tmp;
        return "";
    }

    private void CreateExecutionCache()
    {
        lock (_lockPage)
        {
            if (Cache["ExecutionCache"] == null)
            {
                Cache["ExecutionCache"] = new SortedList();
            }
        }

    }
    protected void _Cancel_Click(object sender, EventArgs e)
    {
        SortedList executionCache = (SortedList)Cache["ExecutionCache"];
        IDictionaryEnumerator listIter = executionCache.GetEnumerator();
        foreach (Simulator.CacheElement ce in executionCache.Values)
        {
            ce.getThread().Abort();
            InfoLabel.Text = "Cancelling " + ce.ID;
        }
        Cache["ExecutionCache"] = new SortedList();
    }
    protected void _Refresh_Click(object sender, EventArgs e)
    {
        BindExecutionList();
    }
    private void BindExecutionList()
    {
        CreateExecutionCache();
        SortedList sl = (SortedList)Cache["ExecutionCache"];

        if (sl != null && sl.Count != 0)
        {
            ResultsView.DataSource = sl.GetValueList();
            ResultsView.DataBind();
            ResultsView.Visible = true;
            RefreshExecButton.Visible = true;
            CancelExecButton.Visible = true;
        }
        else
        {
            ResultsView.Visible = false;
            RefreshExecButton.Visible = false;
            CancelExecButton.Visible = false;
        }
    }
    protected void _TransferImmediate_Click(object sender, EventArgs e)
    {
        BackEndSubs util = new BackEndSubs();
        string area = (string)HttpContext.Current.Session["CurrentDB"];
        setupRgwFlags();
        util.logInfo(area, "Browser", "Transfer immediate started");
        _deferredTransfer = false;
        double Amount;
        int Time;
        _amtDelta = AmtDelta.Text.Trim();
        if (_amtDelta.Length == 0)
        {
            _amtDelta = "0";
        }
        else
        {
            if (!double.TryParse(_amtDelta, out Amount))
            {
                TransferInfo.Visible = true;
                TransferInfo.Text = "Amount Delta must be a decimal type";
                return;
            }
        }
        _timeDelta = TimeDelta.Text.Trim();
        if (_timeDelta.Length == 0)
        {
            _timeDelta = "0";
        }
        else
        {
            if (!int.TryParse(_timeDelta, out Time))
            {
                TransferInfo.Visible = true;
                TransferInfo.Text = "Time Delta must be an integer type";
                return;
            }
        }
        if (AlgorithmList.SelectedIndex != -1)
        {
            _algorithm = AlgorithmList.SelectedItem.Text;
        }
        else
        {
            _algorithm = " ";
        }

        _loadCompare = "Y";
        startTransferThread();
        MultiView1.ActiveViewIndex = 0;
    }

    private void findRepository(string area, string SelectedDB)
    {
        BackEndSubs util = new BackEndSubs();
        if (SelectedDB == "MasterRepository")
        {
            _repositoryArea = util.GetRgwRepository(_area, LookInMasterTables);
        }
        else
        {
            _repositoryArea = util.GetLocalRgwArea(_area);
        }
    }

    protected void _TransferImmediateSetup_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 5;
    }

    public string sqlHistoryQueryBuilder(string list)
    {
        string[] qList = list.Trim().Split(' ');
        StringBuilder sb = new StringBuilder();
        sb.Append(string.Format("and( message_hist.Que_Line_ID like '%{0}%' and " +
            " message.trn_date = message_hist.trn_date and message.trn_number = message_hist.trn_number)", qList[0]));
        if (qList.Length > 1)
        {
            for (int i = 1; i < qList.Length; i++)
            {
                sb.Append(" ");
                string x = string.Format(
                " and (CONVERT(varchar(10),message.trn_date, 112)+'-'+right('00000000' + cast(message.trn_number as varchar),8)) in (select " +
                " (CONVERT(varchar(10),message_hist.trn_date, 112)+'-'+right('00000000' + cast(message_hist.trn_number as varchar),8))  " +
                " from message_hist where message_hist.Que_Line_ID like '%{0}%') ", qList[i]);

                sb.Append(x);
            }
        }
        return sb.ToString();
    }
}

