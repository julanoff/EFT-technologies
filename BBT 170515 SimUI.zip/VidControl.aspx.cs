/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
using OboutInc.Calendar2;

namespace Simulator
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
    
	public partial class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlInputHidden Hidden1;


		protected void Page_Load(object sender, System.EventArgs e)
		{
            if (!Page.IsPostBack)
                BindDataGrid();

            if (!ClientScript.IsClientScriptBlockRegistered("confirm"))
			{
				string jsConfirm = @"<script language='javascript'> "+
					"function confirm_delete() "+
					"{ return (confirm('Are you sure you want to delete this item?')); }"+
					"</script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "confirm", jsConfirm);
            }		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DataGrid1.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.ItemCommands);
			this.DataGrid1.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Cancel);
			this.DataGrid1.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Edit);
			this.DataGrid1.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Update);
			this.DataGrid1.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Delete);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.ItemBound);

		}
		#endregion


		void DataGrid_Edit(Object sender, DataGridCommandEventArgs e) 
		{
            DataGrid1.EditItemIndex = e.Item.ItemIndex;
            BindDataGrid();
		}

		void DataGrid_Cancel(Object sender, DataGridCommandEventArgs e) 
		{
			// Set the EditItemIndex property to the index of the item clicked
			// in the DataGrid control to enable editing for that item. Be sure
			// to rebind the DateGrid to the data source to refresh the control.
			DataGrid1.EditItemIndex =  -1;
			BindDataGrid();
		}

// called in edit mode to update the row.

		void DataGrid_Update(Object sender, DataGridCommandEventArgs e) 
		{
            TextBox1.Visible = false;
            string UniqueKey = (string)((TextBox)(e.Item.FindControl("UniqueKeyBox"))).Text.Trim();
			string Mode=((TextBox) e.Item.FindControl("ModeEdit")).Text.Trim();
			string TimeOut=((TextBox) e.Item.FindControl("TimeOutEdit")).Text.Trim();
			string TimeOutCallSel=((TextBox) e.Item.FindControl("TimeOutCallSelEdit")).Text.Trim();
			string TimeOutScroll=((TextBox) e.Item.FindControl("TimeOutScrollEdit")).Text.Trim();
			string MakeTrace=(string)((DropDownList)(e.Item.FindControl("MakeTraceEdit"))).SelectedItem.Text.Trim();
			string AutoReplay=(string)((DropDownList)(e.Item.FindControl("AutoReplayEdit"))).SelectedItem.Text.Trim();
			string VideoPort=((TextBox) e.Item.FindControl("VideoPortEdit")).Text.Trim();
			string IntPort=((TextBox) e.Item.FindControl("IntPortEdit")).Text.Trim();
			string DisplFlow=(string)((DropDownList)(e.Item.FindControl("DisplFlowEdit"))).SelectedItem.Text.Trim();
			string VDate = string.Empty;
            // Get DatePicker from DataGridItem.
            /*
			BasicFrame.WebControls.BasicDatePicker bdp = ((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker1"));
			// Check if DateTime !isNull(DateTime.MinValue).
			if(!bdp.IsNull)
				VDate = string.Format("'{0}'",BasicFrame.WebControls.BasicDatePicker.FormatDate(bdp.SelectedDate,"M/d/yyyy"));			
			else 
				VDate="NULL";
            */
            VDate = DateTime.Now.ToShortDateString();
    // Do Edits of the fields
            string Edt = EditFld("UPD", Mode, TimeOut, TimeOutCallSel, TimeOutScroll, VideoPort, IntPort);
            if (Edt != null)
            {
                TextBox1.Visible = true;
                TextBox1.Text = Edt;
                return;
            }
			string Cmd=string.Format("update VideoConfig set Mode='{0}',TimeOut={1},TimeOutCallSel={2}, "+
                        "TimeOutScroll={3}, MakeTrace='{4}', AutoReplay='{5}',VideoPort={6},IntPort={7},DisplFlow='{8}',ValDate={9} where UniqueKey='{10}'",
				Mode, TimeOut, TimeOutCallSel, TimeOutScroll, MakeTrace, AutoReplay, VideoPort, IntPort, DisplFlow, VDate, UniqueKey);
			DBAccess Connection= new DBAccess();
			String Area=(String)HttpContext.Current.Session["CurrentDB"];
			try
			{
				Connection.Connect(true,Area);
				Connection.Execute(Cmd,true);
				DataGrid1.EditItemIndex =  -1;
				BindDataGrid();
			}
			catch (Exception ){}
			finally
			{
				Connection.DisConnect();
			}
		}

        private string EditFld(string who, string Mode, string TimeOut, string TimeOutCallSel, string TimeOutScroll, string VideoPort, string IntPort)
        {
            TextBox1.Visible = false;
            string ret=null;
            if ((who == "ADD") && 
                ((Mode.Length < 4) ||
                 ((Mode.Substring(0,3) != "RPR") && 
                  (Mode.Substring(0,3) != "ENT") &&
                  (Mode.Substring(0,3) != "VFY")) ||
                 ((Convert.ToInt16(Mode.Substring(3,1))<0) || (Convert.ToInt16(Mode.Substring(3,1))> 9) )))
            {
                ret = "Incorrect Mode. Must be RPR, VFY or ENT with a number";
                return ret;
            }
            try
            {
                int i = Convert.ToInt16(TimeOut);
                if (i < 1000)
                {
                    ret = "Incorrect Time Out field. Must be more than 1000";
                    return ret;
                }
            }
            catch
            {
                ret = "Incorrect Time Out field. Must be numeric";
                return ret;
            }

            try
            {
                int i = Convert.ToInt16(TimeOutCallSel);
                if (i < 1000)
                {
                    ret = "Incorrect Time Out for Select field. Must be more than 1000";
                    return ret;
                }
            }
            catch
            {
                ret = "Incorrect Time Out for Select field. Must be numeric";
                return ret;
            }

            try
            {
                int i = Convert.ToInt16(TimeOutScroll);
                if ((i < 100) && (i>1000))
                {
                    ret = "Incorrect Scroll Time Out field. Must be more than 100 and less than 1000";
                    return ret;
                }
            }
            catch
            {
                ret = "Incorrect Scroll Time Out field. Must be numeric";
                return ret;
            }
            try
            {
                int i = Convert.ToInt16(VideoPort);
                if ((i < 1000) || (i > 60000))
                {
                    ret = "Incorrect Video Port field. Must be between than 1000 and 60000";
                    return ret;
                }
            }
            catch
            {
                ret = "Incorrect Video Port field. Must be numeric";
                return ret;
            }
            try
            {
                int i = Convert.ToInt16(IntPort);
                if ((i < 20000) || (i > 30000))
                {
                    ret = "Incorrect Internal Port field. Must be between than 20000 and 30000";
                    return ret;
                }
                i = i % 2;
                if (i != 0)
                {
                    ret = "Incorrect Internal Port field. Must be even number";
                    return ret;
                }
            }
            catch
            {
                ret = "Incorrect Internal Port field. Must be numeric";
                return ret;
            }
            return ret;
        }

        private void DataGrid_Delete(object source, DataGridCommandEventArgs e)
		{
			string UniqueKey;
			try
			{
				UniqueKey=(string)((Label)(e.Item.FindControl("UniqueKey"))).Text.Trim();
			}
			catch
			{
				UniqueKey=(string)((TextBox)(e.Item.FindControl("UniqueKeyBox"))).Text.Trim();
			}
			string Cmd="delete from VideoConfig where uniquekey="+UniqueKey;	
			DBAccess Connection= new DBAccess();
			string Area=(String)HttpContext.Current.Session["CurrentDB"];
            string Cmd1 = "select Mode from VideoConfig where uniquekey=" + UniqueKey;
            string Mode=null;
            Connection.Connect(true, Area);
            if (Connection.OpenDataReader(Cmd1))
            {
                Connection.SQLDR.Read();
                Mode = Connection.SQLDR["Mode"].ToString().TrimEnd();
                Connection.CloseDataReader();
            }
            Cmd1 = string.Format("delete from SimulatorProcesses where ModArgs='{0} {1}'", Area, Mode);
            try { Connection.Execute(Cmd1, false); }  // Sometimes the process is not there. Don't need to trap
            catch { }

            try
			{
                Connection.Execute(Cmd, true);
                DataGrid1.EditItemIndex = -1;
				BindDataGrid();
			}
			catch (Exception ){}
			finally
			{
				Connection.DisConnect();
			}

		}

        // called when the row goes into edit mode.  Populates the editable rows.

		private void ItemBound(object sender, DataGridItemEventArgs e)
		{
            if (e.Item.ItemType == ListItemType.EditItem)
			{
                TextBox1.Visible = false;
                ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ModeEdit"))).Enabled = false;
                string Mode = ((DataRowView)e.Item.DataItem).Row.ItemArray[0].ToString().Trim();
				string TimeOut        = ((DataRowView)e.Item.DataItem).Row.ItemArray[1].ToString();
				string TimeOutCallSel = ((DataRowView)e.Item.DataItem).Row.ItemArray[2].ToString();
				string TimeOutScroll  = ((DataRowView)e.Item.DataItem).Row.ItemArray[3].ToString();
				string MakeTrace      = ((DataRowView)e.Item.DataItem).Row.ItemArray[4].ToString().Trim();
				string AutoReplay     = ((DataRowView)e.Item.DataItem).Row.ItemArray[5].ToString().Trim();
				string VideoPort      = ((DataRowView)e.Item.DataItem).Row.ItemArray[6].ToString();
				string IntPort        = ((DataRowView)e.Item.DataItem).Row.ItemArray[7].ToString();
		        string DisplFlow      = ((DataRowView)e.Item.DataItem).Row.ItemArray[8].ToString().Trim();

				// DateTime VDate;
                /*
				BasicFrame.WebControls.BasicDatePicker bdp;
				if (((DataRowView)e.Item.DataItem).Row.ItemArray[9].ToString()!="")
				{
					VDate = Convert.ToDateTime(((DataRowView)e.Item.DataItem).Row.ItemArray[9].ToString());
					bdp = ((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker1"));
					bdp.SelectedDate=VDate;
				}
                */
                //cal1.SelectedDate = VDate;
				((TextBox) e.Item.FindControl("ModeEdit")).Text=Mode;
		        ((TextBox) e.Item.FindControl("TimeOutEdit")).Text = TimeOut;
		        ((TextBox) e.Item.FindControl("TimeOutCallSelEdit")).Text = TimeOutCallSel;
		        ((TextBox) e.Item.FindControl("TimeOutScrollEdit")).Text = TimeOutScroll;
				((DropDownList)e.Item.FindControl("MakeTraceEdit")).Items.FindByValue(MakeTrace).Selected = true;
				((DropDownList)e.Item.FindControl("AutoReplayEdit")).Items.FindByValue(AutoReplay).Selected = true;
		        ((TextBox) e.Item.FindControl("VideoPortEdit")).Text = VideoPort;
		        ((TextBox) e.Item.FindControl("IntPortEdit")).Text = IntPort;
				((DropDownList)e.Item.FindControl("DisplFlowEdit")).Items.FindByValue(DisplFlow).Selected = true;
				//((Label) e.Item.FindControl("Label2")).Text="";
			}
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.EditItem)
			{
				Button cancelButton = (Button)e.Item.FindControl("DelButtonId");
				if(cancelButton != null)
					cancelButton.Attributes.Add("onclick", "return confirm_delete();");
			}		
		}

		public void ItemCommands(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
            TextBox1.Visible = false;
			if (e.CommandName == "AddNewRow")
				Add_on(e);
			else
				if (e.CommandName == "CancelAddRow")
				Add_off(e);
			else
			{
				if (e.CommandName == "ConfirmAddRow")
				{
                    TextBox1.Visible = false;
                    string Mode = ((TextBox)e.Item.FindControl("ModeFt")).Text.Trim();
                    string TimeOutX = ((TextBox)e.Item.FindControl("TimeOutFt")).Text.Trim();
                    string TimeOutCallSelX = ((TextBox)e.Item.FindControl("TimeOutCallSelFt")).Text.Trim();
                    string TimeOutScrollX = ((TextBox)e.Item.FindControl("TimeOutScrollFt")).Text.Trim();
                    string VideoPortX = ((TextBox)e.Item.FindControl("VideoPortFt")).Text.Trim();
                    string IntPortX = ((TextBox)e.Item.FindControl("IntPortFt")).Text.Trim();
					string MakeTrace = (string)((DropDownList)(e.Item.FindControl("MakeTraceFt"))).SelectedItem.Text.Trim();
					string AutoReplay = (string)((DropDownList)(e.Item.FindControl("autoReplayFt"))).SelectedItem.Text.Trim();
					string DisplFlow = (string)((DropDownList)(e.Item.FindControl("DisplFlowFt"))).SelectedItem.Text.Trim();
					string VDate = string.Empty;
				// Get DatePicker from DataGridItem.
                    /*
					BasicFrame.WebControls.BasicDatePicker bdp = ((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker3"));
				// Check if DateTime !isNull(DateTime.MinValue).
					if(!bdp.IsNull)
						VDate = string.Format("'{0}'",BasicFrame.WebControls.BasicDatePicker.FormatDate(bdp.SelectedDate,"M/d/yyyy"));			
					else 
						VDate="NULL";
                    */
                    VDate = DateTime.Now.ToShortDateString();
                    // VDate = cal1.SelectedDate;
                    // Do Edits of the fields
                    string Edt = EditFld("ADD", Mode, TimeOutX, TimeOutCallSelX, TimeOutScrollX, VideoPortX, IntPortX);
                    if (Edt != null)
                    {
                        TextBox1.Visible = true;
                        TextBox1.Text = Edt;
                        return;
                    }
                    DBAccess Connection = new DBAccess();
                    String Area = (String)HttpContext.Current.Session["CurrentDB"];
			        Connection.Connect(false,Area);
			        string Cmd=string.Format("select * from VideoConfig where Mode='{0}'",Mode);
                    try
                    {
                        Connection.OpenDataReader(Cmd);
                        if (Connection.SQLDR.HasRows)
                        {
                            TextBox1.Visible = true;
                            TextBox1.Text = string.Format("{0} entry already exists.",Mode);
                            return;
                        }
                    }
                    catch { }
                    finally
                    {
                        Connection.CloseDataReader();
                        Connection.DisConnect();
                    }
                    int TimeOut = Convert.ToInt32(((TextBox)e.Item.FindControl("TimeOutFt")).Text.Trim());
                    int TimeOutCallSel = Convert.ToInt32(((TextBox)e.Item.FindControl("TimeOutCallSelFt")).Text.Trim());
                    int TimeOutScroll = Convert.ToInt32(((TextBox)e.Item.FindControl("TimeOutScrollFt")).Text.Trim());
                    int VideoPort = Convert.ToInt32(((TextBox)e.Item.FindControl("VideoPortFt")).Text.Trim());
                    int IntPort = Convert.ToInt32(((TextBox)e.Item.FindControl("IntPortFt")).Text.Trim());
                    string PrName="Auto ";
                    switch (Mode.Substring(0, 3))
                    {
                        case "RPR":
                            PrName += "Repair_" + Mode.Substring(3, 1);
                            break;
                        case "ENT":
                            PrName += "Entry_" + Mode.Substring(3, 1);
                            break;
                        case "VFY":
                            PrName += "Verify_" + Mode.Substring(3, 1);
                            break;
                    }
                    Cmd = string.Format("insert into VideoConfig (Mode,TimeOut,TimeOutCallSel,TimeOutScroll," +
						"MakeTrace,AutoReplay,VideoPort,IntPort,DisplFlow,ValDate) "+
							"values ('{0}',{1},{2},{3},'{4}','{5}',{6},{7},'{8}',{9}) ", 
							Mode,TimeOut,TimeOutCallSel,TimeOutScroll,MakeTrace,AutoReplay,VideoPort,IntPort,DisplFlow,VDate);
                    string Cmd1 = string.Format("insert into SimulatorProcesses (ModName,ModPath,ModArgs,MultiAllowed,StartUp,ProcName,GroupNo)" +
                        " values ('videosrv','c:\\simulator\\allbin\\','{0} {1}','n','y','{2}','4')",
                        Area, Mode, PrName);
                    try
					{
						Connection.Connect(true,Area);
                        Connection.Execute(Cmd, false);
                        Connection.Execute(Cmd1, true);
                        DataGrid1.EditItemIndex = -1;
						BindDataGrid();				
						Add_off(e);
					}
					catch (Exception ){}
					finally
					{
						Connection.DisConnect();
					}
				}
			}
		}

// function called to make the footer controls visible.

		private void Add_on(DataGridCommandEventArgs e)
		{
            /*
			((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker3")).SelectedDate=DateTime.MinValue;
			((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker3")).NullDateText=null;
            */
            //cal1.SelectedDate = DateTime.MinValue;
			((TextBox) e.Item.FindControl("TimeOutFt")).Text="5000";
			((TextBox) e.Item.FindControl("TimeOutCallSelFt")).Text="5000";
			((TextBox) e.Item.FindControl("TimeOutScrollFt")).Text="200";
            /*
			((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker3")).Enabled =true;
			((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker3")).Visible =true;
			*/
             ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ModeFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ModeFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutCallSelFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutCallSelFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutScrollFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutScrollFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("MakeTraceFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("MakeTraceFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("AutoReplayFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("AutoReplayFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("VideoPortFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("VideoPortFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("IntPortFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("IntPortFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("DisplFlowFt"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("DisplFlowFt"))).Visible=true;

			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnAddRow"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnAddRow"))).Visible=false;

			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnCancel"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnCancel"))).Visible=true;

			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnConfirm"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnConfirm"))).Visible=true;
		}
		// function called to populate the path control, either in the footer or in the datagrid for in-situ edits.


	        public void MyPageChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
	        {
			DataGrid1.CurrentPageIndex = e.NewPageIndex;
			BindDataGrid();
	        }

		private void Add_off(DataGridCommandEventArgs e)
		{
            /*
			((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker3")).Enabled =false;
			((BasicFrame.WebControls.BasicDatePicker)e.Item.FindControl("BasicDatePicker3")).Visible =false;
            */
            //cal1.enable = false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ModeFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ModeFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutCallSelFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutCallSelFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutScrollFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("TimeOutScrollFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("MakeTraceFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("MakeTraceFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("AutoReplayFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("AutoReplayFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("VideoPortFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("VideoPortFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("IntPortFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("IntPortFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("DisplFlowFt"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("DisplFlowFt"))).Visible=false;

			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnAddRow"))).Enabled=true;
			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnAddRow"))).Visible=true;
			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnCancel"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnCancel"))).Visible=false;
			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnConfirm"))).Enabled=false;
			((System.Web.UI.WebControls.WebControl) (e.Item.FindControl("btnConfirm"))).Visible=false;
		}

		private void BindDataGrid()
		{
			DBAccess Connection= new DBAccess();
			String dbname=(String)HttpContext.Current.Session["CurrentDB"];
            TextBox1.Visible = false;
			try
			{
				Connection.Connect(false,dbname);
				String Cmd="select Mode,TimeOut,TimeOutCallSel,TimeOutScroll,MakeTrace,AutoReplay,VideoPort,"+
					"IntPort,DisplFlow,ValDate,UniqueKey from VideoConfig";
				DataSet ds = Connection.getDataSet(Cmd);
				DataGrid1.DataSource=ds;
				DataGrid1.DataBind();
				Connection.DisConnect();
			}
			catch (Exception ){}
			finally
			{
				Connection.DisConnect();
			}
		}

        protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
}
}
