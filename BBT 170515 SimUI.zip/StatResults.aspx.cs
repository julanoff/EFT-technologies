using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Xml;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//using Oracle.DataAccess.Client;

using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

using Obout.Grid;
using Obout.Interface;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.SimLog;

namespace Simulator
{
    public partial class StatResults : OboutInc.oboutAJAXPage
    {
        private static DataSet m_ds;
        private static DataTable m_dt;
        private static bool m_localDB = true;
        private static string m_table;
        private static string m_tbl_val;
        private static string m_sql;
        private static string m_srcconnstr;
        private static DataSet m_fields;
        DBAccess m_Connection;
	private OracleConnection m_OraConnection;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)	// Code to execute first time when the page is loaded.
            {
                Grid2.Visible = true;
		string Cmd = "select * from StatsSummary";
                BindDataGrid2(Cmd);
                string area = (String)HttpContext.Current.Session["CurrentDB"];
		if (area == "") 	// Kludge. if area is empty then this session timed out.
			Session["_timeout"] = "Y";	// Next statement will fail and Application_error in Global.asax will occur.

            }
        }
        
        protected void BindDataGrid2(string Cmd)
        {
            if (m_localDB)
            {
	            m_Connection = new DBAccess();
	            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
	            try
	            {
	                m_Connection.Connect(false, dbname);
	                DataSet ds = m_Connection.getDataSet(Cmd);
	                Grid2.DataSource = ds;
	                Grid2.DataBind();
	            }
	            catch (Exception e) { throw e; }
	            finally
	            {
	                m_Connection.DisConnect();
	            }
	    }
	    else
	    {
	        m_OraConnection.Close(); // in case it is left open for any reason
		m_OraConnection.Open(); 
		OracleCommand command = m_OraConnection.CreateCommand();
    		command.CommandText = Cmd;
		OracleDataReader reader;

		try { 
			reader = command.ExecuteReader(); 
	                Grid2.DataSource = reader;
	                Grid2.DataBind();
		    }
		catch (Exception ex) {throw ex; }

                command.Dispose();
	        m_OraConnection.Close();
	    }
            Grid2.Visible = true;

            return;
        }

        public string[] LoadRecord(string mid)
        {
            int NoElem = 4;
            string[] sRecord = new string[NoElem];
            string Cmd;
            string dbname = (String)HttpContext.Current.Session["CurrentDB"];


            Cmd = string.Format("select StepNo, Score, LogMessage, msgid " +
                 "from StatsDetail where msgid = '{0}'", mid);
            if (m_localDB)
            {
                m_Connection = new DBAccess();
                SqlConnection conn = new SqlConnection(m_Connection.GetConnString(dbname));
                conn.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand(Cmd, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    History.DataSource = reader;
                    History.DataBind();
                    UpdatePanel("HistPanel");
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    m_Connection.DisConnect();
                    conn.Dispose();
                }
            }
            else
            {
                m_OraConnection = new OracleConnection();
                m_OraConnection.ConnectionString = m_srcconnstr;
                m_OraConnection.Open();
                OracleCommand command = m_OraConnection.CreateCommand();
                command.CommandText = Cmd;
                OracleDataReader reader;

                try
                {
                    reader = command.ExecuteReader();
                    History.DataSource = reader;
                    History.DataBind();
                    UpdatePanel("HistPanel");
                }
                catch (Exception ex) { throw ex; }
                command.Dispose();
                m_OraConnection.Close();
                m_OraConnection.Dispose();

            }
            
            
            
            if (m_localDB)
            {
                DBAccess Connection = new DBAccess();
                Connection.Connect(false, dbname);
                Cmd = string.Format("select StepNo, Score, LogMessage, msgid " +
                     "from StatsDetail where msgid = '{0}'", mid);
                try
                {
                    if (Connection.OpenDataReader(Cmd))
                    {
                        if (Connection.SQLDR.Read())
                        {
                            for (int i = 0; i < NoElem; i++)
                            {
                                sRecord[i] = (Connection.SQLDR[i].ToString().Trim());
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    Connection.CloseDataReader();
                    Connection.DisConnect();
                }
            }
            else
            {
		        m_OraConnection=new OracleConnection();
		        m_OraConnection.ConnectionString = m_srcconnstr;
		        m_OraConnection.Open(); 
		        char [] dtype= new char[] {'s','s','s','s', 
		        's','s','s','s','s','d', 
		        's','n','s','n','s', 
		        'n','s','n','s','s',
		        'n','d','s','n','s',
		        'n','d','s','s','s','s','s','s',
		        's','s','s','s','s','s','s','s','s',
		        's','s','s','s','s','s','s','s','s','s',
		        's','s','s','s','s','s','s','s','s',
		        's','s','s','s','s','s','s','s','s','s',
		        's','s','s','s','s','s','s','s','s','s',
		        's','s','s','s','n','s','s','s','s',
		        's','s','s','n','s'};
// s- string, n - numeric, d -datetime      
                Cmd = string.Format("select " +
            "a.MSG_STATUS, a.PRIORITY, a.DEPARTMENT, a.OFFICE," +
            "a.ORIG_MT, a.MOP, a.ORIG_REFERENCE, a.LOCAL_REF, a.CHEQUE_NUMBER, a.ORIGVALUEDATE," +
            "a.ORIG_CURRENCY, a.ORIG_AMOUNT, a.ORIG_INSTRUCT_CURRENCY, a.ORIG_INSTRUCT_AMOUNT, a.OCMT_CURRENCY," +
            "a.OCMT_AMOUNT, a.ORIG_SENDER, a.BASE_AMOUNT, a.DEAL_BOOKED, a.DBCURRENCY," +
            "a.DBAMOUNT, a.DRVALUEDATE, a.DBCURRENCY, a.DBAMOUNT, a.CRCURRENCY," +
            "a.CRAMOUNT, a.VALUE_DATE, b.RFB, b.ORG_BIC, b.ORG_ID, b.ORG, b.ORG_ADDR1, b.ORG_ADDR2," +
            "b.ORG_ADDR3, b.OGB_BIC, b.OGB_ID, b.OGB, b.OGB_ADDR1, b.OGB_ADDR2, b.OGB_ADDR3, b.COR_BIC, b.COR_ID," +
            "b.COR, b.COR_ADDR1, b.COR_ADDR2, b.COR_ADDR3, b.RCR_BIC, b.RCR_ID, b.RCR, b.RCR_ADDR1, b.RCR_ADDR2, b.RCR_ADDR3," +
            "b.RCB_BIC, b.RCB_ID, b.RCB, b.RCB_ADDR1, b.RCB_ADDR2, b.RCB_ADDR3, b.SEND_ABA , b.SEND_NAME, b.REC_ABA ," +
            "b.REC_NAME, b.IBK_BIC, b.IBK_ID, b.IBK, b.IBK_ADDR1, b.IBK_ADDR2, b.IBK_ADDR3, b.BBK_BIC, b.BBK_ID, b.BBK," +
            "b.BBK_ADDR1, b.BBK_ADDR2, b.BBK_ADDR3, b.BNF_BIC, b.BNF_ID, b.BNF, b.BNF_ADDR1, b.BNF_ADDR2, b.BNF_ADDR3, b.ACC_NO," +
            "b.MP_DB_ACC, b.DB_FEE_ACC, b.DB_FEES , b.DB_FEES_CURRENCY, b.DR_RATE, b.CR_ACC_NO, b.MP_CR_ACC, b.CR_FEE_ACC, b.CR_FEES ," +
            "b.CR_FEES_CURRENCY, b.AGENT_FEES , b.AGENT_FEES_CURRENCY, b.CR_RATE, a.MID " +
            "from mif a, mtf1000 b where  a.mid = '{0}' and a.mid=b.mid", mid);
		        OracleCommand command = m_OraConnection.CreateCommand();
    		        command.CommandText = Cmd;
		        OracleDataReader reader;
		        try { reader = command.ExecuteReader(); }
		        catch (Exception ex) { throw ex; }
		        if (reader.Read()) 
		        { 
	                        for (int i = 0; i < NoElem; i++)
                                {
                                  if (dtype[i] == 'n')
                                    try { sRecord[i] = reader.GetDecimal(i).ToString(); }
                                    catch (Exception) { sRecord[i] = " "; }
                                  else
                                    if (dtype[i] == 'd')
                                    	try { sRecord[i] = reader.GetDateTime(i).ToString(); }
                                    	catch (Exception) { sRecord[i] = " "; }
                                    else
                                    	try { sRecord[i] = reader.GetString(i).ToString(); }
                                    	catch (Exception) { sRecord[i] = " "; }
                                }
		        }
		
                command.Dispose();
		        m_OraConnection.Close();
                m_OraConnection.Dispose();            
            }
            return sRecord;
        }
    }
}