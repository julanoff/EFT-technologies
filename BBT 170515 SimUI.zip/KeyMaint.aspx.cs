/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;

/*
	29-Sep-05	JR	Add the cancel button.
	30-Apr-06	JR	Prevent edits/deletes on the RGW master key table.
 * 
 * 07-Apr-07    JR  Generalized cleanup.
 * 19-Apr-07    JR  When deleting a results table, delete the two summary tables
 *                  that are created when the results are generated.
 * 
 * 29-Jul-08    JR  I've changed the name of the master idi key table to have 'idi'
 *                  as part of the name. This routine has to know about that new
 *                  naming convention.
 * 
 * 10-Aug-08    JR  The actual routine to copy one key table to another is now in
 *                  BackEndSubs. I need to be able to call it from the compare function
 *                  in case somebody wants to reinitialize the default key tables.
 * 16-Nov-13    JN  Disable ALL functionality for key tables. Use new CmpKeyMnt
 * 
 */
namespace Simulator
{
    /// <summary>
    /// Summary description for KeyMaint.
    /// </summary>
    public partial class KeyMaint : System.Web.UI.Page
    {
        protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
        protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator2;
        private Hashtable m_hashTable;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            // Put user code to initialize the page here
            if (!Page.IsPostBack)
            {
                TmpTableName.Text = string.Empty;
                Description.Text = string.Empty;
                NewTableName.Text = string.Empty;
                EverybodyOff();
                MainWindowOn();
            }
            if (!ClientScript.IsClientScriptBlockRegistered("confirm"))
            {
                string jsConfirm = @"<script language='javascript'> " +
                    "function confirm_delete() " +
                    "{ return (confirm('Are you sure you want to delete this item?')); }" +
                    "</script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "confirm", jsConfirm);
            }
        }

        protected void NewTableClick(object sender, System.EventArgs e)
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(true, Area);
            try
            {
                string Cmd = "select Description from SimTableList where TableType = 'Comparekeys'";
                if (Connection.OpenDataReader(Cmd))
                {
                    StartingTableDropDown.DataSource = Connection.SQLDR;
                    StartingTableDropDown.DataTextField = "Description";
                    StartingTableDropDown.DataValueField = "Description";
                    StartingTableDropDown.DataBind();
                }
            }
            catch (Exception) { }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
            TmpTableName.Text = string.Empty;
            Description.Text = string.Empty;
            NewTableName.Text = string.Empty;
            RequiredFieldValidator1.Enabled = false;
            RequiredFieldValidator2.Enabled = false;

            StartingTableLabel.Visible = true;
            //TableLabel.Visible = true;
            Description.Visible = true;

            StartingTableDropDown.Visible = true;
            ActionsRadioButton.Visible = true;
            DescLabel.Visible = true;
            NewTableName.Visible = true;
            NewTableNameLabel.Visible = true;
            //doNewTableButton.Visible = true;
            EditDoneButton.Visible = false;
            UserMsg.Visible = false;

            RequiredFieldValidator1.Enabled = false;
            NewTableName.Visible = false;
            NewTableNameLabel.Visible = false;
            CancelButton.Visible = true;
            CancelButton.Enabled = true;
            showActionsRadioList();
        }

        protected void NewTable()
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(true, Area);
            try
            {
                string Cmd = "select Description from SimTableList where TableType = 'Comparekeys'";
                if (Connection.OpenDataReader(Cmd))
                {
                    StartingTableDropDown.DataSource = Connection.SQLDR;
                    StartingTableDropDown.DataTextField = "Description";
                    StartingTableDropDown.DataValueField = "Description";
                    StartingTableDropDown.DataBind();
                }
            }
            catch (Exception) { }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
            TmpTableName.Text = string.Empty;
            Description.Text = string.Empty;
            NewTableName.Text = string.Empty;
            RequiredFieldValidator1.Enabled = false;
            RequiredFieldValidator2.Enabled = false;

            StartingTableLabel.Visible = true;
            Description.Visible = true;
            StartingTableDropDown.Visible = true;
            ActionsRadioButton.Visible = true;
            DescLabel.Visible = true;
            NewTableName.Visible = true;
            NewTableNameLabel.Visible = true;
            EditDoneButton.Visible = false;
            //EditDoneButton.Text = "Create New Table";
            NewTableButton.Visible = true;
            UserMsg.Visible = false;

            RequiredFieldValidator1.Enabled = false;
            NewTableName.Visible = false;
            NewTableNameLabel.Visible = false;
            CancelButton.Visible = true;
            CancelButton.Enabled = true;
            showActionsRadioList();
        }

        protected void doNewTableButtonClick(object sender, System.EventArgs e)
        {
            string NewTableDesc = Description.Text.TrimEnd();

            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(true, Area);

            UserMsg.Visible = false;
            ErrorTextBox.Visible = false;
            try
            {
                string Cmd = string.Format("select Count(*) from SimTableList where TableType = 'Comparekeys' and Description like '{0}'",
                    NewTableDesc);
                if (Connection.OpenDataReader(Cmd))
                {
                    Connection.SQLDR.Read();
                    int i = Connection.SQLDR.GetInt32(0);
                    if (i > 0)
                    {
                        //UserMsg.Text = string.Format("There already is a table by that name. Use Edit instead.");
                        //UserMsg.Visible = true;
                        ErrorTextBox.Text = string.Format("There already is a table by that name. \r Use Edit instead.");
                        ErrorTextBox.Visible = true;
                        ErrorTextBox.Width = 400;
                        ErrorTextBox.Font.Bold = true;
                    }
                }
            }
            catch { }

            if (!ErrorTextBox.Visible)
            {
                if (Regex.IsMatch(NewTableDesc, "^[ a-zA-Z0-9._-]+$"))
                {
                    NewTableFieldsOff();
                    EditDoneButton.Visible = true;
                    MakeTmpAndDisplay();
                    NewTableButton.Visible = false;
                    EditDoneButton.Text = "Commit New Table";
                }
                else
                {
                    if (NewTableDesc.Length == 0)
                        UserMsg.Text = string.Format("Key Table Description is required.");
                    else
                        UserMsg.Text = string.Format("Invalid Description: must be alphanumeric");
                    UserMsg.Visible = true;
                }
            }
        }

        protected void CancelButtonClick(object sender, System.EventArgs e)
        {
            // They're punting on some sort of action. Let's whack any tmp key
            // tables that have been created. Maybe they've made one, maybe not,
            // but let's go for it. 
            String TmpTable = (String)HttpContext.Current.Session["myTmpTable"];
            try
            {
                if (TmpTable.Length > 0)
                {
                    String Area = (String)HttpContext.Current.Session["CurrentDB"];
                    DBAccess dbWriter = new DBAccess();
                    try
                    {
                        dbWriter.Connect(true, Area);
                        BackEndSubs util = new BackEndSubs();
                        util.DeleteTable(TmpTable, dbWriter);
                        HttpContext.Current.Session["myTmpTable"] = string.Empty;
                    }
                    catch (Exception) { }
                    finally
                    {
                        dbWriter.DisConnect();
                    }
                }
            }
            catch { }
            EverybodyOff();
            MainWindowOn();
        }

        private void MakeTmpAndDisplay()
        {
            string tmpTable = string.Empty;
            string StartingTableDesc = StartingTableDropDown.SelectedItem.Value.TrimEnd();
            string NewTable = string.Empty;
            string NewTableDesc = Description.Text.TrimEnd();

            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            tmpTable = makeNewKeyTable(StartingTableDesc, NewTableDesc, Area);
            DBAccess Connection = new DBAccess();
            DBAccess Conn1 = new DBAccess();
            try
            {
                Connection.Connect(true, Area);
                Conn1.Connect(true, Area);
                string Cmd = string.Empty;

                Cmd = string.Format("select  xmlset,cmpkey,include,0 as setcheck from {0} " +
                    " where include ='N' union select xmlset,cmpkey,include,1 as setcheck from {0} " +
                    " where include ='Y' order by xmlset,cmpkey", tmpTable);
                FileProperties.DataSource = Connection.getDataSet(Cmd);
                FileProperties.DataBind();
            }
            catch (Exception) { }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
                Conn1.DisConnect();
            }
        }

        protected void EditTableClick(object sender, System.EventArgs e)
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess Connection = new DBAccess();
            try
            {
                Connection.Connect(true, Area);

                string Cmd = "select Description from SimTableList where TableType = 'Comparekeys'" +
                    " and TableName != 'MasterIdiCompareKeys' and TableName != 'MasterRGWCompareKeys'";
                if (Connection.OpenDataReader(Cmd))
                {
                    StartingTableDropDown.DataSource = Connection.SQLDR;
                    StartingTableDropDown.DataTextField = "Description";
                    StartingTableDropDown.DataValueField = "Description";
                    StartingTableDropDown.DataBind();
                }
                int n = StartingTableDropDown.Items.Count;
                if (n > 0)
                {
                    StartingTableLabel.Visible = true;
                    StartingTableDropDown.Visible = true;
                    StartingTableLabel.Text = "Table to edit";
                    RequiredFieldValidator1.Enabled = false;
                    RequiredFieldValidator2.Enabled = false;
                    doEditButton.Visible = true;
                }
                else
                {
                    RequiredFieldValidator1.Enabled = false;
                    RequiredFieldValidator2.Enabled = false;
                    UserMsg.Text = string.Format("No key tables to edit");
                    UserMsg.Visible = true;
                }
                CancelButton.Visible = true;
            }
            catch (Exception) { }
            finally
            {
                Connection.DisConnect();
            }

        }

        protected void EditTable()
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess Connection = new DBAccess();
            try
            {
                Connection.Connect(true, Area);

                string Cmd = "select Description from SimTableList where TableType = 'Comparekeys'" +
                    " and TableName != 'MasterIdiCompareKeys' and TableName != 'MasterRGWCompareKeys'";
                if (Connection.OpenDataReader(Cmd))
                {
                    StartingTableDropDown.DataSource = Connection.SQLDR;
                    StartingTableDropDown.DataTextField = "Description";
                    StartingTableDropDown.DataValueField = "Description";
                    StartingTableDropDown.DataBind();
                }
                int n = StartingTableDropDown.Items.Count;
                if (n > 0)
                {
                    StartingTableLabel.Visible = true;
                    StartingTableDropDown.Visible = true;
                    StartingTableLabel.Text = "Table to edit";
                    RequiredFieldValidator1.Enabled = false;
                    RequiredFieldValidator2.Enabled = false;
                    doEditButton.Visible = true;
                }
                else
                {
                    RequiredFieldValidator1.Enabled = false;
                    RequiredFieldValidator2.Enabled = false;
                    UserMsg.Text = string.Format("No key tables to edit");
                    UserMsg.Visible = true;
                }
                CancelButton.Visible = true;
            }
            catch (Exception) { }
            finally
            {
                Connection.DisConnect();
            }

        }

        protected void doEditButtonClick(object sender, System.EventArgs e)
        {
            string Desc = string.Empty;
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess C = new DBAccess();
            try
            {
                C.Connect(false, Area);
                string TableToEdit = StartingTableDropDown.SelectedItem.Value.TrimEnd();
                string Cmd = string.Format("select * from SimTableList where Description like '{0}' " +
                    " and TableType = 'CompareKeys'", TableToEdit);
                if (C.OpenDataReader(Cmd))
                {
                    C.SQLDR.Read();
                    Desc = C.SQLDR["Description"].ToString().TrimEnd();
                }
                C.DisConnect();
                NewTableName.Text = TableToEdit;
                Description.Text = Desc;

                NewTableFieldsOff();
                EditDoneButton.Visible = true;
                doEditButton.Visible = false;
                StartingTableLabel.Visible = false;

                MakeTmpAndDisplay();
                hideActionsRadioList();
                EditDoneButton.Text = "Commit Edit";
            }
            catch (Exception) { }
            finally
            {
                C.DisConnect();
                C.CloseDataReader();
            }
        }
      

        protected void doTableMaintClick(object sender, System.EventArgs e)
        {
            RequiredFieldValidator1.Visible = false;
            RequiredFieldValidator2.Visible = false;
            RequiredFieldValidator1.Enabled = false;
            RequiredFieldValidator2.Enabled = false;

            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess C = new DBAccess();
            DBAccess dbWrt = new DBAccess();
            try
            {
                C.Connect(false, Area);
                String Cmd = string.Empty;
                dbWrt.Connect(true, Area);
                int n;

                string Function = ActionsRadioButton.SelectedItem.Text.TrimEnd();
                switch (Function)
                {
/*
                    case "Edit Key Table":
                        EditTable();
                        doTableMaintButton.Visible = false;
                        ActionsRadioButton.Visible = false;
                        break;

                    case "Add New Key Table":
                        NewTable();
                        doTableMaintButton.Visible = false;
                        ActionsRadioButton.Visible = false;
                        break;

                    case "Delete Tmp Tables":
                        int i = 0;
                        BackEndSubs util = new BackEndSubs();
                        Cmd = "Select * from SimTableList where TableType = 'CompareKeys'";
                        if (C.OpenDataReader(Cmd))
                        {
                            while (C.SQLDR.Read())
                            {
                                string TableName = C.SQLDR["TableName"].ToString().TrimEnd();
                                if (TableName.StartsWith("Tmp"))
                                {
                                    util.DeleteTable(TableName, dbWrt);
                                    i++;
                                }
                            }
                        }
                        C.DisConnect();
                        dbWrt.DisConnect();
                        if (i > 0)
                            UserMsg.Text = string.Format("Deleted {0} Tmp key tables", i);
                        else
                            UserMsg.Text = string.Format("No Tmp key tables to delete");
                        UserMsg.Visible = true;
                        HttpContext.Current.Session["DeleteTable"] = "Tmp";
                        break;
                    case "Delete Key Tables":
                        Cmd = "Select * from SimTableList where " +
                            " TableType = 'CompareKeys' and TableName != 'MasterIdiCompareKeys' " +
                            "and TableName != 'MasterRGWCompareKeys'";

                        if (C.OpenDataReader(Cmd))
                        {
                            TableNameDropDown.DataSource = C.SQLDR;
                            TableNameDropDown.DataTextField = "Description";
                            TableNameDropDown.DataValueField = "Description";
                            TableNameDropDown.DataBind();
                        }
                        n = TableNameDropDown.Items.Count;
                        if (n > 0)
                        {
                            hideActionsRadioList();
                            DeleteTableButton.Visible = true;
                            DeleteTableButton.Attributes.Add("onclick", "return confirm_delete();");
                            StartingTableLabel.Visible = false;
                            StartingTableDropDown.Visible = false;
                            doTableMaintButton.Visible = false;
                            TableNameDropDown.Visible = true;
                            UserMsg.Visible = false;
                            C.DisConnect();
                            HttpContext.Current.Session["DeleteTable"] = "Key";
                        }
                        else
                        {
                            UserMsg.Text = string.Format("No key tables to delete");
                            UserMsg.Visible = true;
                        }
                        break;
*/
                    case "Delete Results Tables":
                        Cmd = "Select * from SimTableList where " +
                            " TableType = 'CompareResults'";

                        if (C.OpenDataReader(Cmd))
                        {
                            TableNameDropDown.DataSource = C.SQLDR;
                            TableNameDropDown.DataTextField = "Description";
                            TableNameDropDown.DataValueField = "Description";
                            TableNameDropDown.DataBind();
                        }
                        n = TableNameDropDown.Items.Count;
                        if (n > 0)
                        {
                            hideActionsRadioList();
                            DeleteTableButton.Visible = true;
                            DeleteTableButton.Attributes.Add("onclick", "return confirm_delete();");
                            StartingTableLabel.Visible = false;
                            StartingTableDropDown.Visible = false;
                            doTableMaintButton.Visible = false;
                            TableNameDropDown.Visible = true;
                            UserMsg.Visible = false;
                            C.DisConnect();
                            HttpContext.Current.Session["DeleteTable"] = "Results";
                        }
                        else
                        {
                            UserMsg.Text = string.Format("No Results tables to delete");
                            UserMsg.Visible = true;
                        }
                        break;

                    case "Delete Compare Tables":
                        Cmd = "Select * from SimTableList where " +
                            " TableType = 'Compare'";

                        if (C.OpenDataReader(Cmd))
                        {
                            TableNameDropDown.DataSource = C.SQLDR;
                            TableNameDropDown.DataTextField = "Description";
                            TableNameDropDown.DataValueField = "Description";
                            TableNameDropDown.DataBind();
                        }
                        n = TableNameDropDown.Items.Count;
                        if (n > 0)
                        {
                            hideActionsRadioList();
                            DeleteTableButton.Visible = true;
                            DeleteTableButton.Attributes.Add("onclick", "return confirm_delete();");
                            StartingTableLabel.Visible = false;
                            StartingTableDropDown.Visible = false;
                            doTableMaintButton.Visible = false;
                            TableNameDropDown.Visible = true;
                            UserMsg.Visible = false;
                            C.DisConnect();
                            HttpContext.Current.Session["DeleteTable"] = "Compare";
                        }
                        else
                        {
                            UserMsg.Text = string.Format("No Compare tables to delete");
                            UserMsg.Visible = true;
                        }
                        break;

                }
            }
            catch (Exception) { }
            finally
            {
                C.CloseDataReader();
                dbWrt.CloseDataReader();
                C.DisConnect();
                dbWrt.DisConnect();
            }
        }

        protected void DeleteTableClick(object sender, System.EventArgs e)
        {
            string TableDesc = TableNameDropDown.SelectedItem.Text.TrimEnd();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            String Cmd = string.Empty;
            DBAccess C = new DBAccess();
            DBAccess dbWrt = new DBAccess();
            try
            {
                dbWrt.Connect(true, Area);
                C.Connect(false, Area);
                string TableType = string.Empty;
                string TableName = string.Empty;
                string tabletype = (String)HttpContext.Current.Session["DeleteTable"];
                switch (tabletype)
                {
                    case "Key":
                        TableType = "CompareKeys";
                        break;
                    case "Compare":
                        TableType = "Compare";
                        break;
                    case "Results":
                        TableType = "CompareResults";
                        break;
                }

                BackEndSubs util = new BackEndSubs();
                Cmd = string.Format("Select * from SimTableList where TableType = '{0}' and " +
                    "Description like '{1}'", TableType, TableDesc);
                if (C.OpenDataReader(Cmd))
                {
                    while (C.SQLDR.Read())
                    {
                        TableName = C.SQLDR["TableName"].ToString().TrimEnd();
                        util.DeleteTable(TableName, dbWrt);
                        UserMsg.Text = string.Format("Deleted table: {0}", TableDesc);
                    }
                }

                if (tabletype.Equals("Results"))
                {
                    TableType = "CompareSummary";
                    Cmd = string.Format("Select * from SimTableList where TableType = '{0}' and " +
                    "Description like '{1}'", TableType, TableDesc);
                    if (C.OpenDataReader(Cmd))
                    {
                        while (C.SQLDR.Read())
                        {
                            TableName = C.SQLDR["TableName"].ToString().TrimEnd();
                            util.DeleteTable(TableName, dbWrt);
                            UserMsg.Text = string.Format("Deleted table: {0}", TableDesc);
                        }
                    }

                    TableType = "CompareMetaSummary";
                    Cmd = string.Format("Select * from SimTableList where TableType = '{0}' and " +
                    "Description like '{1}'", TableType, TableDesc);
                    if (C.OpenDataReader(Cmd))
                    {
                        while (C.SQLDR.Read())
                        {
                            TableName = C.SQLDR["TableName"].ToString().TrimEnd();
                            util.DeleteTable(TableName, dbWrt);
                            UserMsg.Text = string.Format("Deleted table: {0}", TableDesc);
                        }
                    }
                }

                C.DisConnect();

                UserMsg.Visible = true;
                //
                // Let's refresh the list in the dropdown box to reflect the fact
                // that we just deleted one of the tables in the list.
                //
                String type = (String)HttpContext.Current.Session["DeleteTable"];
                C.Connect(false, Area);
                switch (type)
                {
                    case "Results":
                        Cmd = "Select * from SimTableList where  TableType = 'CompareResults'";

                        if (C.OpenDataReader(Cmd))
                        {
                            TableNameDropDown.DataSource = C.SQLDR;
                            TableNameDropDown.DataTextField = "Description";
                            TableNameDropDown.DataValueField = "Description";
                            TableNameDropDown.DataBind();
                        }
                        C.DisConnect();
                        break;

                    case "Compare":
                        Cmd = "Select * from SimTableList where  TableType = 'Compare'";
                        if (C.OpenDataReader(Cmd))
                        {
                            TableNameDropDown.DataSource = C.SQLDR;
                            TableNameDropDown.DataTextField = "Description";
                            TableNameDropDown.DataValueField = "Description";
                            TableNameDropDown.DataBind();
                        }
                        C.DisConnect();
                        HttpContext.Current.Session["DeleteTable"] = "Compare";
                        break;

                    case "Key":
                        Cmd = "Select * from SimTableList where " +
                            " TableType = 'CompareKeys' and TableName != 'MasterIdiCompareKeys'" +
                            " TableName != 'MasterRgwCompareKeys'";

                        if (C.OpenDataReader(Cmd))
                        {
                            TableNameDropDown.DataSource = C.SQLDR;
                            TableNameDropDown.DataTextField = "Description";
                            TableNameDropDown.DataValueField = "Description";
                            TableNameDropDown.DataBind();
                        }
                        C.DisConnect();
                        break;
                }
                int n = TableNameDropDown.Items.Count;
                if (n <= 0)
                {
                    EverybodyOff();
                    UserMsg.Visible = true;
                    ErrorTextBox.Text = string.Format("No more {0} tables", type);
                    ErrorTextBox.Visible = true;
                    //StartingTableDropDown.Visible = true;
                    //StartingTableLabel.Text = "Function";
                    //StartingTableLabel.Visible = true;
                    doTableMaintButton.Visible = true;
                    showActionsRadioList();
                }
                CancelButton.Visible = true;
            }
            catch (Exception) { }
            finally
            {
                C.CloseDataReader();
                dbWrt.CloseDataReader();
                C.DisConnect();
                dbWrt.DisConnect();
            }
        }



        protected void EditDoneClick(object sender, System.EventArgs e)
        {
            EverybodyOff();
            FileProperties.Visible = false;
            UpdatePropertiesTable();
            EditDoneButton.Visible = false;
            string NewTable = NewTableName.Text.TrimEnd();
            string NewTableDesc = Description.Text.TrimEnd();
            UserMsg.Text = string.Format("Created/edited new keys table: {0}", NewTableDesc);
            UserMsg.Visible = true;
            showActionsRadioList();
        }

        private void NewTableFieldsOn()
        {
            StartingTableLabel.Visible = true;
            Description.Visible = true;
            StartingTableDropDown.Visible = true;
            DescLabel.Visible = true;
            NewTableName.Visible = true;
            NewTableNameLabel.Visible = true;
        }
        private void NewTableFieldsOff()
        {
            StartingTableLabel.Visible = false;
            Description.Visible = false;
            StartingTableDropDown.Visible = false;
            DescLabel.Visible = false;
            NewTableName.Visible = false;
            NewTableNameLabel.Visible = false;
            TableNameDropDown.Visible = false;
            DeleteTableButton.Visible = false;
            TableNameLabel.Visible = false;
        }
        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion

        private void DataGrid1_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            //doNewTableButton.Visible = true;
        }

        private void UpdatePropertiesTable()
        {
            PropertyHashTable();
            string NewTable = NewTableName.Text.TrimEnd();
            DBAccess writeConnection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                writeConnection.Connect(false, dbname);
                foreach (DataGridItem item in FileProperties.Items)
                {
                    CheckBox ChkBxItem = (CheckBox)item.FindControl("CheckBox1");
                    string Key = item.Cells[1].Text.Trim() + item.Cells[2].Text.Trim();
                    string Checked = (String)m_hashTable[Key];
                    string setCmd = "";
                    if (ChkBxItem.Checked && Checked.Equals("N"))
                        setCmd = string.Format("update {2} set include='Y' where xmlset='{0}' " +
                            " and cmpkey='{1}'", item.Cells[1].Text.Trim(),
                            item.Cells[2].Text.Trim(),
                            NewTable);
                    else
                        if (!ChkBxItem.Checked && Checked.Equals("Y"))
                            setCmd = string.Format("update {2} set include='N' where xmlset='{0}' " +
                                "and cmpkey='{1}'", item.Cells[1].Text.Trim(),
                                item.Cells[2].Text.Trim(),
                                NewTable);
                    if (setCmd.Length != 0)
                        writeConnection.Execute(setCmd, true);
                }
            }
            catch (Exception) { }
            finally
            {
                writeConnection.DisConnect();
            }
        }

        private void PropertyHashTable()
        {
            DBAccess dbWriter = new DBAccess();
            DBAccess readConnection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];

            try
            {
                dbWriter.Connect(true, dbname);
                readConnection.Connect(false, dbname);

                string idiKey, xmlSet, cmpKey, include, OrdinalType;

                m_hashTable = new Hashtable();

                string NewTable = NewTableName.Text.TrimEnd();
                string NewTableDesc = Description.Text.TrimEnd();
                string TmpTable = TmpTableName.Text.TrimEnd();
                BackEndSubs util = new BackEndSubs();
                util.MakeNewTable(NewTable, "CompareKeys", dbWriter, dbname);
                util.UpdateTableDescription(NewTable, NewTableDesc, dbWriter);

                String Cmd = string.Format("select * from {0}", TmpTable);
                if (readConnection.OpenDataReader(Cmd))
                {
                    while (readConnection.SQLDR.Read())
                    {
                        idiKey = readConnection.SQLDR["idikey"].ToString().TrimEnd();
                        xmlSet = readConnection.SQLDR["xmlset"].ToString().TrimEnd();
                        cmpKey = readConnection.SQLDR["cmpkey"].ToString().TrimEnd();
                        include = readConnection.SQLDR["include"].ToString().TrimEnd();
                        OrdinalType = readConnection.SQLDR["OrdinalType"].ToString().TrimEnd();
                        Cmd = string.Format("Insert into {0} values ('{1}', '{2}', '{3}', '{4}', '{5}')",
                            NewTable, idiKey, cmpKey, xmlSet, include, OrdinalType);
                        dbWriter.Execute(Cmd, true);
                    }
                }
                readConnection.CloseDataReader();
                util.DeleteTable(TmpTable, dbWriter);
                HttpContext.Current.Session["myTmpTable"] = string.Empty;
                dbWriter.DisConnect();


                Cmd = string.Format("select xmlset,cmpkey,include from {0}", NewTable);
                if (readConnection.OpenDataReader(Cmd))
                {
                    while (readConnection.SQLDR.Read())
                    {
                        xmlSet = readConnection.SQLDR["xmlset"].ToString().TrimEnd();
                        cmpKey = readConnection.SQLDR["cmpkey"].ToString().TrimEnd();
                        include = readConnection.SQLDR["include"].ToString().TrimEnd();
                        m_hashTable.Add(xmlSet + cmpKey, include);
                    }
                }
            }
            catch (Exception) { }
            finally
            {
                readConnection.DisConnect();
                dbWriter.DisConnect();
            }
        }
        protected bool isChecked(object Check)
        {
            if ((Int32)Check == 1)
                return true;
            return false;
        }
        private void EverybodyOff()
        {
            ActionsRadioButton.Visible = false;
            StartingTableDropDown.Visible = false;
            TableDropDown.Visible = false;
            Description.Visible = false;
            StartingTableLabel.Visible = false;
            TableLabel.Visible = false;
            DescLabel.Visible = false;
            NewTableName.Visible = false;
            NewTableNameLabel.Visible = false;
            RequiredFieldValidator1.Visible = false;
            RequiredFieldValidator2.Visible = false;
            FileProperties.Visible = false;
            EditDoneButton.Visible = false;
            TmpTableName.Visible = false;
            UserMsg.Visible = false;
            doEditButton.Visible = false;
            doTableMaintButton.Visible = false;
            DeleteTableButton.Visible = false;
            TableNameDropDown.Visible = false;
            hideActionsRadioList();
            NewTableButton.Visible = false;
        }

        private void showActionsRadioList()
        {
            ActionsRadioButton.Visible = true;
            doTableMaintButton.Visible = true;
        }

        private void hideActionsRadioList()
        {
            ActionsRadioButton.Visible = false;
            doTableMaintButton.Visible = false;
        }


        private void MainWindowOn()
        {
            CancelButton.Visible = false;
            CancelButton.Visible = true;
            doTableMaintButton.Visible = true;

            ErrorTextBox.Visible = false;

            ArrayList values = new ArrayList();
          //  values.Add("Add New Key Table");
          //  values.Add("Edit Key Table");
          //  values.Add("Delete Tmp Tables");
          //  values.Add("Delete Key Tables");
            values.Add("Delete Compare Tables");
            values.Add("Delete Results Tables");

            ActionsRadioButton.RepeatColumns = 1;
            ActionsRadioButton.DataSource = values;
            ActionsRadioButton.DataBind();
            ActionsRadioButton.Visible = true;
            HelpTextBox.Visible = false;
        }

        public string makeNewKeyTable(string StartingTableDesc, string NewTableDesc, string area)
        {
            string TmpTable = string.Empty;
            DBAccess Connection = new DBAccess();
            DBAccess Conn1 = new DBAccess();
            try
            {
                Connection.Connect(true, area);
                Conn1.Connect(true, area);
                string Cmd = string.Empty;

                Cmd = string.Format("select * from SimTableList where TableType = 'CompareKeys' and " +
                    " Description like '{0}'", StartingTableDesc);
                string StartingTable = string.Empty;
                if (Connection.OpenDataReader(Cmd))
                {
                    while (Connection.SQLDR.Read())
                    {
                        StartingTable = Connection.SQLDR["TableName"].ToString().TrimEnd();
                    }
                }
                Connection.CloseDataReader();

                //
                // See if there's already a table in there with this description. If so,
                // we'll overwrite that table.
                //
                string NewTable = string.Empty;
                //string NewTableDesc = Description.Text.TrimEnd();
                Cmd = string.Format("select * from SimTableList where TableType = 'CompareKeys' and " +
                    " Description like '{0}'", NewTableDesc);
                if (Connection.OpenDataReader(Cmd))
                {
                    while (Connection.SQLDR.Read())
                    {
                        NewTable = Connection.SQLDR["TableName"].ToString().TrimEnd();
                    }
                }
                Connection.CloseDataReader();
                if (NewTable.Length == 0)
                {
                    NewTable = string.Format("CompareKeys_{0:d2}{1:d2}{2:d2}{3:d2}{4:d2}",
                        DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour,
                        DateTime.Now.Minute, DateTime.Now.Second);
                }

                NewTableName.Text = NewTable;

                TmpTable = "Tmp" + Convert.ToString(DateTime.Now.Ticks);
                TmpTableName.Text = TmpTable;

                HttpContext.Current.Session["myTmpTable"] = TmpTable;
                BackEndSubs util = new BackEndSubs();
                util.copyKeyTable(StartingTable, TmpTable, NewTableDesc, area);
               
                FileProperties.Visible = true;

                Connection.CloseDataReader();
                return TmpTable;
            }
            catch { return ""; }
        }
    }
}
