/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using System.Threading;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace Simulator
{
	/// <summary>
	/// Summary description for ProcessList.
	/// </summary>
	public partial class ProcessList : System.Web.UI.Page
	{
        private int SelectedGroup
        {
            get
            {
                object group = Session["SelectedGroup"];
                if (group != null)
                    return (int)group;
                return 0;

            }
            set
            {
                Session["SelectedGroup"] = value;
            }
        }

        protected void Page_Load(object sender, System.EventArgs e)
        {
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
	    String GrList="GroupList_" + dbname;
            List <ListItem> groups = (List <ListItem>)Cache[GrList];
            if (groups == null)
              {
                  string SimServerHost = null;

                  SimServerHost = System.Environment.GetEnvironmentVariable("SIMDBHOST");
                  //  Console.Write("Our host: " + SimServerHost);
                  if (SimServerHost == null)
                  {
                      SimServerHost = "(local)";
                  }
                  string connectString = string.Format("server={0};Trusted_Connection=yes;database=Simulator_{1}", SimServerHost, dbname);
                  using (SqlConnection dbConnection = new SqlConnection(connectString))
                  {
                      dbConnection.Open();
                      string sqlCommand = "select 'All Groups' ,0 as GroupNo from   ProcessGroup union select GroupName,GroupNo from ProcessGroup order by GroupNo";
                      using (SqlCommand cmd = new SqlCommand(sqlCommand,dbConnection))
                      {
                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                groups=new List <ListItem> ();
                                while(dr.Read())
                                {
                                    string GroupName=dr.GetString(0).Trim();
                                    string GroupNo=dr.GetInt32(1).ToString();
                                    ListItem ls = new ListItem(GroupName, GroupNo);
                                    groups.Add(ls);
                                }
                                Cache[GrList] = groups;
                            }
                      }
                  }
              }
            if (!Page.IsPostBack)         // if page loading (not responding to post)
            {
                foreach (ListItem li in groups)
                    SelGroup.Items.Add(li);
                SelGroup.SelectedIndex = SelectedGroup;
                SelGroup.DataBind();
                ShowProcessList();
           }
        }


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
		}
		#endregion


        protected void StartAll_Click(object sender, System.EventArgs e)
        {
            if (DataGrid1.SelectedRecords != null)
            {
                foreach (Hashtable oRecord in DataGrid1.SelectedRecords)
                {
                    Do_command("Start", oRecord["ProcessName"].ToString(), oRecord["Status"].ToString());
                }
            }
        }
        protected void Restart_Click(object sender, System.EventArgs e)
        {
            if (DataGrid1.SelectedRecords != null)
            {
                foreach (Hashtable oRecord in DataGrid1.SelectedRecords)
                {
                    Do_command("Restart", oRecord["ProcessName"].ToString(), oRecord["Status"].ToString());
                }
            }
        }

        private void Do_command(string CommandName, string ProcessName, string Status)
        {
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
            if (procMgr != null)
            {
                if (CommandName == "Restart")
                {
                    if (Status.Equals("InActive") || Status.Equals("Exited"))
                        procMgr.startProcess(dbname, ProcessName);
                    else
                    {
                        procMgr.stopProcess(dbname, ProcessName);
                        System.Threading.Thread.Sleep(500);
                        procMgr.startProcess(dbname, ProcessName);
                    }
                }
                else
                {
                    procMgr.toggleProcess(dbname, ProcessName);
                }
            }
            ShowProcessList();
        }
        
        protected void StartSel_click(object sender, System.EventArgs e)
		{
			IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr),"tcp://localhost:21005/ProcMgr");
			if(procMgr !=null)
			{
				String dbname=(String)HttpContext.Current.Session["CurrentDB"];
				procMgr.startSelProcesses(dbname,SelectedGroup);
			}
			ShowProcessList();
		}

		protected void StopAll_Click(object sender, System.EventArgs e)
		{
			IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr),"tcp://localhost:21005/ProcMgr");
			if(procMgr !=null)
			{
				String dbname=(String)HttpContext.Current.Session["CurrentDB"];
				procMgr.stopAllProcesses(dbname);
			}
			ShowProcessList();
		}

		protected void StopSel_click(object sender, System.EventArgs e)
		{
			IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr),"tcp://localhost:21005/ProcMgr");
			if(procMgr !=null)
			{
				String dbname=(String)HttpContext.Current.Session["CurrentDB"];
				procMgr.stopSelProcesses(dbname,SelectedGroup);
			}
			ShowProcessList();
		}

		private void ShowProcessList()
		{
			IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr),"tcp://localhost:21005/ProcMgr");
			if(procMgr !=null)
			{
				String dbname=(String)HttpContext.Current.Session["CurrentDB"];
				IListSource ds=procMgr.getProcessList(dbname,SelectedGroup);
				DataGrid1.DataSource= ds;
				DataGrid1.DataBind();
			}
		}

		protected void Refresh_Click(object sender, System.EventArgs e)
		{
			String dbname=(String)HttpContext.Current.Session["CurrentDB"];
//			m_Processes=new Processes(dbname);
            ShowProcessList();
        }

        protected void SelGroup_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            SelectedGroup = int.Parse(SelGroup.SelectedItem.Value);
            //                (int)groups[SelGroup.SelectedItem.Value.ToString()];
            DataGrid1.CurrentPageIndex = 0;
            ShowProcessList();
        }
    }
}

