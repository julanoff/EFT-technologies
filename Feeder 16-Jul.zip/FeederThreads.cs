/*                                                             
 Copyright (c) 1999 - 2005 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Diagnostics;
using Simulator.DBLibrary;
using System.Net;
using System.Threading;
using Simulator.FormatersLib;
using Simulator.BackEndSubLib;
using Simulator.SimLog;
/*
 
 */
namespace FeederThreads
{

    public class Feeder
    {
        /// <summary>
        /// This is the feeder. It reads msgs from the FDR_line_name table.
        /// The control table for it is FeederControl table. It indicates if the line is
        /// in the timely delivery mode. The user can Stop/Start the feeder.
        /// The control table has Max Number of msgs per transaction.
        /// The logic:
        /// 1. Get an argument with the Line Name
        /// 2. Access the FeederControl table to get all info and read it AFTER each 
        ///    processed message.
        /// 3. Get messages from the FDR_line_name table. 
        ///    Get up to MAX per transaction or all available at the time.
        /// 4. Check TimeDelivary agains the Control table and RCVtime.
        /// 5. If within the range. Get the origTRn, qbl, and the text, make
        ///    string array and Call appropriate formatter based on the source field 
        ///    from the control table.
        /// 6. Formatter passes back the string that is queued up to the LNK_line_name
        ///    queue for the link. The that time Commit the transaction.
        /// </summary>
        /// 
        //	J.Richardson	09-Aug-05. When selecting from the Feeder queue, just select
        //					10 msgs at a pop. There's an issue where the delete from the
        //					the Feeder table hangs if we've read too much from it.
        //					Dynamically create the LNK table if we find it's not present.
        //  J.N.			13-Aug-05. Changed all console.write --> to dbaccess.consolewrite call.
        //					The output is based on Debug switch in the Simulator Table.
        //  JR				22-Aug. Create a FDR table if there isn't one present already.
        //	JR				29-Sep-05. Run all the Feeders as separate threads inside this process.
        //	JR				29-Sep-05. Add Chp formatter. We'll know what it should do soon enough.
        //	JR				10-Oct-05. Add Dave's changes to 'dofeed'.
        //  JR				19-Oct-05. Enough with having a log file per thread. Let's have one log file
        //					and each thread will write a little preamble when it logs to identify itself.
        //	JR				21-Oct-05. Check the severity status on the recordevent call. Check for
        //					consolewrite's.
        //
        /*
         * 19-Jan-07    JN  Add Fed stuff.
         * 03-Feb-07    JR  Filter out the 'Default' Feeder. It's just a dummy.
         * 18-Mar-07    JN  Figure out transport for ISI2 and pass it to the formatter.
         * 07-May-2007  JN  Add MsgCount into the Lnk tables in order to show number of real messages on the SysTotals.
         * 
         * 27-Sep-08    JR  Long story, but the issue is that the feeder queue is liable to have
         *                  traffic on it that spans more than one calendar day. In timely delivery
         *                  mode we want to send the traffic in the same order it was originally delivered.
         *                  However, we'll get out-foxed by traffic that came in the door before midnight;
         *                  we might think that is too late to be delivered, not realizing it's for the
         *                  'day before'. Which means we need some sort of idea of what "day it is" so
         *                  we can spot the traffic that came in earlier than the timely delivery window
         *                  we're looking at. Long story, see the comments in 'getMostPopulatedQueueDate'.
         * 
         * 16-Oct-08    JR  The routine GetSimValues does a check to make sure the areas are consistent.
         *                  I made the test case-insensitive. If it *does* find an area mismatch,
         *                  the text of the event that's posted shows the names of the areas that 
         *                  don't match.
         * 
         * 19-Jun-11    JR  For STI - we're letting the humans choose a pin - it lives in the link
         *                  control table - and we'll plug that into the 3FTR line of an ISI message.
         * 19-Jul-2012  JN  Added two more field to feedercontrol to accomodate FT MQ links;
         *		    1. FmtName - comes from xxx_config.xml, tells which formatter to call. for ACI make sure
         *			we map same as source
         *		    2. FmtTag - tells MQ formatter how to format the msg in order to support diff way to construct 
         *			a message
         *			
         * 28-Nov-15    JR  Synch code between Jacob and John
         * 04-Mar-2016  JN  Make it debuggable to see wtf is going on
         * 15-Jul-17    JR  More debugging stuff. Thanks, BBT !
         * 
         */
        private DBAccess m_readConnection;
        private DBAccess m_readConnection1;
        private DBAccess m_writeConnection;
        private SwiftSnd swfr;
        private AsiFormatter asifmt;
        private Isi2Formatter isi2fmt;
        private IsiFormatter isifmt;
        private MQFormatter mqfmt;
        private ChpFormatter chpfmt;
        private FedFormatter fedfmt;
        private TlxFormatter tlxfmt;
        private bool m_DBConnected;
        private bool m_DataReaderOpen;
        private string m_Lterm;
        private string m_transport;
        private string line_name;
        private string source;
        private string state;
        private string timedlv;
        private string fmtName;
        private string fmtTag;
        private DateTime timefrom;
        private DateTime timeto;
        private int msgpertrn;
        private string qline_name;
        private string send_line;
        private string Finalmsg;
        private string area;
        private string Debug;
        private string RootDir;
        private string ChpAba;
        private bool first_time = true;
        //private bool Show;
        public int debuglevel = 0;

        // SimulatorLog eventLog = new SimulatorLog("Simulator");
        private BackEndSubs subs;
        private int nSel;
        private string Args;
        private string myProcName;
        private string status;
        public StreamWriter sw;
        private StreamWriter LogWrt;
        private string Pin;

        public Feeder(string myarea, string linename, StreamWriter logwriter, int dbg)
        {
            m_readConnection = new DBAccess();
            m_readConnection1 = new DBAccess();
            m_writeConnection = new DBAccess();
            m_DBConnected = false;
            m_DataReaderOpen = false;
            subs = new BackEndSubs();
            area = myarea;
            line_name = linename;
            LogWrt = logwriter;
            debuglevel = dbg;
        }

        public void dofeed()
        {
            if (debuglevel >= 5)   // NO TRY . need it to crash to figure out wtf is going on
            {
                executeFeed();
                return;
            }
            try
            {
                executeFeed();
            }
            catch (Exception ex)
            {
                string error = string.Format("Feeder thread for line {0} exiting abnormally with status \n{1}", line_name, ex.Message);
                try
                {
                    Simulator.SimLog.log.eventLog(area, error, 5);
                    // m_readConnection.RecordEvent(1, myProcName, error, area);
                }
                catch { }
            }
        }
        private void executeFeed()
        {
            bool timelyDelivery = false;
            int DateForTimelyDelivery = 0;
            ArrayList msgs = new ArrayList();
            Args = String.Format("{0} {1}", area, line_name);
            qline_name = "FDR_" + line_name;
            send_line = "LNK_" + line_name;
            myProcName = "Feeder_" + line_name;
            if (debuglevel >= 0)
            {
                Simulator.SimLog.log.write(area, string.Format("Feeder: {0} inline {1} outline {2}", line_name, qline_name, send_line));
            }

            if (!m_DBConnected)
            {
                m_readConnection.Connect(false, area);
                m_readConnection1.Connect(false, area);
                m_writeConnection.Connect(true, area);
                m_DBConnected = true;
            }
            GetSimValues();
            get_control_values(line_name, true);
            if (timedlv == "Y")
            {
                /*
                 * Check out the notes in the 'getMostPopulatedQueueDate' routine,
                 * below. The issue is that the queue is liable to hold traffic that
                 * spans a calendar day. We want to take an educated guess as to
                 * what calendar day the timely delivery is for. Again, see below.
                 * 
                 * We'll only come here if the timely delivery flag has already been
                 * set when the feeders start up. This is the initialization part ...
                 */
                timelyDelivery = true;

                Simulator.SimLog.log.eventLog(area, "Timely Delivery is ON", 0);
                try
                {
                    DateForTimelyDelivery = getMostPopulatedQueueDate(qline_name);
                }
                catch
                {
                    Simulator.SimLog.log.eventLog(area, "Table for line not there: " + line_name, 5);
                    return;
                }
            }
            for (; ; ) /// loop forever
            {
                bool rls_reset = true;
                get_control_values(line_name, rls_reset);
                if (timedlv == "Y")
                    timelyDelivery = true;
                else
                    timelyDelivery = false;

                if (!m_DataReaderOpen)
                {
                    string Cmd;
                    if (timelyDelivery)
                    {
                        /*
                         * Use this query if you want to select just those messages where the date
                         * part of the message rcvtime is the same as the 'DateForTimelyDelivery'
                         * value. Depending on what's on the feeder queue, this may or may not
                         * pull messages out of the middle of the queue.
                         * 
                         * 
                        Cmd = string.Format("select top 10 qblid,qbltext,timely,rcvtime,TrnNumber " +
                        " from {0} where datepart(dayofyear,rcvtime)= {1} order by rcvtime ",
                        qline_name, DateForTimelyDelivery);
                         */

                        Cmd = string.Format("select top {0} qblid,qbltext,timely,rcvtime,TrnNumber " +
                        " from {1} order by rcvtime ",
                        nSel, qline_name);
                    }
                    else
                    {
                        /*
                         * This is the 'regular' non-timelydelivery select. Let's order by rcvtime, though.
                         */
                        Cmd = string.Format("select top {0} qblid,qbltext,timely,rcvtime,TrnNumber from {1} " +
                            " order by rcvtime ",
                            nSel, qline_name);
                    }
                    /*
                     * If the debuglevel is high enough, let's force a trap on the read and commit suicide.
                     */
                    if (debuglevel >= 5)
                    {
                        try
                        {
                            m_DataReaderOpen = m_readConnection.OpenDataReader(Cmd);
                        }
                        catch (Exception e)
                        {
                            string tmp = string.Format("Line {0} {1}", line_name, e.Message);
                            Simulator.SimLog.log.eventLog(area, tmp, 5);
                            throw e;
                        }
                    }
                    else
                    {
                        try
                        {
                            m_DataReaderOpen = m_readConnection.OpenDataReader(Cmd);
                        }
                        catch
                        {
                            /*
                             * Feeder table's not there. Ouch.
                             */
                            string tmp = string.Format("Feeder Error. Line {0} is missing feeder table FDR_{0}",
                                line_name);
                            Simulator.SimLog.log.eventLog(area, tmp, 3);

                            /*
                             * Let's keep this thread running just so we keep complaining to the outside world.
                             * However, let's take a long nap between complaints.
                             */
                            System.Threading.Thread.Sleep(300000);
                        }
                    }
                }
                if (m_DataReaderOpen)
                {
                    bool okToSend = true;
                    rls_reset = true;
                    get_control_values(line_name, rls_reset);
                    bool tab_empty = true;
                    while (m_readConnection.SQLDR.Read())
                    {
                        int qblid = m_readConnection.SQLDR.GetInt32(0);
                        string qbltext = m_readConnection.SQLDR["qbltext"].ToString();
                        string qtimedlv = m_readConnection.SQLDR["timely"].ToString().ToUpper();
                        string qorigtrn = m_readConnection.SQLDR["TrnNumber"].ToString();
                        DateTime qrcvtime = m_readConnection.SQLDR.GetDateTime(3);

                        DateTime rightNow = DateTime.Now;

                        string from = timefrom.TimeOfDay.ToString();
                        string to = timeto.TimeOfDay.ToString();
                        string now = rightNow.TimeOfDay.ToString();
                        string msgTime = qrcvtime.TimeOfDay.ToString();
                        int msgDay = qrcvtime.DayOfYear;

                        if (timelyDelivery)
                        {
                            if (DateForTimelyDelivery < 1)
                            {
                                // We'll get here if somebody turned timely delivery
                                // on after the Feeders were started. We'll see that
                                // the flag has been set but we won't know the target
                                // day is. Let's look in the queue and find the most
                                // populated date on the queue.
                                DateForTimelyDelivery = getMostPopulatedQueueDate(qline_name);
                            }
                            if (msgDay == DateForTimelyDelivery)
                            {
                                //msgIsToday = true;
                                timelyDelivery = true;
                                if (
                                  (timefrom.TimeOfDay.CompareTo(qrcvtime.TimeOfDay) < 0) &&
                                  (timeto.TimeOfDay.CompareTo(qrcvtime.TimeOfDay) > 0) &&
                                  (qrcvtime.TimeOfDay.CompareTo(rightNow.TimeOfDay) > 0)
                                  )
                                {
                                    // This guy's later than the system clock. Don't send it.
                                    // Figure out how long we should wait.
                                    okToSend = false;
                                }
                                else
                                {
                                    // This one's fine, off you go.
                                    // Simulator.SimLog.log.write(area, qline_name + " Msg ok");
                                    okToSend = true;
                                }
                            }
                            else
                            {
                                /*
                                 * This message is before or after the date that we're
                                 * going to be paying attention to. Should we send
                                 * it (?) or should we skip it?
                                 * 
                                 * Let's send it. Stay tuned...
                                 * 
                                 */
                                okToSend = true;
                            }
                        }
                        tab_empty = false;

                        /*
                         * The way this code works is that it will send everything before
                         * or after the TimelyDelivery window as fast as it can.
                         * 
                         * If you wanted to change this behavior - to discard all the traffic
                         * that's outside the TimelyDeliver window - you could do that. The logic 
                         * in here would need some tweaking. 
                         * 
                         * 1. One mechanism would be to change the select above so that we only
                         * select messages that match the DateForTimelyDelivery value. That's only
                         * part of the puzzle, though.
                         * 
                         * 2. If you really want to discard stuff outside the window, you need to
                         * change the flag behavior so you can tell between when something's to be 
                         * discarded and when you just want to hold things up waiting until the
                         * right time to send a message.
                         * 
                         */

                        if (
                            (msgs.Count >= msgpertrn) ||
                            ((timelyDelivery) && (!okToSend))
                            )
                        {
                            /*
                             * Bail out of the loop if we've filled up our
                             * buffer (so to speak) or we're in timely delivery
                             * mode and it's *not* ok to send the last message
                             * we looked at.
                             */
                            break;
                        }

                        // If we get here we know we want to send this message.
                        // This is part of the logic that sends messages outside
                        // the TimelyDelivery window. We also end up here in
                        // 'normal' mode.

                        msg_array next_msg = new msg_array();
                        next_msg.OrigTrn = qorigtrn;
                        next_msg.qblid = qblid;
                        next_msg.qbltext = qbltext;
                        int y = msgs.Add(next_msg);

                        /*
                         * You might want to ressurect some of this logic below if you
                         * want the logic to discard messages that are outside the
                         * TimelyDelivery window. For now, it's not needed.
                         */
                        //if (timelyDelivery)
                        //{
                        //    if (msgIsToday)
                        //    {
                        //        if (okToSend)
                        //        {
                        //            msg_array next_msg = new msg_array();
                        //            next_msg.OrigTrn = qorigtrn;
                        //            next_msg.qblid = qblid;
                        //            next_msg.qbltext = qbltext;
                        //            int y = msgs.Add(next_msg);
                        //        }
                        //        else
                        //        {
                        //            /*
                        //             * We should get to this spot when timely
                        //             * deliver is turned on and the message we're
                        //             * looking at is later than the current clock.
                        //             * Thus, we don't want to send it now.
                        //             * I don't think we need to do anything here ...
                        //             * more experiments are needed.
                        //             * We gotta break out of the loop;
                        //             */
                        //            break;
                        //        }
                        //    }
                        //    else
                        //    {
                        //        /*
                        //         * It's timely delivery but this msg has a receive
                        //         * *date* that's outside our window of interest. 
                        //         * For now, let's send it over. Stay tuned, we may
                        //         * find we just want to delete these ... 
                        //         */
                        //        msg_array next_msg = new msg_array();
                        //        next_msg.OrigTrn = qorigtrn;
                        //        next_msg.qblid = qblid;
                        //        next_msg.qbltext = qbltext;
                        //        int y = msgs.Add(next_msg);
                        //    }
                        //}
                        //else
                        //{
                        //    /*
                        //     * Timely delivery isn't turned on, so we end
                        //     * up here ...
                        //     */
                        //    msg_array next_msg = new msg_array();
                        //    next_msg.OrigTrn = qorigtrn;
                        //    next_msg.qblid = qblid;
                        //    next_msg.qbltext = qbltext;
                        //    int y = msgs.Add(next_msg);
                        //}
                    }
                    m_readConnection.CloseDataReader();
                    m_DataReaderOpen = false;

                    // if we have unprocessed msgs process them now.
                    if (msgs.Count > 0)
                    {
                        if (debuglevel >= 3)
                            Simulator.SimLog.log.write(area, string.Format("{0} - {1} sending {2} msgs", qline_name, DateTime.Now, msgs.Count));
                        Format_msg(msgs);
                        msgs.Clear();
                    }

                    // There's nothing on queue, wait 15 seconds and look again.
                    if (tab_empty)
                        System.Threading.Thread.Sleep(15000);

                    // We're in TimelyDelivery mode and we've got something to send
                    // but it isn't time yet. We know how long we need to wait.
                    if ((timelyDelivery) && (!okToSend))
                    {
                        //Simulator.SimLog.log.write(area,string.Format("{0} - {1} seconds till next msg delivery", qline_name, howLongUntilNextMsg));
                        System.Threading.Thread.Sleep(2000);
                    }
                }
            }

        }
        private void Format_msg(ArrayList msgs)
        {
            string Cmd;
            string src;
            src = fmtName;
            if (debuglevel >= 3)
                Simulator.SimLog.log.write(area, " Format_msg. src= " + src + " Send line " + send_line);
            switch (src)
            {
                case "ASI":
                    if (first_time)
                    {
                        first_time = false;
                        asifmt = new AsiFormatter();
                    }
                    Finalmsg = asifmt.FmtMsg(msgs);
                    break;

                case "CHP":
                    if (first_time)
                    {
                        first_time = false;
                        chpfmt = new ChpFormatter();
                    }
                    Finalmsg = chpfmt.FmtMsg(m_readConnection, ChpAba, msgs, send_line);
                    break;

                case "FED":
                    if (first_time)
                    {
                        string Cmd1 = string.Format("select SwfTid from LinkControl where LineName='{0}'", send_line.Substring(4, send_line.Length - 4));
                        m_readConnection.OpenDataReader(Cmd1);
                        m_readConnection.SQLDR.Read();
                        m_Lterm = m_readConnection.SQLDR["SwfTid"].ToString().TrimEnd();
                        m_readConnection.CloseDataReader();
                        first_time = false;
                        fedfmt = new FedFormatter();
                    }
                    Finalmsg = fedfmt.FmtMsg(m_readConnection, msgs, m_Lterm, send_line);
                    break;

                case "IS2":
                    if (first_time)
                    {
                        Cmd = string.Format("select MQMgrName, inputMQName, " +
                        " outputMQName  from linkcontrol where LineName = '{0}'", line_name);
                        m_readConnection.OpenDataReader(Cmd);
                        m_readConnection.SQLDR.Read();
                        string MQMgr = m_readConnection.SQLDR["MQMgrName"].ToString().TrimEnd().ToUpper();
                        string inMQName = m_readConnection.SQLDR["inputMQName"].ToString().TrimEnd().ToUpper();
                        string outMQName = m_readConnection.SQLDR["outputMQName"].ToString().TrimEnd().ToUpper();
                        m_readConnection.CloseDataReader();
                        if ((MQMgr.Length > 0) && (inMQName.Length > 0) && (outMQName.Length > 0))
                            m_transport = "MQ";
                        else
                            m_transport = "IP";
                        first_time = false;
                        isi2fmt = new Isi2Formatter();
                    }
                    Finalmsg = isi2fmt.FmtMsg(msgs, m_transport);
                    break;

                case "ISI":
                    string z = Pin;
                    if (first_time)
                    {
                        first_time = false;
                        isifmt = new IsiFormatter();
                    }
                    Finalmsg = isifmt.FmtMsg(msgs, Pin);
                    break;

                case "MQS":
                    if (first_time)
                    {
                        first_time = false;
                        mqfmt = new MQFormatter(area);
                    }
                    Finalmsg = mqfmt.FmtMsg(fmtTag, msgs);
                    break;

                case "SWF":
                    if (first_time)
                    {
                        first_time = false;
                        swfr = new SwiftSnd();	//Declare Formatting Classes 
                    }
                    Finalmsg = swfr.SwiftFmt(msgs, m_readConnection, LogWrt, Debug);
                    break;

                case "TLX":
                    if (first_time)
                    {
                        first_time = false;
                        tlxfmt = new TlxFormatter();
                    }
                    Finalmsg = tlxfmt.FmtMsg(msgs);
                    break;

                default:
                    status = line_name + " Wrong Source. Message discarded.";
                    if (debuglevel >= 0)
                        Simulator.SimLog.log.eventLog(area, "Wrong Source. Message discarded. Line: " + line_name, 1);
                    // m_readConnection.RecordEvent(1, myProcName,
                    // string.Format("{0}: {1}", DateTime.Now, status), area);
                    LogIt(status, Debug);
                    break;
            }

            // And finally, delete processed msgs from the feeder queue and 
            // enqueue the msg to the LNKq.
            // Let's catch any funky timeouts with deleting from the table.
            // We still get those from time to time.
            try
            {
                for (int i = 0; i < msgs.Count; i++)
                {
                    msg_array next_msg = (msg_array)msgs[i];
                    Cmd = string.Format("delete from {0} where qblid={1}",
                        qline_name, next_msg.qblid);
                    m_writeConnection.Execute(Cmd, false);
                }
            }
            catch
            {
                m_readConnection.RecordEvent(1, myProcName,
                    string.Format("{0}: {1}", DateTime.Now, "Error Deleting from DB"),
                    area);
                string tmp = string.Format("{0}: {1}", DateTime.Now, "Error Deleting from DB");
                LogIt(tmp, "Y");
                throw new Exception(tmp);
            }

            char prio = '1';
            Cmd = string.Format("insert into {0} values ('{1}',{2}, '{3}')", send_line, prio, msgs.Count, Finalmsg);
            status = m_writeConnection.ExecuteExc(Cmd, true);

            if (debuglevel >= 3)
                Simulator.SimLog.log.write(area, "Inserting into " + send_line + " txt " + Finalmsg);

            if (source == "CHP")
            {
                decimal d = Convert.ToDecimal(Finalmsg.Substring(Finalmsg.IndexOf("[260]") + 5, 12));
                d = d / 100;
                Cmd = string.Format("exec ChpRcvUpd {0}", d);
                if (m_writeConnection.OpenDataReader(Cmd))
                {
                    m_writeConnection.SQLDR.Read();
                    decimal Qblid = m_writeConnection.SQLDR.GetSqlMoney(0).ToDecimal();
                    m_writeConnection.CloseDataReader();
                }
            }
            if (source == "FED")
            {
                // Find out the subtype. We need ONLY acct msgs not Service. Acct msgs are **00, **02, **32
                int pos = Finalmsg.IndexOf("{1510}");
                string subtyp = "";
                if (pos != -1)
                    subtyp = Finalmsg.Substring(pos + 8, 2);
                if ((subtyp.Length > 0) &&
                    ((subtyp == "00") || (subtyp == "02") || (subtyp == "08") || (subtyp == "20") || (subtyp == "32")))
                {
                    decimal d = Convert.ToDecimal(Finalmsg.Substring(Finalmsg.IndexOf("{2000}") + 6, 12));
                    d = d / 100;
                    Cmd = string.Format("exec FedRcvUpd {0}", d);
                    if (m_writeConnection.OpenDataReader(Cmd))
                    {
                        m_writeConnection.SQLDR.Read();
                        decimal Qblid = m_writeConnection.SQLDR.GetSqlMoney(0).ToDecimal();
                        m_writeConnection.CloseDataReader();
                    }
                }
            }

            if (status.IndexOf("Normal") == -1)
                if (status.IndexOf("Invalid object name") != -1)
                {
                    Simulator.SimLog.log.eventLog(area, status, 1);
                    m_writeConnection.Connect(true, area);
                }
                else // We have a problem
                {
                    m_readConnection.RecordEvent(1, myProcName,
                    string.Format("Unhandled Fatal Error. {0}: {1}", DateTime.Now, status), area);
                    string tmp = String.Format("Problem inserting into LNK table. Error - {0}", status);
                    Simulator.SimLog.log.eventLog(area, tmp, 1);
                    throw new Exception(tmp);
                }

            bool rls_reset = true;
            get_control_values(line_name, rls_reset);
        }

        private void GetSimValues()
        {
            string l_Area;
            string Cmd;
            Cmd = string.Format("select Area, RootDir, Debug, ChpAba from SimulatorControl");
            m_readConnection.OpenDataReader(Cmd);
            m_readConnection.SQLDR.Read();
            l_Area = m_readConnection.SQLDR["Area"].ToString().TrimEnd();
            Debug = m_readConnection.SQLDR["Debug"].ToString().TrimEnd().ToUpper();
            RootDir = m_readConnection.SQLDR["RootDir"].ToString().TrimEnd();
            ChpAba = m_readConnection.SQLDR["ChpAba"].ToString().TrimEnd();
            m_readConnection.CloseDataReader();
            if (debuglevel >= 3)
            {
                string tmp = string.Format("Feeder - GetSimValues: area: {0} ChpAba: '{1}'",
                    l_Area, ChpAba);
                Simulator.SimLog.log.write(area, tmp);
            }
            if (area.ToLower() != l_Area.ToLower())
            {
                string st = "Process not Started. Areas Discrepancy - " + area + ":" + l_Area;
                m_readConnection.RecordEvent(1, myProcName, string.Format("{0}", st), area);
                m_readConnection.ConsoleWrite("Y", "Feeder", sw, "Areas Discrepancy " + area + ":" + l_Area);
                sw.Flush();
                sw.Close();
                throw new Exception("Bad area " + l_Area + " specified");
            }
        }

        private void get_control_values(string line_name, bool rls_reset)
        {
            if (!m_DBConnected)
            {
                m_readConnection.Connect(false, area);
                m_readConnection1.Connect(false, area);
                m_writeConnection.Connect(true, area);
                m_DBConnected = true;
            }
            string Cmd = string.Format("select Source, ProcessState, timelyDelivery, TimeFrom, TimeTo, " +
                " MsgperTrn, NumberSel, FmtName, FmtTag  from feedercontrol where LineName = '{0}'", line_name);
            m_readConnection1.OpenDataReader(Cmd);
            m_readConnection1.SQLDR.Read();
            source = m_readConnection1.SQLDR["Source"].ToString().TrimEnd().ToUpper();
            state = m_readConnection1.SQLDR["ProcessState"].ToString().TrimEnd().ToUpper();
            timedlv = m_readConnection1.SQLDR["TimelyDelivery"].ToString().TrimEnd().ToUpper();
            if (timedlv == "Y")
            {
                timefrom = m_readConnection1.SQLDR.GetDateTime(3);
                timeto = m_readConnection1.SQLDR.GetDateTime(4);
            }
            msgpertrn = m_readConnection1.SQLDR.GetInt16(5);
            nSel = m_readConnection1.SQLDR.GetInt32(6);
            fmtName = m_readConnection1.SQLDR["FmtName"].ToString().TrimEnd().ToUpper();
            fmtTag = m_readConnection1.SQLDR["FmtTag"].ToString().TrimEnd().ToUpper();
            m_readConnection1.CloseDataReader();

            Cmd = string.Format("select pin from linkcontrol where LineName = '{0}'", line_name);
            try
            {
                m_readConnection1.OpenDataReader(Cmd);
                m_readConnection1.SQLDR.Read();
                Pin = m_readConnection1.SQLDR["Pin"].ToString().TrimEnd();
                if (Pin.Length > 0 && Pin.Length != 10)
                {
                    /*
                     * Let's pad this guy with trailing spaces.
                     */
                    string spaces = "          ";
                    Pin = Pin + spaces.Substring(0, 10 - Pin.Length);
                }
            }
            catch (Exception ePin)
            {
                /*
                 * This can only mean that there's no entry in the LinkControl table for this
                 * line. Setup issue. [I suppose it could also mean there's no 'pin' field
                 * in the LinkControl row, ha!]
                 */
                string tmp = string.Format("Feeder {0}, failed to find that line in LinkTable. Setup issue",
                    line_name);
                Simulator.SimLog.log.eventLog(area, tmp, 5);
                throw (ePin);
            }
            m_readConnection1.CloseDataReader();
        }

        private void LogIt(string msg, string dbg)
        {
            string tmp = line_name + "-" + msg;
            m_readConnection.ConsoleWrite(dbg, "Feeder", LogWrt, tmp);
        }

        private int getMostPopulatedQueueDate(string qname)
        {
            /*
               * Yikes, this is a tangled web ...
               * 
               * The issue is that we may (will?) have stuff on the feeder queue
               * where the various receive times cover more than one day. The obvious
               * one is where something came in before midnight in a particular period.
               * Equally ugly and equally possible is where the select out of the
               * MDR specified a date range.
               * 
               * So, now we're looking at a queue where the traffic is spread over a
               * couple of days (or more) and we want to chuck the traffic that came
               * in before our start time and we want to stop sending if the receive
               * time is later than the system clock or we've hit the stop time for
               * timely delivery.
               * 
               * And furthermore, I think we should try to deliver the stuff in the
               * same order that it originally came in the door to MTS.
               * 
               * So, now we got a problem. We select out of the feeder queue doing
               * an order by receive time and - for argument's sake - the first
               * message we see says it came in at 10pm and that's outside of our
               * stop time for timely delivery. Now the whole thing freezes.
               * 
               * But, that 10pm receive time was for last night and the next message
               * is - for argument's sake - one that we should send because it matches
               * the date criteria ... This suggests that we need to have some idea
               * of the calendar date of the period we're operating on so we call tell
               * that 10pm message should be skipped.
               * 
               * For want of a better idea today, I'm gonna do it like you see here. We'll
               * look on the feeder queue and see all the different days that are on queue.
               * Then we'll walk that list and see which day has the most trn's. We'll
               * assume that's the target date we should be concerned with.
               * 
               * Betcha down the road we want some mechanism so the humans can *tell* 
               * us what the period of interest is. Not quite sure how they'd know that,
               * so for now here we are ...
               * 
               */
            int DateForTimelyDelivery = 0;
            int highestSeen = 0;
            DBAccess tmpRdr = new DBAccess();
            tmpRdr.Connect(false, area);
            DBAccess tmpRdr2 = new DBAccess();
            tmpRdr2.Connect(false, area);

            // Find out what dates are on the feeder queue. We get returned the julian date.
            string tmp = string.Format("select distinct datepart(dayofyear,rcvtime) from {0}",
                qline_name);
            tmpRdr.OpenDataReader(tmp);
            while (tmpRdr.SQLDR.Read())
            {
                // Walk the list of dates and see which one has the most trn's.
                // That's the date we'll use.
                int dayOfYear = tmpRdr.SQLDR.GetInt32(0);
                string tmp2 = string.Format("select count(*) from {0} where datepart(dayofyear,rcvtime)= {1}",
                    qline_name, dayOfYear);
                tmpRdr2.OpenDataReader(tmp2);
                tmpRdr2.SQLDR.Read();
                int nThisDay = tmpRdr2.SQLDR.GetInt32(0);
                if (nThisDay > highestSeen)
                {
                    DateForTimelyDelivery = dayOfYear;
                    highestSeen = nThisDay;
                }
            }
            tmpRdr.DisConnect();
            tmpRdr.Dispose();
            tmpRdr2.DisConnect();
            tmpRdr2.Dispose();
            return DateForTimelyDelivery;
        }
    }

    class FdrThread
    {
        private DBAccess dbReader;
        private DBAccess dbWriter;
        private BackEndSubs util;


        public FdrThread()
        {
            dbReader = new DBAccess();
            dbWriter = new DBAccess();
            util = new BackEndSubs();
        }

        [STAThread]
        static void Main(string[] args)
        {
            string area = args[0].ToString();

            FdrThread fdr = new FdrThread();
            try
            {
                fdr.StartMeUp(args);
            }
            catch
            {
                Simulator.SimLog.log.eventLog(area, "Feeder exiting. Incorrect args.");
                Simulator.SimLog.log.write(area, "Usage:");
                Simulator.SimLog.log.write(area, "Feederthreads <area> optional - <Y> for show <line name> to process 1 line");
                Simulator.SimLog.log.write(area, "Are you trying to start a thread not in FeederControl table?");
            }
        }

        private void StartMeUp(string[] args)
        {
            int dbg = 0;
            int nFeeders;
            Feeder[] fList;
            Thread[] threadList;

            string area = args[0];
            string sh = "N";

            /*
             * Let's get the area-wide debug level and then let's see if the
             * humans passed in another arg to tell us to debug the crap out 
             * of this process.
             */

            dbg = util.GetDebugLevel(area);

            try
            {
                sh = args[1].ToUpper().Trim();
                if (sh.Equals("Y"))
                {
                    dbg = 7;
                }
            }
            catch { };

            string DebLine = "";
            try
            {
                DebLine = args[2].Trim();
            }
            catch { };

            dbReader.Connect(false, area);
            dbWriter.Connect(true, area);
            dbReader.RecordEvent(0, "Feeder", string.Format("Starting Feeders"), area);

            //Register the process.
            string ldir = util.GetLogDir(dbReader);
            string ts = util.GetTimestampTag();
            string filename = string.Format("{0}Feeder_{1}.log", ldir, ts);
            FileStream file1 = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw = new StreamWriter(file1);
            string myProcName = "FeederThreads";


            if (!dbReader.RegisterProcess(dbReader, dbWriter, "FeederThreads", area,
                sw, dbg, area))
            {
                string status = "Error starting a process. Process already exists.";
                dbReader.RecordEvent(1, myProcName, string.Format("{0}: {1}", DateTime.Now, status), area);
                dbReader.ConsoleWrite("Y", "Feeder", sw, "Process already exists\r\n");
                Simulator.SimLog.log.write(area, status);
                return;
            }

            string dbCmd = "select count(*) from FeederControl where LineName != 'Default'";
            dbReader.OpenDataReader(dbCmd);
            dbReader.SQLDR.Read();
            nFeeders = dbReader.SQLDR.GetInt32(0);
            dbReader.CloseDataReader();

            fList = new Feeder[nFeeders];
            threadList = new Thread[nFeeders];

            /*
             * If you want to start up just a single thread, pass the name out of the feeder control table in here
             * as the 3rd argument. Args are: area, showSwitch, debugLine.
             * 
             */
            int idx = 0;
            if (DebLine != "")
            {
                nFeeders = 1;
                dbCmd = "select * from FeederControl where LineName like '" + DebLine + "'";
            }
            else
            {
                dbCmd = "select * from FeederControl where LineName != 'Default'";
            }
            dbReader.OpenDataReader(dbCmd);

            /*
             * Debugging stuff - if we're not bringing up all the feeders, but ARE bringing
             * up more than 1, we should pay attention to that ... So, let's actually
             * count how many we find in this next read statement ...
             */
            nFeeders = 0;
            while (dbReader.SQLDR.Read())
            {
                string LineName = dbReader.SQLDR["LineName"].ToString().TrimEnd();
                fList[idx] = new Feeder(area, LineName, sw, dbg);
                threadList[idx] = new Thread(new ThreadStart(fList[idx].dofeed));
                threadList[idx].Name = LineName;
                idx++;
                nFeeders++;
            }

            for (idx = 0; idx < nFeeders; idx++)
            {
                string tmp = string.Format("Starting Feeder: {0}", threadList[idx].Name);
                Simulator.SimLog.log.eventLog(area, tmp, 0);
                sw.WriteLine(tmp);
                threadList[idx].Start();
                System.Threading.Thread.Sleep(1000);
            }
            sw.Flush();
            // 
            // Wait for them all to finish. They never will, of course ;-)
            //
            Simulator.SimLog.log.write(area, "Feeder - done starting threads. Will 'join' to each one");
            foreach (Thread fThread in threadList)
            {
                /*
                 * Normally, we'd start up all the threads so none of these objects would be null. 
                 * However, start up just one thread and all but one of these guys will be null. So,
                 * we should check for that otherwise we're gonna throw an exception which will just
                 * confuse the humans even further. So, only join to threads that exist ...
                 */
                if (fThread == null)
                { }
                else
                    fThread.Join();
            }
            Simulator.SimLog.log.eventLog(area, "Feeder threads exiting", 0);
            sw.WriteLine("Feeder threads exiting. ");
            sw.Flush();
            sw.Close();
        }
    }
}