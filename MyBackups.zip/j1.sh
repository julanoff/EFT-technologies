#!/usr/local/bin/bash
tot=0
showperiods | while read str; 
do
  if [ ${str:0:1} == "0" ] || [ ${str:0:1} == "1" ] || [ ${str:0:1} == "2" ] || [ ${str:0:1} == "3" ] 
  then 
     if [[ $str == *"(none)"* ]]
     then
       echo "period is empty!";
     else
      dt=${str:0:11}
      st=$(q_util -inc /*///SWF_DST_NDX -notrn -message -per $dt | grep Count)
      st1=${st:26:9}
      tot=`expr $st1 + $tot`
      echo "date- " $dt " per period - " $st1 " Acc "  $tot
    fi
  else 
    echo nog0od; 
  fi
done
