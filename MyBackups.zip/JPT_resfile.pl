#!/usr/local/bin/perl
# /*********************************************************************/

use Switch;

MAIN:
$fn = "$ARGV[0]";
$ad = "$ARGV[1]";
$dt = "$ARGV[2]";
$output_dir	= "$ENV{'AREA_ROOT_DIR'}/output";
$area_name 	= uc("$ENV{'AREA_NAME'}");


# 
#open(OUTALL, ">${output_dir}/F50F_report_$cur_date.csv") || die "Can't open ${output_dir}/\n";
open(INALL, "<$fn") || die "Can't open '$fn' /\n";
open(OUTALL, ">$fn.out") || die "Could not open file '$fn' $!\n";
flock(OUTALL, 2) || die;
##{1:F01SCBLDEFXAXXX1789839681}{2:O1032352050911KASITHBKAXXX02453161080509112353N}{4:^M
##:32A:150812EUR5000000
while (my $line = <INALL>)  {
	chomp($line);
	if (substr($line,0,3) eq "{1:") {
		$ad++;
		$txt1 = substr($line,0,18);
		$seqn = substr($line,18,10) + $ad;
		$txt2 = substr($line,28);
#	  print OUTALL "$txt1$seqn$txt2\n";
	  print OUTALL "$line\n";
	}
	else {
		if ( (substr($line,0,5) eq ":32A:") or (substr($line,0,4) eq ":30:") ) {
			$line =~ s/150123/$dt/;
			$line =~ s/150124/$dt/;
			$line =~ s/150125/$dt/;
			$line =~ s/150126/$dt/;
			$line =~ s/150127/$dt/;
			$line =~ s/150128/$dt/;
			$line =~ s/150129/$dt/;
			$line =~ s/150130/$dt/;
			$line =~ s/150202/$dt/;
			$line =~ s/150203/$dt/;
		}
  	print OUTALL "$line\n";
	}
}
flock(OUTALL, 8) || die;
close(OUTALL);
close(INALL);

exit  (1);
