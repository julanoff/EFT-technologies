#!/usr/local/bin/perl
# /*********************************************************************/
# /* Script name: USN_ecenter_format                                   */
# /*                                                                   */
# /* Description:  This script checks for the CHKPRT line and generates*/
# /*               check files in output folder and reformats into     */
# /*               ecenter required format into one single file        */
# /* Parameters :                                                      */
# /*                                                                   */
# /* ------------------------------------------------------------------*/
# /* REVISION HISTORY                                                  */
# /* ------------------------------------------------------------------*/
# /* Date     |  By        | Description                               */
# /* ---------|------------|-------------------------------------------*/
# /* 04.Dec.08|SivaGunturu | Created                                   */
# /*          |NageshDasari| Changed NFS share                         */
# /*          |            |                                           */
# /*-------------------------------------------------------------------*/
#
$area = "$ARGV[1]";
$chkprt_line    = "eCenter";

$wdog_status = `ps -ef | grep -v grep |grep -c USN_ecenter_format`;
if ( $wdog_status > 1 ) {
        my_logger(ERROR,"Another Instance of eCenter format script is currently Running. Aborting.",$chkprt_line);
        exit(0); }

#####system("log_message ENGUARD 'USN_ecenter_format Started.'");

MAIN:
getsystime();
# Check if we are in an area. No point in proceeding if not.
if ( ! $ENV{'AREA_NAME'} ) {
        my_logger(INFO,"You have to be in a Area, Cannot run outside an MTS area. Aborting.",$chkprt_line);
        exit(0); }

my_logger(DEBUG,"Current Area",$ENV{'AREA_NAME'}); 

# Check for entia up. With no ENTIA, no point in doing anything else

$ent_status = system("ent status | grep -v RHS | grep DOWN > /dev/null");
if ( ! $ent_status ) {
######        system("log_message ENGUARD 'watchdog_ecenter Aborting - Entia is DOWN'");
        my_logger(ERROR,"Entia is not currently Running. Aborting.",$chkprt_line);
        exit(0); }

$input_dir	= "$ENV{'AREA_ROOT_DIR'}/ecenter";
$output_dir	= "$ENV{'AREA_ROOT_DIR'}/ecenter/output";
$archive_dir	= "$ENV{'AREA_ROOT_DIR'}/ecenter/archive";
$shared_dir	= "/shared/data/uspay/ecenter/input";
$last_chk_file  = "/shared/data/uspay/ecenter/input/chkprint";
$area_name 	= uc("$ENV{'AREA_NAME'}");


OUTBOUND_LINE:
 my_logger(DEBUG,"Begin processing for line",$chkprt_line);
 if ( -e "$last_chk_file" ) 
 {
         my_logger(ERROR,"CHKPRT FILE STILL NOT PROCESSED. PLEASE CHECK ECENTER PROCESS",$chkprt_line);
 }
 else
 { 
	 check_line_pending();
	 $input_chk_file = `ls -c1 $input_dir/PRT_${area_name}_SCB_CHKPRT_*.DAT|head -1`;
	 chomp $input_chk_file;
         if ( -e $input_chk_file )
         {
           	process_chk_file();
	   	system("mv $input_dir/PRT_${area_name}_SCB_CHKPRT_*.DAT $archive_dir/");
	   	system("cp -p $output_dir/chkprint $archive_dir/chkprint_`date +\%C\%y\%m\%d\%H\%M\%S`");  
	   	system("mv $output_dir/chkprint $shared_dir/");
	  	system("chmod 664 $shared_dir/chkprint*");
         }
         else
         {
           	my_logger(INFO,"No Check files to process ",$chkprt_line);
         } 
 }

sub getsystime {
        # Get the system time. Keep MMDDHHMMSS only.
        system("/usr/bin/date +%y%m%d%H%M%S > ~/junk_time");
        open(TIME,"<~/junk_time");
        $time = <TIME>;
        chop $time;
        close (TIME);
        system("/usr/bin/rm ~/junk_time");

        if ( $debug ) {
              my_logger(DEBUG,"Timestamp (YYMMDDHHMMSS) ",$time); }
} # End getsystime subroutine

sub my_logger {
        local $fn1 = $_[0];
        local $fn2 = $_[1];
        local $fn3 = $_[2];
        system("/usr/bin/date +%y%m%d:%H:%M > ./junk_time");
        open(TIME,"<./junk_time");
        $time = <TIME>;
        chop $time;
        system("/usr/bin/rm ./junk_time");
        printf("%-12.12s %-8.8s  %-80.80s : %s\n",$time,$fn1,$fn2, $fn3);
	$errs = "ERROR";
	if ( "$fn1" eq "$errs" ) {
		system("/usr/bin/logger -p local0.err -t syslog 'USN_FAIL:USN_ecenter_format $fn2 $fn3'");
	}
	else{
		system("/usr/bin/logger -p local0.info -t syslog 'USN_ecenter_format - $fn2 $fn3'");
	}
} # end my_logger
	
sub check_line_pending {

        $pending_count = `linecmd -li CHKPRT -ba SCB -show | grep Pending `;
        $pending_count = substr($pending_count, -10);
	$pending_count = 1;
        if ( $pending_count == 0 ) 
        {
                my_logger(INFO,"No Pending Records to process for line",$chkprt_line);
        }
        else
        { 
                $line_cmd = system("linecmd -li CHKPRT -ba SCB -up");
                printf("%s\n",$line_cmd);
                $line_cmd = system("cd $output_dir");
          #     printf("%s\n",$line_cmd);
                my_logger(INFO,"Line Brought UP",$chkprt_line);
	        sleep 90;
	        $chk_file 	= `ls -c1 $input_dir/PRT_${area_name}_SCB_CHKPRT_*.DAT|tail -1`;
                check_raw_open:
                $in_use = `fuser -f $chk_file 2>/dev/null `;
                if (  $in_use == ""  )
                {
                       my_logger(INFO,"File Available: Waiting... ",$chkprt_line);
                }
                else
                {
                       my_logger(INFO,"File still locked: Waiting... ",$chkprt_line);
                       sleep 60;  
                       goto check_raw_open;
                }
                $line_cmd = system("linecmd -li CHKPRT -ba SCB -down");
           #     printf("%s\n",$line_cmd);
        }
}

sub process_chk_file {
	open(OUT, ">${output_dir}/chkprint") || die "Can't open ${output_dir}/chkprint\n";
	flock(OUT, 2) || die;
	@files = `ls -c1 $input_dir/PRT_${area_name}_SCB_CHKPRT_*.DAT`;
	foreach (@files) {
		chomp $_;
		$in_file=$_;
		$fldname="";
		$i=1;
		%chktable=();
        	open(IN, "${in_file}") || die "can't open $in_file\n";
	        while (<IN>)
        	{
            		if(/^\^job(.*)/ != 1){
                		if(/\^field (.*)/){
                        		$i=1;
                        		$fldname=$1;
                        		chomp($fldname);
                		}else{
                        		chomp($_);
                        		$chktable{"$fldname$i"}=$_; 
                        		$i++;
                		}
            		}
        	}
        	close(IN);
		$chktable{"AMOUNT_MINUS_CHG1"}=~s/\,//g;

		$fileout="";
		$fileout=sprintf("%.9d", $chktable{"CHECK_NUMBER1"});
		$fileout=${fileout}.sprintf("%.2s-%.2s-%.2s", $chktable{VALUE_DATE_MM1},$chktable{VALUE_DATE_DD1},$chktable{VALUE_DATE_YY1});
		$fileout=${fileout}.sprintf("%014s", $chktable{"DEBIT_ACCOUNT1"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DEBIT_NAME11"});
		$fileout=${fileout}.sprintf("%8d%.6d", $chktable{"TRN_DATE1"},$chktable{"TRN_NUM1"});
		$fileout=${fileout}.sprintf("%015.2f", $chktable{"AMOUNT_MINUS_CHG1"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DRAWEE_NAME_ADDRESS1"});
		$fileout=${fileout}.sprintf("%-3s", $chktable{"CURRENCY_CODE1"});
		$fileout=${fileout}.sprintf("%-20s", $chktable{"SBK_REF_NUMBER1"});
		$fileout=${fileout}.sprintf("%-20s", " ");
		$amount=$chktable{"AMOUNT_MINUS_CHG1"};
		$amount=~s/\,//g;
	#	if($chktable{"AMOUNT_MINUS_CHG1"} >= 25000.00){
	#		$fileout=${fileout}.sprintf("%1s", "Y");
	#	}
	#	else{
			$fileout=${fileout}.sprintf("%1s", "N");
	#	}
		$fileout=${fileout}.sprintf("%-20s", " ");
	#	$fileout=${fileout}.sprintf("%-140s", " ");
	#	$fileout=${fileout}.sprintf("%-210s", " ");
		$fileout=${fileout}.sprintf("%-35s", $chktable{"ORP_BEN_INF11"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"ORP_BEN_INF21"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"ORP_BEN_INF31"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"ORP_BEN_INF41"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DEBIT_BANK_INFO1"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DEBIT_BANK_INFO2"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DEBIT_BANK_INFO3"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DEBIT_BANK_INFO4"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DEBIT_BANK_INFO5"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DEBIT_BANK_INFO6"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"BBK_NAME_ADDRESS1"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"BBK_NAME_ADDRESS2"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"BBK_NAME_ADDRESS3"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"BBK_NAME_ADDRESS4"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DRAWEE_NAME_ADDRESS1"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DRAWEE_NAME_ADDRESS2"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DRAWEE_NAME_ADDRESS3"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"DRAWEE_NAME_ADDRESS4"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"ORP_NAME11"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"ORP_NAME21"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"ORP_NAME31"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"ORP_NAME_ADDRESS4"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"OBK_NAME11"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"OBK_NAME21"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"OBK_NAME31"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"OBK_NAME41"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"SBK_NAME_ADDRESS1"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"SBK_NAME_ADDRESS2"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"SBK_NAME_ADDRESS3"});
		$fileout=${fileout}.sprintf("%-35s", $chktable{"SBK_NAME_ADDRESS4"});
		$fileout=${fileout}.sprintf("%-24s", " ");
		$fileout=${fileout}.sprintf("\n");
		print OUT $fileout;
	}
	flock(OUT, 8) || die;
	close(OUT);
}


