#!/usr/local/bin/perl
# /*********************************************************************/
# /* Script name:   aml_rpt.pl                                         */
# /*                                                                   */
# /* Description:                                                      */
#    The report checks for messages that have to be scanned by OFAC filter but for some reason were skipped.
#    It should be run after the new day is declared and be performed against the previous period
#
# Usage:
# aml_rpt.pl <bank> optional <date>
# By default it runs against the previous period. If the <date> is specified the default is overriden with this date.
# <bank> can be: SCB (US), JPR (JP), DEF (DE);
# <date> is in YYYYMMDD format
# 

use Switch;

# debug switch. 1 is ON, 0 is OFF
@months = qw( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );
$deb=1;		
$bnk = "$ARGV[0]";
$inp_date = "$ARGV[1]";
$lookfor = "\"*SYS_MEMO         Stop_Check\"";

# Skipping in US 910,920,935,940,941,942,950,970,971,972,973,985,986,990,991,992,995,996,998

$msglistUS = "101,103,104,107,110,111,112,192,195,196,198,199,200,202,204,
205,206,207,210,292,295,296,298,299,399,400,405,410,416,430,450,456,492,
495,496,498,499,501,502,519,527,540,541,542,543,544,545,546,547,548,599,600,
601,604,605,607,646,649,695,696,699,700,701,705,707,710,711,720,721,740,
742,747,750,752,754,756,760,767,768,769,792,795,796,798,799,998,999,
1000,1001,1002,1007,1008,1031,1032,1500,1501,1502,1507,1508,1600,1601,1602,1607,1608,1631,1632,31";

# skipping in JP 203,210,399,499,599,699,899,940,942,950,999

$msglistJP = "101,103,104,107,110,111,112,192,195,196,198,199,200,202,204,
205,206,207,292,295,296,298,299,400,405,410,416,430,450,456,492,
495,496,498,501,502,519,527,540,541,542,543,544,545,546,547,548,600,
601,604,605,607,646,649,695,696,700,701,705,707,710,711,720,721,740,
742,747,750,752,754,756,760,767,768,769,792,795,796,798,799,998";

#Skipping in Germany 012,399,499,599,699,899,940,942,950,970,999
$msglistDE = "101,103,104,107,110,111,112,192,195,196,198,199,200,202,203,204,
205,206,207,210,292,295,296,298,299,400,405,410,416,430,450,456,492,
495,496,498,501,502,519,527,540,541,542,543,544,545,546,547,548,600,
601,604,605,607,646,649,695,696,700,701,705,707,710,711,720,721,740,
742,747,750,752,754,756,760,767,768,769,792,795,796,798,799,998";


MAIN:
# US logs
$scb_inp_logs = "/SCB//OTP1_RCV,/SCB//FEDIN_LOG,/SCB/MTRANS/FTRENT_LOG,
/SCB/ADMIN/FTRENT_LOG,/SCB/ADMINS/FTRENT_LOG,/SCB/AUDIT/FTRENT_LOG,/SCB/BPVISA/FTRENT_LOG,/SCB/CUS/FTRENT_LOG,/SCB/CUST/FTRENT_LOG,
/SCB/GRP/FTRENT_LOG,/SCB/INV/FTRENT_LOG,/SCB/ITS/FTRENT_LOG,/SCB/LAOPS/FTRENT_LOG,/SCB/LATRS/FTRENT_LOG,/SCB/MEZZAN/FTRENT_LOG,
/SCB/MKTLNS/FTRENT_LOG,/SCB/MSGCTR/FTRENT_LOG,/SCB/PARKAV/FTRENT_LOG,/SCB/REIMB/FTRENT_LOG,/SCB/TRS/FTRENT_LOG,
/SCB//SCBA_F_RCV,/SCB//CHIPSRCV,/SCB//CER_IN,/SCB//ACB1_RCV,/SCB//DTP1_RCV,/SCB//DTP2_RCV,/SCB//OTP2_RCV,MTS///STO_LOG";

# Japan logs
$jpt_inp_logs = "/JPT/MTRANS/FTRENT_LOG,/JPT/CAC/FTRENT_LOG,/JPT/COMMS/FTRENT_LOG,/JPT/CSI/FTRENT_LOG,/JPT/FSI/FTRENT_LOG,/JPT/LAD/FTRENT_LOG,
/JPT/LOC/FTRENT_LOG,/JPT/PSI/FTRENT_LOG,/JPT/RMB/FTRENT_LOG,/JPT/TOPS/FTRENT_LOG,/JPT/TRDE/FTRENT_LOG,/JPT/TRDI/FTRENT_LOG,/JPT//GMS_RCV,MTS///STO_LOG";

# Germany logs
$def_inp_logs = "/EFF/MTRANS/FTRENT_LOG,/EFF/COMMS/FTRENT_LOG,/EFF/OFAC/FTRENT_LOG,/EFF/NRPS/FTRENT_LOG,MTS///STO_LOG,/EFF//GMS_RCV";
$inp_logs="";
$msglist="";

switch($bnk){
		case ["SCB"] {
			$inp_logs = $scb_inp_logs;
			$msglist = $msglistUS;
		}
		case ["JPT"] {
			$inp_logs = $jpt_inp_logs;
			$msglist = $msglistJP;
		}
		case ["DEF"] {
			$inp_logs = $def_inp_logs;
			$msglist = $msglistDE;
		}
		else {
			print "Undefined bank - $bnk (must be SCB / JPT / DEF ). Exiting.\n";
			exit (0);
		}
}

if ( ! $ENV{'AREA_NAME'} ) {
        print "You have to be in a Area";
        exit(0); }

$output_dir	= "$ENV{'AREA_ROOT_DIR'}/output";

open(CRD,"showperiods |") || die "Can not open pipe: $!\n"; 
while (my $line = <CRD>)  {
	    my $pos = index($line, "CURRENT");
			if ($pos != -1) {
				last
			}
			else {
				$cur_date_per=substr($line,1,11);
			}
}
close(CRD);
# Input date is in 20150513 format;
if ($inp_date ne ""){
	$cur_date = $inp_date;
	%hash=("01"=>"Jan","02"=>"Feb","03"=>"Mar","04"=>"Apr","05"=>"May","06"=>"Jun","07"=>"Jul","08"=>"Aug","09"=>"Sep","10"=>"Oct","11"=>"Nov","12"=>"Dec");
	$cur_date=~/([0-9]{4})([0-9]{2})([0-9]{2}).*/;
	$cur_date_per = "$3-$hash{$2}-$1";
}
print "Processing - $cur_date_per\n";

open(OUTALL, ">${output_dir}/aml_report_$cur_date_per.csv") || die "Can't open ${output_dir}/\n";
flock(OUTALL, 2) || die;
print OUTALL "TRN,Source,Msg Type,Adv Type,Address,Memo\n";

# Delete CRs and LFs from the list of logs
$inp_logs =~ s/[\x0A\x0D]//g;
my @lns = split(/,/, $inp_logs);
#print @lns;
for my $line ( @lns ) {
    ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
    print "    Start processing - $line on - $mday $months[$mon] - $hour:$min:$sec\n";
    $epoc_st = time();
    $cnt = work_on_que ($line);
    $epoc_en = time();
    $elp = $epoc_en - $epoc_st;
    ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
		print "       Items processed $cnt. End time for $line - $mday $months[$mon] - $hour:$min:$sec. Elapsed: $elp seconds. \n";
}
	
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
print "Job for period $cur_date_per ended on - $mday $months[$mon] - $hour:$min:$sec\n";
flock(OUTALL, 8) || die;
close(OUTALL);

exit  (1);

sub work_on_que {
	
	my ($que) = @_;
	my @words = split(/\//, $que);
	my $cmdq = "prt_queue -prod $words[0] -b $words[1] -loc $words[2] -na $words[3] -per $cur_date_per ";
	my $qname = $words[3];
	open(PRTQ,"$cmdq|") || die "Can not open pipe: $!\n"; 
	$cnt=0;
	while (my $line = <PRTQ>)  {
	    # split the current line on tabs
	    my @words = split(/\t/, $line);
	    if ( substr($line, 0, 1) == "2" ) {
	    	my @flds = split (/\|/, $words[0]);
		   #print "$words[0]\n";
		    $trn = trim($flds[0]);
		  # Get source 
		    $src = trim($flds[2]);
		    $msgt = trim($flds[5]);
		    $advt = trim($flds[6]);
		    my $result="";
		    my $adr="";
		    my $trni = $trn;
		    $trni =~ s/-/\//;
		    if ($src eq "OTP") {
					my $rs1 = `msgp $trn | grep \"ACK or DLV ACK could not be matched to a pending item\"`;
					if ($rs1 ne "") {
		    		next;
		    	}
		    }
# twice longer				$result = `msgp $trn -h summary -te payment | grep -i $lookfor`;
				$result = `msgp $trn | grep -i $lookfor`;
				my $pos = index($result, "BYPASS");
				if ( ($result eq "") or ( $pos != -1 ) ) {
					# check for future ?
					my $rs = `msgp $trn | grep \"FUTUREQ       ENQ\"`;
	      	if ($deb==1) {
						print "here 3 trn - $trn\n";
					}
					if ($rs eq "") {
							chop ($result);
							trim ($result);
							if ( ($msglist =~ /$msgt/) or ( ($msgt eq "") and ($qname eq "FTRENT_LOG") ) ) {
				      	if ($deb==1) {
									print "   here 4 trn - $trn\n";
								}
								$adr = getadr ($src, $trni);
								my $res = $trn . "," . $src . "," . $msgt . "," . $advt . "," . $adr . "," . $result;
							  print OUTALL "$res\n";
				      }
				      else {
				      		if ($deb==1) {
				      			print "msgtype not on the list - $msgt\n";
				      		}
				      }
					}
				}
				$cnt++;
			}
	}
	close(PRTQ);
	return $cnt;
}

sub getadr {
				my ($src, $trni) = @_;
				switch($src){
					case ["SWF","CAL","ERP","TGT","EBA"] {
						#inbound from SWF or SWF like
							  my $cmdi = "idi message:$trni incoming_ref: end: | grep -i incoming_ref";
								open(IDIQ,"$cmdi|") || die "Can not open pipe: $!\n"; 
								while (my $idil = <IDIQ>)  {
                    my $pos2 = index($idil, "\"");
                    if ($pos2 != -1) {
                    	  $pos2=$pos2 + 7;
                        $adr = substr($idil, $pos2, 11);
                    }
                }
					}
					case "CHP" {
								my $cmdi = "idi message:$trni message_text: end: | grep \"\\\[031\\\]\"";
								open(IDIQ,"$cmdi|") || die "Can not open pipe: $!\n"; 
								while (my $idil = <IDIQ>)  {
                    my $pos2 = index($idil, "]");
                    if ($pos2 != -1) {
                    	  $pos2=$pos2 + 11;
                        $adr = substr($idil, $pos2, 4);
                    }
                }
								close(IDIQ);
					}
					case "FED" {
							  my $cmdi = "idi message:$trni message_text: end: | grep \"{3100}\"";
								open(IDIQ,"$cmdi|") || die "Can not open pipe: $!\n"; 
								while (my $idil = <IDIQ>)  {
                    my $pos2 = index($idil, "}");
                    if ($pos2 != -1) {
                    	  $pos2++;
                        $adr = substr($idil, $pos2, 9);
                    }
                }
								close(IDIQ);
					}
					case ["GMS"] {
						#SRC GMS is different for US vs. JP and DE In US it is out to SWF , in DE and JP it is from SWF or SWF like
						if ( $bnk eq "SCB" ) {
						# outbound to SWIFT 
							  my $cmdi = "idi message:$trni message_text: end: | grep \"{2:I\"";
								open(IDIQ,"$cmdi|") || die "Can not open pipe: $!\n"; 
								while (my $idil = <IDIQ>)  {
                    my $pos2 = index($idil, "{2:I");
                    if ($pos2 != -1) {
                    	  $pos2=$pos2 + 7;
                        $adr = substr($idil, $pos2, 11);
                    }
                }
								if ($deb==1) {
                	print "Debug GMS US - $src - $adr\n";
              	}
						}
						else {
							  my $cmdi = "idi message:$trni incoming_ref: end: | grep -i incoming_ref";
								open(IDIQ,"$cmdi|") || die "Can not open pipe: $!\n"; 
								while (my $idil = <IDIQ>)  {
                    my $pos2 = index($idil, "\"");
                    if ($pos2 != -1) {
                    	  $pos2=$pos2 + 7;
                        $adr = substr($idil, $pos2, 11);
                    }
                }
								if ($deb==1) {
                	print "Debug GMS non US - $src - $adr\n";
                }
            }
					}
					case ["ACB","DTP","OTP"] {
						# outbound to SWIFT 
							  my $cmdi = "idi message:$trni message_text: end: | grep \"{2:I\"";
								open(IDIQ,"$cmdi|") || die "Can not open pipe: $!\n"; 
								while (my $idil = <IDIQ>)  {
                    my $pos2 = index($idil, "{2:I");
                    if ($pos2 != -1) {
                    	  $pos2=$pos2 + 7;
                        $adr = substr($idil, $pos2, 11);
                    }
                }
								if ($deb==1) {
                   print "Debug - $src - $adr\n";
                }
					}
		
					else {
								print "Unknown  src $src -  $trn.\n";
								$adr  = "???";
					}		  
				}
				return $adr;
}
	
# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}
