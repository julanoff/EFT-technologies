#!/usr/local/bin/perl
# /*********************************************************************/
# /* Script name: f50                                  */
# /*                                                                   */
# /* Description:  */
#

use Switch;

MAIN:
$area = "$ARGV[1]";
$output_dir	= "$ENV{'AREA_ROOT_DIR'}/output";
$area_name 	= uc("$ENV{'AREA_NAME'}");
$src="";

$cur_date = "$ARGV[0]";
$lookfor = "\"FLD 50F\"";
$lookfor1="";
$tag1 = ":50F";

# 
open(OUTALL, ">${output_dir}/stoplst_$cur_date.csv") || die "Can't open ${output_dir}/\n";
flock(OUTALL, 2) || die;
#print OUTALL "TRN,Source,Amount,DB Account,Sndr Reference,Phrase,Tag,Line 1,Line 2,Line 3,Line 4,Line 5\n";

my ($que) = "stop_pay_log";
my $cmdq = "prt_queue -b scb -na $que  | grep -v $cur_date";
	
open(PRTQ,"$cmdq|") || die "Can not open pipe: $!\n"; 
while (my $line = <PRTQ>)  {
	    if ( substr($line, 0, 1) == "2" ) {
		    $trn = substr($line,0, 17);
		    $line1 = `msgp $trn | grep  "\"*SYS_MEMO\""`;
		    my @lns = split(/\*SYS_MEMO/, $line1);
		    my $st=0;
		    chomp($line);
		    for my $str ( @lns ) {
			    my $pos = index($str, "Stop_Check");
			    my $pos1 = index($str, "Multiple warnings");
			    if ($pos1 != -1) {
			    	 $st = 0;
					}
					if ($st==1){
						 my $pos2 = index($str, "MATCH REF");
			    	 if ($pos2 != -1) {
			    	 	 $line = $line . "|" . trim($str);
						 }
						 my $pos2 = index($str, " in ");
			    	 if ($pos2 != -1) {
			    	 	 $line = $line . "|" . trim($str);
						 }
				  }
			    if ($pos != -1) {
			    	 $st = 1;
					}
		    }
		    print OUTALL "$line\n";
  }
}
flock(OUTALL, 8) || die;
close(OUTALL);

close (ALLQ);
exit  (1);

# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}