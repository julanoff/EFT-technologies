#!/usr/bin/perl
# -------------------------------------------------------- 
# script to search contents of a DBM repository. 
# -------------------------------------------------------- 
#
use AnyDBM_File;
#
#
my $search = "400.00 USD";
my $savekey;
if ($ARGV[0] ne "") {
		$search = trim($ARGV[0]);
}
dbmopen(%sndrefs,"sndrefndx",0666);

# direct access
print "Direct access TRn number: $sndrefs{$search}\n";

$i = 0;
$j = 0;

# sequential access

while (($key,$trn) = each(%sndrefs)) {
   $j++; 
    if ($key =~ /$search/) {
        $i++; 
        print "$i. [$trn] has [$key]\n";	
        }
    }
printf "\n ===> $i Records found out of $j.\n ";
#
#
dbmclose(%sndrefs);

# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}