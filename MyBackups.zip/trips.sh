#!/usr/local/bin/bash
# make sure no items on cut_excq
cnt=$(q_util -summary -inc /SCB///cut_excq -message -notrn | grep -i count)
if [ "$cnt" != "" ]
then
   echo " CUT_EXCQ has items . Exiting."
   exit
fi
from=$1
cmt=$2
if [ "$cmt" == "WHS" ] && [ "$from" == "FUTUREQ" ]
then
    echo "moving msgs from " $from " with comment " $cmt
else

	if [ "$from" != "DDA_BACKEND" ] && [ "$from" != "TSI1_SRF" ] && [ "$from" != "FUTUREQ" ]
	then
	     echo "from should be either DDA_BACKEND or TSI1_SRF"
	     exit
	fi
	if [ "$cmt" != "SNT" ] && [ "$cmt" != "RCV" ] && [ "$cmt" != "CMP" ] && [ "$cmt" != "WHS" ]
	then
	     echo "comment should be RCV, SNT, or CMP"
	     exit
	fi
	echo "moving msgs from " $from " with comment " $cmt
fi

#exit 


prt_queue -b scb -na $from  -c 3 | while read str; 
do
  if [ ${str:0:1} == "2" ] 
  then 
     if [[ $str == *"(none)"* ]]
     then
       echo "period is empty!";
     else
      dt=${str:0:17}
      at=$( msgp $dt | grep -i dda_postq)
      st=$( msgp $dt | grep -i dda_backend)
      dd=$(date +"%d-%b-%Y %X.00" | tr "[a-z]" "[A-Z]")
      cmd=$(move_utility -f /scb//$from -t /scb//cut_excq -c 1 -memo "$cmt/F $dd")
#good works      cmd=$(move_utility -f /scb//dda_backend -t /scb//cut_excq -c 1 -memo "CMP/F 6-APR-2015 13:45:52.21")
      echo "fromtcmd - " $cmd
#      echo "trn- " $dt "c tip CMP/F" $dd  " backend - " $st " ddapost " $at 
    fi
  else 
    echo nog0od; 
  fi
done
