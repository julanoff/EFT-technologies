#!/usr/local/bin/perl
# /*********************************************************************/
# /* Script name: f50                                  */
# /*                                                                   */
# /* Description:  */
#

	use Switch;
  use MQSeries qw(:functions);
  use MQSeries::Queue;
  use MQSeries::Message;

  print "1. Write Msg\n"
  print "2. Read Msg\n"
	$ans=<>; 
	print $ans;
	Exit;
	
sub writemsg {
  #
  # Open a queue for output, and write a message with properties
  #
  my $qmgr_obj = MQSeries::QueueManager->
    new('QueueManager' => 'JPMTS1S1');
  my $queue = MQSeries::Queue->new(QueueManager => $qmgr_obj,
                                   Queue        => 'JPT.MPS.TEMP',
                                   Mode         => 'output')
    or die("Unable to open queue.\n");

  my $msg = MQSeries::Message->new(Data => "Example message data");

  $queue->Put(Message    => $msg,
              Properties => { 'perl.MQSeries.example' => 'property value', },
             );
}

sub writemsg1 {
  #
  # Alternative: perform a Put1 with properties
  #
  my $qmgr_obj = MQSeries::QueueManager->
    new('QueueManager' => 'some.queue.manager');
  my $msg = MQSeries::Message->new(Data => "Example message data");

  $qmgr_obj->Put1(Queue   =  > 'SOME.QUEUE',
                  Message    => $msg,
                  Properties => { 'perl.MQSeries.example' => 'property value', },
                 );
}

sub readmsg {
  #
  # Open a queue for input, read a message, and then list the properties
  #
  my $queue = MQSeries::Queue->new(QueueManager => $qmgr_obj,
                                   Queue        => 'SOME.QUEUE',
                                   Mode         => 'input')
    or die("Unable to open queue.\n");

  my $msg = MQSeries::Message->new();
  $queue->Get(Message    => $msg)
    or die("Unable to get message");

  my $props_hashref = $msg->Properties()->GetProperties();

  #
  # Create a properties object and manipulate it directly.  It can
  # then be passed to a $queue->Put() operation as the Properties
  # parameter.
  #
  my $props = MQSeries::Properties->new('QueueManager' => $qmgr_obj);
  $props->SetProperty(Name  => 'perl.MQSeries.demo.int',
                      Value => 42,
                      Type  => MQSeries::MQTYPE_INT32);
  $props->SetProperty(Name  => 'perl.MQSeries.demo.float',
                      Value => 3.141265,
                      Type  => MQSeries::MQTYPE_FLOAT64);
  my $prop_hashref = $props->GetProperties('Name' => 'perl.MQSeries.%');
  $props->DeletePropery(Name => 'perl.MQSeries.demo.float');
}