#!/usr/local/bin/bash
from=$1
# make sure no items on OFACHLD_OFPQ
cnt=$(q_util -summary -inc /SCB///$from -message -notrn | grep -i count)
if [ "$cnt" == "" ]
then
   echo " $from has no items . Exiting."
   exit
fi
from=$1

#exit 


prt_queue -b scb -na $1  -c 3 | while read str; 
do
  if [ ${str:0:1} == "2" ] 
  then 
     if [[ $str == *"(none)"* ]]
     then
       echo "period is empty!";
     else
      dt=${str:0:17}
      at=$( msgp $dt | grep -i dda_postq)
      st=$( msgp $dt | grep -i dda_backend)
      dd=$(date +"%d-%b-%Y %X.00" | tr "[a-z]" "[A-Z]")
      cmd=$(msgp $dt | grep -i "\(OFC\)")
      echo "trn-  $str"
      echo " - " $cmd
      echo "_____________________"
    fi
  fi
done
