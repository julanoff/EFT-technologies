#!/usr/bin/perl
# -------------------------------------------------------- 
#
# Use the default DBM utilites
#
use AnyDBM_File;
$fn = "$ARGV[0]";

my $bnk = "SCB";
my $que = "SENDREFNDX";
my $cur_date = "20150515";
my $cmdq = "prt_queue -b $bnk -na $que  | grep  $cur_date";

dbmopen(%sndrefs,"idirefndx",0666);

open(INALL, "<$fn") || die "Can't open '$fn' /\n";
my $st=0;
my $msg ="";
while (my $line = <INALL>)  {
		chomp($line);
		$line = trim($line);
	#print "$line\n";
    if ( substr($line, 0, 8) eq "MESSAGE:" ) {
    	$st=1;
    	$sbk="";
    	$msg="";
    	$amt="";
    	$trn="";
    	$curr="";
			$msg = $msg . $line . "\r\n";
			next;
    }
    if ( substr($line, 0, 33) eq "END: <VSTR(48)>       \"MESSAGE\"" ) {
    	print "end:";
    	$st=0;
			$msg = $msg . $line . "\r\n";
      chop($sbk);
      $key = $sbk . " " . $curr . " " . $amt;
      print "key - $key , trn - $trn, msg - $msg";
      $sndrefs{$key} = $trn; 
	    #print " $sndrefs [ $key ] \n"; 
			open(OUTALL, ">$trn.idi") || die "Can't open ${output_dir}/\n";
			flock(OUTALL, 2) || die;
			print OUTALL $msg;
			flock(OUTALL, 8) || die;
			close(OUTALL);
	    $cnt ++;
			next;
    }
    if ( substr($line, 0, 8) eq "TRN_REF:" ) {
    	 my @lns = split(/\"/, $line);
       $trn = $lns[1];
       $trn =~ s/\//-/;
    }
    if ( substr($line, 0, 7) eq "AMOUNT:" ) {
    	 my @lns = split(/\"/, $line);
       $amt = $lns[1];
    }
    if ( substr($line, 0, 14) eq "CURRENCY_CODE:" ) {
    	 my @lns = split(/\"/, $line);
       $curr = $lns[1];
    }
    if ( substr($line, 0, 12) eq "SBK_REF_NUM:" ) {
    	 my @lns = split(/\"/, $line);
       $sbk = $lns[1];
    	print "sbk - $sbk\n";
    }
		if ($st == 1 ) {
			$msg = $msg . $line . "\r\n";
		}
		$rem = $cnt % 100;
		if ( $rem == 0 and $cnt > 0) {
			print "$cnt\n";
		}
}
close(INALL);

exit  (1);


#
# Commit changes in hash to disk for the next flush.
#
close (PRTQ);
dbmclose(%sndrefs);


# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}