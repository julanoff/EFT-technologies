#!/usr/bin/perl
# -------------------------------------------------------- 
# script to search contents of a DBM repository. 
# -------------------------------------------------------- 
#
use AnyDBM_File;
#
#
my $search = "400.00 USD";
my $savekey;
if ($ARGV[0] ne "") {
		$search = trim($ARGV[0]);
}
dbmopen(%sndrefs,"idirefndx",0666);

# direct access
#print "Direct access TRn number: $sndrefs{$search}\n";
my $trn = $sndrefs{$search};
if ($trn eq "") {
		print "failed";
}
else {
		open(INALL, "<$trn.idi") || die "Can't open '$fn' /\n";
		while (my $line = <INALL>)  {
			print $line;
		}
		close(INALL);
}
dbmclose(%sndrefs);

# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}