#!/usr/local/bin/perl
# /*********************************************************************/
# /* Script name: f50                                  */
# /*                                                                   */
# /* Description:  */
#

use Switch;

MAIN:
$area = "$ARGV[1]";
$output_dir	= "$ENV{'AREA_ROOT_DIR'}/output";
$area_name 	= uc("$ENV{'AREA_NAME'}");
$src="";

# 

work_on_que("20150424-00002490");
exit  (1);

sub work_on_que {
	
	($trn) = @_;
	
		  # Get source 
		    $src = "SWF";
		    my $result="";
				switch($src){
					case "SWF" {
						$lookfor = "\"FLD 50F\"";
						$tag = ":50F";
						$result = `msgp $trn | grep -i $lookfor`;
					}
					case "CHP" {
						$lookfor = "\"FLD 50F\"";
						$tag = ":50F";
				    		$result = `msgp $trn | grep -i $lookfor`;
						if ($result eq ""){
							$lookfor = "\"FLD 502\"";
							$tag="[502]";
					    		$result = `msgp $trn | grep -i $lookfor`;
						}
						print "$trn - $src - $lookfor - $tag \n";
					}
					case "FED" {
						$lookfor = "\"FLD 50F\"";
						$tag = ":50F";
				    		$result = `msgp $trn | grep -i $lookfor`;
						if ($result eq ""){
							$lookfor = "\"FLD 5010\"";
							$tag="{5010}";
					    		$result = `msgp $trn | grep -i $lookfor`;
						}
					}
					else {
						print "$src - incorrect source\n";
					}
				}
		  # print $result;
		    if ($result eq ""){
		    	print "$trn no field $lookfor\n";
		    	next;
		    }
		    my $pos = index($result, "in");
		    my $phrase="";
		    if ($pos != -1)
		    {
					$phrase = substr ($result, 0, $pos);
		    }
		    $phrase =~ s/\*SYS_MEMO/ /;
		    my $res = gatherresults(trim($phrase), $tag);
		    print " res - ", $res, "\n";
		    $res = $res . "\r\n";
		    print $res;
}

sub gatherresults {
	#print " gather results for $trn $src $tag\n";
	my ($phrase, $tag) = @_;
	$trnd=substr($trn,0,8);
	$trnn=substr($trn,9,8);
	my $res = $trnd . "-" . $trnn;
	
	print $trn;

	$res = $res . "," . $src;

	$ret = get_fld_val ("AMOUNT");
	$res = $res . "," . $ret;

	$ret = get_fld_val ("DBT_ACCOUNT");
	$res = $res . "," . $ret;

	$ret = get_fld_val ("SBK_REF_NUM");
	$res = $res . "," . $ret;

	$res = $res . "," . $phrase;
	$res = $res . "," . $tag;
print "1. $res";

	$cmd = "idi message:$trnd/$trnn message_text: end:";
  	if ($src eq "SWF") {
  		$res = $res . parse_swf($cmd, $tag);
	}
  	if ($src eq "CHP") {
  		$res = $res . parse_chp($cmd, $tag);
	}
  	if ($src eq "FED") {
  		$res = $res . parse_fed($cmd, $tag);
	}
	return $res;
}



sub parse_fed {
	my ($cmdi, $tag) = @_;
  	open(MSGP,"$cmdi|") || die "Can not open pipe: $!\n"; 
  	my $sw = 0;
  	my $done=0;
  	my $res="";
  	my $nxt_chr="";
  	if ($tag eq "{5010}") {
  		$nxt_chr = "{";
  	}
  	else {
  		$nxt_chr = ":";
  	}
	while (my $line = <MSGP>)  {
	    # split the current line on tabs
	    my @words = split(/\t/, $line);
	    my $char = "                                    MESSAGE_TEXT: <TEXT_SEQ(80)U>  ";
	    my $pos = index($words[0], $char);
	    my $txt="";
	    if ($pos != -1)
	    {
		$txt = substr $words[0], $pos+length($char) + 1;
	    }
	    my $pos1 = index($txt, $tag);
	    #print "trn-", $trn, " - txt - ", $txt, "  - Tag -", $tag, "\n";
			if ($sw == 1 )
			{
				$pos = index($txt, $nxt_chr);
				if ($pos == 0)
				{
					$done =1;
					next;
				}
				if ($done==0)
				{
					chop($txt);
					chop($txt);
					$txt =~ s/,/ /;
					$res = $res . "," . $txt;
				}
			}
			if ($pos1 != -1)
			{
				$sw=1;
				chop($txt);
				chop($txt);
				$txt =~ s/,/ /;	
				$res = $res . "," .$txt;
			}
		  #print "$res \n";
	}	
	close (MSGP);
	return $res;
}

sub parse_chp {
	my ($cmdi, $tag) = @_;
  open(MSGP,"$cmdi|") || die "Can not open pipe: $!\n"; 
  my $sw = 0;
  my $done=0;
  my $res="";
  my $nxt_chr="";
  if ($tag eq "[502]") {
  	$nxt_chr = "[";
  }
  else {
  	$nxt_chr = ":";
  }
	while (my $line = <MSGP>)  {
	    # split the current line on tabs
	    my @words = split(/\t/, $line);
	    my $char = "                                    MESSAGE_TEXT: <TEXT_SEQ(80)U>  ";
	    my $pos = index($words[0], $char);
	    my $txt="";
			if ($pos != -1)
			{
				$txt = substr $words[0], $pos+length($char) + 1;
			}
	    my $pos1 = index($txt, $tag);
	    #print "trn-", $trn, " - txt - ", $txt, "  - Tag -", $tag, "\n";
			if ($sw == 1 )
			{
				$pos = index($txt, $nxt_chr);
				if ($pos == 0)
				{
					$done =1;
					next;
				}
				if ($done==0)
				{
					chop($txt);
					chop($txt);
					$txt =~ s/,/ /;
					$res = $res . "," . $txt;
				}
			}
			if ($pos1 != -1)
			{
				$sw=1;
				chop($txt);
				chop($txt);
				$txt =~ s/,/ /;
				$res = $res . "," .$txt;
			}
		  #print "$res \n";
	}	
	close (MSGP);
	return $res;
}


sub parse_swf {
	my ($cmdi, $tag) = @_;
  open(MSGP,"$cmdi|") || die "Can not open pipe: $!\n"; 
  my $sw = 0;
  my $done=0;
  my $res="";
	while (my $line = <MSGP>)  {
	    # split the current line on tabs
	    my @words = split(/\t/, $line);
	    my $char = "                                    MESSAGE_TEXT: <TEXT_SEQ(80)U>  ";
	    my $pos = index($words[0], $char);
	    my $txt="";
			if ($pos != -1)
			{
				$txt = substr $words[0], $pos+length($char) + 1;
			}
	    my $pos1 = index($txt, $tag);
	    #print "trn-", $trn, " - txt - ", $txt, "  - Tag -", $tag, "\n";
			if ($sw == 1 )
			{
				$pos = index($txt, ":");
				if ($pos == 0)
				{
					$done =1;
					next;
				}
				if ($done==0)
				{
					chop($txt);
					chop($txt);
					$txt =~ s/,/ /;
					$res = $res . "," . $txt;
				}
			}
			if ($pos1 != -1)
			{
				$sw=1;
				chop($txt);
				chop($txt);
				$txt =~ s/,/ /;
				$res = $res . "," .$txt;
			}
		  #print "$res \n";
	}	
	close (MSGP);
	return $res;
}

sub get_fld_val {
	my ($fld) = @_;
	my $res = "";
	my $cmd = "idi message:$trnd/$trnn $fld: end:";
# go through the file line by line   
  open(MSGP,"$cmd|") || die "Can not open pipe: $!\n"; 
  $sw = 0;
  $done=0;
	while (my $line = <MSGP>)  {
	    # split the current line on tabs
	    my @words = split(/\t/, $line);
	    my $pos = index($words[0], $fld);
			if ($pos != -1 && $done==0)
			{
				my $pos1 = index($words[0], "\"");
				$res = substr $words[0], $pos1+1;
				chop($res);
				chop($res);
				$done=1;
			}
	}
	close(MSGP);
	return $res;
}

# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}
