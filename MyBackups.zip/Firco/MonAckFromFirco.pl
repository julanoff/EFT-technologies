#!/usr/local/bin/perl
# /*********************************************************************/
# /* Script name:   MonAckFromFirco.pl                                         */
# /*                                                                   */
# /* Description:                                                      */
# /* scan firco pending q , check the status for each message.
# /* for EOD report usage (<rpt> argument) it runs once and creates a report.
# /* for constant monitor (<mon> argument) it wakes up every n mins and examines the pending queue. 
# /*    if it finds more than X number of unacked msgs ENGUARD is generated and line shuts down ( maybe).
# /* find unacked transactions, count, and report if the number is higher than x
# Usage:
# MonAckFromFirco.pl <RPT>or<SCAN>, <bank>, <que>
# <bank> can be: SCB (US), JPR (JP), EEF (DE);
# <que> name of the pending queue for firco line

use Switch;

# debug switch. 1 is ON, 0 is OFF
$deb=1;		

$mode = "$ARGV[0]"; 
$bnk = "$ARGV[1]";
$que = "$ARGV[2]";
$passindicator = "DECI-P-FMF";
$hitindicator  = "HIT--I";
$memo  = "\"*SYS_MEMO\"";
$tolerance=20;
@hld_trns = ();
$noack=0;
$nosame=0;
$infack=0;
$minToSleep=15;
$appcode="";
$timstr="";
$cnt=0;


if ( ! $ENV{'AREA_NAME'} ) {
        print "You have to be in a Area\n";
        exit(0); }

if ( ($mode ne "RPT" ) &&  ($mode ne "SCAN" )  ) {
        print "You have to specify a mode (RPT or SCAN)\n";
        exit(0); }

if  ($bnk eq "SCB" ) {
	$appcode="MTS-US";
}
if  ($bnk eq "EEF" ) {
	$appcode="MTS-DE";
}
if  ($bnk eq "JPT" ) {
	$appcode="MTS-JP";
}

if  ($mode eq "RPT" ) {
		open(CRD,"showperiods |") || die "Can not open pipe: $!\n"; 
		while (my $line = <CRD>)  {
			    my $pos = index($line, "CURRENT");
					if ($pos != -1) {
						$cur_date_per=substr($line,1,11);
						last
					}
				}
		close(CRD);
		my ($day,$mon,$yr) = split /\-/,$cur_date_per;
		my @months=qw(JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC );
		$i=0;
		foreach $_ (@months)
		    {
		        $i++; 
		        if (/$mon/i){$mon=$i;}
		    }
		$mon=sprintf "%02d",$mon;
		print "Invalid month format $date present in $file_name" if $mon ==0;
		$cur_date = "$yr$mon$day";	
		print "Producing report for - $cur_date\n";
		$output_dir	= "$ENV{'AREA_ROOT_DIR'}/output";
		open(OUTALL, ">${output_dir}/Pendinglist_MTS_$cur_date.txt") || die "Can't open ${output_dir}/\n";
		flock(OUTALL, 2) || die;

		scan_que();

		flock(OUTALL, 8) || die;
		close(OUTALL);
}
else{
	while (1) {
		$st = scan_que();
		if ( $st == 0 ) {
			break;
		}
		if ($deb==1) {
			print "noack = $noack\n";
			print "nosame = $nosame\n";
		}
		if ( $noack > $tolerance ) {
			if ($nosame > $tolerance ) {
				system("log_message ENGUARD 'There is a problem with FIRCO Scanner. Line is coming down.'");
			}
			else {
				my $msg = "The number of unacknowledge messages is more then $tolerance.";
				system("log_message ENGUARD $msg");
			}
		}
# wake up every 15 mins
		$secToSleep = $minToSleep*60;
		#sleep($secToSleep);
		sleep(5);
	}
}
exit;
		
sub scan_que {
# Check for entia up.

		$ent_status = system("ent status | grep -v RHS | grep DOWN > /dev/null");
		if ( ! $ent_status ) {
			print "Entia is not currently Running. Aborting.\n";
      return(0); 
    }

		my @cur_trns = ();
		$noack=0;
		$nosame=0;
		$infack=0;
		my $cmdq = "prt_queue -b $bnk -na $que ";
   	if ($deb==1) {
				print "Command - $cmdq\n"; }
		open(CRD,"$cmdq|") || die "Can not open pipe: $!\n"; 
		while (my $line = <CRD>)  {
			    if ( substr($line, 0, 1) == "2" ) {
				    my @words = split(/\|/, $line);
# this searchs for time but they don't need it now leave it here in case they change their minds
#						my $cmd1 = "msgprint $words[0]  -text none | grep $que";
#						open(CRD1,"$cmd1|") || die "Can not open pipe: $!\n"; 
#						my $ans = <CRD1>;
#						my @prts = split(/\s+/, $ans);	#split by spaces
#						$timestr=$prts[5] . ' ' . substr($prts[6],0,11);
					#	print "$ans - time  $timestr\n";
#						close(CRD1);
						my $cmd1 = "msgprint $words[0]  -text none -hist summary | grep $memo | grep $hitindicator";
						open(CRD1,"$cmd1|") || die "Can not open pipe: $!\n"; 
						my $ans = <CRD1>;
#						print "$ans\n"; }
					  my $pos2 = index($ans, $hitindicator);
#						print "$words[0] looking for $hitindicator in $ans\n";
# Status : 012-hit , " " -no hit
		        if ($pos2 != -1) {
			        	$infack++;
								if  ($mode eq "RPT" ) {
									my $trn = trim($words[0]);
									$cnt++;
				    	    print OUTALL "$trn|012|MTS|$appcode\n";
				    	  }
								if ($deb==1) {
				        	print "$words[0] Info recieved\n"; }
			   		}
			   		else {
			        $noack++;
			        push @cur_trns, trim($words[0]); 
							if  ($mode eq "RPT" ) {
								my $trn = trim($words[0]);
								$cnt++;
			    	    print OUTALL "$trn| |MTS|$appcode\n";
			    	  }
							if ($deb==1) {
				       	print "$words[0] No Ack recieved\n"; }
				    }
				    close(CRD1);
			   	}
		}
   	print OUTALL "RECORD Count: $cnt";
		close(CRD);
		if  ($mode ne "RPT" ) {
			if ($deb==1) {
	       	print "No Ack recieved list @cur_trns \n"; }
# now we want to compare the trns from our previous runs if they are the same it is pretty good indication we have ISSUES.
			my $curCnt = @cur_trns;
			my $hldCnt = @hld_trns;
			my $loopCnt = 0;
			if ( $hldCnt < $curCnt ) {
				$loopCnt = $hldCnt
			}
			else {
				$loopCnt = $curCnt
			}
			for (my $i=0; $i <= $loopCnt; $i++) {
				if ($hld_trns[$1] == $cur_trns[$i]) {
					$nosame++;
				}
			}
#			foreach (@cur_trns) { print $_; }
			@hld_trns =();
			push @hld_trns, @cur_trns;
			return (1);
		}
}

	
# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}
