#!/usr/local/bin/perl
# /*********************************************************************/

use Switch;

# debug switch. 1 is ON, 0 is OFF
$deb=1;		

$bnk = "$ARGV[0]";
$que = "$ARGV[1]";
$match = "\"*SYS_MEMO         Stop_Check MATCH\"";
$nomatch = "\"*SYS_MEMO         Stop_Check NO MATCH\"";
$hldq = "FIRCO_HOLDQ";


if ( ! $ENV{'AREA_NAME'} ) {
        print "You have to be in a Area\n";
        exit(0); }

scan_que();

exit;
		
sub scan_que {
# Check for entia up.

	  $cnt=0;
		my $cmdq = "prt_queue -b $bnk -na $que";
   	if ($deb==1) {
				print "Command - $cmdq\n"; }
		open(CRD,"$cmdq|") || die "Can not open pipe: $!\n"; 
		while (my $line = <CRD>)  {
			    if ( substr($line, 0, 1) == "2" ) {
			    	$cnt++;
			    	if ( ($cnt % 100) == 0){
			    		print "Processed $cnt\n";
			    	}
				    my @words = split(/\|/, $line);
						my $cmd1 = "msgprint $words[0]  -text none  | grep $nomatch";
						open(CRD1,"$cmd1|") || die "Can not open pipe: $!\n"; 
						my $ans = <CRD1>;
		    	  close(CRD1);
						if ( length ($ans) > 2 ) {
							my $cmd1 = "msgprint $words[0]  -text none  | grep $hldq";
							open(CRD1,"$cmd1|") || die "Can not open pipe: $!\n"; 
							my $ans = <CRD1>;
			    	  close(CRD1);
						  my $pos2 = index($ans, $hldq);
	#						print "$words[0] looking for $hldq in $ans\n";
			        if ($pos2 == -1) {
								my $cmd1 = "msgprint $words[0]  -text none  | grep \"RISK_Q        ENQ\"";
								open(CRD1,"$cmd1|") || die "Can not open pipe: $!\n"; 
								my $ans = <CRD1>;
				    	  close(CRD1);
				        if ( length ($ans) < 2) {
									my $trn = trim($words[0]);
			    	  		print "$trn, no STOP match and NO FIRCOHLDQ. BAD\n";
			    	  	}
			    	  }
			    	  next;
			    	}

						my $cmd1 = "msgprint $words[0]  -text none  | grep $match";
						open(CRD1,"$cmd1|") || die "Can not open pipe: $!\n"; 
						my $ans = <CRD1>;
						close(CRD1);
						if ( length ($ans) > 2 ) {
							my $cmd1 = "msgprint $words[0]  -text none  | grep $hldq";
							open(CRD1,"$cmd1|") || die "Can not open pipe: $!\n"; 
							my $ans = <CRD1>;
			    	  close(CRD1);
						  my $pos2 = index($ans, $hldq);
	#						print "$words[0] looking for $hldq in $ans\n";
			        if ($pos2 != -1) {  
								my $cmd1 = "msgprint $words[0]  -text none  | grep \"PAYADVQ       DEQ\"";
								open(CRD1,"$cmd1|") || die "Can not open pipe: $!\n"; 
								my $ans = <CRD1>;
				    	  close(CRD1);
				        if ( length ($ans) < 2) {
									my $trn = trim($words[0]);
				    	    print "$trn, STOP match and fircohldq. BAD.\n";
			    	  	}
			    	  }
			    	  next;
						}
		    	}
		}
		close(CRD);
}

	
# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}
