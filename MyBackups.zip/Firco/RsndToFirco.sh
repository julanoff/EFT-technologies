#!/usr/local/bin/bash

movetrn () {
  if [ ${str:0:2} = "-n" ] ;
  then
    dt=${str:3:24}
    cnt=$(q_util -summary -inc /JPT///$dt -message -notrn | grep -i count)
    if [ "$cnt" != "" ]
    then
       echo " $dt has $cnt items."
			 if [ $dt == *"ADM"* ] || [ $dt == *"AML"* ] || [ $dt == *"RTN"* ] || [ $dt == *"FCP"* ]
			 then
       		cmd=$(move_utility -f /jpt//$dt -t /jpt//fcs_adm_outq -c 1 -memo "Send to Firco to rescan")
     	 else
       		cmd=$(move_utility -f /jpt//$dt -t /jpt//fcs_pay_outq -c 1 -memo "Send to Firco to rescan")
       fi
       echo "from cmd - " $cmd
  #  else
  #    echo " $dt has no items."
    fi
  else
    echo nog0od;
  fi
}

alloc_que -li | grep OFA | while read str;
do
  movetrn $str
done

alloc_que -li | grep FIRCO_HOLDQ | while read str;
do
  movetrn $str
done

exit
