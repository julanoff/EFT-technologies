#!/usr/local/bin/bash

que_exist=$(alloc_que -li | grep -i fcs3_outq)

if [ -z "$que_exist" ]; then
    echo "Allocating fcs3_outq."
   alloc_que -n FCS3_OUTQ  -b JPT -t GEN_WORK_QUE -d STATIC -o MSG_HISTORY_SEQ -ape -m "BCP2 q for Firco"
else
    echo "Queue exists"
fi  

move_utility -f /jpt//firco_holdq -t /jpt//fcs3_outq -c 999999 -memo "Send to Firco"

linecmd -b jpt -lin fcs3_snd -connect /jpt///fcs3_outq
linecmd -b jpt -lin fcs3_snd -disconnect /jpt///firco_holdq
linecmd -b jpt -lin fcs3_snd -sh

echo "Make sure that ONLY FCS3_OUTQ is connected and Type yes to continue."
read ans
while [ "$ans" != "yes" ] && [ "$ans" != "no" ]; do
        echo -ne "Please type 'yes' or 'no': "
        read ans
done

if [ $ans == "no"  ]; then
   echo "Exiting..."
   return 1 
fi
echo "Bringing up the line..."
linecmd -b jpt -lin fcs3_snd -up

msgNo=$(linecmd -b jpt -lin fcs3_snd -sh | grep "Pending"| tr -s ' ' | cut -d " " -f 5)
while [ $msgNo -gt 0 ]; do
		msgNo=$(linecmd -b jpt -lin fcs3_snd -sh | grep "Pending"| tr -s ' ' | cut -d " " -f 5)
		sleep 20
		echo "Remaining $msgNo messages to process"
done

echo "All messages are sent. Disconnecting the line"

linecmd -b jpt -lin fcs3_snd -down
linecmd -b jpt -lin fcs3_snd -disconnect /jpt///fcs3_outq
linecmd -b jpt -lin fcs3_snd -connect /jpt///firco_holdq
linecmd -b jpt -lin fcs3_snd -sh
 