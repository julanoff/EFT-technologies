#!/usr/bin/perl
# -------------------------------------------------------- 
#
# Use the default DBM utilites
#
use AnyDBM_File;
my $bnk = "SCB";
my $que = "SENDREFNDX";
my $cur_date = "20150515";
my $cmdq = "prt_queue -b $bnk -na $que  | grep  $cur_date";
dbmopen(%sndrefs,"sndrefndx",0666);

open(PRTQ,"$cmdq|") || die "Can not open pipe: $!\n";
my $cnt=0;
while (my $line = <PRTQ>)  {
    if ( substr($line, 0, 1) == "2" ) {
    	 my @lns = split(/\|/, $line);
       $trn = $lns[0];
       $amt = trim($lns[1]);
       $ref = $lns[9];
       chop($ref);
       $key = $ref . " " . $amt;
       #print "key - $key , trn - $trn";
       $sndrefs{$key} = $trn; 
	     #print " $sndrefs [ $key ] \n"; 
	     $cnt ++;
		}	
		$rem = $cnt % 100;
		if ( $rem == 0 ) {
			print "$cnt\n";
		}
}                    
#
# Commit changes in hash to disk for the next flush.
#
close (PRTQ);
dbmclose(%sndrefs);


# perl trim function - remove leading and trailing whitespace
sub trim($)
{
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}