cp -f $(bld_path_ls SBJ_LIB_PATH/scb_fnc_main) /usr/local/intranet/areas/usn_dvl/lib
cp -f $(bld_path_ls SBJ_SYM_PATH/scb_fnc*.sym) /usr/local/intranet/areas/usn_dvl/sym
cp -f $(bld_path_ls SBJ_SYM_PATH/scb_func_*.sym) /usr/local/intranet/areas/usn_dvl/sym
cp -f $(bld_path_ls SBJ_SYM_PATH/scb_fnc_*.symv) /usr/local/intranet/areas/usn_dvl/sym 
cp -f $(bld_path_ls SBJ_BIN_PATH/rsndmsgs) /usr/local/intranet/areas/usn_dvl/bin
cp -f $(bld_path_ls SBJ_SYM_PATH/rsndmsg*.sym) /usr/local/intranet/areas/usn_dvl/sym
