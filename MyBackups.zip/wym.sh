#!/usr/local/bin/bash
from=$1




alloc_que -li | grep OFACQ | while read str; 
do
  if [ ${str:0:2} = "-n" ] ;
  then
    dt=${str:3:24}
    cnt=$(q_util -summary -inc /SCB///$dt -message -notrn | grep -i count)
    echo $cnt
    if [ "$cnt" != "" ]
    then
        echo " $dt has $cnt items."
				prt_queue -b scb -na $dt  | while read str1; 
				do
					workque $str1
				done
  #  else
  #    echo " $dt has no items."
    fi
  else
    echo nog0od;
  fi

done
