#!/usr/local/bin/bash
from=$1
# make sure no items on OFACHLD_OFPQ

prt_queue -b scb -na cancel_log -per 28-may-2015 | while read str; 
do
  if [ ${str:0:1} == "2" ] 
  then 
     if [[ $str == *"(none)"* ]]
     then
       echo "period is empty!";
     else
      dt=${str:0:17}
      at=$( msgp $dt | grep -i "Forcing thru OFAC")
      if [[ $at == *"Memo: Forcing thru OFAC"* ]]
      then
        echo "trn-  $str";
      fi
    fi
  fi
done
