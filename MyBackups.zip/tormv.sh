#!/usr/local/bin/bash

movetrn () {
  if [ ${str:0:2} = "-n" ] ;
  then
    dt=${str:3:24}
    cnt=$(q_util -summary -inc /SCB///$dt -message -notrn | grep -i count)
    if [ "$cnt" != "" ]
    then
       echo " $dt has $cnt items."
       cmd=$(move_utility -f /scb//$dt -t /scb//rejectq -c 999999 -memo "Forcing thru OFAC")
       echo "from cmd - " $cmd
  #  else
  #    echo " $dt has no items."
    fi
  else
    echo nog0od;
  fi
}

alloc_que -li | grep RPRQ | grep -v MCI | grep -v SWF | while read str;
do
  movetrn $str
done

alloc_que -li | grep EXCQ | grep -v BKE | grep -v ADM | while read str;
do
  movetrn $str
done

alloc_que -li | grep VFYQ | grep -v ADM | grep -v AUT | grep -v PDM | while read str;
do
  movetrn $str
done

alloc_que -li | grep FUTUREQ | while read str;
do
  movetrn $str
done

exit
~
