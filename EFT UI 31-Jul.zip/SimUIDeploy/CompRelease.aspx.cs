/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Text;
using System.Data;
using System.Xml;
using System.Collections;
using System.Diagnostics;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Obout.Grid;
using Obout.Interface;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.SimLog;



/*
 * 
 * Project update page.
 * This is a batch monitoring page.
 * 
 * 
 */

namespace Simulator
{
    public partial class CompRelease : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindDataGrid();
            }
        }

        public void DataGrid_Delete(Object sender, GridRecordEventArgs e)
        {
            string Id, Cmd, CmpId, Qname;
            Id = e.Record["Batchind"].ToString();
            CmpId = e.Record["pk"].ToString();
            Qname = e.Record["qn"].ToString();

            DBAccess connection = new DBAccess();
            DBAccess connection1 = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);

            Cmd = string.Format("delete from batchdescr where batchid={0} and compid={1}", Id, CmpId);
            connection.Execute(Cmd, false);
            Cmd = string.Format("delete from {0} where batchind={1} and pk={2}", Qname, Id, CmpId);
            connection.Execute(Cmd, true);
            BindDataGrid();
        }

        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = DataGrid1.Templates[templateIndex].Container.FindControl(controlId);

            //     return ctrl.ClientID;
            return "";
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }

        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {
            //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
        }

        protected void BindDataGrid()
        {
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            string vendor = HttpContext.Current.Session["Vendor"].ToString();
            string Cmd, Cmd1="";
            connection.Connect(false, dbname);
            Cmd = string.Format("SELECT name FROM sysobjects where name like 'COMPARE%Q'");
            connection.OpenDataReader(Cmd);
	        int i=0;
            while (connection.SQLDR.Read())
            {
		        if (i>0)
			        Cmd1 = Cmd1 + " union all ";
		        Cmd1 = Cmd1 + string.Format("select '{0}' as qn, a.pk, a.batchind, b.batchdescr, b.batchstatus from {0} a, batchdescr b where a.ProcessState='H' and a.batchind=b.batchid and a.pk=b.compid ",connection.SQLDR[0].ToString().Trim());
		        i++;
            }
            Cmd1 = Cmd1 + "order by a.batchind, a.pk";
            connection.CloseDataReader();

   //  select 'compare2q' as qn, * from compare2q union all select 'compare1q' as qn, * from compare1Q union all select 'compare3q' as qn, * from compare3q

            try
            {
                DataSet ds = connection.getDataSet(Cmd1);
                DataGrid1.DataSource = ds;
                DataGrid1.DataBind();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                connection.CloseDataReader();
                connection.DisConnect();
            }
        }

        public void Refresh_click(object sender, System.EventArgs e)
        {
            if (DataGrid1.SelectedRecords != null)
            {
                string Id, Cmd, CmpId, Qname;
                DBAccess connection = new DBAccess();
                DBAccess connection1 = new DBAccess();
                String dbname = (String)HttpContext.Current.Session["CurrentDB"];
                connection.Connect(true, dbname);

                foreach (Hashtable oRecord in DataGrid1.SelectedRecords)
                {
                    Id = oRecord["Batchind"].ToString();
                    CmpId = oRecord["pk"].ToString();
                    Qname = oRecord["qn"].ToString();
                    Cmd = string.Format("update batchdescr set BatchStatus='Compare Running' where batchid={0} and compid={1}", Id, CmpId);
                    connection.Execute(Cmd, false);
                    Cmd = string.Format("update {0} set ProcessState='*' where batchind={1} and pk={2}", Qname, Id, CmpId);
                    connection.Execute(Cmd, true);
                }
            }
            BindDataGrid();
        }



        public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
        {
            BindDataGrid();
        }
    }
}