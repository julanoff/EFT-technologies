/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Text.RegularExpressions;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
namespace Simulator
{
    /// <summary>
    /// Summary description for Events.
    /// </summary>
    public partial class ChpControl : System.Web.UI.Page
    {

        protected void Page_Load(object sender, System.EventArgs e)
        {
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            if (!Page.IsPostBack && dbname != null)
                BindData();
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion

        private void BindData()
        {
            DBAccess m_Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            m_Connection.Connect(false, dbname);
            string Cmd = "select * from ChipsControl";
            try
            {
                m_Connection.OpenDataReader(Cmd);
                m_Connection.SQLDR.Read();
                DateTime ValDate = m_Connection.SQLDR.GetDateTime(0);
                Calendar1.SelectedDate = ValDate;
                decimal ActFund = m_Connection.SQLDR.GetDecimal(1);
                TextBox1.Text = string.Format("{0:c}", ActFund);
                string Gen_ssn = m_Connection.SQLDR[2].ToString().TrimEnd();
                ListItem li = DropDownList2.Items.FindByValue(Gen_ssn);
                if (li != null)
                    li.Selected = true;
                string New_day = m_Connection.SQLDR[3].ToString().TrimEnd();
                li = DropDownList3.Items.FindByValue(New_day);
                if (li != null)
                    li.Selected = true;
                string Dup_psn = m_Connection.SQLDR[4].ToString().TrimEnd();
                li = DropDownList1.Items.FindByValue(Dup_psn);
                if (li != null)
                    li.Selected = true;
                string Rslv_fnd = m_Connection.SQLDR[5].ToString().TrimEnd();
                li = DropDownList4.Items.FindByValue(Rslv_fnd);
                if (li != null)
                    li.Selected = true;
            }
            catch (Exception er) { throw er; }
            finally
            {
                m_Connection.DisConnect();
            }

        }

        protected void CancelButton_click(object sender, System.EventArgs e)
        {
        }

        protected void Confirm_Click(object sender, System.EventArgs e)
        {
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];

            DateTime sel_date = DateTime.Today;
            decimal Act_fund;
            if (Calendar1.SelectedDate.Year > 2000)
                sel_date = Calendar1.SelectedDate;
            if (TextBox1.Text.StartsWith("$"))
                Act_fund = Convert.ToDecimal(TextBox1.Text.Substring(1)); //get rid of $ in front
            else
                Act_fund = Convert.ToDecimal(TextBox1.Text);

            string Gen_ssn = this.DropDownList2.SelectedValue.ToString();
            string New_day = this.DropDownList3.SelectedValue.ToString();
            string Dup_psn = this.DropDownList1.SelectedValue.ToString();
            string Rslv_fnd = this.DropDownList4.SelectedValue.ToString();
            string Cmd = string.Format("update ChipsControl set ValDate='{0}', Act_fund={1}," +
                "Gen_ssn='{2}', New_day='{3}', Dup_Psn_check='{4}', Rslv_fund_on='{5}'",
                sel_date, Act_fund, Gen_ssn, New_day, Dup_psn, Rslv_fnd);
            DBAccess m_Connection = new DBAccess();
            SimLog.log.write(dbname, "Chips Control update: " + Cmd + "\n");
            m_Connection.Connect(true, dbname);
            m_Connection.Execute(Cmd, true);
            if (New_day == "Y")
            {
                SimLog.log.write(dbname, "Chips new day. Truncate tables.");
                //  New is declared. We need to clean up PSNQueue, ResolverQ, Amount Tables, Set Seq #s to 1.
                Cmd = string.Format("truncate table PSNQueue");
                try
                {
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("truncate table ResolverQ");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("truncate table Ack31Q");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("truncate table PsnQueue");
                    m_Connection.Execute(Cmd, false);
                    // It could happen that these tables have no rows to update or too many. So. delete all and insert 1.
                    Cmd = string.Format("truncate table ChpRlsAmt");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("insert into ChpRlsAmt (rlsamt) values (0)");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("truncate table ChpRcvAmt");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("insert into ChpRcvAmt (rcvamt) values (0)");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("truncate table RsnNumber");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("insert into RsnNumber (rsnndx) values (0)");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("truncate table OsnNumber");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("insert into OsnNumber (osnndx) values (0)");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("truncate table IsnNumber");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("insert into IsnNumber (isnndx) values (0)");
                    m_Connection.Execute(Cmd, false);
                    Cmd = string.Format("update LinkControl Set NextSeqNo=1, OutSeqNo=1, RsnSeqNo=0 where Source='CHP'");
                    m_Connection.Execute(Cmd, true);
                }
                catch (Exception ex)
                {
                    m_Connection.RecordEvent(1, "ChpControl", ex.Message.TrimEnd(), dbname);
                }
                finally
                { }
            }
            m_Connection.DisConnect();
        }

        protected void GenSSN_changed(object sender, System.EventArgs e)
        {
        }

        protected void NewDay_changed(object sender, System.EventArgs e)
        {
            //  Add check for chips links are up. Issue an error and disallow new day
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;

        }

        protected void Funds_changed(object sender, System.EventArgs e)
        {
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;

        }

        protected void Psn_changed(object sender, System.EventArgs e)
        {
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;

        }

        protected void Act_changed(object sender, System.EventArgs e)
        {
            Confirm_button.Enabled = true;
            Confirm_button.Visible = true;
            Cancel_button.Enabled = true;
            Cancel_button.Visible = true;
        }
        protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }
    }
}
