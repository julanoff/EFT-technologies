/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class DateTimeControl : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            _ge_date.SelectedDate = DateTime.Today.AddDays(-1);
            _le_date.SelectedDate = DateTime.Today;
            _ge_hour.Text = "00";
            _ge_minute.Text = "00";
            _ge_second.Text = "00";
            _le_hour.Text = "23";
            _le_minute.Text = "59";
            _le_second.Text = "59";
        }       
        DateTime lessthan = _le_date.SelectedDate;
        DateTime greater = _ge_date.SelectedDate;
    }
}
