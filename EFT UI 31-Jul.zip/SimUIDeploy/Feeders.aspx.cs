/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Obout.Grid;
using Obout.Interface;
/*
 * 03-Feb-07    JR  Implement a 'global edit' for entries in the Feeder table. The first line
 *                  in the table has a linename of 'Default'. If they edit that line, we'll
 *                  take those values and apply it to all the rest of the entries in the
 *                  table. Lets you turn timely delivery on/off for all lines at once.
 * 
 * 15-Feb-16    JR  Order by linename on the select.
 * 
 */
namespace Simulator
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public partial class Feeders : System.Web.UI.Page
	{
		DBAccess m_Connection;	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack) 
			{
				BindDataGrid();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
		}
		#endregion

   
		private void BindDataGrid()
		{

            m_Connection = new DBAccess();
			String dbname=(String)HttpContext.Current.Session["CurrentDB"];
			try
			{
				m_Connection.Connect(false,dbname);

				String Cmd="select LineName, TimelyDelivery, TimeFrom=convert(varchar(20),TimeFrom,24), "+
					" TimeTo= convert(varchar(20),TimeTo,24)"+
					" from FeederControl order by Linename";
				DataSet ds = m_Connection.getDataSet(Cmd);
				DataGrid1.DataSource=ds;
				DataGrid1.DataBind();
			}
            catch (Exception e) { throw e; }
			finally
			{
				m_Connection.DisConnect();
			}

		}

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }


		void DataGrid_Cancel(Object sender, DataGridCommandEventArgs e) 
		{
			// Set the EditItemIndex property to the index of the item clicked
			// in the DataGrid control to enable editing for that item. Be sure
			// to rebind the DateGrid to the data source to refresh the control.
		//	DataGrid1.EditItemIndex =  -1;
			BindDataGrid();
		}

        public void DataGrid_Update(Object sender, GridRecordEventArgs e)
		{
            //int i =1;
			string Cmd;
            string LineName = e.Record["LineName"].ToString().Trim().ToUpper();
            string TimelyDelivery = e.Record["TimelyDelivery"].ToString().Trim().ToUpper();
            string TimeFrom = e.Record["TimeFrom"].ToString().Trim().ToUpper();
            string TimeTo = e.Record["TimeTo"].ToString().Trim().ToUpper();

            // If they edited the 'Default' line, then apply these values to everybody in
            // the table.

            if (LineName.StartsWith("Default"))
            {
                Cmd = string.Format("update FeederControl " +
                " set TimelyDelivery ='{0}', " +
                " TimeFrom='{1:hh mm ss}', TimeTo='{2:hh mm ss}' ",
                TimelyDelivery, TimeFrom, TimeTo);
            }
            else
            {
                Cmd = string.Format("update FeederControl " +
                 " set TimelyDelivery ='{0}', " +
                 " TimeFrom='{1:hh mm ss}', TimeTo='{2}' " +
                 " where LineName = '{3}'",
                 TimelyDelivery, TimeFrom, TimeTo, LineName);
            }

			DBAccess Connection= new DBAccess();
			String Area=(String)HttpContext.Current.Session["CurrentDB"];
			try
			{
				Connection.Connect(true,Area);
				Connection.Execute(Cmd,true);
		//		DataGrid1.EditItemIndex =  -1;
				BindDataGrid();
			}
			catch(Exception) {}
			finally
			{
				Connection.DisConnect();
			}
		}

        protected void MyPageChanged(object source, DataGridPageChangedEventArgs e)
        {
            DataGrid1.CurrentPageIndex = e.NewPageIndex;
            BindDataGrid();
        }
    }
}
