using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for GridSummaryData
/// </summary>
/// 
namespace RGWDataLayer
{

    public class GridSummaryData
    {
        private string _Trn;

        public string Trn
        {
            get { return _Trn; }
            set { _Trn = value; }
        }
        private int _TrnNo;

        public int TrnNo
        {
            get { return _TrnNo; }
            set { _TrnNo = value; }
        }
        private DateTime _TrnTime;

        public DateTime TrnTime
        {
            get { return _TrnTime; }
            set { _TrnTime = value; }
        }
        private string _Currency;

        public string Currency
        {
            get { return _Currency; }
            set { _Currency = value; }
        }
        private Decimal _Amount;

        public Decimal Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }
        private string _Source;

        public string Source
        {
            get { return _Source; }
            set { _Source = value; }
        }
        private string _AdvType;

        public string AdvType
        {
            get { return _AdvType; }
            set { _AdvType = value; }
        }
        private string _MsgType;

        public string MsgType
        {
            get { return _MsgType; }
            set { _MsgType = value; }
        }
        private string _Bank;
        public string Bank
        {
            get { return _Bank; }
            set {_Bank=value;}
        }

        public GridSummaryData() { }
        public GridSummaryData(string trn, int trnno, DateTime trntime, string bank,string currency, Decimal amount, string source, string advtype, string msgtype)
        {
            _Trn = trn;
            _TrnNo = trnno;
            _TrnTime = trntime;
            _Currency = currency;
            _Amount = amount;
            _Source = source;
            _AdvType = advtype;
            _MsgType = msgtype;
            _Bank = bank;
        }
    }

}