/*                                                             
 Copyright (c) 1999 - 2005 by Professional Practice Automated Solutions, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 Professional Practice Automated Solutions and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 Professional Practice Automated Solutions, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of Professional Practice Automated Solutions, Inc.
*/
using System;
using System.IO;
using Simulator.DBLibrary;
using System.Diagnostics;
using System.ComponentModel;
using System.Data;

namespace Simulator
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Processes
	{
		private DBAccess m_readConnection;
		private DBAccess m_readConnection1;
		private DBAccess m_writeConnection;
		private DataSet m_DataSet;
		private DataTable m_DataTable;
		private string m_Area;

		/// <summary>
		/// The program to start the simulator. It reads the config file with all proc and 
		/// args and start them.
		/// </summary>

		public Processes(string Area)
		{
			m_readConnection=new DBAccess();
			m_readConnection1=new DBAccess();
			m_writeConnection=new DBAccess();
			m_Area=Area;
		}


		public DataSet ShowProcesses()
		{
			try
			{
				m_readConnection.Connect(false,m_Area);
				m_readConnection1.Connect(false,m_Area);
				m_DataSet = new DataSet("DataSet");
				m_DataTable = new DataTable("DataTable");
	
				m_DataTable.Columns.Add("Process", typeof(string));
				m_DataTable.Columns.Add("ProcessName", typeof(string));
				m_DataTable.Columns.Add("Arguments", typeof(string));
				m_DataTable.Columns.Add("Pid", typeof(string));
				m_DataTable.Columns.Add("Status", typeof(string));
				m_DataSet.Tables.Add(m_DataTable);

				string Cmd="select ModName, ModArgs, StartUp, ProcName from SimulatorProcesses ";
				if(m_readConnection.OpenDataReader(Cmd))
				{
					while(m_readConnection.SQLDR.Read())
					{	
						string ModName=m_readConnection.SQLDR["ModName"].ToString().TrimEnd();
						string ModArgs=m_readConnection.SQLDR["ModArgs"].ToString().TrimEnd();
						string StartUp=m_readConnection.SQLDR["StartUp"].ToString().TrimEnd();
						string ProcName=m_readConnection.SQLDR["ProcName"].ToString().TrimEnd();
						Cmd=string.Format("select ProcId from ActiveProcesses where ModName='{0}' and ProcArgs='{1}'",ModName,ModArgs);
						if(m_readConnection1.OpenDataReader(Cmd))
						{
							if (m_readConnection1.SQLDR.HasRows)
							{
								while(m_readConnection1.SQLDR.Read())
								{
									int Pid = m_readConnection1.SQLDR.GetInt32(0);
									try
									{
										Process ProcById = Process.GetProcessById(Pid);
										if (ProcById != null && (ProcById.Responding) && (ProcById.ProcessName.IndexOf(ModName)!=-1))
											AddRow(ModName,ProcName,ModArgs,Pid,"Active");
										else
											AddRow(ModName,ProcName,ModArgs,Pid,"InActive");
									}
									catch
									{
										AddRow(ModName,ProcName,ModArgs,Pid,"InActive");
										if(!m_writeConnection.Open)
											m_writeConnection.Connect(true,m_Area);
										Cmd=string.Format("delete from ActiveProcesses where ModName='{0}'",ModName);
										m_writeConnection.Execute(Cmd,true);
									}
								} // end while
							}  
							else   // no corresponding row in 'ActiveProcess' table
								AddRow(ModName,ProcName,ModArgs,0,"InActive");
							m_readConnection1.CloseDataReader();
						}  // end of connection1.opendatareader
					}	 //end of connection.while
				} // end of connection.opendatareader
			}
			catch(Exception) {}
			finally
			{
				m_readConnection.DisConnect();
				m_readConnection1.DisConnect();
				m_writeConnection.DisConnect();
			}
			return m_DataSet;
		}

		private void AddRow(string Process,string ProcessName,string Args,int Pid,string Status)
		{
			DataRow dr;
			dr = m_DataTable.NewRow();
			dr["Process"] = Process;
			dr["ProcessName"] = ProcessName;
			dr["Arguments"]=Args;
			dr["Pid"]=Pid.ToString();
			dr["Status"]=Status;
			m_DataTable.Rows.Add(dr);
		}

		public bool StartAll()
		{
			Process myProcess = new Process();
			string Path="c:/simulator/allbin/";
			string ProcName="StartSimulator";
			myProcess.StartInfo.FileName = String.Format("{0}{1}",Path,ProcName);
			myProcess.StartInfo.Arguments = m_Area.TrimEnd();
			myProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			try 
			{
				myProcess.Start();
			}
			catch
			{
			}		
			return true;
		}

		public bool StopAll()
		{
			string Cmd=string.Format("select ProcId from ActiveProcesses");
			try
			{
				m_readConnection.Connect(false,m_Area);
				if(m_readConnection.OpenDataReader(Cmd))
				{
					while(m_readConnection.SQLDR.Read())
					{
						int Pid=m_readConnection.SQLDR.GetInt32(0);
						StopProcess(Pid);
					}
				}
			}
			catch(Exception)
			{}
			finally
			{
				m_readConnection.DisConnect();
				m_readConnection.CloseDataReader();
			}

			return true;
		}

		public bool StopProcess(int Pid)	
		{
			try
			{
				if(!m_writeConnection.Open)
					m_writeConnection.Connect(true,m_Area);
			
					Process ProcById = Process.GetProcessById(Pid);
					if (ProcById.Responding)
						ProcById.Kill();
			}
			catch
			{
			}
			finally
			{
				string Cmd=string.Format("delete from ActiveProcesses where procid={0}",Pid);
				m_writeConnection.Execute(Cmd,true);
				m_writeConnection.DisConnect();
			}			
			return true;
		}

		public bool StartProcess(string ProcessName)
		{
			string Cmd=string.Format("select ModName, ModPath, ModArgs, MultiAllowed, StartUp from SimulatorProcesses where procname='{0}'",ProcessName);
			m_readConnection.Connect(false,m_Area);
			
			string ModPath=m_readConnection.SQLDR["ModPath"].ToString().TrimEnd();
			Process myProcess = new Process();
			string Path="c:/simulator/allbin/";
			string ProcName="StartSimulator";
			myProcess.StartInfo.FileName = String.Format("{0}{1}",Path,ProcName);
			myProcess.StartInfo.Arguments = m_Area.TrimEnd()+" \""+ProcessName.TrimEnd()+"\"";
//			myProcess.StartInfo.Arguments = m_Area.TrimEnd()+" "+ProcessName.TrimEnd();
			myProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			try 
			{
				myProcess.Start();
			}
			catch
			{
			}		
			return true;
		}
/*
		private void StartProc()
		{
			m_readConnection1.Connect(false,m_Area);
			while(m_readConnection.SQLDR.Read())
			{
				string Name=m_readConnection.SQLDR["ModName"].ToString().TrimEnd();
				string Path=m_readConnection.SQLDR["ModPath"].ToString().TrimEnd();
				string Args=m_readConnection.SQLDR["ModArgs"].ToString().TrimEnd();
				string Multi=m_readConnection.SQLDR["MultiAllowed"].ToString();
				string StartUp=m_readConnection.SQLDR["StartUp"].ToString().TrimEnd();
				if (StartUp=="N")
					continue;
				//Check ActiveProcesses table if the proc exists in this area.
				string Cmd=string.Format("select ModName, ProcArgs from ActiveProcesses where ModName='{0}' and ProcArgs='{1}'",Name,Args);
				if(m_readConnection1.OpenDataReader(Cmd))
				{
					if((m_readConnection1.SQLDR.HasRows)&&(Multi=="N"))
					{
						m_readConnection1.CloseDataReader();
						continue;
					}
				}
				Process myProcess = new Process();
				myProcess.StartInfo.FileName = String.Format("{0}{1}",Path,Name);
				myProcess.StartInfo.Arguments = Args;
				myProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				try 
				{
					myProcess.Start();
				}
				catch
				{
				}
				m_readConnection1.CloseDataReader();
				//					int id = myProcess.Id;
			}
		}*/
	}
}






