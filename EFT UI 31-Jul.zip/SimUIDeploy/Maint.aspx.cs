/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
/*
 *  3-Sep-06    JR  Added a step to dump the current configurations.
 * 28-Oct-06    JR  Added EntrySources to the list of tables to dump.
 *  1-Nov-06    JR  In the dump config routine, put try/catch on most of the
 *                  tables just in case they're not there. (We're moving BofA
 *                  to .Net version 2 and their config is pretty out of date
 *                  now. I'm hoping we can use this function to dump their
 *                  existing config and then load it back in. Stay tuned.
 *  4-Nov-06    JR  Add VideoConfig to the list of tables to dump.
 * 10-Nov-06    JR  Add a function to load the configuration.
 * 19-Nov-06    JR  Dump the master config info when dumping an area.
 * 03-Feb-07    JR  When dumping the config, skip the 'Default' line in FeederControl.
 * 11-Feb-07    JR  Moved the actual code to dump the area configuration into BackEndSubs.
 *                  
 * 
 */

namespace Simulator
{
    /// <summary>
    /// Summary description for Maint.
    /// </summary>
    public partial class Maint : System.Web.UI.Page
    {

        protected void Page_Load(object sender, System.EventArgs e)
        {
            // Put user code to initialize the page here
            if (!Page.IsPostBack)
            {
                LoadCheckList();
            }
            if (!ClientScript.IsClientScriptBlockRegistered("confirm"))
            {
                string jsConfirm = @"<script language='javascript'> " +
                    "function confirm_delete() " +
                    "{ return (confirm('Are you sure you want to perform this function?')); }" +
                    "</script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "confirm", jsConfirm);
            }
        }

        private void LoadCheckList()
        {
            ArrayList values = new ArrayList();
            values.Add("Truncate Swift Receiver Tables");
            values.Add("Truncate all Receiver Tables");
            values.Add("Truncate all Link Tables");
            values.Add("Truncate all Feeder tables");
            values.Add("Purge Zero Entries from Swf Statistics");
            values.Add("Purge EventLog: Leave last 5 days");
            values.Add("Clear all Log files");
            values.Add("Clear all Results files");
            values.Add("Clear Splitter files");
            values.Add("Purge Logs - keep 2 days");
            values.Add("Purge Results files - keep 2 days");
            values.Add("Purge Splitter files - keep 2 days");
            values.Add("Purge Logs - keep 5 days");
            values.Add("Purge Results files - keep 5 days");
            values.Add("Purge Splitter files - keep 5 days");
            values.Add("Dump Current Configuration");
            //CheckBoxList1.Rows = values.Count;
            CheckBoxList1.DataSource = values;
            CheckBoxList1.ClearSelection();
            CheckBoxList1.Visible = true;

            CheckBoxList1.DataBind();
            Label1.Visible = false;
            ExecButton.Attributes.Add("onclick", "return confirm_delete();");
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion
        private void CancelButtonClick(object sender, System.EventArgs e)
        {
            CheckBoxList1.SelectedIndex = -1;
        }

        protected void ExecButtonClick(object sender, System.EventArgs e)
        {
            BackEndSubs util = new BackEndSubs();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            string text = string.Empty;
            int n = 0;
            Label1.Text = "You chose: ";

            for (int i = 0; i < CheckBoxList1.Items.Count; i++)
            {
                if (CheckBoxList1.Items[i].Selected)
                {
                    text = CheckBoxList1.Items[i].Text;

                    n++;
                    if (n == 1)
                        Label1.Text += text;
                    else
                        Label1.Text += ", " + text;

                    Label1.Visible = true;

                    try
                    {
                        if (text.Equals("Purge EventLog: Leave last 5 days"))
                            util.PurgeEventLogTables(Area);

                        if (text.Equals("Truncate Swift Receiver Tables"))
                            util.TruncateSwfRcvTables(Area);

                        if (text.Equals("Truncate all Receiver Tables"))
                            util.TruncateRcvTables(Area);

                        if (text.Equals("Truncate all Link Tables"))
                            util.TruncateLinkTables(Area);

                        if (text.Equals("Truncate all Feeder tables"))
                            util.TruncateFeederTables(Area);

                        if (text.Equals("Clear all Log files"))
                            util.PurgeLogs(Area, 0);

                        if (text.Equals("Clear all Results files"))
                            util.PurgeResultsFiles(Area, 0);

                        if (text.Equals("Clear Splitter files"))
                            util.PurgeSplitFiles(Area, 0);

                        if (text.Equals("Purge Logs - keep 2 days"))
                            util.PurgeLogs(Area, 2);

                        if (text.Equals("Purge Results files - keep 2 days"))
                            util.PurgeResultsFiles(Area, 2);

                        if (text.Equals("Purge Splitter files - keep 2 days"))
                            util.PurgeSplitFiles(Area, 2);

                        if (text.Equals("Purge Logs - keep 5 days"))
                            util.PurgeLogs(Area, 5);

                        if (text.Equals("Purge Results files - keep 5 days"))
                            util.PurgeResultsFiles(Area, 5);

                        if (text.Equals("Purge Splitter files - keep 5 days"))
                            util.PurgeSplitFiles(Area, 5);

                        if (text.Equals("Purge Zero Entries from Swf Statistics"))
                            util.PurgeSwfStats(Area);

                        if (text.Equals("Dump Current Configuration"))
                        {
                            BaselineConfig basecfg = new BaselineConfig();
                            basecfg.dumpConfiguration(Area);
                            /*
                               dumpMaster(Area);
                            */
                           
                        }

                        if (text.Equals("Create/Edit New Config XML file"))
                        {
                            Response.Write("<script>window.open(\"CfgMaint.aspx\")</script>");
                        }
                    }

                    catch (Exception) { util.logError(Area, "UI", " exception on command: " + text); }
                    finally
                    {

                        //dbWriter.DisConnect();
                    }
                }
            }
            CheckBoxList1.ClearSelection();
        }
    }
}
