/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
/*
 * 03-Feb-07    JR  Filter out the 'Default' line names wherever they appear. They're just
 *                  dummies to let the humans make global edits to tables. Zb, to let you
 *                  pick the timely delivery value for all the feeders at once instead of
 *                  having to do them individually.
 * 07-May-07    JN  Show number of actual real messages on Link queues. It could be different from real count of records 
 *                  in the tables because for certain interfaces we pack more than 1 item per transmission.
 *                  
 * 12-Feb-16    JR  order by linename.
 * 
 */
namespace Simulator
{
    /// <summary>
    /// Summary description for Systotals.
    /// </summary>
    public partial class Systotals : System.Web.UI.Page
    {
        DataTable m_DataTable;
        static protected string m_Rname;


        private void Page_Load(object sender, System.EventArgs e)
        {
            if (!Page.IsPostBack)
                BindData();
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion
        public DataTable Fill_grid1()
        {
            m_DataTable = new DataTable("DataTable");
            m_DataTable.Columns.Add("Name", typeof(string));
            m_DataTable.Columns.Add("Cnt", typeof(string));
            m_DataTable.Columns.Add("RName", typeof(string));

            DBAccess Connection = new DBAccess();
            DBAccess Connection1 = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                Connection1.Connect(false, dbname);


                string Cmd = string.Format("select LineName, Description, SndRcv, NextSeqNo from LinkControl order by linename");
                Connection.OpenDataReader(Cmd);
                while (Connection.SQLDR.Read())
                {
                    DataRow dr;
                    dr = m_DataTable.NewRow();
                    string Lname = Connection.SQLDR["LineName"].ToString().TrimEnd();
                    string Dname = Connection.SQLDR["Description"].ToString().TrimEnd();
                    string SR = Connection.SQLDR["SndRcv"].ToString().TrimEnd();
                    SR = SR.ToUpper();
                    string Seq = Connection.SQLDR["NextSeqNo"].ToString().TrimEnd();
                    string Tname;
                    //
                    // Only sending lines have LNK* tables where the traffic queues.
                    // For receive lines, let's show them the inbound sequence number.
                    //
                    if ((SR == "S") || (SR == "B"))
                    {
                        Tname = string.Format("LNK_{0}", Lname);
                        try
                        {
                            Cmd = string.Format("select SUM(MsgCount) from {0}", Tname);
                            Connection1.OpenDataReader(Cmd);
                            Connection1.SQLDR.Read();
                            int cnt = 0;
                            try
                            {
                                cnt = Connection1.SQLDR.GetInt32(0);
                            }
                            catch { };
                            dr["Cnt"] = cnt;
                            dr["RName"] = Tname;
                            dr["Name"] = Dname;
                        }
                        catch
                        { }
                        finally
                        {
                            Connection1.CloseDataReader();
                        }
                        m_DataTable.Rows.Add(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex; 
            }
            finally
            {
                Connection.DisConnect();
                Connection1.DisConnect();
            }
            return m_DataTable;
        }

        public DataTable Fill_grid2()
        {
            m_DataTable = new DataTable("DataTable");
            m_DataTable.Columns.Add("Name", typeof(string));
            m_DataTable.Columns.Add("Cnt", typeof(string));
            m_DataTable.Columns.Add("RName", typeof(string));

            DBAccess Connection = new DBAccess();
            DBAccess Connection1 = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                Connection1.Connect(false, dbname);
                string Cmd = string.Format("select LineName from FeederControl where LineName != 'Default' order by linename ");
                Connection.OpenDataReader(Cmd);
                while (Connection.SQLDR.Read())
                {
                    DataRow dr;
                    dr = m_DataTable.NewRow();
                    string Lname = Connection.SQLDR["LineName"].ToString().TrimEnd();
                    string Dname = Lname;
                    string Tname = string.Format("FDR_{0}", Lname);
                    try
                    {
                        Cmd = string.Format("select COUNT(*) from {0}", Tname);
                        Connection1.OpenDataReader(Cmd);
                        Connection1.SQLDR.Read();
                        int cnt = Connection1.SQLDR.GetInt32(0);

                        dr["Name"] = Dname;
                        dr["Cnt"] = cnt;
                        dr["RName"] = Tname;
                    }
                    catch
                    {
                    }
                    finally
                    {
                        Connection1.CloseDataReader();
                    }
                    m_DataTable.Rows.Add(dr);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Connection.DisConnect();
                Connection1.DisConnect();
            }
            return m_DataTable;
        }

        public DataTable Fill_grid3()
        {
            m_DataTable = new DataTable("DataTable");
            m_DataTable.Columns.Add("Name", typeof(string));
            m_DataTable.Columns.Add("Cnt", typeof(string));
            m_DataTable.Columns.Add("RName", typeof(string));

            DBAccess Connection = new DBAccess();
            DBAccess Connection1 = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                Connection1.Connect(false, dbname);
                string Cmd = string.Format("select LineName from ReceiveControl order by linename");
                Connection.OpenDataReader(Cmd);
                while (Connection.SQLDR.Read())
                {
                    DataRow dr;
                    dr = m_DataTable.NewRow();
                    string Lname = Connection.SQLDR["LineName"].ToString().TrimEnd();
                    string Dname = Lname;
                    string Tname = string.Format("RCV_{0}", Lname);
                    try
                    {
                        Cmd = string.Format("select COUNT(*) from {0}", Tname);
                        Connection1.OpenDataReader(Cmd);
                        Connection1.SQLDR.Read();
                        int cnt = Connection1.SQLDR.GetInt32(0);
                        Connection1.CloseDataReader();
                        dr["Name"] = Dname;
                        dr["Cnt"] = cnt;
                        dr["RName"] = Tname;
                    }
                    catch
                    {
                    }
                    finally
                    {
                        Connection1.CloseDataReader();
                    }
                    m_DataTable.Rows.Add(dr);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Connection.DisConnect();
                Connection1.DisConnect();
            }
            return m_DataTable;
        }

        public DataTable Fill_grid4(string Table)
        {
            // This is the list of trn's associated with a particular
            // feeder queue.
            m_DataTable = new DataTable("DataTable");
            m_DataTable.Columns.Add("TrnNumber", typeof(string));
            m_DataTable.Columns.Add("RcvTime", typeof(string));
            m_DataTable.Columns.Add("Timely", typeof(string));
            m_DataTable.Columns.Add("FName", typeof(string));
            m_DataTable.Columns.Add("QblText", typeof(string));

            DBAccess Connection = new DBAccess();
            DBAccess Connection1 = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                Connection1.Connect(false, dbname);
                string Cmd = string.Format("select TrnNumber,RcvTime,Timely,QblText from {0} ", Table);
                Connection.OpenDataReader(Cmd);
                while (Connection.SQLDR.Read())
                {
                    DataRow dr;
                    dr = m_DataTable.NewRow();
                    string TrnNumber = Connection.SQLDR["TrnNumber"].ToString().TrimEnd();
                    DateTime RcvTime = Convert.ToDateTime(Connection.SQLDR["RcvTime"].ToString().TrimEnd());
                    string Timely = Connection.SQLDR["Timely"].ToString().TrimEnd();
                    string Txt = Connection.SQLDR["QblText"].ToString().TrimEnd();
                    try
                    {
                        Cmd = string.Format("select FileName, FilePath from QblidTable where OrigTrn='{0}'", TrnNumber);
                        Connection1.OpenDataReader(Cmd);
                        string FName = "";
                        if (Connection1.SQLDR.HasRows)
                        {
                            Connection1.SQLDR.Read();
                            string FileName = Connection1.SQLDR["FileName"].ToString().TrimEnd();
                            string FilePath = Connection1.SQLDR["FilePath"].ToString().TrimEnd();
                            FName = string.Format("{0}{1}", FilePath, FileName);
                        }
                        dr["TrnNumber"] = TrnNumber;
                        dr["RcvTime"] = RcvTime;
                        dr["Timely"] = Timely;
                        dr["FName"] = FName;
                        dr["QblText"] = Txt;
                    }
                    catch
                    { }
                    finally
                    {
                        Connection1.CloseDataReader();
                    }
                    m_DataTable.Rows.Add(dr);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Connection.DisConnect();
                Connection1.DisConnect();
            }
            return m_DataTable;
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindData();
        }
        private void BindData()
        {
            DataGrid4.Visible=false;
            DataGrid1.DataSource = Fill_grid1();
            DataGrid1.DataBind();
            DataGrid2.DataSource = Fill_grid2();
            DataGrid2.DataBind();
            DataGrid3.DataSource = Fill_grid3();
            DataGrid3.DataBind();
        }

         public void DataGrid2_Selected(object sender, System.EventArgs e)
        {
            // Somebody clicked on one of the Feeder queue entries.
            DataGrid1.Visible = false;
            DataGrid2.Visible = false;
            DataGrid3.Visible = false;
            DataGrid4.CurrentPageIndex = 0;
            DataGrid4.Visible = true;
            m_Rname="";
            if (DataGrid2.SelectedRecords != null)  //when user has choosen a record.
            {
                foreach (Hashtable oRecord in DataGrid2.SelectedRecords)
                {
                    m_Rname = oRecord["Rname"].ToString().TrimEnd();
                }
            }
            DataGrid4.Visible = true;
            DataGrid4.DataSource = Fill_grid4(m_Rname);
            DataGrid4.DataBind();
        }

        public void Refresh_click(object sender, System.EventArgs e)
        {
            BindData();
        }
    }
}
