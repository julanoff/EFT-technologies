/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
namespace Simulator
{
	/// <summary>
	/// Summary description for Queues.
	/// </summary>
	public partial class Queues : System.Web.UI.Page
	{
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
				BindDataGrid();
			if(!ClientScript.IsClientScriptBlockRegistered("confirm"))
			{
				string jsConfirm = @"<script language='javascript'> "+
					"function confirm_delete() "+
					"{ return (confirm('Are you sure you want to delete this item?')); }"+
					"</script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "confirm", jsConfirm);
            }

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DataGrid1.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Cancel);
			this.DataGrid1.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Edit);
			this.DataGrid1.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Update);
			this.DataGrid1.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DateGrid_Delete);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.OnItemDataBound);

		}
		#endregion

		void DataGrid_Edit(Object sender, DataGridCommandEventArgs e) 
		{
			// Set the EditItemIndex property to the index of the item clicked
			// in the DataGrid control to enable editing for that item. Be sure
			// to rebind the DateGrid to the data source to refresh the control.
			this.ReleaseButton.Visible=false;
			DataGrid1.EditItemIndex =  e.Item.ItemIndex;
			BindDataGrid();
		}

		void DataGrid_Cancel(Object sender, DataGridCommandEventArgs e) 
		{
			// Set the EditItemIndex property to the index of the item clicked
			// in the DataGrid control to enable editing for that item. Be sure
			// to rebind the DateGrid to the data source to refresh the control.
			DataGrid1.EditItemIndex =  -1;
			this.ReleaseButton.Visible=true;
			BindDataGrid();
		}


		void DataGrid_Update(Object sender, DataGridCommandEventArgs e) 
		{
			string Qbl= e.Item.Cells[5].Text.Trim();
			string Nak= (string)((DropDownList)(e.Item.FindControl("NakList"))).SelectedItem.Text.Trim();
			string ErrorCode=(string)((DropDownList)(e.Item.FindControl("ErrorCodeList"))).SelectedItem.Text.Trim();
			string LineNumber=((TextBox) e.Item.Cells[4].Controls[0]).Text.Trim();
			string Cmd=string.Format("update SwfReceiveAckQue set Nak='{0}',ErrorCode='{1}',LineNumber='{2}' where Qbl={3} ",Nak,ErrorCode,LineNumber,Qbl);
			DBAccess Connection= new DBAccess();
			String Area=(String)HttpContext.Current.Session["CurrentDB"];
			try
			{
				Connection.Connect(true,Area);
				Connection.Execute(Cmd,true);
				DataGrid1.EditItemIndex =  -1;
				this.ReleaseButton.Visible=true;
				BindDataGrid();
			}
			catch(Exception )
			{}
			finally
			{
				Connection.DisConnect();
			}
		}


		private void BindDataGrid()
		{
			DBAccess Connection= new DBAccess();
			String dbname=(String)HttpContext.Current.Session["CurrentDB"];
			String LineName=(String)HttpContext.Current.Session["CurrentQueue"];
			try
			{
				Connection.Connect(false,dbname);
				String Cmd=string.Format("select RefNum_Str,Nak,ErrorCode,LineNumber,Qbl from swfreceiveackque where linename = '{0}'",LineName.Trim());
				DataSet ds = Connection.getDataSet(Cmd);
				DataGrid1.DataSource=ds;
				DataGrid1.DataBind();
				Connection.DisConnect();
			}
			catch(Exception ex)
            { throw ex; }
			finally
			{
				Connection.DisConnect();
			}

		}

		protected void ReleaseButton_Click(object sender, System.EventArgs e)
		{
			DBAccess Connection= new DBAccess();
			String dbname=(String)HttpContext.Current.Session["CurrentDB"];
			String LineName=(String)HttpContext.Current.Session["CurrentQueue"];
			try
			{
				Connection.Connect(false,dbname);
				String Cmd=string.Format("update receivecontrol set ReleaseAckQue='Y' where linename = '{0}'",LineName.Trim());
				Connection.Execute(Cmd,true);
				Response.Write("<script>window.close()</script>");			
			}
			catch(Exception )
			{}
			finally
			{
				Connection.DisConnect();
			}

		}

		private void OnItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.EditItem)
			{
				DropDownList NakList=(DropDownList)e.Item.FindControl("NakList");
				DropDownList errorCodeList=(DropDownList)e.Item.FindControl("ErrorCodeList");
				PopulateErrorCodeList(errorCodeList);

				string ErrorCode=((DataRowView)e.Item.DataItem).Row.ItemArray[2].ToString();
				string Nak=((DataRowView)e.Item.DataItem).Row.ItemArray[1].ToString();
				if(errorCodeList.Items.FindByValue(ErrorCode) != null)
					errorCodeList.Items.FindByValue(ErrorCode).Selected=true;
				if(NakList.Items.FindByValue(Nak) != null)
					NakList.Items.FindByValue(Nak).Selected=true;
			}

			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.EditItem)
			{
				Button cancelButton = (Button)e.Item.FindControl("DelButtonId");
				if(cancelButton != null)
					cancelButton.Attributes.Add("onclick", "return confirm_delete();");
			}		

		}

		private void DateGrid_Delete(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			string Qbl= e.Item.Cells[5].Text.Trim();
			String Cmd=string.Format("delete from SwfReceiveAckQue  where Qbl={0}",Qbl);	
			DBAccess Connection= new DBAccess();
			String Area=(String)HttpContext.Current.Session["CurrentDB"];
			try
			{
				Connection.Connect(true,Area);
				Connection.Execute(Cmd,true);
				DataGrid1.EditItemIndex =  -1;
				this.ReleaseButton.Visible=true;
				BindDataGrid();		
			}
			catch(Exception )
			{}
			finally
			{
				Connection.DisConnect();
			}

		}

		private void PopulateErrorCodeList(DropDownList errorCodList)
		{
			string Cmd=string.Format("select ErrorCode from errorcodes where Source = 'SWF'");
			DBAccess Connection= new DBAccess();
			String Area=(String)HttpContext.Current.Session["CurrentDB"];
			try
			{
				Connection.Connect(false,Area);
				DataSet ds =Connection.getDataSet(Cmd);
				//					errorCodList.DataSource=ds;
				//					errorCodList.DataBind();
				foreach ( DataTable dt in ds.Tables )
				{
					foreach ( DataRow row in dt.Rows )
						errorCodList.Items.Add(row["ErrorCode"].ToString());				
				}
			}
			catch(Exception)
			{
				errorCodList.Items.Add("Error");				
			}
			finally
			{
				Connection.DisConnect();
			}
		}


        protected void MyPageChanged(object source, DataGridPageChangedEventArgs e)
        {
            DataGrid1.CurrentPageIndex = e.NewPageIndex;
            BindDataGrid();

        }
}
}
