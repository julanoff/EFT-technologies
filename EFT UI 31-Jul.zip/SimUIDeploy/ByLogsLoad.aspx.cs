/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
using OboutInc.Calendar2;
/* 
 * 08-Oct-06    JR  Plagarized from the loader screen to handle updates to the RgwMessageLoaderControl table.
 * 24-Feg-07	JR  Get the Repository area out of the control file(s) now.
 */
namespace Simulator
{
    /// <summary>
    /// Summary description for WebForm1.
    /// </summary>

    //public partial class WebForm1 : System.Web.UI.Page
    public partial class ByLogsLoaderForm : System.Web.UI.Page
    {
        const int zzz = 13;

        protected System.Web.UI.HtmlControls.HtmlInputHidden Hidden1;


        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindDataGrid();
            }
            if (!ClientScript.IsClientScriptBlockRegistered("confirm"))
            {
                string jsConfirm = @"<script language='javascript'> " +
                    "function confirm_delete() " +
                    "{ return (confirm('Are you sure you want to delete this item?')); }" +
                    "</script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "confirm", jsConfirm);
            }
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ByLogsLoaderGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.ItemCommands);
            this.ByLogsLoaderGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Cancel);
            this.ByLogsLoaderGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Edit);
            this.ByLogsLoaderGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Update);
            this.ByLogsLoaderGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Delete);
            this.ByLogsLoaderGrid.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.ItemBound);

        }
        #endregion


        void DataGrid_Edit(Object sender, DataGridCommandEventArgs e)
        {
            ByLogsLoaderGrid.EditItemIndex = e.Item.ItemIndex;
            BindDataGrid();
        }

        void DataGrid_Cancel(Object sender, DataGridCommandEventArgs e)
        {
            // Set the EditItemIndex property to the index of the item clicked
            // in the DataGrid control to enable editing for that item. Be sure
            // to rebind the DateGrid to the data source to refresh the control.
            ByLogsLoaderGrid.EditItemIndex = -1;
            BindDataGrid();
        }

        protected void CleanupClick(object sender, System.EventArgs e)
        {
            string Cmd = string.Format("delete from RgwMessageLoaderControl where ProcessState = 'P'");
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception) { }
            finally
            {
                Connection.DisConnect();
            }
        }

        protected void ReleaseAllClick(object sender, System.EventArgs e)
        {
            string Cmd = string.Format("update RgwMessageLoaderControl set ProcessState = '*' where ProcessState = 'W'");
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception) { }
            finally
            {
                Connection.DisConnect();
            }
        }

        protected void RefreshClick(object sender, System.EventArgs e)
        {
            BindDataGrid();
        }

       

        void DataGrid_Update(Object sender, DataGridCommandEventArgs e)
        {
            // Called in edit mode to update the row.
            string UniqueKey = (string)((TextBox)(e.Item.FindControl("UniqueKeyBox"))).Text.Trim();
            string fullFileName = (string)((DropDownList)(e.Item.FindControl("FilePathEdit"))).SelectedItem.Value.Trim();
            int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
            if (LastDelimeter == 0)
                LastDelimeter = fullFileName.LastIndexOf(@"/") + 1;

            String FileName = fullFileName.Substring(LastDelimeter);
            String FilePath = fullFileName.Substring(0, LastDelimeter);

            string localRgw = ((DropDownList)e.Item.FindControl("localRGWEdit")).Text.Trim();

            string ProcessState = (string)((DropDownList)(e.Item.FindControl("ProcessStateList"))).SelectedItem.Text.Trim();

            string Cmd = string.Format("update RgwMessageLoaderControl set ProcessState='{0}', localRGWarea='{1}', " +
                        "FileName='{2}', FilePath='{3}' where UniqueKey={4}",
                        ProcessState, localRgw, FileName, FilePath, UniqueKey);

            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                ByLogsLoaderGrid.EditItemIndex = -1;
                BindDataGrid();
            }
            catch (Exception) { }
            finally
            {
                Connection.DisConnect();
            }
        }

        private void DataGrid_Delete(object source, DataGridCommandEventArgs e)
        {
            string UniqueKey;
            try
            {
                UniqueKey = (string)((Label)(e.Item.FindControl("UniqueKey"))).Text.Trim();
            }
            catch
            {
                UniqueKey = (string)((TextBox)(e.Item.FindControl("UniqueKeyBox"))).Text.Trim();
            }
            String Cmd = "delete from RgwMessageLoaderControl where uniquekey=" + UniqueKey;
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                ByLogsLoaderGrid.EditItemIndex = -1;
                BindDataGrid();
            }
            catch (Exception) { }
            finally
            {
                Connection.DisConnect();
            }
        }

 

        private void ItemBound(object sender, DataGridItemEventArgs e)
        {
            // Called when the row goes into edit mode.  Populates the editable rows.
            if (e.Item.ItemType == ListItemType.EditItem)
            {
                string localRGW = ((DataRowView)e.Item.DataItem).Row.ItemArray[0].ToString().Trim();
                string thisFilePath = ((DataRowView)e.Item.DataItem).Row.ItemArray[1].ToString();
                string thisFileName = ((DataRowView)e.Item.DataItem).Row.ItemArray[2].ToString();
                string ProcessState = ((DataRowView)e.Item.DataItem).Row.ItemArray[5].ToString();

                DropDownList dl = ((DropDownList)(e.Item.FindControl("FilePathEdit")));

                /*
                 * What a pain in the ass ... our localRGW variable is going to be trimmed. It's where
                 * the rgw database for this area lives. The mechanism that Dave uses to populate the
                 * area list when you first come into the app is nice and I tried to use that originally.
                 * The problem is that that mechanism ends up populating the dropdown list with the area
                 * names replete with trailing spaces. Not so bad until you do a findcontrol-findbyvalue
                 * call to try to select our localRGW value. It traps because it can't find it - our value
                 * has been trimmed but the one in the list hasn't. Geez. I couldn't figure out how to
                 * get the original databind methodology to trim the variables, so we have this. 
                 */
                DropDownList areaList = ((DropDownList)(e.Item.FindControl("localRGWEdit")));
                areaList.Items.Add(localRGW);

                BackEndSubs util = new BackEndSubs();
                ArrayList areas = util.getAreaList();
                for (int i = 0; i < areas.Count; i++)
                {
                    if (!areas[i].Equals(localRGW))
                    {
                        areaList.Items.Add(areas[i].ToString().Trim());
                    }
                }
                ((DropDownList)e.Item.FindControl("LocalRGWEdit")).Items.FindByValue(localRGW).Selected = true;

                string fullPathName = ((DataRowView)e.Item.DataItem).Row.ItemArray[1].ToString().Trim() +
                    ((DataRowView)e.Item.DataItem).Row.ItemArray[2].ToString().Trim();

                //PopulatePathControl(dl, thisFileName);
                PopulatePathControl(dl, fullPathName);
                ListItem li = dl.Items.FindByValue(fullPathName);
                if (li != null)
                    li.Selected = true;

                ((DropDownList)e.Item.FindControl("ProcessStateList")).Items.FindByValue(ProcessState).Selected = true;

                ((Label)e.Item.FindControl("Label2")).Text = "";
            }
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.EditItem)
            {
                Button cancelButton = (Button)e.Item.FindControl("DelButtonId");
                if (cancelButton != null)
                    cancelButton.Attributes.Add("onclick", "return confirm_delete();");
            }
        }


        public void ItemCommands(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
        {
            if (e.CommandName == "AddNewRow")
                Add_on(e);
            else
                if (e.CommandName == "CancelAddRow")
                    Add_off(e);
                else
                {
                    string FileName;
                    if (e.CommandName == "ConfirmAddRow")
                    {
                        string ProcessState = (string)((DropDownList)(e.Item.FindControl("ProcessStateListFt"))).SelectedItem.Text.Trim();
                        string localRgw = ((DropDownList)e.Item.FindControl("localRGW")).SelectedItem.Text.Trim();
                        FileName = (string)((DropDownList)(e.Item.FindControl("FilePath"))).SelectedItem.Value.Trim();

                        int LastDelimeter = FileName.LastIndexOf(@"\") + 1;
                        if (LastDelimeter == 0)
                            LastDelimeter = FileName.LastIndexOf(@"/") + 1;

                        String File = FileName.Substring(LastDelimeter);
                        String Path = FileName.Substring(0, LastDelimeter);
                        if (FileName != null && FileName.Length > 0)
                        {
                            DateTime dtCurrTime = DateTime.Now;

                            string Cmd = string.Format("insert into RgwMessageLoaderControl (ProcessState,localRGWarea,FileName,FilePath," +
                                "TimeStarted, " +
                                "TimeEnded, Comment)" +
                                "values ('{0}','{1}','{2}','{3}','{4:dd MMM yyyy}','{4:dd MMM yyyy}', '')",
                                ProcessState, localRgw, File, Path, DateTime.Now);
                            DBAccess Connection = new DBAccess();
                            String Area = (String)HttpContext.Current.Session["CurrentDB"];
                            try
                            {
                                Connection.Connect(true, Area);
                                Connection.Execute(Cmd, true);
                                ByLogsLoaderGrid.EditItemIndex = -1;
                                BindDataGrid();
                                Add_off(e);
                            }
                            catch (Exception) { }
                            finally
                            {
                                Connection.DisConnect();
                            }
                        }
                        else
                            ((Label)(e.Item.FindControl("FileNameLabel"))).Visible = true;
                    }
                }
        }

    
        private void Add_on(DataGridCommandEventArgs e)
        {
            // Function called to make the footer controls visible.

            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ProcessStateListFt"))).Enabled = true;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ProcessStateListFt"))).Visible = true;

            ((System.Web.UI.WebControls.WebControl)e.Item.FindControl("FilePath")).Enabled = true;
            ((System.Web.UI.WebControls.WebControl)e.Item.FindControl("FilePath")).Visible = true;

            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnAddRow"))).Enabled = false;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnAddRow"))).Visible = false;

            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnCancel"))).Enabled = true;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnCancel"))).Visible = true;

            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnConfirm"))).Enabled = true;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnConfirm"))).Visible = true;

            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("FileNameLabel"))).Visible = false;

            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("localRGW"))).Enabled = true;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("localRGW"))).Visible = true;

            string localRGW = string.Empty;
            string area = (string)HttpContext.Current.Session["CurrentDB"];
            BackEndSubs util = new BackEndSubs();
            localRGW = util.GetRgwRepository(area, true);
            
            DropDownList areaList = ((DropDownList)(e.Item.FindControl("localRGW")));

            areaList.Items.Add(localRGW);

            ArrayList areas = util.getAreaList();
            for (int i = 0; i < areas.Count; i++)
            {
                if (!areas[i].Equals(localRGW))
                {
                    areaList.Items.Add(areas[i].ToString().Trim());
                }
            }
            ((DropDownList)e.Item.FindControl("LocalRGW")).Items.FindByValue(localRGW).Selected = true;


            PopulatePathControl(((DropDownList)(e.Item.FindControl("FilePath"))));
        }
      


        private void PopulatePathControl(DropDownList dList, string fullFileName)
        {
            // Function called to populate the path control, 
            // either in the footer or in the datagrid for in-situ edits.

            DBAccess Connection = new DBAccess();
            try
            {
                Connection.Connect(false, (String)HttpContext.Current.Session["CurrentDB"]);
                BackEndSubs util = new BackEndSubs();
                IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), 
                    "tcp://localhost:21005/ProcMgr");

                if (procMgr != null)
                {
                    String targetDir = util.GetRgwLoadFilesDir(Connection);

                    int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
                    if (LastDelimeter == 0)
                        LastDelimeter = fullFileName.LastIndexOf(@"/") + 1;

                    string FileName = fullFileName.Substring(LastDelimeter);
                    ListItem item = new ListItem(FileName, fullFileName);
                    dList.Items.Add(item);
                }
            }
            finally
            {
                Connection.DisConnect();
            }
        }


        private void PopulatePathControl(DropDownList dList)
        {
            DBAccess Connection = new DBAccess();
            try
            {
                Connection.Connect(false, (String)HttpContext.Current.Session["CurrentDB"]);
                BackEndSubs util = new BackEndSubs();
                IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
                if (procMgr != null)
                {
                    String targetDir = util.GetRgwLoadFilesDir(Connection);
                    DataSet ds = (DataSet)procMgr.getDirectoryList(targetDir);		// change this to appropriate directory
                    foreach (DataTable dt in ds.Tables)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            string fullFileName = row["FileName"].ToString();
                            int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
                            if (LastDelimeter == 0)
                                LastDelimeter = fullFileName.LastIndexOf(@"/") + 1;

                            string FileName = fullFileName.Substring(LastDelimeter);
                            ListItem item = new ListItem(FileName, fullFileName);
                            dList.Items.Add(item);
                        }
                    }
                }
            }
            finally
            {
                Connection.DisConnect();
            }
        }


        public void MyPageChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
        {
            ByLogsLoaderGrid.CurrentPageIndex = e.NewPageIndex;
            BindDataGrid();
        }


        private void Add_off(DataGridCommandEventArgs e)
        {
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ProcessStateListFt"))).Enabled = false;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("ProcessStateListFt"))).Visible = false;
     
            ((System.Web.UI.WebControls.WebControl)e.Item.FindControl("FilePath")).Enabled = false;
            ((System.Web.UI.WebControls.WebControl)e.Item.FindControl("FilePath")).Visible = false;

            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnAddRow"))).Enabled = true;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnAddRow"))).Visible = true;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnCancel"))).Enabled = false;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnCancel"))).Visible = false;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnConfirm"))).Enabled = false;
            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("btnConfirm"))).Visible = false;

            ((System.Web.UI.WebControls.WebControl)(e.Item.FindControl("FileNameLabel"))).Visible = false;
        }


        private void BindDataGrid()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                String Cmd = "select localRGWarea,FilePath,FileName," +
                    "TimeStarted, TimeEnded, ProcessState,UniqueKey, replace(FilePath,' ','')+replace(FileName,' ','') as FullPath from RgwMessageLoaderControl";
                DataSet ds = Connection.getDataSet(Cmd);
                ByLogsLoaderGrid.DataSource = ds;
                ByLogsLoaderGrid.DataBind();
                Connection.DisConnect();
            }
            catch (Exception e) { throw e; }
            finally
            {
                Connection.DisConnect();
            }
        }


        private static string getAppSetting(string key)
        {
            string tmp = System.Configuration.ConfigurationManager.AppSettings[key];
            if (tmp != null)
                return tmp;
            return "";
        }
    }
}
