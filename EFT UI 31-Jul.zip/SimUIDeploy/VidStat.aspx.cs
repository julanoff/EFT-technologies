/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using OboutInc.Calendar2;

namespace Simulator
{
    /// <summary>
    /// Summary description for Video Statistics.
    /// </summary>
    public partial class VidStat : System.Web.UI.Page
    {
        DateTime from_time, to_time;
        int RprSum = 0;
        int EntSum = 0;
        int VfySum = 0;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            DBAccess m_Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];


            OboutInc.Calendar2.Calendar from = (OboutInc.Calendar2.Calendar)DateTimeControl1.Controls[8];
            OboutInc.Calendar2.Calendar to = (OboutInc.Calendar2.Calendar)DateTimeControl1.Controls[18];
            from_time = from.SelectedDate;
            to_time = to.SelectedDate;

            if (!Page.IsPostBack && dbname != null)
                BindData();
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion
        protected void Refresh_Click(object sender, System.EventArgs e)
        {
            BindData();
        }

        public void ComputeSum(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                e.Item.Cells[0].Text = "Total: ";
                e.Item.Cells[1].Text = String.Format("Repaired: {0:#,###}", RprSum);
                e.Item.Cells[2].Text = String.Format("Entered: {0:#,###}", EntSum);
                e.Item.Cells[3].Text = String.Format("Verified: {0:#,###}", VfySum);
            }
        }

        private void BindData()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                string Cmd;
                Cmd = string.Format("select Mode, OrigTrn, NewTrn, TrnTime from " +
                    "VideoStats where TrnTime !< '{0}' and TrnTime !> '{1}' and Mode LIKE '{2}%' " +
                    "order by TrnTime desc", from_time, to_time, TextBox1.Text);
                DataSet ds = Connection.getDataSet(Cmd);
                DataGrid1.DataSource = ds;

                if ((TextBox1.Text == "RPR") || (TextBox1.Text == ""))
                {
                    Cmd = string.Format("select COUNT(Mode) from " +
                    "VideoStats where TrnTime !< '{0}' and TrnTime !> '{1}' and Mode = 'RPR'", from_time, to_time);
                    if (Connection.OpenDataReader(Cmd))
                    {
                        try
                        {
                            Connection.SQLDR.Read();
                            RprSum = Connection.SQLDR.GetInt32(0);
                        }
                        catch
                        {
                            RprSum = 0;
                        }
                        finally
                        {
                            Connection.CloseDataReader();
                        }
                    }
                }

                if ((TextBox1.Text == "VFY") || (TextBox1.Text == ""))
                {
                    Cmd = string.Format("select COUNT(Mode) from " +
                        "VideoStats where TrnTime !< '{0}' and TrnTime !> '{1}' and Mode = 'VFY'", from_time, to_time);
                    if (Connection.OpenDataReader(Cmd))
                    {
                        try
                        {
                            Connection.SQLDR.Read();
                            VfySum = Connection.SQLDR.GetInt32(0);
                        }
                        catch
                        {
                            VfySum = 0;
                        }
                        finally
                        {
                            Connection.CloseDataReader();
                        }
                    }
                }

                if ((TextBox1.Text == "ENT") || (TextBox1.Text == ""))
                {
                    Cmd = string.Format("select COUNT(Mode) from " +
                        "VideoStats where TrnTime !< '{0}' and TrnTime !> '{1}' and Mode = 'ENT'", from_time, to_time);
                    if (Connection.OpenDataReader(Cmd))
                    {
                        try
                        {
                            Connection.SQLDR.Read();
                            EntSum = Connection.SQLDR.GetInt32(0);
                        }
                        catch
                        {
                            EntSum = 0;
                        }
                        finally
                        {
                            Connection.CloseDataReader();
                        }
                    }
                }
                DataGrid1.DataBind();
            }
            catch (Exception)
            { }
            finally
            {
                Connection.DisConnect();
            }
            VfySum = 0;
            RprSum = 0;
            EntSum = 0;
        }
        protected void MyPageChanged(object source, DataGridPageChangedEventArgs e)
        {
            DataGrid1.CurrentPageIndex = e.NewPageIndex;
            BindData();
        }
    }
}
