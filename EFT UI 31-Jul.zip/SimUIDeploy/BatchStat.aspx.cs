/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.IO;
using System.Text;
using System.Data;
using System.Xml;
using System.Linq;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using Obout.Grid;
using Obout.Interface;
using Simulator.BackEndSubLib;
using Simulator.EventLogger;
using Simulator.SimLog;

namespace Simulator
{


/*
 * 
 * Project update page.
 * 
 * 09-Jul-12        Orig.
 * 
 */
    public partial class BatchStat : OboutInc.oboutAJAXPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            OboutDropDownList EdtTmplConndb1 = DataGrid1.Templates[0].Container.FindControl("EdtTmplConndb") as OboutDropDownList;

            ListItem item1 = new ListItem("ORA", "ORA");
            EdtTmplConndb1.Items.Add(item1);
            item1 = new ListItem("SQL", "SQL");
            EdtTmplConndb1.Items.Add(item1);

            OboutDropDownList EdtTmplFiletype1 = DataGrid1.Templates[0].Container.FindControl("EdtTmplFiletype") as OboutDropDownList;

            ListItem item2 = new ListItem("PDF", "PDF");
            EdtTmplFiletype1.Items.Add(item2);
            item2 = new ListItem("CSV", "CSV");
            EdtTmplFiletype1.Items.Add(item2);

            connection.Connect(false, "Master");
            string Cmd = "select AreaName from Areas";
            if (connection.OpenDataReader(Cmd))
            {
                try
                {
                    OboutDropDownList EdtTmplArea1 = DataGrid1.Templates[0].Container.FindControl("EdtTmplArea") as OboutDropDownList;
                    EdtTmplArea1.DataSource = connection.SQLDR;
                    EdtTmplArea1.DataTextField = "AreaName";
                    EdtTmplArea1.DataValueField = "AreaName";
                    EdtTmplArea1.DataBind();
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    connection.CloseDataReader();
                    connection.DisConnect();
                }

                if (!Page.IsPostBack)
                {
                    BindDataGrid();
                    HttpContext.Current.Session["EditsAllowed"] = "Y";
                    DataGrid1.Visible = true;
                }

            }
        }

        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = DataGrid1.Templates[templateIndex].Container.FindControl(controlId);

            //     return ctrl.ClientID;
            return "";
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }

        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {
            //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
        }

        protected void BindDataGrid()
        {
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            string fileName = "c:\\Simulator\\" + dbname.TrimEnd() + "\\feed\\feedstat.xml";
            DataSet ds = new DataSet();
            ds.ReadXml(fileName);
            if (ds.HasErrors)
            {
                SimulatorLog _simLog = new SimulatorLog("FTFeeder");
                _simLog.WriteEntry("Errors in feedstat.xml. Check the file", EventLogEntryType.Error);
                Simulator.SimLog.log.write(dbname, "Errors in feedstat.xml. Check the file", true);
            }

            DataGrid1.DataSource = ds;

            DataGrid1.DataBind();
            string vendor = HttpContext.Current.Session["Vendor"].ToString();


            DataGrid1.Visible = true;
        }

        public void DataGrid_Edit(Object sender, GridRecordEventArgs e)
        {
            string Connstr, TrgConnstr, Description, Cmptable, Conndb, Area, Filetype, Keys, Prefix,
            Show, Fromdatabase, Todatabase, Outfile;
            

            Show = e.Record["show"].ToString().Trim().ToUpper();
            Fromdatabase = e.Record["fromdatabase"].ToString().Trim().ToUpper();
            Todatabase = e.Record["todatabase"].ToString().Trim().ToUpper();
            Connstr = e.Record["src_connection_string"].ToString().Trim().ToUpper();
            TrgConnstr = e.Record["trg_connection_string"].ToString().Trim().ToUpper();
            Description = e.Record["description"].ToString().Trim().Replace("'", "''");
            Cmptable = e.Record["cmptable"].ToString().Trim();
            Conndb = e.Record["conndb"].ToString().Trim();
            Area = e.Record["area"].ToString().Trim();
            Prefix = e.Record["prefix"].ToString().Trim();
            Outfile = e.Record["outfile"].ToString().Trim().ToUpper();
            Keys = e.Record["keys"].ToString().Trim().ToUpper().Replace("\r\n", " ");
            Filetype = e.Record["filetype"].ToString().Trim().ToUpper().Replace("\r\n", " ");

            String area = (String)HttpContext.Current.Session["CurrentDB"];
            StringBuilder thisXml = new StringBuilder();
            thisXml.Length = 0;
            thisXml.Append("<?xml version=\"1.0\" standalone=\"yes\"?>");
            thisXml.Append("\r\n");
            thisXml.Append("<ourxml>");
            thisXml.Append("\r\n");
            thisXml.Append("<src_connection_string>");
            thisXml.Append(Connstr);
            thisXml.Append("</src_connection_string>");
            thisXml.Append("<trg_connection_string>");
            thisXml.Append(TrgConnstr);
            thisXml.Append("</trg_connection_string>");
            thisXml.Append("\r\n");
            thisXml.Append("<description>");
            thisXml.Append(Description);
            thisXml.Append("</description>");
            thisXml.Append("\r\n");
            thisXml.Append("<conndb>");
            thisXml.Append(Conndb);
            thisXml.Append("</conndb>");
            thisXml.Append("\r\n");
            thisXml.Append("<cmptable>");
            thisXml.Append(Cmptable);
            thisXml.Append("</cmptable>");
            thisXml.Append("\r\n");
            thisXml.Append("<area>");
            thisXml.Append(Area);
            thisXml.Append("</area>");
            thisXml.Append("\r\n");
            thisXml.Append("<outfile>");
            thisXml.Append(Outfile);
            thisXml.Append("</outfile>");
            thisXml.Append("\r\n");
            thisXml.Append("<show>");
            thisXml.Append(Show);
            thisXml.Append("</show>");
            thisXml.Append("\r\n");
            thisXml.Append("<fromdatabase>");
            thisXml.Append(Fromdatabase);
            thisXml.Append("</fromdatabase>");
            thisXml.Append("\r\n");
            thisXml.Append("<todatabase>");
            thisXml.Append(Todatabase);
            thisXml.Append("</todatabase>");
            thisXml.Append("\r\n");
            thisXml.Append("<prefix>");
            thisXml.Append(Prefix);
            thisXml.Append("</prefix>");
            thisXml.Append("\r\n");
            thisXml.Append("<keys>");
            thisXml.Append(Keys);
            thisXml.Append("</keys>");
            thisXml.Append("\r\n");
            thisXml.Append("<filetype>");
            thisXml.Append(Filetype);
            thisXml.Append("</filetype>");
            thisXml.Append("\r\n");
            thisXml.Append("</ourxml>");

            DBAccess db = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            db.Connect(true, dbname);
            DateTime dt = DateTime.Now;
            string Cmd = string.Format("insert into BatchQ values " +
                "('{0}','{1}','{2}','S','{3}')",
                "*",
                dt,
                null,
                thisXml.ToString().Replace("'", "''"));
            db.Execute(Cmd, true);
            // Get batch Id from BatchQ PK (identity filed)
            Cmd = string.Format("select Pk from Batchq where AssignTime = '{0}'", dt);
            db.OpenDataReader(Cmd);
            db.SQLDR.Read();
            int Pk = db.SQLDR.GetInt32(0);
            db.CloseDataReader();
            Cmd = string.Format("insert into BatchDescr values " +
                "('{0}',0, '{1}','{2}','{3}','{4}','{5}','',0,0,0)",
                Pk,
                Description,
                "Batch Submitted",
                Fromdatabase,
                Todatabase,
                dt );
            db.Execute(Cmd, true);
        }

        public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
        {
            //        DataGrid1.EditItemIndex = -1;
            BindDataGrid();
        }
        private string testInt(string num)
        {
            try
            {
                int tst = int.Parse(num);
                return num;
            }
            catch
            {
                return "1";
            }
        }

        public void DataGrid_Insert(object source, GridRecordEventArgs e)
        {
        }
    }
}
