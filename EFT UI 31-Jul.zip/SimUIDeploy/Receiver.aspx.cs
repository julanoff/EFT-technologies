/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Linq;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Obout.Grid;
using Obout.Interface;
using Obout.ComboBox;
using Simulator.DBLibrary;
using Simulator.EventLogger;
using Simulator.SimLog;

//new grid CHP: nak, tag, err code, Line #
//new grid FED: nak, tag, err code
//new grid SWF: nak, err code, Line #

namespace Simulator
{
    /// <summary>
    /// Summary description for Receiver.
    /// </summary>
    public partial class Receiver : OboutInc.oboutAJAXPage
    {
        private static string m_Source;
        private static string m_rule;
        private static string m_Line;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            string dbname = (String)HttpContext.Current.Session["CurrentDB"];
            if (!Page.IsPostBack)
                BindData();
            if (DataGrid1.SelectedRecords != null)  //when user has choosen a record.
            {
                foreach (Hashtable oRecord in DataGrid1.SelectedRecords)
                {
                    m_Line = oRecord["LineName"].ToString().TrimEnd();
                    m_Source = oRecord["Source"].ToString().TrimEnd();
                }
                DataGrid1.Visible = false;
                DataGrid2.Visible = true;
                Release.Visible = true;
                // DataGrid1.AllowFiltering = true;
                BindDataGrid2();
            }

        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        }
        #endregion

        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = DataGrid1.Templates[templateIndex].Container.FindControl(controlId);

            return ctrl.ClientID;
        }
        protected string GetControlClientIdFromTemplate2(string controlId, int templateIndex)
        {
            Control ctrl = DataGrid2.Templates[templateIndex].Container.FindControl(controlId);

            return ctrl.ClientID;
        }

        protected string GetControlClientIdFromTemplateX(string controlId, int templateIndex)
        {

            return "yo";
        }




        protected void ComboBoxRule_LoadingItems(object sender, EventArgs e)
        {
            //int zzz = 666;
            FillRules(sender, e);
        }
        // this is an async AJAX call. The names of args must be = to the names in JS in .aspx        
        public List<string> unique(string elementID, string table)
        {
            List<string> rules = new List<string>();

            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            string Cmd = string.Format("select '     ' as RuleName from NakRulesTables union select replace(RuleName, ' ','')  from NakRulesTables where Source='{0}'", elementID);

            try
            {
                Connection.OpenDataReader(Cmd);
                while (Connection.SQLDR.Read())
                {
                    rules.Add(Connection.SQLDR[0].ToString().Trim());

                    //    RuleList.DataSource = Connection.SQLDR;
                    ///   RuleList.DataTextField = "RuleName";
                    //    RuleList.DataValueField = "RuleName";
                    //    RuleList.DataBind();
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }

            //                ComboBox RuleList = DataGrid1.Templates[0].Container.FindControl("EdtTmplTable1") as ComboBox;
            //                RuleList.Items.Clear();
            //                RuleList.DataSource = null;
            //       RuleList.DataBind();

            m_Source = elementID;
            m_rule = table;
            return (rules);
        }

        protected void RlsQueue(object sender, EventArgs e)
        {
            DBAccess Connection = new DBAccess();
            string dbname = (String)HttpContext.Current.Session["CurrentDB"];
            string LineName = (String)HttpContext.Current.Session["CurrentQueue"];
            try
            {
                Connection.Connect(false, dbname);
                String Cmd = string.Format("update receivecontrol set ReleaseAckQue='Y' where linename = '{0}'", m_Line.Trim());
                Connection.Execute(Cmd, true);
            }
            catch (Exception)
            { }
            finally
            {
                Connection.DisConnect();
            }
            DataGrid1.Visible = true;
            DataGrid2.Visible = false;
            Release.Visible = false;
            BindData();
        }


        protected void RowBound(object sender, GridRowEventArgs e)
        {
            if (e.Row.RowType == GridRowType.DataRow)
            {
                //                GridDataControlFieldCell cell = e.Row.Cells[7] as GridDataControlFieldCell;
                //                ComboBox RuleList = cell.FindControl("EdtTmplTable1") as ComboBox;
                //                string Cmd = string.Format("select '     ' as RuleName, '0' as Pk from NakRulesTables union select replace(RuleName, ' ',''), Pk from NakRulesTables where Source='{0}'", m_Source);



                string LineName = e.Row.Cells[1].Text.TrimEnd();
                int i = LineName.IndexOf("&");
                if (i != -1)
                    LineName = LineName.Remove(i);
                String Area = (String)HttpContext.Current.Session["CurrentDB"];
                DBAccess Connection = new DBAccess();
                Connection.Connect(false, Area);

                string cmd = "";

                switch (e.Row.Cells[2].Text.Trim())
                {
                    case "SWF":
                        cmd = string.Format("select COUNT(*) from swfreceiveackque where linename = '{0}'", LineName);
                        break;

                    case "CHP":
                        cmd = string.Format("select COUNT(*) from chpreceiveackque where linename = '{0}'", LineName);
                        break;

                    case "FED":
                        cmd = string.Format("select COUNT(*) from fedreceiveackque where linename = '{0}'", LineName);
                        break;
                    default:
                        break;
                }
                if (cmd.Length > 0)
                {
                    try
                    {
                        Connection.Connect(false, Area);
                        Connection.OpenDataReader(cmd);
                        Connection.SQLDR.Read();
                        e.Row.Cells[8].Text = Convert.ToString(Connection.SQLDR.GetInt32(0));
                    }
                    catch (Exception)
                    { }
                    finally
                    {
                        Connection.CloseDataReader();
                        Connection.DisConnect();
                    }
                }
                else
                {
                    e.Row.Cells[8].Text = " ";
                }
            }
        }

        public void DataGrid_Cancel(Object sender, DataGridCommandEventArgs e)
        {
            BindData();
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindData();
        }

        protected void RebindGrid2(object sender, EventArgs e)
        {
            BindDataGrid2();
        }

        protected void DataGrid2_Update(Object sender, GridRecordEventArgs e)
        {
            string Qbl = e.Record["Qbl"].ToString();
            string Tag = e.Record["Tag"].ToString().Trim();
            string ErrCode = e.Record["ErrorCode"].ToString().Trim();
            string LineNo = e.Record["ErrorLen"].ToString().Trim();
            string Nak = e.Record["Nak"].ToString().Trim();
            string Cmd = "";
            switch (m_Source)
            {
                case "SWF":
                    Cmd = string.Format("update SwfReceiveAckQue set Nak='{0}',ErrorCode='{1}',LineNumber='{2}' where Qbl={3} ", Nak, ErrCode, LineNo, Qbl);
                    break;
                case "FED":
                    Cmd = string.Format("update FedReceiveAckQue set Nak='{0}',ErrCode='{1}',Tag='{2}' where Qblid={3} ", Nak, ErrCode, Tag, Qbl);
                    break;
                case "CHP":
                    Cmd = string.Format("update ChpReceiveAckQue set Nak='{0}',ErrorCode='{1}',Tag='{2}',ErrorLen='{3}' where Qbl={4} ", Nak, ErrCode, Tag, LineNo, Qbl);
                    break;
            }
            DBAccess Connection = new DBAccess();
            string Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                Release.Visible = true;
                BindDataGrid2();
            }
            catch (Exception)
            { }
            finally
            {
                Connection.DisConnect();
            }
        }

        protected void DataGrid_Update(Object sender, GridRecordEventArgs e)
        {
            string UniqueKey = e.Record["Pk"].ToString();
            string LineName = e.Record["LineName"].ToString().Trim();
            string Source = e.Record["Source"].ToString().Trim();
            string StopAckQue = e.Record["StopAckQue"].ToString().Trim();
            string WritetoFile = e.Record["WriteToFile"].ToString().Trim();
            string FileName = e.Record["FileName"].ToString().Trim();
            string AckRuleTableName = e.Record["AckRuleTableName"].ToString().Trim();
            /*
                        if(FileName.Trim().Length ==0 && WritetoFile.Equals("Y"))
                            e.Item.FindControl("FileNameRequired").Visible=true;
                        else
                        {
                            string AckRuleTableName=(string)((DropDownList)(e.Item.FindControl("AckRuleTableNameList"))).SelectedItem.Text.Trim();
            //if StopACkQUE=Y AckRuleTable must be empty
                            if (AckRuleTableName.Length > 0 && StopAckQue.Equals("Y"))
                            {
                                lblWarning.Visible=true;	
                                lblWarning.Text="Must be 'N' if AckRuleTable present";
                            }
                            else
                            {
             */
            string Cmd = string.Format("update receivecontrol set stopackque='{0}',WritetoFile='{1}',FileName='{2}',AckRuleTableName='{3}' where linename='{4}'",
                StopAckQue, WritetoFile, FileName, AckRuleTableName, LineName);
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, Area);
                Connection.Execute(Cmd, true);
                BindData();
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                Connection.DisConnect();
            }
        }

        private void BindData()
        {
            DBAccess m_Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];

            try
            {
                m_Connection.Connect(false, dbname);
                String Cmd = "select LineName,Source,StopAckQue,WritetoFile,AckRuleTableName,FileName,ReleaseAckQue from receivecontrol where exists (select naksources.source from naksources where  naksources.Source=receivecontrol.source);";
                DataSet ds = m_Connection.getDataSet(Cmd);
                DataGrid1.DataSource = ds;
                DataGrid1.DataBind();
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                m_Connection.DisConnect();
            }
            DataGrid2.Visible = false;
            Release.Visible = false;
        }

        protected void BindDataGrid2()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            Connection.Connect(false, dbname);

            OboutDropDownList ctrl = (OboutDropDownList)DataGrid2.Templates[0].Container.FindControl("EdtTmplTag");
            switch (m_Source)
            {
                case "SWF":
                    ctrl.Items.Clear();
                    break;
                case "FED":
                    PopulateFedTags(ctrl);
                    break;
                case "CHP":
                    PopulateChpTags(ctrl);
                    break;
            }

            OboutDropDownList ctrl1 = (OboutDropDownList)DataGrid2.Templates[0].Container.FindControl("EdtTmplCode");
            PopulateErrorCodeList(ctrl1);

            string Cmd = "";
            switch (m_Source)
            {
                case "CHP":
                    Cmd = string.Format("select Nak,Tag,ErrorCode,ErrorLen,Qbl,Msg_Header, '{1}' as Src from chpreceiveackque where linename = '{0}'", m_Line.Trim(), m_Source);
                    break;
                case "SWF":
                    Cmd = string.Format("select Nak,' ' as Tag,ErrorCode,LineNumber as ErrorLen,Qbl, Msg_Body as Msg_Header, '{1}' as Src from swfreceiveackque where linename = '{0}'", m_Line.Trim(), m_Source);
                    break;
                case "FED":
                    Cmd = string.Format("select Nak, Tag,ErrCode as ErrorCode, ' '  as ErrorLen, QblId as Qbl, MsgText as Msg_Header, '{1}' as Src from fedreceiveackque where linename = '{0}'", m_Line.Trim(), m_Source);
                    break;
            }

            /*	    switch(m_Source)       
                        {
                        case "SWF":   
                            DataGrid2.hideColumn("Tag");
                        break;
                        case "FED":   
                            DataGrid2.hideColumn("LineN");
                        break;
                        case "CHP":   
                        break;
                        }
                        DataGrid1.showColumn("Tag");
            */

            try
            {
                DataSet ds = Connection.getDataSet(Cmd);
                DataGrid2.DataSource = ds;
                DataGrid2.DataBind();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                Connection.DisConnect();
            }
        }

        private void PopulateFedTags(OboutDropDownList tagTxt)
        {
            tagTxt.Items.Clear();
            ListItem item1 = new ListItem("Data Error", "E");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("Insuficient Balance", "F");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("Duplicate IMAD-=TAG", "X");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("IMAD-TAG Error", "H");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("Cut off Hour Timing Error", "W");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("Intercepted", "I");
            tagTxt.Items.Add(item1);
        }

        private void PopulateChpTags(OboutDropDownList tagTxt)
        {
            tagTxt.Items.Clear();
            string Cmd = string.Format("select Tag from ChpTags");
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, Area);
                DataSet ds = Connection.getDataSet(Cmd);
                foreach (DataTable dt in ds.Tables)
                {
                    foreach (DataRow row in dt.Rows)
                        tagTxt.Items.Add(row["Tag"].ToString());
                }
            }
            catch (Exception)
            {
                tagTxt.Items.Add("Error");
            }
            finally
            {
                Connection.DisConnect();
            }
        }

        private void PopulateErrorCodeList(OboutDropDownList errorCodList)
        {
            errorCodList.Items.Clear();
            string Cmd = string.Format("select ErrorCode from errorcodes where Source = '{0}'", m_Source);
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, Area);
                DataSet ds = Connection.getDataSet(Cmd);
                foreach (DataTable dt in ds.Tables)
                {
                    foreach (DataRow row in dt.Rows)
                        errorCodList.Items.Add(row["ErrorCode"].ToString());
                }
            }
            catch (Exception)
            {
                errorCodList.Items.Add("Error");
            }
            finally
            {
                Connection.DisConnect();
            }
        }


        public void FakeEvent(object sender, EventArgs e)
        {
            //int zzz = 666;
        }

        // NOT USED keep for Example
        public void FillRules(object sender, EventArgs e)
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            //string Cmd = string.Format("select '     ' as RuleName, '0' as Pk from NakRulesTables union select replace(RuleName, ' ',''), Pk from NakRulesTables where Source='{0}'", m_Source);
            string Cmd = string.Format("select '     ' as RuleName, '0' as Pk from NakRulesTables union select replace(RuleName, ' ',''), Pk from NakRulesTables");
            ComboBox RuleList = sender as ComboBox; // DataGrid1.Templates[0].Container.FindControl("EdtTmplTable1") as ComboBox;
            try
            {
                if (Connection.OpenDataReader(Cmd))
                {
                    RuleList.DataSource = Connection.SQLDR;
                    RuleList.DataTextField = "RuleName";
                    RuleList.DataValueField = "RuleName";
                    RuleList.DataBind();
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
            //int i = 0;
            //for (i = 0; i < RuleList.Items.Count; i++)
            //{
            //    if (RuleList.Items[i].Text == m_rule.TrimEnd())
            //        RuleList.SelectedIndex = i;
            //}
        }
    }
}