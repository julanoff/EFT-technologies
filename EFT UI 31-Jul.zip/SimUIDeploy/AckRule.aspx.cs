/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using Obout.Grid;
using Obout.Interface;
using Simulator.DBLibrary;
using Simulator.EventLogger;
using Simulator.SimLog;


namespace Simulator
{
    public partial class AckRule : System.Web.UI.Page
    {
        private static string m_Ind;
        private static string m_Src;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                FillBatch();
                HttpContext.Current.Session["EditsAllowed"] = "Y";
                DataGrid1.Visible = false;
                DelTable.Visible = false;
                RuleDropdown.Visible = false;
                ErrorBtn.Visible = false;
            }

            SrcDropdown.Visible = true;
            Box1.Visible = false;
            ConfButton.Visible = false;
            AddTable.Visible = false;
        }

        protected void FillBatch()
        {
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            try
            {
                string Cmd = "select '      ' as Source from NakSources union select  replace(Source, ' ','') from NakSources";

                if (Connection.OpenDataReader(Cmd))
                {
                    SrcDropdown.DataSource = Connection.SQLDR;
                    SrcDropdown.DataTextField = "Source";
                    SrcDropdown.DataValueField = "Source";
                    SrcDropdown.DataBind();
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
        }

        protected void DelTableEvent(object sender, EventArgs e)
        {

            String Cmd = "delete from AckNakRules where TabInd=" + m_Ind;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, dbname);
                Connection.Execute(Cmd, true);
                Cmd = "delete from NakRulesTables where Pk=" + m_Ind;
                Connection.Execute(Cmd, true);
                FillBatch();
                FillRules();
                DataGrid1.Visible = false;
                ErrorBtn.Visible = false;
                Box1.Text = "";
            }
            catch (Exception ex)
            { throw ex; }
        }


// When user wants to add new rules. Add button click. Enable Box1 (to enter name) and Confirm button.
        protected void AddTableEvent(object sender, EventArgs e)  
        {
            SrcDropdown.Visible = true;
            RuleDropdown.Visible = true;
            Box1.Visible = true;
            Box1.Focus();
            ConfButton.Visible = true;
            ErrorBtn.Visible = false;
            DataGrid1.Visible = false;
        }

//When user confirms new rules addition.
        protected void AddNameEvent(object sender, EventArgs e) 
        {
            string name = Box1.Text.TrimEnd();
            if (RuleDropdown.Items.FindByText(name) != null)
            {
                ErrorBtn.Text = "Duplicate Rule";
                ErrorBtn.Visible = true;
                Box1.Visible = true;
                Box1.Focus();
                ConfButton.Visible = true;
                return;
            }
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);
            string src = SrcDropdown.SelectedItem.Text;
            string Cmd = string.Format("insert into NakRulesTables (Source, RuleName) values ('{0}', '{1}')", src, name);
            try
            {
                connection.Execute(Cmd, true);
            }
            catch (Exception ex) { throw ex; }
            ErrorBtn.Visible = false;
            FillRules();
        }

        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = DataGrid1.Templates[templateIndex].Container.FindControl(controlId);

            return ctrl.ClientID;
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }

        protected void OnSelectedRuleIndexChanged(object sender, EventArgs e)
        {
            m_Ind = RuleDropdown.SelectedValue.TrimEnd();

 /*
	    switch(m_Src)       
            {
		    case "SWF":   
		        DataGrid1.hideColumn("Tab");
			break;
		    case "FED":   
		        DataGrid1.hideColumn("LineN");
			break;
		    case "CHP":   
			break;
            }

            DataGrid1.showColumn("Tag");
*/
            DataGrid1.Visible = true;
            DelTable.Visible = true;
            BindDataGrid();
        }
        
        protected void OnSelectedSrcIndexChanged(object sender, EventArgs e)
        {
            FillRules();
            RuleDropdown.Visible = true;
            DataGrid1.Visible = false;
            DelTable.Visible = false;
            ErrorBtn.Visible = false;
        }

        protected void FillRules()
        {
            m_Src = SrcDropdown.SelectedValue.TrimEnd();

            string Cmd = string.Format("select '     ' as RuleName, '0' as Pk from NakRulesTables union select replace(RuleName, ' ',''), Pk from NakRulesTables where Source='{0}'", m_Src);
            String Area = (String)HttpContext.Current.Session["CurrentDB"];

            DBAccess Connection = new DBAccess();
            Connection.Connect(false, Area);
            try
            {
                if (Connection.OpenDataReader(Cmd))
                {
                    RuleDropdown.DataSource = Connection.SQLDR;
                    RuleDropdown.DataTextField = "RuleName";
                    RuleDropdown.DataValueField = "Pk";
                    RuleDropdown.DataBind();
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                Connection.CloseDataReader();
                Connection.DisConnect();
            }
            AddTable.Visible = true;
        }

        protected void BindDataGrid()
        {
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            Connection.Connect(false, dbname);

	        OboutDropDownList ctrl = (OboutDropDownList)DataGrid1.Templates[0].Container.FindControl("EdtTmplTag");
            switch (m_Src)
            {
                case "SWF":
                    ctrl.Items.Clear();
                    break;
                case "FED":
                    PopulateFedTags(ctrl);
                    break;
                case "CHP":
                    PopulateChpTags(ctrl);
                    break;
            } 

	        OboutDropDownList ctrl1 = (OboutDropDownList)DataGrid1.Templates[0].Container.FindControl("EdtTmplCode");
	        PopulateErrorCodeList(ctrl1);

            string Cmd = string.Format("select '{0}' as Src, Pk, Tag, BicOrString,BicString,Tag,ErrorCode,LineN from AckNakRules where TabInd={1}", m_Src, m_Ind);
            try
            {
                DataSet ds = Connection.getDataSet(Cmd);
                DataGrid1.DataSource = ds;
                DataGrid1.DataBind();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                Connection.DisConnect();
            }
        }


        public void DataGrid_Edit(Object sender, GridRecordEventArgs e)
        {
            string UniqueKey = e.Record["Pk"].ToString();
            string BicOrString = e.Record["BicOrString"].ToString().Trim();
            string BicString = e.Record["BicString"].ToString().Trim();
            string Tag = e.Record["Tag"].ToString().Trim();
            string ErrorCode = e.Record["ErrorCode"].ToString().Trim();
            string LineN = e.Record["LineN"].ToString().Trim();

            if (BicString.Length > 40)
            {
                BicString = BicString.Substring(0, 40);
            }

            string Cmd = string.Format("update AckNakRules set Tag='{0}', BicOrString='{1}',BicString='{2}',ErrorCode='{3}'," +
                "LineN='{4}' where Pk={5}",
                Tag, BicOrString, BicString, ErrorCode, LineN, UniqueKey);

            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);
            connection.Execute(Cmd, true);

            BindDataGrid();
        }

        public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
        {
            BindDataGrid();
        }

        public void DataGrid_Insert(object source, GridRecordEventArgs e)
        {

            string BicOrString = e.Record["BicOrString"].ToString();
            string BicString = e.Record["BicString"].ToString().Trim();
            string Tag = e.Record["Tag"].ToString();
            string ErrorCode = e.Record["ErrorCode"].ToString().Trim();
            string LineN = e.Record["LineN"].ToString();

            string Cmd = string.Format("insert into AckNakRules (TabInd,Tag,BicorString,BicString,ErrorCode,LineN)" +
                    " values ({0},'{1}','{2}','{3}','{4}','{5}')",
                    m_Ind, Tag, BicOrString, BicString, ErrorCode, LineN);
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                Connection.DisConnect();
                Connection.Dispose();
            }
        }

        public void DataGrid_Delete(object source, GridRecordEventArgs e)
        {
            string UniqueKey = "";
            try
            {
                UniqueKey = (e.Record["Pk"].ToString());
            }
            catch
            {
            }
            String Cmd = "delete from AckNakRules where Pk=" + UniqueKey;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(true, dbname);
                Connection.Execute(Cmd, true);
                BindDataGrid();
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                Connection.DisConnect();
                Connection.Dispose();
            }
        }

        private void PopulateFedTags(OboutDropDownList tagTxt)
        {
            tagTxt.Items.Clear();
            ListItem item1 = new ListItem("Data Error","E");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("Insuficient Balance","F");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("Duplicate IMAD-=TAG","X");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("IMAD-TAG Error","H");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("Cut off Hour Timing Error","W");
            tagTxt.Items.Add(item1);
            item1 = new ListItem("Intercepted","I");
            tagTxt.Items.Add(item1);
        }
        
        private void PopulateChpTags(OboutDropDownList tagTxt)
        {
            tagTxt.Items.Clear();
            string Cmd = string.Format("select Tag from ChpTags");
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, Area);
                DataSet ds = Connection.getDataSet(Cmd);
                foreach (DataTable dt in ds.Tables)
                {
                    foreach (DataRow row in dt.Rows)
                        tagTxt.Items.Add(row["Tag"].ToString());
                }
            }
            catch (Exception)
            {
                tagTxt.Items.Add("Error");
            }
            finally
            {
                Connection.DisConnect();
            }
        }

        private void PopulateErrorCodeList(OboutDropDownList errorCodList)
        {
            errorCodList.Items.Clear();
            string Cmd = string.Format("select ErrorCode from errorcodes where Source = '{0}'", m_Src);
            DBAccess Connection = new DBAccess();
            String Area = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, Area);
                DataSet ds = Connection.getDataSet(Cmd);
                foreach (DataTable dt in ds.Tables)
                {
                    foreach (DataRow row in dt.Rows)
                        errorCodList.Items.Add(row["ErrorCode"].ToString());
                }
            }
            catch (Exception)
            {
                errorCodList.Items.Add("Error");
            }
            finally
            {
                Connection.DisConnect();
            }
        }
    }
}