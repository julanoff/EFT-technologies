/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;
using Obout.Grid;
using Obout.Interface;

namespace Simulator
{
	/// <summary>
	/// Summary description for Events.
	/// </summary>
    public partial class Events : System.Web.UI.Page
	{
		string sel_time;
		string sel_event;
		DateTime sel_date;
		bool a_date; 
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			String dbname=(String)HttpContext.Current.Session["CurrentDB"];
			if(!Page.IsPostBack && dbname != null)
				BindData();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Refresh_Click(object sender, System.EventArgs e)
		{
			BindData();
		}

		public void RebindGrid(object sender, System.EventArgs e)
		{
			BindData();
		}

		private void BindData()
		{
			DBAccess m_Connection= new DBAccess();
			String dbname=(String)HttpContext.Current.Session["CurrentDB"];
			try
			{
				m_Connection.Connect(false,dbname);
				DateTime til = DateTime.Now.Subtract(System.TimeSpan.FromMinutes(Convert.ToInt32(sel_time)));
/*
				string Cmd="select Event,who,severity,EventTime from SimulatorEvents  where(";
				if (a_date)
					Cmd=Cmd+string.Format(" DATEPART(dy,EventTime)={0}",sel_date.DayOfYear);
				else
					Cmd=Cmd+string.Format(" EventTime > '{0}'",til);
				if (sel_event != "5")
					Cmd=Cmd+string.Format(" and severity='{0}'",sel_event);
				Cmd = Cmd + ") order by EventTime desc";
*/
				string Cmd="select Event,who,severity,EventTime from SimulatorEvents order by eventtime desc";
				DataSet ds = m_Connection.getDataSet(Cmd);
				DataGrid1.DataSource=ds;
				DataGrid1.DataBind();
			}
		        catch (Exception e) { throw e; }
			finally
			{
				m_Connection.DisConnect();
			}

		}
	}
}
