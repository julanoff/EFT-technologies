/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using Obout.Grid;
using OboutInc.Calendar2;
using Obout.Interface;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;

namespace Simulator
{
    public partial class IdiCompPrep : OboutInc.oboutAJAXPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindDataGridFirstTime();
                HttpContext.Current.Session["EditsAllowed"] = "Y";
            }
            PrepGrid.Visible = true;
        }


        protected string GetControlClientIdFromTemplate(string controlId, int templateIndex)
        {
            Control ctrl = PrepGrid.Templates[templateIndex].Container.FindControl(controlId);

            return ctrl.ClientID;
        }


        protected void OnGridRowCreated(object sender, GridRowEventArgs args)
        {
            //int z = 666;
            //PrepGrid.Columns[1].ReadOnly = false;
            // gets called before a row created. It stop each time the row is populated from DB not used
        }

        protected void RebindGrid(object sender, EventArgs e)
        {
            BindDataGrid();
        }

        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {
            //  int zzz = 666;
            //  label1.Text = "A new country was selected: " + EdtTmplProjAct.SelectedValue;
        }

        protected void BindDataGridFirstTime()
        {
            DataSet ds = new DataSet();
            PrepGrid.DataSource = ds;
            PrepGrid.ClearPreviousDataSource();
            string skin = PrepGrid.SkinID;
            BindDataGrid();
        }
        protected void BindDataGrid()
        {

            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            Connection.Connect(false, dbname);
            try
            {
                PrepGrid.Dispose();
                /*
                 * We can't compress the spaces out of the file name or the path
                 * now that TestAWire is putting stuff into this table.
                 */
                Connection.Connect(false, dbname);

                String Cmd = "select UniqueKey,ProcessState,InputFileName,PathtoInputFile,TimeStarted,TimeEnded,OutputTableName," +
                    "UsedForAutoRepair,NumberLoaded,NumberRead,WriteFile,replace(PathtoInputFile,' ','')+replace(InputFileName,' ','') as filename from FileCompControl";

                DataSet ds = Connection.getDataSet(Cmd);
                PrepGrid.DataSource = ds;

                OboutDropDownList ctrl = (OboutDropDownList)PrepGrid.Templates[0].Container.FindControl("EdtTmplPath");
                PopulatePathControl(ctrl);
                PrepGrid.DataBind();
                Connection.DisConnect();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                Connection.DisConnect();
            }
        }

        public void DataGrid_Select(Object sender, GridRecordEventArgs e)
        {
            //int j = 666;
        }
        public void DataGrid_Edit(Object sender, GridRecordEventArgs e)
        {
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);

            BackEndSubs util = new BackEndSubs();
            string FilePath = util.GetSplitDir(connection);
            string UniqueKey = e.Record["UniqueKey"].ToString();
            string ProcessState = e.Record["ProcessState"].ToString();
            string FileName = e.Record["FileName"].ToString();
            string UsedForAutoRepair = e.Record["UsedForAutoRepair"].ToString();
            string WriteFile = e.Record["WriteFile"].ToString();
            string TableL = e.Record["OutputTableName"].ToString();
            string Cmd = string.Format("update FileCompcontrol set ProcessState='{0}'," +
            "OutputTableName='{1}',UsedForAutoRepair='{2}', " +
            "WriteFile='{3}',InputFileName='{4}',PathToInputFile='{5}' where UniqueKey='{6}'",
            ProcessState, TableL, UsedForAutoRepair, WriteFile, FileName, FilePath, UniqueKey);
            connection.Connect(true, dbname);
            connection.Execute(Cmd, true);

            BindDataGrid();
        }

        public void DataGrid_Cancel(Object sender, GridRecordEventArgs e)
        {
            //        PrepGrid.EditItemIndex = -1;
            BindDataGrid();
        }

        public void DataGrid_Insert(object source, GridRecordEventArgs e)
        {
            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(true, dbname);

            BackEndSubs util = new BackEndSubs();
            string FilePath = util.GetSplitDir(connection);

            string UniqueKey = e.Record["UniqueKey"].ToString();
            string ProcessState = e.Record["ProcessState"].ToString();
            string FileName = e.Record["FileName"].ToString();
            string UsedForAutoRepair = e.Record["UsedForAutoRepair"].ToString();
            string WriteFile = e.Record["WriteFile"].ToString();
            string TableL = e.Record["OutputTableName"].ToString();
            if (Regex.IsMatch(TableL, "^[ a-zA-Z0-9._-]*$"))
            {
                string Cmd = string.Format("insert into FileCompControl (CompPid,ProcessState,InputFileName,PathtoInputFile," +
                    "TimeStarted,TimeEnded,OutputTableName,UsedForAutoRepair,NumberLoaded,NumberRead, " +
                    "WriteFile)" +
                "values (0,'{0}','{1}','{2}',NULL,NULL,'{3}','{4}',0,0,'{5}')",
                ProcessState, FileName, FilePath, TableL, UsedForAutoRepair, WriteFile);
                connection.Execute(Cmd, true);
            }
            else
            {
                ExecOnLoad("Table Desc must be AlphaNumeric");
            }
            BindDataGrid();
        }

        public void DataGrid_Delete(object source, GridRecordEventArgs e)
        {
            string UniqueKey = "";
            try
            {
                UniqueKey = (e.Record["UniqueKey"].ToString());
            }
            catch
            {
            }
            String Cmd = "delete from FileCompcontrol where uniquekey=" + UniqueKey;
            DBAccess Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                Connection.Connect(false, dbname);
                Connection.Execute(Cmd, true);
                //                PrepGrid.EditItemIndex = -1;
                BindDataGrid();
            }
            catch (Exception)
            {
            }
            finally
            {
                Connection.DisConnect();
                Connection.Dispose();
            }
        }

        private void InitializeComponent()
        {
            //this.PrepGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.ItemCommands);
            //this.PrepGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Cancel);
            //this.PrepGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Edit);
            //this.PrepGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Update);
            //this.PrepGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid_Delete);
            //this.PrepGrid.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.ItemBound);

        }
        private void PopulatePathControl(OboutDropDownList dList)
        {
            Hashtable list = new Hashtable();
            DBAccess Connection = new DBAccess();
            try
            {
                Connection.Connect(false, (String)HttpContext.Current.Session["CurrentDB"]);
                BackEndSubs util = new BackEndSubs();
                IProcMgr procMgr = (IProcMgr)Activator.GetObject(typeof(IProcMgr), "tcp://localhost:21005/ProcMgr");
                if (procMgr != null)
                {
                    String targetDir = util.GetSplitDir(Connection);
                    DataSet ds = (DataSet)procMgr.getDirectoryList(targetDir);		// change this to appropriate directory
                    foreach (DataTable dt in ds.Tables)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            string fullFileName = row["FileName"].ToString();
                            int LastDelimeter = fullFileName.LastIndexOf(@"\") + 1;
                            if (LastDelimeter == 0)
                            {
                                LastDelimeter = fullFileName.LastIndexOf(@"/") + 1;
                            }
                            string FileName = fullFileName.Substring(LastDelimeter);
                            list.Add(FileName, fullFileName);
                            dList.Items.Add(FileName);
                        }
                    }
                    dList.DataSource = list;
                    //dList.Items.Add(list);
                }
            }
            finally
            {
                Connection.DisConnect();
            }
        }
    }
}