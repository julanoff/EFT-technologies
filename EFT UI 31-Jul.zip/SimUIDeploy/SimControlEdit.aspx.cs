/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Simulator.DBLibrary;

using System.Web.Configuration;
using Simulator.BackEndSubLib;
using System.ComponentModel;
using System.Drawing;
using System.Web.SessionState;
using System.Data.SqlClient;
//using System.Configuration;
//using Simulator.BackEndSubLib;
using Simulator.EventLogger;


/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/





namespace Simulator
{
    /// <summary>
    /// Summary description for WebForm1.
    /// </summary>
    /// public partial class SimControlEdit : System.Web.UI.Page

    public partial class SimControlEdit : System.Web.UI.Page
    {
        DBAccess m_Connection;
        protected void Page_Load(object sender, System.EventArgs e)
        {

            DBAccess connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            connection.Connect(false, dbname);

            if (!Page.IsPostBack)
            {
                BindDataGrid();
                editGridEnable(false);
            }
            setVendor();
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer supCompareRgwArea - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {

        }
        #endregion


        private void BindDataGrid()
        {
            m_Connection = new DBAccess();
            String dbname = (String)HttpContext.Current.Session["CurrentDB"];
            try
            {
                clearEditFields();

                String Cmd;
                m_Connection.Connect(false, dbname);

                Cmd = String.Format(" select * from SimulatorControl");
                DataSet ds = m_Connection.getDataSet(Cmd);
                DataTable dt = ds.Tables[0];
                DataRow dr = dt.Rows[0];

                OurHostAddress.Text = dr["OurHostAddress"].ToString().Trim();
                ApplicationName.Text = dr["ApplicationName"].ToString().Trim();
                Area.Text = dr["Area"].ToString().Trim();
                LocalRgwArea.Text = dr["LocalRgwArea"].ToString().Trim();
                CompareRgwArea.Text = dr["CompareRgwArea"].ToString().Trim();

                RemoteRgwArea.Text = dr["RemoteRgwArea"].ToString().Trim();
                defaultCompareTable.Text = dr["DefaultCompareTable"].ToString().Trim();

                MTSHostName.Text = dr["MTSHostName"].ToString().Trim();
                RootDir.Text = dr["RootDir"].ToString().Trim();
                RemoteRgwArea.Text = dr["RemoteRgwArea"].ToString().Trim();
                RgwRepository.Text = dr["RgwRepository"].ToString().Trim();
                ReceiverRGWArea.Text = dr["ReceiverRGWArea"].ToString().Trim();

                RemoteMtsHostName.Text = dr["RemoteMtsHostName"].ToString().Trim();
                ChpAba.Text = dr["ChpAba"].ToString().Trim();
                FedAba.Text = dr["FedAba"].ToString().Trim();

                SwfVersion.Text = dr["SwfVersion"].ToString().Trim();
                SimVersion.Text = dr["SimVersion"].ToString().Trim();

                JavaHost.Text = dr["JavaHost"].ToString().Trim();
                JavaPort.Text = dr["JavaPort"].ToString().Trim();

                DebugSwitch.Text = dr["Debug"].ToString().Trim();

                MTSPort.Text = dr["MtsSrvPort"].ToString().Trim();
                MtsScript.Text = dr["MtsScriptDir"].ToString().Trim();

            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            finally
            {
                m_Connection.DisConnect();
            }

        }

        void DataGrid_Edit(Object sender, DataGridCommandEventArgs e)
        {

            editGridEnable(true);

            RefreshButton.Visible = false;
        }

        void DataGrid_Cancel(Object sender, DataGridCommandEventArgs e)
        {
            // Set the EditItemIndex property to the index of the item clicked
            // in the DataGrid control to enable editing for that item. Be sure
            // to rebind the DateGrid to the data source to refresh the control.

            BindDataGrid();
        }


        void DataGrid_Update(Object sender, DataGridCommandEventArgs e)
        {
        }

        private void MyDataGrid_Change(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
        {

            BindDataGrid();
        }

        protected void SelGroup_change(object sender, System.EventArgs e)
        {


            BindDataGrid();
        }

        protected void Refresh_click(object sender, System.EventArgs e)
        {
            BindDataGrid();
        }
        protected void CancelButton_click(object sender, System.EventArgs e)
        {
            editGridEnable(false);
            BindDataGrid();
        }
        protected void Confirm_Click(object sender, System.EventArgs e)
        {

            bool okToCommit = true;

            string _OurHostAddress = OurHostAddress.Text;
            string _ApplicationName = ApplicationName.Text;
            string _Area = Area.Text;
            string _LocalRgwArea = LocalRgwArea.Text;
            string _ReceiverRGWArea = ReceiverRGWArea.Text;
            string _CompareRgwArea = CompareRgwArea.Text;
            string _RemoteRgwArea = RemoteRgwArea.Text;
            string _RgwRepository = RgwRepository.Text;
            string _defaultCompareTable = defaultCompareTable.Text;
            string _MTSHostName = MTSHostName.Text;
            string _RootDir = RootDir.Text;
            string _FedAba = FedAba.Text;
            string _ChpAba = ChpAba.Text;
            string _SimVersion = SimVersion.Text.Trim();
            string _SwfVersion = SwfVersion.Text.Trim();
            string _RemoteMtsHostName = RemoteMtsHostName.Text.Trim();
            string _JavaHost = JavaHost.Text.Trim();
            string _JavaPort = JavaPort.Text.Trim();
            string _debug = DebugSwitch.Text.Trim().ToUpper();
            string _mtsSrvPort = MTSPort.Text.Trim().ToUpper();
            string _mtsScriptDir = MtsScript.Text.Trim().ToUpper();

            if (_OurHostAddress.Length > 15)
            {
                editErrors.Text = "Our Host Address cannot be more than 15 chars";
                okToCommit = false;
            }
            if (_ApplicationName.Length > 20)
            {
                editErrors.Text = "Application Name cannot be more than 20 chars";
                okToCommit = false;
            }

            if (_LocalRgwArea.Length > 20)
            {
                editErrors.Text = "Local Rgw Area cannot be more than 20 chars";
                okToCommit = false;
            }
            if (_RootDir.Length > 64)
            {
                editErrors.Text = "Root Directory cannot be more than 64 chars";
                okToCommit = false;
            }
            if (_MTSHostName.Length > 15)
            {
                editErrors.Text = "MTS Host Name cannot be more than 15 chars";
                okToCommit = false;
            }

            if (_RemoteMtsHostName.Length > 15)
            {
                editErrors.Text = "Remote MTS Host Name cannot be more than 15 chars";
                okToCommit = false;
            }

            if (_ChpAba.Length > 4)
            {
                editErrors.Text = "Chip value cannot be more than 4 chars";
                okToCommit = false;
            }

            if (_FedAba.Length > 9)
            {
                editErrors.Text = "Fed ABA cannot be more than 9 chars";
                okToCommit = false;
            }
            if (_SimVersion.Length == 0)
            {
                _SimVersion = "5.0";
            }
            else
            {
                okToCommit = true;
            }
            if (_JavaHost.Length > 15)
            {
                editErrors.Text = "Java Host cannot be more than 15 chars long";
                okToCommit = false;
            }
            try
            {
                int zzz = int.Parse(_JavaPort);
            }
            catch
            {
                _JavaPort = "0";
            }
            switch (_debug)
            {
                case "0":
                case "1":
                case "2":
                case "3":
                case "5":
                    break;
                default:
                    {
                        editErrors.Text = "Debug value must be '0' or '1' or '2' or '3' or '5'";
                        okToCommit = false;
                        break;
                    }
            }

            /*
             * So far so good ... let's edit what the humans supplied.
             */

            if (okToCommit)
            {
                /*
                 * Ok, all the edits passed, let's update the Simulator control table.
                 */
                string Cmd = string.Format("update SimulatorControl set " +

                    "OurHostAddress = '{0}', " +
                    "ApplicationName = '{1}', " +
                    "Area = '{2}', " +
                    "LocalRgwArea = '{3}', " +
                    "ReceiverRGWArea = '{4}', " +
                    "CompareRgwArea = '{5}', " +
                    "RemoteRgwArea = '{6}', " +
                    "RgwRepository = '{7}', " +
                    "defaultCompareTable = '{8}', " +
                    "MTSHostName = '{9}', " +
                    "RootDir = '{10}', " +
                    "FedAba = '{11}', " +
                    "ChpAba= '{12}', " +
                    "SwfVersion = '{13}', " +
                    "SimVersion = '{14}', " +
                    "RemoteMTSHostName = '{15}', " +
                    "JavaHost = '{16}', " +
                    "JavaPort = {17}, " +
                    "Debug = '{18}', " +
                    "MtsSrvPort = {19}, " +
                    "MtsScriptDir = '{20}' ",
                    _OurHostAddress,
                    _ApplicationName,
                    _Area,
                    _LocalRgwArea,
                    _ReceiverRGWArea,
                    _CompareRgwArea,
                    _RemoteRgwArea,
                    _RgwRepository,
                    _defaultCompareTable,
                    _MTSHostName,
                    _RootDir,
                    _FedAba,
                    _ChpAba,
                    _SwfVersion,
                    _SimVersion,
                    _RemoteMtsHostName,
                    _JavaHost,
                    _JavaPort,
                    _debug,
                    _mtsSrvPort,
                    _mtsScriptDir

                    );

                DBAccess Connection = new DBAccess();

                String _area = (String)HttpContext.Current.Session["CurrentDB"];
                try
                {
                    Connection.Connect(true, _area);
                    Connection.Execute(Cmd, true);

                    BindDataGrid();
                }
                catch (Exception e1)
                {
                    editErrors.Text = e1.Message;
                    editErrors.Visible = true;
                    editErrors.ForeColor = Color.Red;
                }
                finally
                {
                    Connection.DisConnect();
                }

                Cancel_button.Visible = false;
                Confirm_button.Visible = false;

                BindDataGrid();

                editGridEnable(false);

            }
            else
            {
                editErrors.Visible = true;
                editErrors.ForeColor = Color.Red;

                RefreshButton.Visible = false;
                EditButton.Visible = false;
            }

        }

        protected void clearEditFields()
        {
            OurHostAddress.Text = "";
            ApplicationName.Text = "";
            Area.Text = "";
            LocalRgwArea.Text = "";
            ReceiverRGWArea.Text = "";
            CompareRgwArea.Text = "";
            RemoteRgwArea.Text = "";
            RgwRepository.Text = "";
            defaultCompareTable.Text = "";
            MTSHostName.Text = "";
            RootDir.Text = "";
            FedAba.Text = "";
            ChpAba.Text = "";
            SwfVersion.Text = "";
            RemoteMtsHostName.Text = "";
            SimVersion.Text = "";
            DebugSwitch.Text = "";

        }
        protected void Delete_Click(object sender, System.EventArgs e)
        {

        }

        private void setVendor()
        {

            string vendor = Session["vendor"].ToString().ToLower();
            bool aci = false;
            if (vendor.StartsWith("aci"))
            {
                aci = true;
            }
            if (aci)
            {
                LocalRgwArea.Visible = true;
                ReceiverRGWArea.Visible = true;
                CompareRgwArea.Visible = true;
                RemoteRgwArea.Visible = true;
                RgwRepository.Visible = true;
                //defaultCompareTable.Visible = true;

                ChpAba.Visible = true;
                SwfVersion.Visible = true;
                RemoteMtsHostName.Visible = true;


                JavaHost.Visible = false;
                JavaPort.Visible = false;
                JavaHostLabel.Visible = false;
                JavaPortLabel.Visible = false;
            }
            else
            {

                LocalRgwArea.Visible = false;
                LocalRgwAreaLabel.Visible = false;
                ReceiverRGWArea.Visible = false;
                ReceiverRgwLabel.Visible = false;
                CompareRgwArea.Visible = false;
                CompareRgwAreaLabel.Visible = false;
                RemoteRgwArea.Visible = false;
                RemoteRgwAreaLabel.Visible = false;
                RgwRepository.Visible = false;
                RgwRepositoryLabel.Visible = false;
                defaultCompareTable.Visible = false;
                defaultCompareTableLabel.Visible = false;
                ChpAba.Visible = false;
                ChpAbaLabel.Visible = false;
                SwfVersion.Visible = false;
                SwfVersionLabel.Visible = false;
                RemoteMtsHostName.Visible = false;
                RemoteMtsHostNameLabel.Visible = false;

            }
        }


        private void editGridEnable(bool enable)
        {
            if (enable)
            {
                OurHostAddress.Enabled = true;
                ApplicationName.Enabled = true;
                Area.Enabled = false;
                MTSHostName.Enabled = true;
                RootDir.Enabled = true;
                FedAba.Enabled = true;
                SimVersion.Enabled = true;

                LocalRgwArea.Enabled = true;
                ReceiverRGWArea.Enabled = true;
                CompareRgwArea.Enabled = true;
                RemoteRgwArea.Enabled = true;
                RgwRepository.Enabled = true;
                defaultCompareTable.Enabled = true;

                ChpAba.Enabled = true;
                SwfVersion.Enabled = true;
                RemoteMtsHostName.Enabled = true;

                JavaHost.Enabled = true;
                JavaPort.Enabled = true;

                RefreshButton.Visible = false;
                Confirm_button.Visible = true;
                Cancel_button.Visible = true;
                EditButton.Visible = false;
                DebugSwitch.Enabled = true;
                MTSPort.Enabled = true;
                MtsScript.Enabled = true;
            }
            else
            {
                OurHostAddress.Enabled = false;
                ApplicationName.Enabled = false;
                Area.Enabled = false;
                MTSHostName.Enabled = false;
                SimVersion.Enabled = false;

                RootDir.Enabled = false;
                FedAba.Enabled = false;

                LocalRgwArea.Enabled = false;
                ReceiverRGWArea.Enabled = false;
                CompareRgwArea.Enabled = false;
                RemoteRgwArea.Enabled = false;
                RgwRepository.Enabled = false;
                defaultCompareTable.Enabled = false;

                ChpAba.Enabled = false;
                SwfVersion.Enabled = false;
                RemoteMtsHostName.Enabled = false;

                JavaHost.Enabled = false;
                JavaPort.Enabled = false;

                RefreshButton.Visible = true;
                EditButton.Visible = true;
                editErrors.Visible = false;
                Confirm_button.Visible = false;
                Cancel_button.Visible = false;

                DebugSwitch.Enabled = false;
                MTSPort.Enabled = false;
                MtsScript.Enabled = false;
            }
        }

        protected void Edit_click(object sender, System.EventArgs e)
        {
            editGridEnable(true);
        }


        private IDbConnection getDBConnection(string selectedDB, string area)
        {
            IDbConnection dbConn;
            string sqlConnectionString = getConnectionString(selectedDB, area);
            dbConn = new SqlConnection(sqlConnectionString);
            dbConn.Open();
            return dbConn;
        }


        private string getConnectionString(string selectedDB, string area)
        {

            string connectionString;
            SimulatorLog eventLog = new SimulatorLog("Simulator");

            connectionString = "Simulator_" + area + "ConnectionString";


            ConnectionStringsSection connectionStringsSection =
                WebConfigurationManager.GetSection("connectionStrings") as ConnectionStringsSection;

            if (connectionStringsSection == null)
            {
                throw (new ApplicationException("No Connection String section in web.config"));
            }

            ConnectionStringSettingsCollection connectionStrings = connectionStringsSection.ConnectionStrings;
            ConnectionStringSettings connectionSettings = connectionStrings[connectionString];
            if (null == connectionSettings)
            {
                throw (new ApplicationException("Cannot find ConnectionString for " + connectionString));
            }

            string dsn = connectionSettings.ConnectionString;
            return dsn;
        }
        protected void OurHostAddress_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


