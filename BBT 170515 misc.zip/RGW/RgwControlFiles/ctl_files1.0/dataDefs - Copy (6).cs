/*                                                              
 Copyright (c) 1999 - 2005 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/

using System;
using System.Collections;
using System.Text;
using Simulator.DBLibrary;
using Simulator.SimLog;

/*
 * If all you're doing is changing a field or two or three in a table, you need to change
 * the definition below. 
 * 
 * If you're lucky, though, you won't touch one of those and all you have to do is
 * fiddle with the fields below.
 * 
 * If you want to add an entirely new table, change the config below and add corresponding
 * entries to the two routines that follow. If the table you're adding is part of the
 * basic application configuration, you'll want to add its name to the "InitialTables"
 * list in baselineconfig in backendsubs. That way it'll get built when you initialize
 * a new area. 
 */
/*
 * 10-Sep-06    JR  Add Ack31q. Add OutSeqNo to link control.
 * 08-Oct-06    J.Richardson    Add an 'area' field to bylogsloadercontrol.
 * 
 * 13-Oct-06    J.Richardson    Add 'SwfVersion' to simulator control.
 * 14-Oct-06    J.Richardson    Add 'EntRprFdr' table.
 * 15-Oct-06    J.Richardson    Add 'EntRprStaging' table.
 * 28-Oct-06    J.Richardson    Add 'EntrySources' table.
 *  3-Nov-06    J.Richardson    More fields to EntRprFdr.
 * 12-Nov-06    JR              Add unique key to entrprfeeder. Change videoconfig ports
 *                              to ints.
 * 25-Jan-07    JR              Fed tables. LTermControl. FedControl. Imad. FedReceiveAckQue.
 * 
 * 03-Feb-07    JR              Expand the error code in the error code table to 6 chars. A couple
 *                              more fields in the SimulatorControl table listing where the 
 *                              receiver(s) should put the inbound rgw traffic & where to stash
 *                              compare tables. Put those fields in the Master table, too.
 *                              Also add a field for 'defaultCompareTable' to the above.
 * 
 * 07-Feb-07    JR              A class for the rgw tables in their form today, complete with
 *                              methods to delete them, create them, and add indices.
 * 
 * 10-Feb-07    JR              Add AreaBanks, AreaAdvTypes, AreaSources, AreaTranTypes.
 * 15-Feb-07    JR              Rework the control files for the RGW area info. Simplify it...
 * 14-Apr-07    JR              Add CompareSummary table.
 * 19-Apr-07    JR              Add CompareMetaSummary table.
 * 22-Apr-07    JR              Increase the size of the strings in CompareResults.
 * 24-Apr-07    JR              More fields to CompareMetaSummary.
 * 29-Apr-07    JR              A totals field added to compare summary.
 * 30-Apr-07    JR              Another MQ link field in LinkControl.
 * 05-May-07 	JN		Add MsgCount field into LNK tables and SimVersion into SimulatorControl.
 * 15-May-07    JN		Add Rsn table and deleted RsnSeqNo from LinkcontrolTable.
 * 
 * 07-Jul-08    JR      Change (a little) the definintion of the compare results table. I
 *                      want it to match what the simulator code is building when it does
 *                      the 'trial' compare in the ui.
 * 
 * 10-oct-08	JN	    Renamed entrprfdr to EntRprFeeder
 * 
 * 01-nov-08	JN	    Add OprSources table. It is used in Autoentry module to specifiy Sources 
 *                      a particular operator can enter.
 * 
 * 06-Jul-09    JR      STI - version 3.0 of MTS. In spite of Dick Ellis' promises to the contrary,
 *                      we're seeing RGW table changes for MTS 3.0. Message, Message_cr, and Message_dr
 *                      so far. Stay tuned ... This all means a value in simulator_control to tell
 *                      us which version of RGW we're looking at, more smarts in a number of places
 *                      to keep track of which table layout we have, etc, etc. In here we now
 *                      have two different classes for the rgw message tables, one for the 'old'
 *                      style, one for MTS 3.0 tables.
 * 
 * 12-Jun-11    JR      We're now able to look up msgs that went to a specific queue. We need
 *                      an index on message_hist.que_line_id to support that. I added it in here.
 * 
 * 17-Jun-11    JR      Add a 'Pin' column to the line control table. For STI so we can have the
 *                      ISI code plug a pin into the msg we're sending.
 * 
 * 01-Feb-12    JR      Wholesale changes coming down for FundTech.
 * 
 *                          CompareKeys
 *                              XpathExp	  str(20)
 *                              CompExpression str(40)
 * 
 *                          MQLineSrc is new
 * 
 *    
 * 03-Mar-12    JR      Included Jacobi's changes for FT, etc.
 * 
 * 29-Oct-12    JR  Add ExcelQ table.
 * 08-Mar-2013	JN 	Add ChangeRef to SimulatorControl
 * 8-Mar-2013	JN  Add ChageRef to SimulatorControl
 		JN  Add SrcDb, TrgDb, DbPrefix to MqLineSrc table
 * 05-Jul-2013	JN 	Add RptFileter table.
 * 09-Jul-2014  JR	Error code in acknak rules needs to be 4 chars, not 4.
 * 06-Nov-2014  JR  Non-trivial changes for outgound text comparison.
 * 11-Aug-2015  JR  Added a 'MtsSourceCode' column to linenames so we can tie the inbound source in the message
 *                  to the format of the message. At STI, for example, the S1I line is ISI. We need to know that
 *                  so we can find the xref trn for comparing.
 * 15-Nov-2015  JN  Add MtsSrvPort  , MtsScriptDir to SimulatorControl
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 31-Dec-2015  JN  Add Client to SimulatorControl
 *
 */



namespace Simulator.dataDefs
{
    /*
     * Techie note:
     * 
     * Most of the table definition strings below have the real name of the table
     * embedded in the string as in:
     * 
     *          "CREATE TABLE [dbo].[ApplicationBanks] (",
     * 
     * and that's ok as long as you're only going to have one table of that type and
     * the name of the table matches the type of the table. That's true with the above
     * table. However, there are others where we end up with multiple versions of 
     * a particular type. 'CompareKeys' is one. For those, the create string needs
     * to look like:
     * 
     *          "CREATE TABLE [dbo].[{0}] (",
     * 
     * because the table creation routine is going to be looking for '{0}' to know
     * where to substitute the actual table name.
     * 
     */
    public class tableDefs
    {
        /*
         * Master tables here.
         * 
         * Note: ApplicationBanks lives as a master table and at the area level, too.
         */

        string[] ApplicationBanks = {
                "CREATE TABLE [dbo].[ApplicationBanks] (",
                "[Bank] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                ") ON [PRIMARY]"};


        string[] Areas = {
               "CREATE TABLE [dbo].[Areas] (",
                "[AreaName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                ") ON [PRIMARY]"};

        string[] MasterControl = { 
                "CREATE TABLE [dbo].[MasterControl] (",
                "[remoteRgwArea] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                "[RgwRepository] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                "[defaultCompareTable] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                ") ON [PRIMARY]"};

        string[] SplitterFileTypes = {
                "CREATE TABLE [dbo].[SplitterFileTypes] (",
                "[FileType] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                ") ON [PRIMARY]"};


        /*
         * 'Regular' application tables here.
         */

        string[] Ack31q = {
                        "CREATE TABLE [dbo].[Ack31q] (",
                        "[Qbl] [int] NOT NULL ,",
                        "[Osn] [int] NULL ,",
                        "[Ssn] [int] NULL ,",
                        "[Acked] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[QblText] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] AckNakRules = { 
			"CREATE TABLE [dbo].[AckNakRules] (",
			"[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
			"[TabInd] [int] NOT NULL ,",
			"[Tag] [char] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
			"[BicOrString] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
			"[BicString] [char] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
			"[ErrorCode] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
			"[LineN] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
			") ON [PRIMARY]"};

        string[] ActionQue = { 
                        "CREATE TABLE [dbo].[ActionQue] (",
                        "[ActionId] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[TimeofAction] [datetime] NULL ,",
                        "[Severity] [int] NULL ,",
                        "[ActionText] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] ActiveProcesses = { 
                        "CREATE TABLE [dbo].[ActiveProcesses] (",
                        "[ModName] [char] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ProcId] [int] NULL ,",
                        "[ProcArgs] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[StartTime] [datetime] NULL ",
                        ") ON [PRIMARY]"};

        string[] AreaAdvTypes = {
                        "CREATE TABLE [dbo].[AreaAdvTypes] (",
                        "[AdvType] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] AreaBanks = {
                        "CREATE TABLE [dbo].[AreaBanks] (",
                        "[Bank] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] AreaSources = {
                        "CREATE TABLE [dbo].[AreaSources] (",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] AreaTranTypes = {
                        "CREATE TABLE [dbo].[AreaTranTypes] (",
                        "[TranType] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] BatchQ = {
                        "CREATE TABLE [dbo].[BatchQ] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[ProcessState] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL, ",
                        "[AssignTime] [datetime] NOT NULL ,",
                        "[LoadTime] [datetime] NULL ,",
                        "[Type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL, ",
                        "[XmlText] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] BatchDescr = {
                        "CREATE TABLE [dbo].[BatchDescr] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[BatchId] [int] NULL ,",
                        "[CompId] [int] NULL ,",
                        "[BatchDescr] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[BatchStatus] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[AreaBefore] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[AreaAfter] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[TimeStart] [datetime] NULL ,",
                        "[TimeEnd] [datetime] NULL ,",
                        "[NoReplay] [int] NULL ,",
                        "[NoDiffs] [int] NULL, ",
                        "[NoExcel] [int] NULL, ",
                        "[DbPrefix] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] ByLogsControl = { 
                        "CREATE TABLE [dbo].[ByLogsControl] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[LoaderPid] [int] NULL ,",
                        "[ProcessState] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FileName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FilePath] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[LastTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[TimelyDlv] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[nLoad] [int] NULL ,",
                        "[FileValueDate] [datetime] NULL ,",
                        "[NewValueDate] [datetime] NULL ,",
                        "[AmtDelta] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[nLoadAlgorithm] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[AssignTime] [datetime] NOT NULL ,",
                        "[LoadTime] [datetime] NULL ,",
                        "[NumberLoaded] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] ByLogsLoaderControl = {
                        "CREATE TABLE [dbo].[ByLogsLoaderControl] (",
	                    "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
	                    //"[RgwLoaderPid] [int] NULL ,",
	                    "[ProcessState] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
	                    "[LocalRGWarea] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                            "[FileName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
	                    "[FilePath] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
	                    "[TimeStarted] [datetime] NULL ,",
	                    "[TimeEnded] [datetime] NULL, ",
                            "[Comment] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] ChipsControl = { 
                        "CREATE TABLE [dbo].[ChipsControl] (",
                        "[ValDate] [datetime] NULL ,",
                        "[Act_fund] [money] NULL ,",
                        "[Gen_ssn] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[New_day] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Dup_psn_check] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Rslv_fund_on] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] ChpCustomEdit =  { 
                        "CREATE TABLE [dbo].[ChpCustomEdit] (",
                        "[Tag] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Nak] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RegExpr] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] ChpFieldEdit =  { 
                        "CREATE TABLE [dbo].[ChpFieldEdit] (",
                        "[Tag] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Nak] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RegExpr] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] ChpLineList =  { 
                        "CREATE TABLE [dbo].[ChpLineList] (",
                        "[LineName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS not NULL PRIMARY KEY,",
                        "[MsgCount] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] ChpReceiveAckQue =  { 
                        "CREATE TABLE [dbo].[ChpReceiveAckQue] (",
                        "[Qbl] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[LineName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Nak] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Tag] [char] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ErrorCode] [char] (180) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ErrorLen] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Msg_header] [char] (48) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Msg_body] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};


        string[] ChpRcvAmt = { 
                        "CREATE TABLE [dbo].[ChpRcvAmt] (",
                        "[RcvAmt] [money] NULL ",
                        ") ON [PRIMARY]"};


        string[] ChpRlsAmt = { 
                        "CREATE TABLE [dbo].[ChpRlsAmt] (",
                        "[RlsAmt] [money] NULL ",
                        ") ON [PRIMARY]"};

        string[] ChpStats = { 
                        "CREATE TABLE [dbo].[ChpStats] (",
                        "[SessionNo] [char] (19) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[StartTime] [datetime] NULL ,",
                        "[EndTime] [datetime] NULL ,",
                        "[NoSent] [int] NULL ,",
                        "[NoReceived] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] ChpTags = { 
                        "CREATE TABLE [dbo].[ChpTags] (",
                        "[Tag] [char] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Description] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] Compare = {
                        "CREATE TABLE [dbo].[{0}] (",
                        "[Trn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Text] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ParentTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[XrefTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Xref] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] CompareControl = { 
                    "CREATE TABLE [dbo].[CompareControl] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[ProcessState] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Table1] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Table2] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Filter] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] CompareHistory = { 
                        "CREATE TABLE [dbo].[CompareHistory] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ," ,
                        "[Table1] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Table2] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Filter] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[TimeStamp] [datetime] NOT NULL",
                        ") ON [PRIMARY]"};

        string[] CompareKeys = {
                        "CREATE TABLE [dbo].[{0}] (",
 			            "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ," ,
                        "[IdiKey] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[CmpKey] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[XmlSet] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[CompExpression] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS  ,",
                        "[Include] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[OrdinalType] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] oldCompareResults = { "CREATE TABLE [dbo].[{0}] (",
                        "[Trn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[XmlSet] [char] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FieldName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Val1] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Val2] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[CompareId] [int] NOT NULL",
                        ") ON [PRIMARY]"};

        string[] CompareResults = { "CREATE TABLE [dbo].[{0}] (",
                        "[Trn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Section] [char] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FieldName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[C] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[OldValue] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[NewValue] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[CompareId] [int] NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] CompareMetaSummary = {
                        "CREATE TABLE [dbo].[{0}] (",
                        "[totalMsgs] [int] NOT NULL, ",
                        "[deltaMsgs] [int] NOT NULL, ",
                        "[Ftr] [int] NOT NULL, ",
                        "[Cdt] [int] NOT NULL, ",
                        "[Dbt] [int] NOT NULL, ",
                        "[Dst] [int] NOT NULL, ",
                        "[Text] [int] NOT NULL, ",
                        "[Hist] [int] NOT NULL, ",
                        "[Prm] [int] NOT NULL, ",
                        "[CreateTime] [datetime] NOT NULL ,",
                        "[CmpTableName] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[CmpTableDescription] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] CompareSummary = {
                        "CREATE TABLE [dbo].[{0}] (",
                        "[Trn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Ftr] [int] NOT NULL, ",
                        "[Cdt] [int] NOT NULL, ",
                        "[Dbt] [int] NOT NULL, ",
                        "[Dst] [int] NOT NULL, ",
                        "[Text] [int] NOT NULL, ",
                        "[Hist] [int] NOT NULL, ",
                        "[Prm] [int] NOT NULL, ",
                        "[nDelta] [int] NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] CommandCentral = { 
                        "CREATE TABLE [dbo].[CommandCentral] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[Process] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Command] [char] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] CompQ = {
                        "CREATE TABLE [dbo].[CompQ] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[BatchInd] [int] NOT NULL, ",
                        "[ProcessState] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL, ",
                        "[AssignTime] [datetime] NOT NULL ,",
                        "[LoadTime] [datetime] NULL ,",
                        "[Type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL, ",
                        "[XmlText] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] DiffResults = { 
                        "CREATE TABLE [dbo].[DiffResults] (",
                        "[Pk1] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[BatchId] [int] NOT NULL, ",
                        "[RefBefore] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[RefAfter] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FldName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ValBefore] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ValAfter] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[XmlSet] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] DiffSummary = { 
                        "CREATE TABLE [dbo].[DiffSummary] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[RefBefore] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[RefAfter] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[BatchId] [int] NOT NULL, ",
                        "[DiffNumber] [int] NOT NULL ,",
                        "[Mifs] [int] NOT NULL, ",
                        "[Mtfs] [int] NOT NULL, ",
                        "[Swfmids] [int] NOT NULL, ",
                        "[Freemsgs] [int] NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] EntRprFeeder = {
                        "CREATE TABLE [dbo].[EntRprFeeder] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[TrnNumber] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Source_cd] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[AdviceType] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Bank] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,", 
                        "[DebitIdType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[DebitId] [char] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[BranchIdType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[BranchId] [char] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Amount] [money] NULL ,",
                        "[Status] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[OprFunction] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[RcvTime] [datetime] NOT NULL ,",
                        "[AbsTime] [bigint] NOT NULL ,",
                        "[DeltaTime] [bigint] NOT NULL ,",
                        "[Timely] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] EntrySources = {
                        "CREATE TABLE [dbo].[EntrySources] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};


        string[] ErrorCodes = { 
                        "CREATE TABLE [dbo].[ErrorCodes] (",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ErrorCode] [char] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[LineReq] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ErrorDesc] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL  ",
                        ") ON [PRIMARY]"};

        string[] ExcelQ = {
                        "CREATE TABLE [dbo].[ExcelQ](",
                        "[pk] [int] IDENTITY(1,1) NOT NULL,",
                        "[ProcessState] [nchar](1) NOT NULL,",
                        "[BatchId] [int] NOT NULL,",
                        "[FilterName] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[AssignTime] [datetime] NULL,",
                        "[EndTime] [datetime] NULL",
                        ") ON [PRIMARY]"};

        string[] FDR = {
                        "CREATE TABLE [dbo].[{0}] (",
                        "[Qblid] [int] NOT NULL ,",
                        "[TrnNumber] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[RcvTime] [datetime] NOT NULL ,",
                        "[AbsTime] [bigint] NOT NULL ,",
                        "[DeltaTime] [bigint] NOT NULL ,",
                        "[Disposition] [int] NOT NULL ,",
                        "[Timely] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[QblText] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] FedCustomEdit =  { 
                        "CREATE TABLE [dbo].[FedCustomEdit] (",
                        "[Tag] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Nak] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RegExpr] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] FedFieldEdit =  { 
                        "CREATE TABLE [dbo].[FedFieldEdit] (",
                        "[Tag] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Nak] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RegExpr] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] FedControl =  { 
                        "CREATE TABLE [dbo].[FedControl] (",
                        "[ApplId] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[CycleDate] [datetime] NULL ,",
                        "[NumberPerBatch] [int] NOT NULL ,",                 
                        "[GenOMAD] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[ChangeCDate] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[CheckDups] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[CheckGaps] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[OpenBal] [money] NULL ,",
                        "[DebitCap] [money] NULL ,",
                        "[FundsColl] [money] NULL ,",
                        "[CreditAmt] [money] NULL ,",
                        "[CreditCnt] [int] NOT NULL, ",
                        "[DebitAmt] [money] NULL ,",
                        "[DebitCnt] [int] NOT NULL, ",
                        "[BankName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] FedReceiveAckQue = {
                        "CREATE TABLE [dbo].[FedReceiveAckQue] (",
                        "[Qblid] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[LineName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Nak] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Tag] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ErrCode] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ErrDesc] [char] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[MsgText] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] FeederControl =  { 
                        "CREATE TABLE [dbo].[FeederControl] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[LineName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ProcessState] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[TimelyDelivery] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[FmtName] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[FmtTag] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[TimeFrom] [datetime] NULL ,",
                        "[TimeTo] [datetime] NULL ,",
                        "[MsgperTrn] [smallint] NULL ,",
                        "[NumberSel] [int] NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] FileCompControl = { 
                        "CREATE TABLE [dbo].[FileCompControl] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[CompPid] [int] NULL ,",
                        "[ProcessState] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[InputFileName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[PathtoInputFile] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[OutputTableName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Description] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[UsedForAutoRepair] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[TimeStarted] [datetime] NULL ,",
                        "[TimeEnded] [datetime] NULL ,",
                        "[NumberLoaded] [int]  NULL ,",
                        "[NumberRead] [int]  NULL ,",
                        "[WriteFile] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] Imad = {
                        "CREATE TABLE [dbo].[Imad] (",
	                    "[Cycledate] [char] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
	                    "[Lterm] [char] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
	                    "[SeqNo] [int] NOT NULL ,",
	                    "[Amount] [money] NULL ,",
	                    "[Status] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
	                    "[Acked] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] IsnNumber = { 
                        "CREATE TABLE [dbo].[IsnNumber] (",
                        "[isnndx] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] LinkControl = { 
                        "CREATE TABLE [dbo].[LinkControl] (",                    
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[LineName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Description] [char] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[SndRcv] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Port] [int] NULL ,",
                        "[IntPort] [int] NULL ,",
                        "[NextSeqNo] [int] NULL ,",
                        "[OutSeqNo] [int] NULL ,",
                        "[LineStatus] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[TrnRef] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[NumberSel] [int] NOT NULL, ",
                        "[P1] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL, ",
                        "[TimeDelay] [int] NULL , ",
                        "[outputMQName] [varchar] (52) COLLATE SQL_Latin1_General_CP1_CI_AS NULL , ",
                        "[outputMQName1] [varchar] (52) COLLATE SQL_Latin1_General_CP1_CI_AS NULL , ",
                        "[inputMQName] [varchar] (52) COLLATE SQL_Latin1_General_CP1_CI_AS NULL , ",
                        "[MQMgrName] [varchar] (52) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[ConnChannel] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[Mode] [int] NULL, ",
                        "[GroupNo] [int] NULL,  ",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[RsnSeqNo] [int] NULL ,",
                        "[SwfTid] [char] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[Pin] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",

                        ") ON [PRIMARY]"};

        string[] LinkGroup = { 
                        "CREATE TABLE [dbo].[LinkGroup] (",
                        "[GroupName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL , ",
                        "[GroupNo] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] LoaderControl = { 
                        "CREATE TABLE [dbo].[LoaderControl] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[LoaderPid] [int] NULL ,",
                        "[ProcessState] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FileName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FilePath] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[LastTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL  ,",
                        "[TimelyDlv] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL  ,",
                        "[nLoad] [int] NULL ,",
                        "[FileValueDate] [datetime] NULL ,",
                        "[NewValueDate] [datetime] NULL ,",
                        "[AmtDelta] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL  ,",
                        "[nLoadAlgorithm] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[AssignTime] [datetime] NOT NULL ,",
                        "[LoadTime] [datetime] NULL ,",
                        "[NumberLoaded] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] LineNames = { 
                        "CREATE TABLE [dbo].[LineNames] (",
                        "[LineNameKey] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Source] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[MtsSourceCode] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[SplitFileName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[DefaultLine] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[CrLf] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] LocalKeyName = { 
                        "CREATE TABLE [dbo].[LocalKeyName] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[TabName] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[TabDesc] [char] (132) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL, ",
                        "[UpdTime] [datetime] NULL ",
                        ") ON [PRIMARY]"};

        string[] LocalKeys = { 
                        "CREATE TABLE [dbo].[LocalKeys] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[TabNameInd] [int] NOT NULL ,",
                        "[IdiKey] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[CmpKey] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[XmlSet] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[CompExpression] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS  ,",
                        "[Include] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};


        string[] LNK = {
                        "CREATE TABLE [dbo].[{0}] (",
                        "[Qbl] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[Prio] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[MsgCount] [int] NULL ,",
                        "[QblText] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};


        string[] LTermControl = { 
                        "CREATE TABLE [dbo].[LTermControl] (",
                        "[LineNo] [int] NULL ,",
                        "[LTerm] [char] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Total] [money] NULL ",
                        ") ON [PRIMARY]"};

        string[] MQLineSrc = { 
                        "CREATE TABLE [dbo].[MQLineSrc] (",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ExternalSrc] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[LineName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[StrToSub] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[SaveFromStr] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[SaveToStr] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[AckType] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[FldToFetch] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[SrcDb] [char] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[TrgDb] [char] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[DbPrefix] [char] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] MsgutilNumber = { 

                        "CREATE TABLE [dbo].[MsgutilNumber] (",
                        "[msgutilndx] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] MTS_RCV_TEXT = { 
                        "CREATE TABLE [dbo].[MTS_RCV_TEXT] (",
                        "[TrnRef] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[RefString] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[Fmt] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[Text] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] MTS_REF_IDS = { 
                        "CREATE TABLE [dbo].[MTS_REF_IDS] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[RefId] [int] NULL, ",
                        "[RefLen] [int] NULL, ",
                        "[RefTab] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[RefPos] [int] NULL, ",
                        "[RefSeq] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] NakRulesTables = { 
                        "CREATE TABLE [dbo].[NakRulesTables] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RuleName] [char] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] NakSources = { 
                        "CREATE TABLE [dbo].[NakSources] (",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] OsnNumber = { 
                        "CREATE TABLE [dbo].[OsnNumber] (",
                        "[osnndx] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] OprSources = { 
                        "CREATE TABLE [dbo].[OprSources] (",
                        "[Opr] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL , ",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        string[] ProcessGroup = { 
                        "CREATE TABLE [dbo].[ProcessGroup] (",
                        "[GroupName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL , ",
                        "[GroupNo] [int] NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] PsnQueue = { 
                        "CREATE TABLE [dbo].[PsnQueue] (",
                        "[PSN] [int] NULL ,",
                        "[SSN] [int] NULL ,",
                        "[ISN] [int] NULL ,",
                        "[RSN] [int] NULL ,",
                        "[Amt] [money] NULL ,",
                        "[Resolved] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RslvTime] [datetime] NULL ,",
                        "[Txt] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] QblidTable = { 
                        "CREATE TABLE [dbo].[QblidTable] (",
                        "[Qblid] [int] NOT NULL ,",
                        "[CreateTime] [datetime] NOT NULL ,",
                        "[OrigTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[LineName] [char] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[NewTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FileName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[FilePath] [char] (62) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
                        ") ON [PRIMARY]"};

        string[] RCV = {
                        "CREATE TABLE [dbo].[{0}] (",
                        "[Qbl] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[QblText] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] RcvLog = { 
                        "CREATE TABLE [dbo].[Rcvlog] (",
                        "[IntraNetTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ReceiveTime] [datetime] NULL ,",
                        "[DeptCode] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[LineName] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[QblId] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] ReceiveControl = { 
                        "CREATE TABLE [dbo].[ReceiveControl] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[LineName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[StopAckQue] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[WritetoFile] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[FileName] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[AckRuleTableName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ReleaseAckQue] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[TimeDelay] [int] NULL, ",
                        "[nSelect] [int] NULL, ",
                        "[DoEdits] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[FmtName] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[MsgFormat] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[RefId] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] RprFeeder = {
                        "CREATE TABLE [dbo].[RprFeeder] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[NewTrnNumber] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[OldTrnNumber] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[Source] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ValueDate] [datetime] NULL ",
                        ") ON [PRIMARY]"};

        string[] RptFilter = { 
                        "CREATE TABLE [dbo].[RptFilter] (",
                        "[Pk] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[FilterName] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[SrcTable] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[SrcFld] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[SrcOpr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS  ,",
                        "[SrcValue] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS  ,",
                        "[Opr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS  ,",
                        "[TrgOpr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS  ,",
                        "[TrgValue] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS ",
                        ") ON [PRIMARY]"};
        string[] RsnNumber = { 
                        "CREATE TABLE [dbo].[RsnNumber] (",
                        "[rsnndx] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] ResolverQ = { 
                        "CREATE TABLE [dbo].[ResolverQ] (",
                        "[Qbl] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[PSN] [int] NULL ,",
                        "[ISN] [int] NULL ,",
                        "[SSN] [int] NULL ,",
                        "[Amt] [money] NULL ,",
                        "[Line] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Text] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] SimTableList = { 
                        "CREATE TABLE [dbo].[SimTableList] (",
                        "[TableName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[TableType] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[CreateTime] [datetime] NOT NULL ,",
                        "[Description] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] SimulatorControl = { 
                        "CREATE TABLE [dbo].[SimulatorControl] (",
                        "[OurHostAddress] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ApplicationName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Area] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[localRgwArea] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[receiverRgwArea] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[compareRgwArea] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[remoteRgwArea] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RgwRepository] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[defaultCompareTable] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[MTSHostName] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Debug] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RootDir] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[RemoteArea] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RemoteMTSHostName] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[JavaHost] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[JavaPort] [int] NULL ,",
                        "[ChpAba] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[FedAba] [char] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[SwfVersion] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[SimVersion] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Vendor] [char] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[ChangeRef] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[MtsSrvPort] [int] NULL, ",
                        "[MtsScriptDir] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[Client] [char] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};

        public string[] SimulatorEvents = { 
                        "CREATE TABLE [dbo].[SimulatorEvents] (",
                        "[EventTime] [datetime] NULL ,",
                        "[severity] [int] NULL ,",
                        "[Who] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Event] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY]"};


        string[] SimulatorProcesses = {    
                        "CREATE TABLE [dbo].[SimulatorProcesses] (",
                        "[ModName] [char] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[ModPath] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ModArgs] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[MultiAllowed] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[StartUp] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ProcName] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[GroupNo] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] SplitterControl = { 
                        "CREATE TABLE [dbo].[SplitterControl] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[SplitterPid] [int] NULL ,",
                        "[ProcessState] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[InputFileName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[InputFilePath] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[OutputFileName] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[OutputFilePath] [char] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[FileType] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[DefaultBank] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[DefaultLine] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[TimeStarted] [datetime] NULL ,",
                        "[TimeEnded] [datetime] NULL ,",
                        "[NumberLoaded] [int] NULL ,",
                        "[NumberRead] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] SsnNumber = { 
                        "CREATE TABLE [dbo].[SsnNumber] (",
                        "[ssnndx] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] SwfReceiveAckQue = { 
                        "CREATE TABLE [dbo].[SwfReceiveAckQue] (",
                        "[Qbl] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[LineName] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[RefNum_str] [char] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[AckTxt] [char] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Nak] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[ErrorCode] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[LineNumber] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[Msg_body] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
                        ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"};

        string[] SwfStats = { 
                        "CREATE TABLE [dbo].[SwfStats] (",
                        "[SessionNo] [char] (19) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
                        "[StartTime] [datetime] NULL ,",
                        "[EndTime] [datetime] NULL ,",
                        "[NoSent] [int] NULL ,",
                        "[NoReceived] [int] NULL ",
                        ") ON [PRIMARY]"};

        string[] TrnNumber = { 
                        "CREATE TABLE [dbo].[TrnNumber] (",
                        "[trnndx] [int] NULL ",
                        ") ON [PRIMARY]"};


        string[] VideoConfig = { 
                        "CREATE TABLE [dbo].[VideoConfig] (",
                        "[UniqueKey] [int] IDENTITY (1, 1) NOT NULL ,",
                        "[Mode] [char] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[TimeOut] [int] NULL ,",
                        "[TimeOutCallSel] [int] NULL ,",
                        "[TimeOutScroll] [int] NULL ,",
                        "[MakeTrace] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[AutoReplay] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[VideoPort] [int] NULL ,",
                        "[IntPort] [int] NULL ,",
                        "[DisplFlow] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, ",
                        "[ValDate] [datetime] NULL ",
                        ") ON [PRIMARY]"};

        string[] VideoStats = { 
                        "CREATE TABLE [dbo].[VideoStats] (",
                        "[Mode] [char] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[OrigTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[NewTrn] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
                        "[TrnTime] [datetime] NULL  ",
                        ") ON [PRIMARY]"};



        public string getCreateString(string tName)
        {
            switch (tName)
            {
                case "ApplicationBanks":
                    return buildCreateString(ApplicationBanks);

                case "AreaAdvTypes":
                    return buildCreateString(AreaAdvTypes);

                case "AreaBanks":
                    return buildCreateString(AreaBanks);

                case "AreaSources":
                    return buildCreateString(AreaSources);

                case "AreaTranTypes":
                    return buildCreateString(AreaTranTypes);

                case "Areas":
                    return buildCreateString(Areas);

                case "MasterControl":
                    return buildCreateString(MasterControl);

                case "SplitterFileTypes":
                    return buildCreateString(SplitterFileTypes);

                case "ActionQue":
                    return buildCreateString(ActionQue);

                case "Ack31q":
                    return buildCreateString(Ack31q);

                case "ActiveProcesses":
                    return buildCreateString(ActiveProcesses);

                case "ByLogsLoaderControl":
                    return buildCreateString(ByLogsLoaderControl);

                case "BatchQ":
                    return buildCreateString(BatchQ);

                case "BatchDescr":
                    return buildCreateString(BatchDescr);

                case "AckNakRules":
                    return buildCreateString(AckNakRules);

                case "ChpCustomEdit":
                    return buildCreateString(ChpCustomEdit);

                case "ChpFieldEdit":
                    return buildCreateString(ChpFieldEdit);

                case "ChpLineList":
                    return buildCreateString(ChpLineList);

                case "ChipsControl":
                    return buildCreateString(ChipsControl);

                case "ChpReceiveAckQue":
                    return buildCreateString(ChpReceiveAckQue);

                case "ChpRcvAmt":
                    return buildCreateString(ChpRcvAmt);

                case "ChpRlsAmt":
                    return buildCreateString(ChpRlsAmt);

                case "ChpStats":
                    return buildCreateString(ChpStats);

                case "ChpTags":
                    return buildCreateString(ChpTags);

                case "Compare":
                    return buildCreateString(Compare);

                case "CompareControl":
                    return buildCreateString(CompareControl);

                case "CompareHistory":
                    return buildCreateString(CompareHistory);

                case "CompareKeys":
                    return buildCreateString(CompareKeys);

                case "CompareResults":
                    return buildCreateString(CompareResults);

                case "CompareMetaSummary":
                    return buildCreateString(CompareMetaSummary);

                case "CompareSummary":
                    return buildCreateString(CompareSummary);

                case "CommandCentral":
                    return buildCreateString(CommandCentral);

                case "CompQ":
                    return buildCreateString(CompQ);

                case "DiffResults":
                    return buildCreateString(DiffResults);

                case "DiffSummary":
                    return buildCreateString(DiffSummary);

                case "EntRprFeeder":
                    return buildCreateString(EntRprFeeder);

                case "EntrySources":
                    return buildCreateString(EntrySources);

                case "ErrorCodes":
                    return buildCreateString(ErrorCodes);

                case "ExcelQ":
                    return buildCreateString(ExcelQ);

                case "FDR":
                    return buildCreateString(FDR);

                case "FedCustomEdit":
                    return buildCreateString(FedCustomEdit);

                case "FedFieldEdit":
                    return buildCreateString(FedFieldEdit);

                case "FedControl":
                    return buildCreateString(FedControl);

                case "FedReceiveAckQue":
                    return buildCreateString(FedReceiveAckQue);

                case "FeederControl":
                    return buildCreateString(FeederControl);

                case "FileCompControl":
                    return buildCreateString(FileCompControl);

                case "Imad":
                    return buildCreateString(Imad);

                case "IsnNumber":
                    return buildCreateString(IsnNumber);

                case "LinkControl":
                    return buildCreateString(LinkControl);

                case "LinkGroup":
                    return buildCreateString(LinkGroup);

                case "LoaderControl":
                    return buildCreateString(LoaderControl);

                case "LocalKeyName":
                    return buildCreateString(LocalKeyName);

                case "LocalKeys":
                    return buildCreateString(LocalKeys);

                case "LineNames":
                    return buildCreateString(LineNames);

                case "LNK":
                    return buildCreateString(LNK);

                case "LTermControl":
                    return buildCreateString(LTermControl);

                case "MQLineSrc":
                    return buildCreateString(MQLineSrc);

                case "MsgutilNumber":
                    return buildCreateString(MsgutilNumber);

                case "MTS_REF_IDS":
                    return buildCreateString(MTS_REF_IDS);

                case "MTS_RCV_TEXT":
                    return buildCreateString(MTS_RCV_TEXT);

                case "NakRulesTables":
                    return buildCreateString(NakRulesTables);

                case "NakSources":
                    return buildCreateString(NakSources);

                case "OprSources":
                    return buildCreateString(OprSources);

                case "OsnNumber":
                    return buildCreateString(OsnNumber);

                case "ProcessGroup":
                    return buildCreateString(ProcessGroup);

                case "PsnQueue":
                    return buildCreateString(PsnQueue);

                case "QblidTable":
                    return buildCreateString(QblidTable);

                case "RCV":
                    return buildCreateString(RCV);

                case "RcvLog":
                    return buildCreateString(RcvLog);

                case "ReceiveControl":
                    return buildCreateString(ReceiveControl);

                case "RprFeeder":
                    return buildCreateString(RprFeeder);

                case "RptFilter":
                    return buildCreateString(RptFilter);

                case "RsnNumber":
                    return buildCreateString(RsnNumber);

                case "ResolverQ":
                    return buildCreateString(ResolverQ);

                case "SimTableList":
                    return buildCreateString(SimTableList);

                case "SimulatorControl":
                    return buildCreateString(SimulatorControl);

                case "SimulatorEvents":
                    return buildCreateString(SimulatorEvents);

                case "SimulatorProcesses":
                    return buildCreateString(SimulatorProcesses);

                case "SplitterControl":
                    return buildCreateString(SplitterControl);

                case "SsnNumber":
                    return buildCreateString(SsnNumber);

                case "SwfReceiveAckQue":
                    return buildCreateString(SwfReceiveAckQue);

                case "SwfStats":
                    return buildCreateString(SwfStats);

                case "TrnNumber":
                    return buildCreateString(TrnNumber);

                case "VideoConfig":
                    return buildCreateString(VideoConfig);

                case "VideoStats":
                    return buildCreateString(VideoStats);

            }
            return "";
        }

        public string buildCreateString(string[] tName)
        {
            string s = string.Empty;
            for (int i = 0; i < tName.Length; i++)
            {
                s += tName[i];
            }
            return s;
        }



        public ArrayList getFieldNames(string tName)
        {
            switch (tName)
            {

                case "ApplicationBanks":
                    return buildFieldNameArray(ApplicationBanks);

                case "AreaAdvTypes":
                    return buildFieldNameArray(AreaAdvTypes);

                case "AreaBanks":
                    return buildFieldNameArray(AreaBanks);

                case "AreaSources":
                    return buildFieldNameArray(AreaSources);

                case "AreaTranTypes":
                    return buildFieldNameArray(AreaTranTypes);

                case "Areas":
                    return buildFieldNameArray(Areas);

                case "MasterControl":
                    return buildFieldNameArray(MasterControl);

                case "SplitterFileTypes":
                    return buildFieldNameArray(SplitterFileTypes);

                case "ActionQue":
                    return buildFieldNameArray(ActionQue);

                case "Ack31q":
                    return buildFieldNameArray(Ack31q);

                case "ActiveProcesses":
                    return buildFieldNameArray(ActiveProcesses);

                case "ByLogsLoaderControl":
                    return buildFieldNameArray(ByLogsLoaderControl);

                case "BatchQ":
                    return buildFieldNameArray(BatchQ);

                case "BatchDescr":
                    return buildFieldNameArray(BatchDescr);

                case "AckNakRules":
                    return buildFieldNameArray(AckNakRules);

                case "ChpCustomEdit":
                    return buildFieldNameArray(ChpCustomEdit);

                case "ChpFieldEdit":
                    return buildFieldNameArray(ChpFieldEdit);

                case "ChpLineList":
                    return buildFieldNameArray(ChpLineList);

                case "ChipsControl":
                    return buildFieldNameArray(ChipsControl);

                case "ChpReceiveAckQue":
                    return buildFieldNameArray(ChpReceiveAckQue);

                case "ChpRcvAmt":
                    return buildFieldNameArray(ChpRcvAmt);

                case "ChpRlsAmt":
                    return buildFieldNameArray(ChpRlsAmt);

                case "ChpStats":
                    return buildFieldNameArray(ChpStats);

                case "ChpTags":
                    return buildFieldNameArray(ChpTags);

                case "Compare":
                    return buildFieldNameArray(Compare);

                case "CompareControl":
                    return buildFieldNameArray(CompareControl);

                case "CompareHistory":
                    return buildFieldNameArray(CompareHistory);

                case "CompareKeys":
                    return buildFieldNameArray(CompareKeys);

                case "CompareResults":
                    return buildFieldNameArray(CompareResults);

                case "CompareMetaSummary":
                    return buildFieldNameArray(CompareMetaSummary);

                case "CompareSummary":
                    return buildFieldNameArray(CompareSummary);

                case "CommandCentral":
                    return buildFieldNameArray(CommandCentral);

                case "CompQ":
                    return buildFieldNameArray(CompQ);

                case "DiffResults":
                    return buildFieldNameArray(DiffResults);

                case "DiffSummary":
                    return buildFieldNameArray(DiffSummary);

                case "EntRprFeeder":
                    return buildFieldNameArray(EntRprFeeder);

                case "EntrySources":
                    return buildFieldNameArray(EntrySources);

                case "ErrorCodes":
                    return buildFieldNameArray(ErrorCodes);

                case "ExcelQ":
                    return buildFieldNameArray(ExcelQ);

                case "FDR":
                    return buildFieldNameArray(FDR);

                case "FedCustomEdit":
                    return buildFieldNameArray(FedCustomEdit);

                case "FedFieldEdit":
                    return buildFieldNameArray(FedFieldEdit);

                case "FedControl":
                    return buildFieldNameArray(FedControl);

                case "FedReceiveAckQue":
                    return buildFieldNameArray(FedReceiveAckQue);

                case "FeederControl":
                    return buildFieldNameArray(FeederControl);

                case "FileCompControl":
                    return buildFieldNameArray(FileCompControl);

                case "Imad":
                    return buildFieldNameArray(Imad);

                case "IsnNumber":
                    return buildFieldNameArray(IsnNumber);

                case "LinkControl":
                    return buildFieldNameArray(LinkControl);

                case "LinkGroup":
                    return buildFieldNameArray(LinkGroup);

                case "LoaderControl":
                    return buildFieldNameArray(LoaderControl);

                case "LineNames":
                    return buildFieldNameArray(LineNames);

                case "LNK":
                    return buildFieldNameArray(LNK);

                case "LocalKeyName":
                    return buildFieldNameArray(LocalKeyName);

                case "LocalKeys":
                    return buildFieldNameArray(LocalKeys);

                case "LTermControl":
                    return buildFieldNameArray(LTermControl);

                case "MQLineSrc":
                    return buildFieldNameArray(MQLineSrc);

                case "MsgutilNumber":
                    return buildFieldNameArray(MsgutilNumber);

                case "Mts_Rcv_Text":
                    return buildFieldNameArray(MTS_RCV_TEXT);

                case "Mts_Ref_Ids":
                    return buildFieldNameArray(MTS_REF_IDS);

                case "NakRulesTables":
                    return buildFieldNameArray(NakRulesTables);

                case "NakSources":
                    return buildFieldNameArray(NakSources);

                case "OprSources":
                    return buildFieldNameArray(OprSources);

                case "OsnNumber":
                    return buildFieldNameArray(OsnNumber);

                case "ProcessGroup":
                    return buildFieldNameArray(ProcessGroup);

                case "PsnQueue":
                    return buildFieldNameArray(PsnQueue);

                case "QblidTable":
                    return buildFieldNameArray(QblidTable);

                case "RCV":
                    return buildFieldNameArray(RCV);

                case "RcvLog":
                    return buildFieldNameArray(RcvLog);

                case "ReceiveControl":
                    return buildFieldNameArray(ReceiveControl);

                case "ResolverQ":
                    return buildFieldNameArray(ResolverQ);

                case "RprFeeder":
                    return buildFieldNameArray(RprFeeder);

                case "RptFilter":
                    return buildFieldNameArray(RptFilter);

                case "RsnNumber":
                    return buildFieldNameArray(RsnNumber);

                case "SimTableList":
                    return buildFieldNameArray(SimTableList);

                case "SimulatorControl":
                    return buildFieldNameArray(SimulatorControl);

                case "SimulatorEvents":
                    return buildFieldNameArray(SimulatorEvents);

                case "SimulatorProcesses":
                    return buildFieldNameArray(SimulatorProcesses);

                case "SplitterControl":
                    return buildFieldNameArray(SplitterControl);

                case "SsnNumber":
                    return buildFieldNameArray(SsnNumber);

                case "SwfReceiveAckQue":
                    return buildFieldNameArray(SwfReceiveAckQue);

                case "SwfStats":
                    return buildFieldNameArray(SwfStats);

                case "TrnNumber":
                    return buildFieldNameArray(TrnNumber);

                case "VideoConfig":
                    return buildFieldNameArray(VideoConfig);

                case "VideoStats":
                    return buildFieldNameArray(VideoStats);
            }
            ArrayList fArray = new ArrayList(); ;

            return fArray;
        }

        private ArrayList buildFieldNameArray(string[] tName)
        {
            /*
             * Return the names of all the fields, but skip any 'identity'
             * columns. We never insert values into identity columns...
             */
            ArrayList fArray = new ArrayList();

            for (int i = 0; i < tName.Length; i++)
            {
                string s = tName[i];

                // Skip over any 'identity' fields.
                string s1 = s.ToLower();
                if (s1.IndexOf("identity") != -1)
                    continue;

                if (s.StartsWith("["))
                {
                    string fName = s.Substring(1, s.IndexOf("]") - 1);
                    fArray.Add(fName);
                }
            }

            return fArray;
        }


        private ArrayList buildFullFieldNameArray(string[] tName)
        {
            /*
             * Return *all* the field names. We'll return 'identity' column
             * row names, too.
             */
            ArrayList fArray = new ArrayList();

            for (int i = 0; i < tName.Length; i++)
            {
                string s = tName[i];
                if (s.StartsWith("["))
                {
                    string fName = s.Substring(1, s.IndexOf("]") - 1);
                    fArray.Add(fName);
                }
            }

            return fArray;
        }

        public string[] getTableDefinitionStrings(string tName)
        {
            tName = tName.ToLower();
            string[] fList = { "" };

            switch (tName)
            {
                case "applicationbanks":
                    fList = ApplicationBanks;
                    break;
                case "areaadvtypes":
                    fList = AreaAdvTypes;
                    break;
                case "areabanks":
                    fList = AreaBanks;
                    break;
                case "areasources":
                    fList = AreaSources;
                    break;
                case "areatrantypes":
                    fList = AreaTranTypes;
                    break;
                case "areas":
                    fList = Areas;
                    break;
                case "mastercontrol":
                    fList = MasterControl;
                    break;
                case "splitterfiletypes":
                    fList = SplitterFileTypes;
                    break;
                case "ack31q":
                    fList = Ack31q;
                    break;
                case "actionque":
                    fList = ActionQue;
                    break;
                case "activeprocesses":
                    fList = ActiveProcesses;
                    break;
                case "batchq":
                    fList = BatchQ;
                    break;
                case "batchdescr":
                    fList = BatchDescr;
                    break;
                case "bylogscontrol":
                    fList = ByLogsControl;
                    break;
                case "bylogsloadercontrol":
                    fList = ByLogsLoaderControl;
                    break;
                case "acknakrules":
                    fList = AckNakRules;
                    break;
                case "chpcustomedit":
                    fList = ChpCustomEdit;
                    break;
                case "chpfieldedit":
                    fList = ChpFieldEdit;
                    break;
                case "chplinelist":
                    fList = ChpLineList;
                    break;
                case "chipscontrol":
                    fList = ChipsControl;
                    break;
                case "chpreceiveackque":
                    fList = ChpReceiveAckQue;
                    break;
                case "chprcvamt":
                    fList = ChpRcvAmt;
                    break;
                case "chprlsamt":
                    fList = ChpRlsAmt;
                    break;
                case "chpstats":
                    fList = ChpStats;
                    break;
                case "chptags":
                    fList = ChpTags;
                    break;
                case "compare":
                    fList = Compare;
                    break;
                case "comparecontrol":
                    fList = CompareControl;
                    break;
                case "comparehistory":
                    fList = CompareHistory;
                    break;
                case "comparekeys":
                    fList = CompareKeys;
                    break;
                case "compareresults":
                    fList = CompareResults;
                    break;
                case "comparemetasummary":
                    fList = CompareMetaSummary;
                    break;
                case "comparesummary":
                    fList = CompareSummary;
                    break;
                case "commandcentral":
                    fList = CommandCentral;
                    break;
                case "compq":
                    fList = CompQ;
                    break;
                case "diffresults":
                    fList = DiffResults;
                    break;
                case "diffsummary":
                    fList = DiffSummary;
                    break;
                case "entrprfeeder":
                    fList = EntRprFeeder;
                    break;
                case "entrysources":
                    fList = EntrySources;
                    break;
                case "errorcodes":
                    fList = ErrorCodes;
                    break;
                case "excelq":
                    fList = ExcelQ;
                    break;
                case "fdr":
                    fList = FDR;
                    break;
                case "fedcustomedit":
                    fList = FedCustomEdit;
                    break;
                case "fedfieldedit":
                    fList = FedFieldEdit;
                    break;
                case "fedcontrol":
                    fList = FedControl;
                    break;
                case "fedreceiveackque":
                    fList = FedReceiveAckQue;
                    break;
                case "feedercontrol":
                    fList = FeederControl;
                    break;
                case "filecompcontrol":
                    fList = FileCompControl;
                    break;
                case "imad":
                    fList = Imad;
                    break;
                case "isnnumber":
                    fList = IsnNumber;
                    break;
                case "linkcontrol":
                    fList = LinkControl;
                    break;
                case "linkgroup":
                    fList = LinkGroup;
                    break;
                case "loadercontrol":
                    fList = LoaderControl;
                    break;
                case "localkeyname":
                    fList = LocalKeyName;
                    break;
                case "localkeys":
                    fList = LocalKeys;
                    break;
                case "linenames":
                    fList = LineNames;
                    break;
                case "lnk":
                    fList = LNK;
                    break;
                case "ltermcontrol":
                    fList = LTermControl;
                    break;
                case "mqlinesrc":
                    fList = MQLineSrc;
                    break;
                case "msgutilnumber":
                    fList = MsgutilNumber;
                    break;
                case "mts_rcv_text":
                    fList = MTS_RCV_TEXT;
                    break;
                case "mts_ref_ids":
                    fList = MTS_REF_IDS;
                    break;
                case "nakrulestables":
                    fList = NakRulesTables;
                    break;
                case "naksources":
                    fList = NakSources;
                    break;
                case "oprsources":
                    fList = OprSources;
                    break;
                case "osnnumber":
                    fList = OsnNumber;
                    break;
                case "processgroup":
                    fList = ProcessGroup;
                    break;
                case "psnqueue":
                    fList = PsnQueue;
                    break;
                case "qblidtable":
                    fList = QblidTable;
                    break;
                case "rcv":
                    fList = RCV;
                    break;
                case "rcvlog":
                    fList = RcvLog;
                    break;
                case "receivecontrol":
                    fList = ReceiveControl;
                    break;
                case "resolverq":
                    fList = ResolverQ;
                    break;
                case "rprfeeder":
                    fList = RprFeeder;
                    break;
                case "rptfilter":
                    fList = RptFilter;
                    break;
                case "rsnnumber":
                    fList = RsnNumber;
                    break;
                case "simtablelist":
                    fList = SimTableList;
                    break;
                case "simulatorcontrol":
                    fList = SimulatorControl;
                    break;
                case "simulatorevents":
                    fList = SimulatorEvents;
                    break;
                case "simulatorprocesses":
                    fList = SimulatorProcesses;
                    break;
                case "splittercontrol":
                    fList = SplitterControl;
                    break;
                case "ssnnumber":
                    fList = SsnNumber;
                    break;
                case "swfreceiveackque":
                    fList = SwfReceiveAckQue;
                    break;
                case "swfstats":
                    fList = SwfStats;
                    break;
                case "trnnumber":
                    fList = TrnNumber;
                    break;
                case "videoconfig":
                    fList = VideoConfig;
                    break;
                case "videostats":
                    fList = VideoStats;
                    break;
            }
            return fList;
        }


        public Hashtable buildFieldHashtable(string tName)
        {
            /*
             * We want to build a hashtable of all the fields and some
             * reasonable default values for the fields.
             */

            string[] fList = getTableDefinitionStrings(tName);

            Hashtable hashish = new Hashtable();

            for (int idx = 0; idx < fList.Length; idx++)
            {
                string s = fList[idx];

                // Skip over any 'identity' fields.
                string s1 = s.ToLower();
                if (s1.IndexOf("identity") != -1)
                    continue;

                if (s.StartsWith("["))
                {
                    string fName = s.Substring(1, s.IndexOf("]") - 1);
                    int i = s.IndexOf("[", s.IndexOf("]")) + 1;
                    int j = s.IndexOf("]", i) - i;
                    string fType = s.Substring(i, j);
                    fType = fType.ToLower();
                    switch (fType)
                    {
                        case "char":
                        case "varchar":
                        case "text":
                            hashish.Add(fName, "");
                            break;

                        case "datetime":
                            hashish.Add(fName, DateTime.Now.ToShortDateString());
                            break;

                        case "int":
                        case "money":
                        case "bigint":
                        case "smallint":
                            hashish.Add(fName, "0");
                            break;
                    }
                }
            }

            return hashish;
        }

        public string buildInsertClause(string tName)
        {
            return buildInsertClause(tName, tName);
        }

        public string buildInsertClause(string tType, string tName)
        {
            //
            // We want to build the 'values' clause used to insert into our
            // table of interest.

            StringBuilder valuesClause = new StringBuilder();
            valuesClause.Append(string.Format("insert into {0} (", tName));

            string[] fList = getTableDefinitionStrings(tType);

            int n = 0;
            for (int idx = 0; idx < fList.Length; idx++)
            {
                string s = fList[idx];

                // Skip over any 'identity' fields.
                string s1 = s.ToLower();
                if (s1.IndexOf("identity") != -1)
                    continue;

                if (s.StartsWith("["))
                {
                    n++;
                    string fName = s.Substring(1, s.IndexOf("]") - 1);
                    if (n > 1)
                        valuesClause.Append("," + fName);
                    else
                        valuesClause.Append(fName);
                }
            }
            valuesClause.Append(") values ");
            return valuesClause.ToString(); ;
        }

        public string buildFormatStatement(string tName)
        {
            StringBuilder fmtStatement = new StringBuilder();
            fmtStatement.Append("(");

            string[] fList = getTableDefinitionStrings(tName);

            int n = 0;
            for (int idx = 0; idx < fList.Length; idx++)
            {
                string s = fList[idx];

                // Skip over any 'identity' fields.
                string s1 = s.ToLower();
                if (s1.IndexOf("identity") != -1)
                    continue;

                if (s.StartsWith("["))
                {
                    if (n > 0)
                        fmtStatement.Append(",");
                    string fName = s.Substring(1, s.IndexOf("]") - 1);
                    int i = s.IndexOf("[", s.IndexOf("]")) + 1;
                    int j = s.IndexOf("]", i) - i;
                    string fType = s.Substring(i, j);
                    fType = fType.ToLower();
                    switch (fType)
                    {
                        case "char":
                        case "varchar":
                        case "text":
                        case "datetime":
                            fmtStatement.Append("'{" + n + "}'");
                            break;

                        case "int":
                        case "money":
                        case "bigint":
                        case "smallint":
                            fmtStatement.Append("{" + n + "}");
                            break;
                    }
                    n++;
                }
            }
            fmtStatement.Append(") ");
            return fmtStatement.ToString(); ;
        }


        public string buildInsertFormatStatement(string tableType, string tName)
        {
            // Let's make this generalized so that we can fix the actual
            // table name right here. This applies to tables like the LNK ones
            // where we end up with a number of different tables of the same type.
            // the insert clause will have a '{0}' spot where the actual table
            // name goes.

            string s = buildInsertClause(tableType, tName);
            s = s.Replace("{0}", tName);
            return s + buildFormatStatement(tableType);
        }
    }


    public class rgwDef_v1
    {
        /*
         * This class defines all these Message Data Repository (aka rgw) tables
         * as we know and love them today, 7-Feb-2007. Trust me, there'll be changes.
         * 
         */

        string dropMESSAGE = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE]";

        string dropMESSAGE_ACCTG = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_ACCTG]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_ACCTG]";


        string dropMESSAGE_CR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_CR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_CR]";


        string dropMESSAGE_DEST = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_DEST]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_DEST]";


        string dropMESSAGE_DR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_DR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_DR]";


        string dropMESSAGE_HIST = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_HIST]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_HIST]";


        string dropMESSAGE_PR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR]";


        string dropMESSAGE_PR_MCH = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_MCH]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_MCH]";


        string dropMESSAGE_PR_PRM = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_PRM]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_PRM]";


        string dropMESSAGE_PR_PVL = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_PVL]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_PVL]";


        string dropMESSAGE_QUEUE = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_QUEUE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_QUEUE]";


        string dropMESSAGE_REL_AMT = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_REL_AMT]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_REL_AMT]";


        string dropMESSAGE_TEXT = "if exists (select * from dbo.sysobjects where id = " +
                "object_id(N'[dbo].[MESSAGE_TEXT]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
                "drop table [dbo].[MESSAGE_TEXT]";


        // Version 1 - from what, MTS 1.2 or 2.0? Prior to MTS 3.0.
        string[] MESSAGE = {
        "CREATE TABLE [dbo].[MESSAGE] (",
        "[TRN_DATE] [datetime] NOT NULL ,",
        "[TRN_NUMBER] [int] NOT NULL ,",
        "[TRN_TIMESTAMP] [numeric](23, 0) NOT NULL ,",
        "[PROC_DATE] [datetime] NULL ,",
        "[BANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LOC] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAY_DATE] [datetime] NULL ,",
        "[PAY_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INST_DATE] [datetime] NULL ,",
        "[TRAN_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPETITIVE_ID] [varchar] (48) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SOURCE_CD] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INSTR_ADV_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BASE_AMOUNT] [numeric](21, 3) NULL ,",
        "[TYPE_CD] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SUBTYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IN_TYPE_CD] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IN_SUBTYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CHRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CHRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMMISSION] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_CHARGE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[WIRE_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STRAIGHT_THRU] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NETWORK_SND_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NETWORK_SND_ACC] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_ACC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CAN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_RISK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_AUTO] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_OVER] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CSTMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_DSTMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_LIM] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_RPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_NON_RPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALLBACK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FAIL_TST] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTV_LIM] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTV_CHNG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_NOF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MON_INTERCEPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCV_DATE] [datetime] NULL ,",
        "[RCV_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DLV_DATE] [datetime] NULL ,",
        "[DLV_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALLER] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DOC_NUM] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ITEM_NUM] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAN_MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAN_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAL] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_RATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FX_TOLERANCE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_RATE] [numeric](29, 11) NULL ,",
        "[AMOUNT] [numeric](21, 3) NULL ,",
        "[CURRENCY_CODE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADER_CTRL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDS_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_IMAD] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_OMAD] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_SSN_1] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_SSN_6] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_IN_MIR] [varchar] (28) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_OUT_MIR] [varchar] (28) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ENTRY_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VERIFY_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPAIR_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCEPT_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TOT_AMT] [numeric](21, 3) NULL ,",
        "[CUSIP] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUSIP_DESC] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHECK_SEQ] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NO_PHNADV_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXC_MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAY_STATE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NOTIFY] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STOP_INTERCEPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELEASE_TIME_HH] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELEASE_TIME_MM] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRE_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FX_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COR_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RTE_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_LAST_NAME] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_FIRST_NAME] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OVER_DRAFT_AMT] [numeric](21, 3) NULL ,",
        "[DBT_CON_BANK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CON_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CON_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_BANK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SYS_OF_REC] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SYS_OF_REC] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PARENT_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PARENT_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RECEIPT_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FRONTEND_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_DADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AVAIL_BAL] [numeric](21, 3) NULL ,",
        "[LEDGER_BAL] [numeric](21, 3) NULL ,",
        "[OVER_TIMESTAMP] [datetime] NULL ,",
        "[RECORD_EXPIRED] [numeric](23, 0) NULL ,",
        "[RECORD_UPDATED] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRADE_STATE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NEW_TRADE_STATE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_OPERATION] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OPERATION_SCOPE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_CUSTOMER] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PARTY_B] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND5] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND6] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_METHOD] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_BRANCH_PTYA] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_BRANCH_PTYB] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_ID] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_COMISN] [numeric](21, 3) NULL ,",
        "[COUNTERPARTY_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORIG_MSG_DATE] [datetime] NULL ,",
        "[TRADE_PARTY_SUSP_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OTHER_PARTY_SUSP_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LAST_USED_DATE] [datetime] NULL ,",
        "[ORIG_INST_VAL_DATE] [datetime] NULL ,",
        "[TRADE_TYPE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_SUBTYPE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_BUY_SELL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_UPDATE_PENDING_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORIG_EXCH_RATE] [numeric](29, 11) NULL ,",
        "[RECEIVE_CHAR_COUNT] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INCOMING_FORMAT] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INCOMING_REF] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDS_CATEGORY] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SEGMENT_INDEX] [numeric](11, 0) NULL ,",
        "[SPLIT_CTR] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPR_LEVEL] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[POST_DATE] [datetime] NULL ,",
        "[POST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SEND_DATE] [datetime] NULL ,",
        "[FEDFUND_TYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_DAYS] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INTEREST_RATE] [numeric](7, 5) NULL ,",
        "[ANT_TOL_AMT] [numeric](21, 3) NULL ,",
        "[CAL_OVR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_REF_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFC_PIN_REF_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PHN_NOF_ID] [varchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TESTKEY_IN] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_TEXT] [varchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RISKINESS_IND] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMM_MODE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_MODE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADM_LOCK_TEXT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNK_TX_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULT_DBT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULT_CDT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AMT_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUR_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SERIAL_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PDM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADV_OVR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_REQ_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SITE_OPTION1_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ACCT_VFC_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULTI_CUR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIORITY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DELIVERY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RTP_INTERCEPT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DELAY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCHED_ANT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPAIR_CHNG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHIPS_RECVRY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NON_ACCTING_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_STMT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHARGE_STATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFY_COUNT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_DBT_AUTH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_DBT_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_CDT_AUTH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_CDT_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_STATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFC_COUNT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDED_MSG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PMT_CHRG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INT_REROUTE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUR_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OVR_OUT_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FORCE_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTD_SWF_STMT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHECK_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_DBT_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_CDT_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_BNP_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_SRN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_SIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[UMBRELLA_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BANK_OPERATION_CODE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ACC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BIC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_DBT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_SBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_OBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ORP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_INS] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CDT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_IB1] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_IBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BNP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BBI] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_OBI] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_DTE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_AMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CNF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_REG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_PRD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PMT_CHAR_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUTOFF_OVERRIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCHANGE_RATE_STAT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FOREX_BYPASS_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[GLOBAL_DEBIT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_PTY_SIDE_IND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FORCE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEFINITIVE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CANCELLED_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FIN_CPY_SRC_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SUPPR_PMT_CONF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ENTERED_SIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE] [datetime] NULL ,",
        "[DUE_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE] [datetime] NULL ,",
        "[PRIME_SEND_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE] [datetime] NULL ,",
        "[SECOND_SEND_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REG_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REG_ID] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AUTH_REF] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MSG_STATE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELATED_TRN_DATE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELATED_TRN_NUM] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_POST_DATE] [datetime] NULL ,",
        "[CDT_POST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OPERTNL_RLS_DATE] [datetime] NULL ,",
        "[OPERTNL_RLS_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RAMET_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NON_RET_VALVE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUTOFF_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FOREX_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FEE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EUR_BENE_CHRG_ALLOW] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[HIGH_MSG_STATE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMM_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FTR_PROC_RULE_STATE] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_ACCTG = {
        "CREATE TABLE [dbo].[MESSAGE_ACCTG] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Acctg_IDType] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Acctg_Account] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Amount] [numeric](21, 3) NOT NULL ,",
        "[STS_DBT_CDT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[STS_CROSS_BANK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[STS_PRIMARY] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Period] [datetime] NULL ,",
        "[Proc_Date] [datetime] NULL ,",
        "[Bank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Value_date] [datetime] NULL ,",
        "[Inst_date] [datetime] NULL ,",
        "[Tran_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Repetitive_ID] [varchar] (48) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Source_cd] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Instr_adv_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Type_cd] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Subtype] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[In_type_cd] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[In_subtype] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_chrg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_chrg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Commission] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cbl_charge] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Wire_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Adr_Country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Adr_Type] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Adr_Subtyp] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sec_Acctg_Flg] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sec_Acctg_Amt] [numeric](21, 3) NULL ,",
        "[Offset_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Offset_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Offset_Name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Funds_type] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ASC_Amount] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ASC_Sec_Amt] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REC_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LAST_ADDR] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_AUTH_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_Recon_ref] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_Recon_ref] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cur_Code] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_CR = {
        "CREATE TABLE [dbo].[MESSAGE_CR] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[CDT_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_SLASH] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DISTRICT] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_OFFICE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_SUBTYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_ACCTG_FLG] [numeric](10, 0) NULL ,",
        "[CDT_SEC_ACCTG_AMT] [numeric](21, 3) NULL ,",
        "[CDT_TER_ACCTG_FLG] [numeric](10, 0) NULL ,",
        "[CDT_TER_ACCTG_AMT] [numeric](21, 3) NULL ,",
        "[CDT_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_AMOUNT] [numeric](21, 3) NULL ,",
        "[CDT_CURRENCY] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SHNAM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RT_CODE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_SUB_ACCT] [varchar] (61) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_PROD_CODE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DELIVERY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_PARENT] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RECON_REF] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CUSTOMER_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ID_OVERFLOW] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ID_OVERFLOW] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_BNK_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_CHARGE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ID_OVERFLOW] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_IB1_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ID_OVERFLOW] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Ib1_chips_upto] [numeric](10, 0) NULL ,",
        "[Ib1_chips_qual] [numeric](10, 0) NULL ,",
        "[Ibk_chips_upto] [numeric](10, 0) NULL ,",
        "[Ibk_chips_qual] [numeric](10, 0) NULL ,",
        "[Bbk_chips_upto] [numeric](10, 0) NULL ,",
        "[Bbk_chips_qual] [numeric](10, 0) NULL ,",
        "[Bnp_chips_upto] [numeric](10, 0) NULL ,",
        "[Bnp_chips_qual] [numeric](10, 0) NULL ,",
        "[Cdt_currency_susp_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_lim_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_exch_rate] [numeric](29, 11) NULL ,",
        "[Cdt_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_acc_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_adr_class] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_adr_city] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_adv_typ] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_adr_adv_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_location] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_rt_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_wir_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_wir_id] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pymnt_Adv_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pymnt_Phn_time] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pymnt_q] [varchar] (65) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_pay_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_secwir_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_alt_swift_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_id_chg_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_nof_looked_up] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_secwir] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_paysys_fmt] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_mailing_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Regulatory_report1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Regulatory_report2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Regulatory_report3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_auth_ref] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_value_date] [datetime] NULL ,",
        "[Cdt_value_date_chg] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_value_date_adj] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_value_date_sp] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_book_date] [datetime] NULL ,",
        "[Cdt_book_date_chg] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_book_date_adj] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_book_date_sp] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Creditside_residency] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_Idacc] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_Idadr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_Idpad] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_bilat_Idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_bilat_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_bilat_Idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_sec_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_sec_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_sec_idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_sec_acctg_cur] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ter_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ter_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ter_idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ter_acctg_cur] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spare_acc] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spare_adr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spare_pad] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_proc_rule_state] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spc_inst1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spc_inst2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spc_inst3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_DEST = {
         "CREATE TABLE [dbo].[MESSAGE_DEST] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Dst_Ordinal] [numeric](5, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Alternate_acct] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cost_center] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Param_1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Param_2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Identifier] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ovr] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_carrier] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_area_code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_dial] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sign] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_mac] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ans] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_cab2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_cab3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_cab4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_city] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_que_Bank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_que_Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_que_name] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_route_id] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_department] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_rt_code] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_char_count] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_multi_seq] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_multi_start] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_multi_count] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_out_test] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_pdm_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_attn] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_area_code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_dial] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_sign] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_mac] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_ans] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_cab2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_cab3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_cab4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ack_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_nak_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_delivery_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_adr_location] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_3rd_party_tst] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_format] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_msgtype] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_conn_time] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_charges] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_carrier_ref] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ter_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ter_id] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_tertiary_dept] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_msg_cond] [numeric](10, 0) NULL ,",
        "[Dst_msg_type] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_src_cond] [numeric](10, 0) NULL ,",
        "[Dst_src_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_time] [datetime] NULL ,",
        "[Dst_outgoing_ref] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_test_date] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Dst_fin_copy_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_119_hdr_data] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_casc_name] [varchar] (33) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_Srv_Msg_Flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_Inc_Hdr_Flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_copies] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_no_acct_stmt] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_precedence] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_origin] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_113_hdr_data] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_email_address] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_type_indicator] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_DR = {
        "CREATE TABLE [dbo].[MESSAGE_DR] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Dbt_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_name_2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_name_3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_name_4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_SLASH] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_DISTRICT] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_OFFICE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_SUBTYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_ACCTG_FLG] [numeric](10, 0) NULL ,",
        "[DBT_SEC_ACCTG_AMT] [numeric](21, 3) NULL ,",
        "[DBT_TER_ACCTG_FLG] [numeric](10, 0) NULL ,",
        "[DBT_TER_ACCTG_AMT] [numeric](21, 3) NULL ,",
        "[DBT_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BAL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHIPS_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_GRP_BAL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PRE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_GRP_PRE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_AMOUNT] [numeric](21, 3) NULL ,",
        "[DBT_CURRENCY] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RT_CODE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF5] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF6] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_SUB_ACCT] [varchar] (61) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_PROD_CODE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TER_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TER_IDKEY] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_FEE_CODE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RECON_REF] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_PARENT_CD] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CUSTOMER_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_draft_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Sbk_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_Rel_ID] [numeric](10, 0) NULL ,",
        "[Ins_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_name2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_name3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_name4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_rel_id] [numeric](10, 0) NULL ,",
        "[Rca_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_name2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_name3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_name4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_short_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_group_short_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_cross_short_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_exch_rate] [numeric](29, 11) NULL ,",
        "[Dbt_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_adr_class] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_adr_city] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_adv_typ] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_rt_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_wir_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_wir_id] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_drawdown_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ps_elig_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_item_hold_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_nof_looked_up] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_currency_susp_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dda_balance] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Balance_risk] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_auth_ref] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_value_date] [datetime] NULL ,",
        "[Dbt_value_date_chg] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_value_date_adj] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_value_date_sp] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_book_date] [datetime] NULL ,",
        "[Dbt_book_date_chg] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_book_date_adj] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_book_date_sp] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Debitside_residency] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_Idacc] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_Idadr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_Idpad] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_Idacc] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_Idadr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_Idpad] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_bilat_Idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_bilat_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_bilat_Idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_sec_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_sec_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_sec_idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_sec_acctg_cur] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ter_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ter_acctg_cur] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_iban] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_prule_copy] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_prule_copy] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_proc_rule_state] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_proc_rule_state] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_spc_inst1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_spc_inst2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_spc_inst3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_HIST = {
        "CREATE TABLE [dbo].[MESSAGE_HIST] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Hist_No] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Sub_Hist_No] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Entry_Type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Que_Line_ID] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Date_Time] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sequence_No] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Details] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Opr_Initials] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Amount] [numeric](21, 3) NULL ,",
        "[Msg_Info] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR = {
        "CREATE TABLE [dbo].[MESSAGE_PR] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Pr_ordinal] [numeric](10, 0) NULL ,",
        "[Pr_level] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_source] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_source_id] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_name] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_type] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_text] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_effective_time] [datetime] NULL ,",
        "[Pr_expiration_time] [datetime] NULL ,",
        "[Pr_subtype] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR_MCH = { 
        "CREATE TABLE [dbo].[MESSAGE_PR_MCH] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prmatch_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Prmatch_cond] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Prmatch_value] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Prmatch_logical] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Prmatch_action] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR_PRM = {
        "CREATE TABLE [dbo].[MESSAGE_PR_PRM] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prparm_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_timestamp] [numeric](23, 0) NOT NULL ,",
        "[Prparm_edit] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Prparm_count] [numeric](10, 0) NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};

        string[] MESSAGE_PR_PVL = {
        "CREATE TABLE [dbo].[MESSAGE_PR_PVL] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prparm_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Value_seq_num] [numeric](10, 0) NOT NULL ,",
        "[TRN_timestamp] [numeric](23, 0) NOT NULL ,",
        "[Parameter_values] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_QUEUE = {
         "CREATE TABLE [dbo].[MESSAGE_QUEUE] (",
        "[Queue_Prod_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Bank_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Cust] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Name] [varchar] (33) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[TRN_Timestamp] [datetime] NOT NULL ,",
        "[Record_Expired] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Future_date] [datetime] NULL ,",
        "[Rls_action] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_REL_AMT = {
         "CREATE TABLE [dbo].[MESSAGE_REL_AMT] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Sequence_no] [numeric](10, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Amt_Codeword] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Amount] [numeric](21, 3) NULL ,",
        "[Curr] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Memo] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_TEXT = {
        "CREATE TABLE [dbo].[MESSAGE_TEXT] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Text_Type] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Sequence_no] [numeric](10, 0) NOT NULL ,",
        "[Dst_ordinal] [numeric](5, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Message_text] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] createIndex = {
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_REL_AMT] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_ACCTG] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_CR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_DEST] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_DR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_HIST] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",	
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_MCH] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_PRM] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_PVL] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_QUEUE] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_TEXT] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",

            "create  INDEX [Bank] ON [dbo].[MESSAGE]([BANK]) ON [PRIMARY]",
            "create  INDEX [Source_cd] ON [dbo].[MESSAGE]([SOURCE_CD]) ON [PRIMARY]",
            "create  INDEX [Base_Amount] ON [dbo].[MESSAGE]([BASE_AMOUNT]) ON [PRIMARY]",
            "create  INDEX [Amount] ON [dbo].[MESSAGE]([AMOUNT]) ON [PRIMARY]",
            "create  INDEX [ReceiveTime] ON [dbo].[MESSAGE]([RCV_DATE], [RCV_TIME]) ON [PRIMARY]",
            "create  INDEX [TranType] ON [dbo].[MESSAGE]([TRAN_TYPE]) ON [PRIMARY]",
            "create  INDEX [AdviceType] ON [dbo].[MESSAGE]([INSTR_ADV_TYPE]) ON [PRIMARY]",
            "create  INDEX [CurrencyCode] ON [dbo].[MESSAGE]([CURRENCY_CODE]) ON [PRIMARY]",
            "create  INDEX [ValueDate] ON [dbo].[MESSAGE]([PAY_DATE], [PAY_TIME]) ON [PRIMARY]",
            "create  INDEX [InstructionDate] ON [dbo].[MESSAGE]([INST_DATE], [INST_TIME]) ON [PRIMARY]",
            "create  INDEX [DbtChrg] ON [dbo].[MESSAGE]([DBT_CHRG]) ON [PRIMARY]",
            "create  INDEX [CdtChrg] ON [dbo].[MESSAGE]([CDT_CHRG]) ON [PRIMARY]",
            "create  INDEX [Comission] ON [dbo].[MESSAGE]([COMMISSION]) ON [PRIMARY]",
            "create  INDEX [CblCharge] ON [dbo].[MESSAGE]([CBL_CHARGE]) ON [PRIMARY]",
            "create  INDEX [Imad] ON [dbo].[MESSAGE]([FED_IMAD]) ON [PRIMARY]",
            "create  INDEX [ChipSsn] ON [dbo].[MESSAGE]([CHP_SSN_6]) ON [PRIMARY]",
            "create  INDEX [SwiftMir] ON [dbo].[MESSAGE]([SWF_IN_MIR]) ON [PRIMARY]", 

            "create  INDEX [IX_SRC_VAL] ON [dbo].[DiffResuts]([RefBefore], [XmlSet], [FldName]) ON [PRIMARY]", 
            "create  INDEX [IX_Trg_VAL] ON [dbo].[DiffResuts]([RefAfter], [XmlSet], [FldName]) ON [PRIMARY]", 
            "create  INDEX [IX_Trg_VAL] ON [dbo].[DiffResuts]([RefAfter], [XmlSet], [FldName]) ON [PRIMARY]",
            "create  INDEX [TRNMID] ON [dbo].[MTS_RCV_TEXT]([TrnRef]) ON [PRIMARY]",
            "create  INDEX [REFSTRING] ON [dbo].[MTS_RCV_TEXT]([RefString]) ON [PRIMARY]",
            "create  INDEX [qName] ON [dbo].[MESSAGE_HIST]([QUE_LINE_ID]) ON [PRIMARY]"
        };

        public void createAllRgwTables(string area)
        {
            /*
             * This one creates all the rgw tables.
             */
            tableDefs tableDefs = new tableDefs();
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_ACCTG), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_CR), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_DEST), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_DR), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_HIST), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_MCH), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_PRM), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_PVL), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_QUEUE), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_REL_AMT), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_TEXT), true);
            }
            catch { dbWriter.Connect(true, area); }

            dbWriter.Dispose();
        }


        public void createAllRgwIndices(string area)
        {
            /*
             * This one adds all the indices to the rgw tables.
             */
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);
            for (int i = 0; i < createIndex.Length; i++)
            {
                try
                {
                    dbWriter.Execute(createIndex[i], true);
                }
                catch { dbWriter.Connect(true, area); }
            }
            dbWriter.Dispose();
        }


        public void dropAllRgwTables(string area)
        {
            /*
             * This one kills all the existing rgw tables.
             */
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);

            try { dbWriter.Execute(dropMESSAGE, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_ACCTG, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_CR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_DEST, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_DR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_HIST, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_MCH, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_PRM, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_PVL, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_QUEUE, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_REL_AMT, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_TEXT, true); }
            catch { dbWriter.Connect(true, area); }

            dbWriter.Dispose();
        }

        public void initMessageRepository(string area)
        {
            /*
             * Wipe 'em all out and make 'em again. Add the indices.
             */
            dropAllRgwTables(area);
            createAllRgwTables(area);
            createAllRgwIndices(area);
        }
    }

    public class rgwDef_v3
    {
        /*
         * This class defines all these Message Data Repository (aka rgw) tables
         * as we know and love them today, 7-Feb-2007. Trust me, there'll be changes.
         * 
         * Yep, these are the definitions from STI for MTS v3.0. So far the changes are
         * confined to message, message_cr, and mesasge_dr. Could be worse, I suppose ...
         * 
         */

        string dropMESSAGE = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE]";

        string dropMESSAGE_ACCTG = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_ACCTG]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_ACCTG]";


        string dropMESSAGE_CR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_CR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_CR]";


        string dropMESSAGE_DEST = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_DEST]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_DEST]";


        string dropMESSAGE_DR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_DR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_DR]";


        string dropMESSAGE_HIST = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_HIST]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_HIST]";


        string dropMESSAGE_PR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR]";


        string dropMESSAGE_PR_MCH = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_MCH]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_MCH]";


        string dropMESSAGE_PR_PRM = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_PRM]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_PRM]";


        string dropMESSAGE_PR_PVL = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_PVL]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_PVL]";


        string dropMESSAGE_QUEUE = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_QUEUE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_QUEUE]";


        string dropMESSAGE_REL_AMT = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_REL_AMT]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_REL_AMT]";


        string dropMESSAGE_TEXT = "if exists (select * from dbo.sysobjects where id = " +
                "object_id(N'[dbo].[MESSAGE_TEXT]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
                "drop table [dbo].[MESSAGE_TEXT]";


        // MTS 3.0 tables.
        string[] MESSAGE = {
        "CREATE TABLE [dbo].[MESSAGE] (",
        "[TRN_DATE] [datetime] NOT NULL ,",
        "[TRN_NUMBER] [int] NOT NULL ,",
        "[TRN_TIMESTAMP] [numeric](23, 0) NOT NULL ,",
        "[PROC_DATE] [datetime] NULL ,",
        "[BANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LOC] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAY_DATE] [datetime] NULL ,",
        "[PAY_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INST_DATE] [datetime] NULL ,",
        "[TRAN_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPETITIVE_ID] [varchar] (48) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SOURCE_CD] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INSTR_ADV_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AMOUNT] [numeric](21, 3) NULL ,",
        "[TYPE_CD] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SUBTYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IN_TYPE_CD] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IN_SUBTYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CHRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CHRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMMISSION] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_CHARGE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[WIRE_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STRAIGHT_THRU] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NETWORK_SND_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NETWORK_SND_ACC] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_ACC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CAN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_RISK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_AUTO] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_OVER] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CSTMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_DSTMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_LIM] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_RPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_NON_RPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALLBACK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FAIL_TST] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTV_LIM] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTV_CHNG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_NOF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MON_INTERCEPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCV_DATE] [datetime] NULL ,",
        "[RCV_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DLV_DATE] [datetime] NULL ,",
        "[DLV_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALLER] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DOC_NUM] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ITEM_NUM] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAN_MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAN_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAL] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_RATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FX_TOLERANCE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_RATE] [numeric](29, 11) NULL ,",
        "[BASE_AMOUNT] [numeric](21, 3) NULL ,",
        "[CURRENCY_CODE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADER_CTRL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDS_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_IMAD] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_OMAD] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_SSN_1] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_SSN_6] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_IN_MIR] [varchar] (28) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_OUT_MIR] [varchar] (28) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ENTRY_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VERIFY_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPAIR_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCEPT_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TOT_AMT] [numeric](21, 3) NULL ,",
        "[CUSIP] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUSIP_DESC] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHECK_SEQ] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NO_PHNADV_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXC_MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAY_STATE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NOTIFY] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STOP_INTERCEPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELEASE_TIME_HH] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELEASE_TIME_MM] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRE_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FX_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COR_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RTE_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_LAST_NAME] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_FIRST_NAME] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OVER_DRAFT_AMT] [numeric](21, 3) NULL ,",
        "[DBT_CON_BANK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CON_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CON_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_BANK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SYS_OF_REC] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SYS_OF_REC] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PARENT_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PARENT_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RECEIPT_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FRONTEND_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_DADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AVAIL_BAL] [numeric](21, 3) NULL ,",
        "[LEDGER_BAL] [numeric](21, 3) NULL ,",
        "[OVER_TIMESTAMP] [datetime] NULL ,",
        "[RECORD_EXPIRED] [numeric](23, 0) NULL ,",
        "[RECORD_UPDATED] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRADE_STATE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NEW_TRADE_STATE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_OPERATION] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OPERATION_SCOPE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_CUSTOMER] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PARTY_B] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND5] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND6] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_METHOD] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_BRANCH_PTYA] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_BRANCH_PTYB] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_ID] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_COMISN] [numeric](21, 3) NULL ,",
        "[COUNTERPARTY_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORIG_MSG_DATE] [datetime] NULL ,",
        "[TRADE_PARTY_SUSP_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OTHER_PARTY_SUSP_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LAST_USED_DATE] [datetime] NULL ,",
        "[ORIG_INST_VAL_DATE] [datetime] NULL ,",
        "[TRADE_TYPE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_SUBTYPE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_BUY_SELL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_UPDATE_PENDING_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORIG_EXCH_RATE] [numeric](29, 11) NULL ,",
        "[RECEIVE_CHAR_COUNT] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INCOMING_FORMAT] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INCOMING_REF] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDS_CATEGORY] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SEGMENT_INDEX] [numeric](11, 0) NULL ,",
        "[SPLIT_CTR] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPR_LEVEL] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[POST_DATE] [datetime] NULL ,",
        "[POST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SEND_DATE] [datetime] NULL ,",
        "[FEDFUND_TYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_DAYS] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INTEREST_RATE] [numeric](7, 5) NULL ,",
        "[ANT_TOL_AMT] [numeric](21, 3) NULL ,",
        "[CAL_OVR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_REF_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFC_PIN_REF_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PHN_NOF_ID] [varchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TESTKEY_IN] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_TEXT] [varchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RISKINESS_IND] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMM_MODE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_MODE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADM_LOCK_TEXT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNK_TX_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULT_DBT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULT_CDT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AMT_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUR_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SERIAL_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PDM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADV_OVR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_REQ_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SITE_OPTION1_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ACCT_VFC_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULTI_CUR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIORITY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DELIVERY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RTP_INTERCEPT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DELAY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCHED_ANT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPAIR_CHNG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHIPS_RECVRY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NON_ACCTING_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_STMT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHARGE_STATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFY_COUNT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_DBT_AUTH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_DBT_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_CDT_AUTH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_CDT_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_STATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFC_COUNT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDED_MSG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PMT_CHRG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INT_REROUTE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUR_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OVR_OUT_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FORCE_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTD_SWF_STMT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHECK_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_DBT_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_CDT_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_BNP_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_SRN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_SIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[UMBRELLA_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BANK_OPERATION_CODE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ACC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BIC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_DBT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_SBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_OBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ORP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_INS] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CDT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_IB1] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_IBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BNP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BBI] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_OBI] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_DTE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_AMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CNF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_REG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_PRD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PMT_CHAR_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUTOFF_OVERRIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCHANGE_RATE_STAT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FOREX_BYPASS_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[GLOBAL_DEBIT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_PTY_SIDE_IND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FORCE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEFINITIVE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CANCELLED_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FIN_CPY_SRC_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SUPPR_PMT_CONF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ENTERED_SIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE] [datetime] NULL ,",
        "[DUE_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE] [datetime] NULL ,",
        "[PRIME_SEND_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE] [datetime] NULL ,",
        "[SECOND_SEND_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REG_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REG_ID] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AUTH_REF] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MSG_STATE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELATED_TRN_DATE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELATED_TRN_NUM] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_POST_DATE] [datetime] NULL ,",
        "[CDT_POST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OPERTNL_RLS_DATE] [datetime] NULL ,",
        "[OPERTNL_RLS_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RAMET_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NON_RET_VALVE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUTOFF_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FOREX_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FEE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EUR_BENE_CHRG_ALLOW] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[HIGH_MSG_STATE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMM_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FTR_PROC_RULE_STATE] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
             
            // New stuff for v3.0. Note, there were a couple of changes above, so
            // don't think this is the only new stuff, ok?

        "[POSTAL_CODE_OVR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPR_FLG]  [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXC_FLG]  [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IMPOSED_AMOUNT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[GLOBAL_CREDIT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAYMNT_FUNDING_IND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAYMNT_ASYNCH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAYMNT_RESP_TIME] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MON_PER_INTERCEPT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MON_PER_LOG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SMPL_WRHS_INDICATOR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ENT_REF_SYS_VEC] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[WRHS_REF_SYS_VEC] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REF_CALL_VECTOR] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SMPL_PYMT_FORMAT] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTAINER_REJ_REASON] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[UNIQUE_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SRGW_EXPORT_SERIAL] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MSGTYPE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_ACCTG = {
        "CREATE TABLE [dbo].[MESSAGE_ACCTG] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Acctg_IDType] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Acctg_Account] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Amount] [numeric](21, 3) NOT NULL ,",
        "[STS_DBT_CDT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[STS_CROSS_BANK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[STS_PRIMARY] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Period] [datetime] NULL ,",
        "[Proc_Date] [datetime] NULL ,",
        "[Bank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Value_date] [datetime] NULL ,",
        "[Inst_date] [datetime] NULL ,",
        "[Tran_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Repetitive_ID] [varchar] (48) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Source_cd] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Instr_adv_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Type_cd] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Subtype] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[In_type_cd] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[In_subtype] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_chrg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_chrg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Commission] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cbl_charge] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Wire_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Tran_Name_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Adr_Country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Adr_Type] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Adr_Subtyp] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sec_Acctg_Flg] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sec_Acctg_Amt] [numeric](21, 3) NULL ,",
        "[Offset_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Offset_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Offset_Name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Funds_type] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ASC_Amount] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ASC_Sec_Amt] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REC_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LAST_ADDR] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_AUTH_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_Recon_ref] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_Recon_ref] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cur_Code] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_CR = {
        "CREATE TABLE [dbo].[MESSAGE_CR] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[CDT_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_SLASH] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DISTRICT] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_OFFICE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_SUBTYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_ACCTG_FLG] [numeric](10, 0) NULL ,",
        "[CDT_SEC_ACCTG_AMT] [numeric](21, 3) NULL ,",
        "[CDT_TER_ACCTG_FLG] [numeric](10, 0) NULL ,",
        "[CDT_TER_ACCTG_AMT] [numeric](21, 3) NULL ,",
        "[CDT_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_AMOUNT] [numeric](21, 3) NULL ,",
        "[CDT_CURRENCY] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SHNAM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RT_CODE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_SUB_ACCT] [varchar] (61) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_PROD_CODE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DELIVERY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_PARENT] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RECON_REF] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CUSTOMER_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        // not in v3.0 "[BBK_ID_OVERFLOW] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        "[BBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        // not in v3.0 "[BNP_ID_OVERFLOW] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        "[BNP_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_BNK_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_CHARGE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        // not in v3.0 "[IBK_ID_OVERFLOW] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        "[IBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_IB1_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        // not in v3.0 "[IB1_ID_OVERFLOW] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        "[ORP_BEN_INF1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Ib1_chips_upto] [numeric](10, 0) NULL ,",
        "[Ib1_chips_qual] [numeric](10, 0) NULL ,",
        "[Ibk_chips_upto] [numeric](10, 0) NULL ,",
        "[Ibk_chips_qual] [numeric](10, 0) NULL ,",
        "[Bbk_chips_upto] [numeric](10, 0) NULL ,",
        "[Bbk_chips_qual] [numeric](10, 0) NULL ,",
        "[Bnp_chips_upto] [numeric](10, 0) NULL ,",
        "[Bnp_chips_qual] [numeric](10, 0) NULL ,",
        "[Cdt_currency_susp_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_lim_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_exch_rate] [numeric](29, 11) NULL ,",
        "[Cdt_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_acc_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_adr_class] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_adr_city] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_adv_typ] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_adr_adv_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_location] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_rt_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_wir_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_wir_id] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pymnt_Adv_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pymnt_Phn_time] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pymnt_q] [varchar] (65) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_pay_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_secwir_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_alt_swift_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_id_chg_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_nof_looked_up] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_secwir] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_paysys_fmt] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_mailing_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Regulatory_report1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Regulatory_report2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Regulatory_report3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_auth_ref] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_value_date] [datetime] NULL ,",
        "[Cdt_value_date_chg] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_value_date_adj] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_value_date_sp] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_book_date] [datetime] NULL ,",
        "[Cdt_book_date_chg] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_book_date_adj] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_book_date_sp] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Creditside_residency] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_Idacc] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_Idadr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_profile_Idpad] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ibk_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ib1_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bbk_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bnp_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_bilat_Idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_bilat_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_bilat_Idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_sec_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_sec_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_sec_idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_sec_acctg_cur] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ter_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ter_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ter_idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_ter_acctg_cur] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spare_acc] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spare_adr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spare_pad] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_proc_rule_state] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spc_inst1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spc_inst2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cdt_spc_inst3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_COMM_CBL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_DEST = {
         "CREATE TABLE [dbo].[MESSAGE_DEST] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Dst_Ordinal] [numeric](5, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Alternate_acct] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Cost_center] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Param_1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Param_2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Identifier] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ovr] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_carrier] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_area_code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_dial] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sign] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_mac] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ans] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_cab2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_cab3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_cab4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_city] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_que_Bank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_que_Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_que_name] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_route_id] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_department] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_rt_code] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_char_count] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_multi_seq] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_multi_start] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_multi_count] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_out_test] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_pdm_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_attn] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_area_code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_dial] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_sign] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_mac] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_ans] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_cab2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_cab3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_sec_cab4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ack_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_nak_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_delivery_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_adr_location] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_3rd_party_tst] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_format] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_msgtype] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_conn_time] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_charges] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_carrier_ref] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ter_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_ter_id] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_tertiary_dept] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_msg_cond] [numeric](10, 0) NULL ,",
        "[Dst_msg_type] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_src_cond] [numeric](10, 0) NULL ,",
        "[Dst_src_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_time] [datetime] NULL ,",
        "[Dst_outgoing_ref] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_test_date] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Dst_fin_copy_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_119_hdr_data] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_casc_name] [varchar] (33) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_Srv_Msg_Flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_Inc_Hdr_Flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_copies] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_no_acct_stmt] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_precedence] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_origin] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_113_hdr_data] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_email_address] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dst_type_indicator] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_DR = {
        "CREATE TABLE [dbo].[MESSAGE_DR] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Dbt_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_name_2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_name_3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_name_4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_SLASH] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_DISTRICT] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_OFFICE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_SUBTYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_ACCTG_FLG] [numeric](10, 0) NULL ,",
        "[DBT_SEC_ACCTG_AMT] [numeric](21, 3) NULL ,",
        "[DBT_TER_ACCTG_FLG] [numeric](10, 0) NULL ,",
        "[DBT_TER_ACCTG_AMT] [numeric](21, 3) NULL ,",
        "[DBT_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BAL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHIPS_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_GRP_BAL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PRE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_GRP_PRE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_AMOUNT] [numeric](21, 3) NULL ,",
        "[DBT_CURRENCY] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RT_CODE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF5] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF6] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_SUB_ACCT] [varchar] (61) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_PROD_CODE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TER_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TER_IDKEY] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_FEE_CODE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RECON_REF] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_PARENT_CD] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CUSTOMER_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_draft_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",       
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",

        // not in v3.0 "[Sbk_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        // not in v3.0 "[Obk_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        // not in v3.0 "[Orp_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        "[Ins_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_Rel_ID] [numeric](10, 0) NULL ,",
        "[Ins_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        // not in v3.0 "[Ins_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        "[Ins_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_name2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_name3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_name4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_rel_id] [numeric](10, 0) NULL ,",
        "[Rca_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

         // not in v3.0 "[Rca_id_overflow] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",

        "[Rca_name1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_name2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_name3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_name4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_short_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_group_short_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_cross_short_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_exch_rate] [numeric](29, 11) NULL ,",
        "[Dbt_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_adr_class] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_adr_city] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_adv_typ] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_rt_state] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_wir_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_wir_id] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_drawdown_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ps_elig_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_item_hold_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_nof_looked_up] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_currency_susp_flg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dda_balance] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Balance_risk] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_adr_bnk_id] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_rel_id] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ref_num] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_state] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_postal_code] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_res_country] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_auth_ref] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_value_date] [datetime] NULL ,",
        "[Dbt_value_date_chg] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_value_date_adj] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_value_date_sp] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_book_date] [datetime] NULL ,",
        "[Dbt_book_date_chg] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_book_date_adj] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_book_date_sp] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_camefrom] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Debitside_residency] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_Idacc] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_Idadr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_profile_Idpad] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_Idacc] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_Idadr] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_profile_Idpad] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Obk_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Orp_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Ins_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Rca_bei_flag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_bilat_Idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_bilat_Idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_bilat_Idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_sec_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_sec_idtype] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_sec_idkey] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_sec_acctg_cur] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ter_idbank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_ter_acctg_cur] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_iban] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_prule_copy] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_prule_copy] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_proc_rule_state] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sbk_proc_rule_state] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_spc_inst1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_spc_inst2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Dbt_spc_inst3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_COMM_CBL_FLG]  [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_HIST = {
        "CREATE TABLE [dbo].[MESSAGE_HIST] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Hist_No] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Sub_Hist_No] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Entry_Type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Que_Line_ID] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Date_Time] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sequence_No] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Details] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Opr_Initials] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Amount] [numeric](21, 3) NULL ,",
        "[Msg_Info] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR = {
        "CREATE TABLE [dbo].[MESSAGE_PR] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Pr_ordinal] [numeric](10, 0) NULL ,",
        "[Pr_level] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_source] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_source_id] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_name] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_type] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_text] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_effective_time] [datetime] NULL ,",
        "[Pr_expiration_time] [datetime] NULL ,",
        "[Pr_subtype] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR_MCH = { 
        "CREATE TABLE [dbo].[MESSAGE_PR_MCH] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prmatch_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Prmatch_cond] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Prmatch_value] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Prmatch_logical] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Prmatch_action] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR_PRM = {
        "CREATE TABLE [dbo].[MESSAGE_PR_PRM] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prparm_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_timestamp] [numeric](23, 0) NOT NULL ,",
        "[Prparm_edit] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Prparm_count] [numeric](10, 0) NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};

        string[] MESSAGE_PR_PVL = {
        "CREATE TABLE [dbo].[MESSAGE_PR_PVL] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prparm_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Value_seq_num] [numeric](10, 0) NOT NULL ,",
        "[TRN_timestamp] [numeric](23, 0) NOT NULL ,",
        "[Parameter_values] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_QUEUE = {
         "CREATE TABLE [dbo].[MESSAGE_QUEUE] (",
        "[Queue_Prod_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Bank_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Cust] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Name] [varchar] (33) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[TRN_Timestamp] [datetime] NOT NULL ,",
        "[Record_Expired] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Future_date] [datetime] NULL ,",
        "[Rls_action] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_REL_AMT = {
         "CREATE TABLE [dbo].[MESSAGE_REL_AMT] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Sequence_no] [numeric](10, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Amt_Codeword] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Amount] [numeric](21, 3) NULL ,",
        "[Curr] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Memo] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_TEXT = {
        "CREATE TABLE [dbo].[MESSAGE_TEXT] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Text_Type] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Sequence_no] [numeric](10, 0) NOT NULL ,",
        "[Dst_ordinal] [numeric](5, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Message_text] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] createIndex = {
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_REL_AMT] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_ACCTG] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_CR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_DEST] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_DR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_HIST] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",	
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_MCH] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_PRM] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_PVL] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_QUEUE] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_TEXT] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",

            "create  INDEX [Bank] ON [dbo].[MESSAGE]([BANK]) ON [PRIMARY]",
            "create  INDEX [Source_cd] ON [dbo].[MESSAGE]([SOURCE_CD]) ON [PRIMARY]",
            "create  INDEX [Base_Amount] ON [dbo].[MESSAGE]([BASE_AMOUNT]) ON [PRIMARY]",
            "create  INDEX [Amount] ON [dbo].[MESSAGE]([AMOUNT]) ON [PRIMARY]",
            "create  INDEX [ReceiveTime] ON [dbo].[MESSAGE]([RCV_DATE], [RCV_TIME]) ON [PRIMARY]",
            "create  INDEX [TranType] ON [dbo].[MESSAGE]([TRAN_TYPE]) ON [PRIMARY]",
            "create  INDEX [AdviceType] ON [dbo].[MESSAGE]([INSTR_ADV_TYPE]) ON [PRIMARY]",
            "create  INDEX [CurrencyCode] ON [dbo].[MESSAGE]([CURRENCY_CODE]) ON [PRIMARY]",
            "create  INDEX [ValueDate] ON [dbo].[MESSAGE]([PAY_DATE], [PAY_TIME]) ON [PRIMARY]",
            "create  INDEX [InstructionDate] ON [dbo].[MESSAGE]([INST_DATE], [INST_TIME]) ON [PRIMARY]",
            "create  INDEX [DbtChrg] ON [dbo].[MESSAGE]([DBT_CHRG]) ON [PRIMARY]",
            "create  INDEX [CdtChrg] ON [dbo].[MESSAGE]([CDT_CHRG]) ON [PRIMARY]",
            "create  INDEX [Comission] ON [dbo].[MESSAGE]([COMMISSION]) ON [PRIMARY]",
            "create  INDEX [CblCharge] ON [dbo].[MESSAGE]([CBL_CHARGE]) ON [PRIMARY]",
            "create  INDEX [Imad] ON [dbo].[MESSAGE]([FED_IMAD]) ON [PRIMARY]",
            "create  INDEX [ChipSsn] ON [dbo].[MESSAGE]([CHP_SSN_6]) ON [PRIMARY]",
            "create  INDEX [SwiftMir] ON [dbo].[MESSAGE]([SWF_IN_MIR]) ON [PRIMARY]",
            "create  INDEX [TRNMID] ON [dbo].[MTS_RCV_TEXT]([TrnRef]) ON [PRIMARY]",
            "create  INDEX [REFSTRING] ON [dbo].[MTS_RCV_TEXT]([RefString]) ON [PRIMARY]",
            "create  INDEX [qName] ON [dbo].[MESSAGE_HIST]([QUE_LINE_ID]) ON [PRIMARY]"
        };



        public void createAllRgwTables(string area)
        {
            SimLog.log.write(area, "createAllRgwTables");
            /*
             * This one creates all the rgw tables.
             */
            tableDefs tableDefs = new tableDefs();
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(tableDefs.SimulatorEvents), true);
                SimLog.log.write(area, "created SimulatorEvents", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE), true);
                SimLog.log.write(area, "created Message", true);
            }
            catch
            {
                string x = tableDefs.buildCreateString(MESSAGE);
                dbWriter.Connect(true, area);
            }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_ACCTG), true);
                SimLog.log.write(area, "created Message_Acctg", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_CR), true);
                SimLog.log.write(area, "created Message_cr", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_DEST), true);
                SimLog.log.write(area, "created message_dest", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_DR), true);
                SimLog.log.write(area, "created Message_dr", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_HIST), true);
                SimLog.log.write(area, "created Message_hist", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR), true);
                SimLog.log.write(area, "created Message_pr", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_MCH), true);
                SimLog.log.write(area, "created Message_pr_mch", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_PRM), true);
                SimLog.log.write(area, "created Message_pr_prm", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_PVL), true);
                SimLog.log.write(area, "created Message_pr_pvl", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_QUEUE), true);
                SimLog.log.write(area, "created Message_queue", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_REL_AMT), true);
                SimLog.log.write(area, "created Message_rel_amt", true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_TEXT), true);
                SimLog.log.write(area, "created Message_text", true);
            }
            catch { dbWriter.Connect(true, area); }

            dbWriter.Dispose();
        }


        public void createAllRgwIndices(string area)
        {
            /*
             * This one adds all the indices to the rgw tables.
             */
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);
            for (int i = 0; i < createIndex.Length; i++)
            {
                try
                {
                    dbWriter.Execute(createIndex[i], true);
                }
                catch { dbWriter.Connect(true, area); }
            }
            dbWriter.Dispose();
        }


        public void dropAllRgwTables(string area)
        {
            /*
             * This one kills all the existing rgw tables.
             */
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);

            try { dbWriter.Execute(dropMESSAGE, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_ACCTG, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_CR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_DEST, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_DR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_HIST, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_MCH, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_PRM, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_PVL, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_QUEUE, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_REL_AMT, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_TEXT, true); }
            catch { dbWriter.Connect(true, area); }

            dbWriter.Dispose();
        }

        public void initMessageRepository(string area)
        {
            /*
             * Wipe 'em all out and make 'em again. Add the indices.
             */
            dropAllRgwTables(area);
            createAllRgwTables(area);
            createAllRgwIndices(area);
        }
    }
}
