/* NEX_TIME_ARITH.C
 *
 * Time arithmetic -- operations using delta times
 *
 * (c) 1999  IntraNet, Inc., 1 Gateway Center, Newton, MA 02458
 *
 * Author: John Munzer
 *
 * Revision history:
 *
 * 6-Oct-1999	JM	Initial version:  NEX_TIME_DELTA, NEX_TIME_ADD, &
 *			NEX_TIME_SUBTRACT.
 *
 */

#include <stdlib.h>
#include <jni.h>
/*
  Turn a time into a time delta

  accept:	"days hours:minutes"	e.g. "1 1:30"
  .   or:	"hours:minutes"		e.g. "2:15"

  return delta_time = equivalent number of nanoseconds
  
  return value:		1 success
  .			0 failure
*/

#define MINUTES_PER_DAY		1440
#define MINUTES_PER_HOUR	60
#define NANOSECONDS_PER_MINUTE	60000000000LL

int NEX_TIME_DELTA(const char *delta_time_string, int time_length, long long
		   *delta_time)
{
    int days, hours, minutes;
    int state;
    int i;
    char c;
    int digit;
    int accumulator;
    boolean_t failure = FALSE;
    
    /* only allow strings of the form

       space*  digit+  colon  digit+

       and

       space*  digit+  space*  digit+  colon  digit+
    */

    state = 0;
    
    for (i = 0; i < time_length; i++)
	{
	    /* if c is a digit, capture its value in digit, and simplify c */
	    c = delta_time_string[i];
	    if ((c >= '0') && (c <= '9'))
		{
		    digit = c - '0';
		    c = '0';
		}
	    
	    switch (state)
		{
		case 0:		/* initial spaces */
		    if (c == ' ')
			continue;
		    if (c == '0')
			{
			    accumulator = digit;
			    state = 1;
			    continue;
			}
		    failure = TRUE;
		    break;
		case 1:		/* first number */
		    if (c == ' ')
			{
			    days = accumulator;
			    state = 2;
			    continue;
			}
		    if (c == ':')
			{
			    /* no days in string */
			    days = 0;
			    hours = accumulator;
			    accumulator = 0;
			    state = 4;
			    continue;
			}
		    if (c == '0')
			{
			    accumulator *= 10;
			    accumulator += digit;
			    continue;
			}
		    failure = TRUE;
		    break;
		case 2:		/* spaces between days & hours */
		    if (c == ' ')
			continue;
		    if (c == '0')
			{
			    accumulator = digit;
			    state = 3;
			    continue;
			}
		    failure = TRUE;
		    break;
		case 3:		/* hours (after seeing days) */
		    if (c == ':')
			{
			    hours = accumulator;
			    accumulator = 0;
			    state = 4;
			    continue;
			}
		    if (c == '0')
			{
			    accumulator *= 10;
			    accumulator += digit;
			    continue;
			}
		    failure = TRUE;
		    break;
		case 4:		/* minutes */
		    if (c == '0')
			{
			    accumulator *= 10;
			    accumulator += digit;
			    continue;
			}
		    failure = TRUE;
		    break;
		}
	}

    if (failure)
	{
	    *delta_time = 0;
	    /*failure */
	    return 0;
	}

    minutes = accumulator;
    
    /* calculate nanoseconds */
    *delta_time = MINUTES_PER_DAY * days + MINUTES_PER_HOUR * hours + minutes;
    *delta_time *= NANOSECONDS_PER_MINUTE;
    
    /* success */
    return 1;
}


/*
  Add a time_delta to a time

  add a delta time (returned from time_delta) from a Subject time to get a
  new Subject time

  return answer_time = sum

  return value:		1 success
  .			0 failure  
*/
int NEX_TIME_ADD(long long time, long long time_delta, long long *answer_time)
{
    *answer_time = time + time_delta;
    /* success */
    return 1;
}

/*
  Subtract a time_delta from a time

  subtract a delta time (returned from time_delta) from a Subject time to get a
  new Subject time

  return answer_time = difference

  return value:		1 success
  .			0 failure  
*/
int NEX_TIME_SUBTRACT(long long time, long long time_delta, long long
		      *answer_time)
{
    *answer_time = time - time_delta;
    /* success */
    return 1;
}



