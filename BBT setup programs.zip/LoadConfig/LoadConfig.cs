/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/
using System;
using System.Collections;
using System.Data;
using System.IO;
using Simulator.DBLibrary;
using Simulator.BackEndSubLib;
using Simulator.dataDefs;

/*
   18-Mar-06	JR	The real guts have been moved into BackEndSubs. This is just
			a shell to invoke that class.
			
   23-Apr-06	JR	Add a 'close' method to do a disconnect on all the DBAccess objects.
   11-Feb-06    JR	Comment out the loginfo call here. We'll log the activity when we
                    	do it in the lower-level code.
   1-Apr-08	JN	Added an ability to manually create an config xml file. Used for initial installation.
 * 
 * 07-July-09   JR  RGW table changes for MTS 3.0. We've now got another argument to loadConfig,
 *                  the simVersion, that argument is of the form "1.3" where 1 is the simulator
 *                  version (which we don't much care about at the moment) but the 3 tells
 *                  us that the RGW tables are for MTS 3.0. We'll default to building areas
 *                  with the MTS 3.0 rgw style.
 
 28-Nov-15    JR  Synch code between Jacob and John
 * 
 *  03-May-16    JR  SimVersion used to be of the form "1.5" where '1' was the Simulator version and '5' 
 *                  specified the RGW/MTS version for that area. I'm changing the use of SimVersion so
 *                  it will be of the form "5.2" where '5' is the main MTS/RGW version the the '2' indicates
 *                  which release/sub-version we want in that area. Now, let's by default build areas 
 *                  as MTS 5.0.
   
 * 
*/

namespace myLoadConfig
{

    class myLoadConfig
    {

        static void Main(string[] args)
        {
            string area = args[0];
            string xxx = args[0].ToUpper();
            string simVersion = "5.0";
            try
            {
                simVersion = args[2];
            }
            catch { }
            if (simVersion == "")
            {
                simVersion = "5.0";
            }

            if (args.Length > 1)
            {
                string func = args[1].ToUpper();
                if (func.Equals("NEWDB"))
                {
                    CreateDatabase createDB = new CreateDatabase();
                    int status = createDB.newDB(area);
                    if (status > 0)
                        Console.WriteLine("New Database created: 'Simulator_" + area);
                    return;
                }
                if (func.Equals("XML"))
                {
        		    CreateXmlFile MakeCfg = new CreateXmlFile();
		            MakeCfg.CreateXml(args[0], "ALL", "");
                    Console.WriteLine("Config XML is created for : 'Simulator_" + area);
		            return;
		        }
            }

            LoadConfig lCfg = new LoadConfig(area);
            if (xxx.Equals("HELP"))
            {
                string helpMsg = lCfg.help();
                Console.WriteLine(helpMsg);
                return;
            }
            lCfg.SetVendor("ACI");
            lCfg.load(args);
            lCfg.close();
            BackEndSubs util = new BackEndSubs();
            //util.logInfo(area, "LoadConfig", "New configuration loaded");
        }
    }
}
