/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
*/

/*  Revisions.
	This class contains three routine;
	1. Fed_parse
	   Gets the msgbody as it comes off the link, separate account msgs from admins and
	   creates a message on FedReceiveAckQue for non admins.
	2. MakeFinalMsg
	   Gets msg off FedReceiveAckQue, does field edits (DoEdits), checks agains NAK tables if one is
	   assigned to the line and formats either ack or nak back to MTS
	3. WriteToFile
	   This routine is call based on debug switch from Receiver and writes a msg into the file
	4. FmtMsg
	   Formats the msgs destined to MTS. Basically it assigns new seq numbers.
 * 
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 04-Mar-2016  JN Changed headers for GPPSP support. 
*/
using System;
using System.IO;
using System.Text;
using System.Globalization;
using System.Data;
using System.Collections;
using System.Text.RegularExpressions;
using Simulator.DBLibrary;
using System.Data.SqlClient;

namespace Simulator.FormatersLib
{
    /// </summary>
    public class FedFormatter : IDisposable
    {
        StringBuilder MsgHeader;
        StringBuilder acktxt;
        StringBuilder fedmsg;
        //        private string m_pretxt1 = "        MIDNAME1 FTR811";   //ACI
        //        private string m_pretxt2 = "        MIDNAME1 FTA811";   //ACI
        //	  private string m_pretxt3 = "       MIDNAME1 FTNBAL";    //ACI
        //	  private string m_pretxt4 = "02T";    //ACI
//        private string m_pretxt1 = ".BB..01.@@@@@@@@.FTR811FFT811  ";   //CITIBank
//        private string m_pretxt2 = ".BB..01.@@@@@@@@.FTA811FFA811  ";   //CITIBank
//        private string m_pretxt3 = ".BB..01.@@@@@@@@.FTNABAL       ";   //CITIBank
//	  private string m_pretxt4 = "02T";    //citibank
        private string m_pretxt1 = ".....01.FTI0350 .FTR811YFT811  ";   //GPPSP
        private string m_pretxt2 = "";   //GPPSP
        private string m_pretxt3 = "";   //GPPSP
        private string m_pretxt4 = "30T";   //GPPSP
        private int m_ackseq = 0;

/*  FT GPPSP FED incoming and ack
        0307L1B77F1C00000803071423FT012 0307LTERMOBK00000103071423FT0120162016

<Original_FED_Message>........FTI0811 XFT811  {1500}30        T {1510}1033{1520}20151130L1B77F1C000002{2000}000000017900{3100}026003557{3320}FVDEC110310*{3400}026003023{3500}20151130B1Q8154C000004{3600}DRC{4200}D987987987*PSE&amp;G*{4400}D033300109*PSE&amp;G*{5000} *PSE&amp;G*{5400}026003023{6500}REFUSE YOUR REF FVDEC110310.*</Original_FED_Message>
<MOP_NOTIFICATION_MSG>        1130L1B77F1C00000211301125FT012 1130LTERMOBK00000211301125FT0120152015</MOP_NOTIFICATION_MSG>
*/

        public FedFormatter()
        {
            fedmsg = new StringBuilder();
            acktxt = new StringBuilder();
            MsgHeader = new StringBuilder();
        }

        public int Fed_parse(DBAccess writeConnection, DBAccess readConnection, string buffer, string Aba, string Lterm, string CycleDate, string CheckDup, string CheckGaps, string LineName, StreamWriter sw, string Debug, string ApplId)
        {
            string send_line = LineName;
            string Cmd;
            // Before placing msgs on the Ack queue check if it is paymnets.
            // ACI            int pos = buffer.IndexOf("FTI");
            int pos = buffer.IndexOf("FT");		//FT: XFT811  
            string Msgtype = buffer.Substring(pos, 7);

            if ((Msgtype == "FTI0811") || (Msgtype == "FT811  ") || (Msgtype == "FTR811Y") )
            {
                string Imad = "";
                pos = buffer.IndexOf("{1520}");  // must be here
                if (pos != -1)
                    Imad = buffer.Substring(pos + 6, 22);
                pos = buffer.IndexOf("{2000}");
                decimal amt = 0;
                try  // In case amount is screwed up
                {
                    if (pos != -1)
                        amt = Convert.ToDecimal(buffer.Substring(pos + 6, 12)) / 100;
                }
                catch { }
                if (CheckGaps == "Y")
                {
                    pos = buffer.IndexOf("{1500}");  // must be here
                    if ((pos != -1) && (buffer.Substring(pos + 18, 1) != "P")) // P - is for resends (possible DUP)
                    {
                        string SeqNo = buffer.Substring(pos + 22, 6);
                        Cmd = "select MAX(SeqNo) from IMAD where CycleDate = '" + Imad.Substring(0, 8) +
                        "' and Lterm = '" + Imad.Substring(8, 8) + "';";
                        int Sn = 0;
                        if (writeConnection.OpenDataReader(Cmd))
                        {
                            writeConnection.SQLDR.Read();
                            try
                            {
                                Sn = writeConnection.SQLDR.GetInt32(0);
                            }
                            catch (Exception)
                            {
                            }
                        }
                        Sn++;
                        writeConnection.CloseDataReader();
                        if (Sn < Convert.ToInt32(Imad.Substring(16, 6)))
                        {
                            string nakstr = "H/054/GAP IN SEQNO";
                            string msg = NakFedMsg(ApplId, nakstr);
                            pos = buffer.IndexOf("{1500}");
                            string msg1 = buffer.Substring(pos, buffer.Length - pos);
                            string prio = "0";
                            Cmd = string.Format("insert into {0} (prio,msgcount,qbltext) values ('{1}',1,'{2}');", send_line, prio, m_pretxt2 + msg + msg1.Replace("'", "''"));
                            writeConnection.Execute(Cmd, true);
                            return 2;
                        }
                    }
                }

                if (CheckDup == "Y")
                {
                    pos = buffer.IndexOf("{1520}");  // must be here
                    Cmd = "select * from IMAD where CycleDate = '" + Imad.Substring(0, 8) +
                    "' and Lterm = '" + Imad.Substring(8, 8) + "' and SeqNo = " + Imad.Substring(16, 6) + ";";
                    writeConnection.OpenDataReader(Cmd);
                    bool hasRows = writeConnection.SQLDR.HasRows;
                    writeConnection.CloseDataReader();
                    if (hasRows)  //reject as dup
                    {
                        string nakstr = "X/035/DUPLICATE IMAD";
                        string msg = NakFedMsg(ApplId, nakstr);
                        pos = buffer.IndexOf("{1500}");
                        string msg1 = buffer.Substring(pos, buffer.Length - pos);
                        string prio = "0";
                        Cmd = string.Format("insert into {0} (prio,msgcount,qbltext) values ('{1}',1,'{2}');", send_line, prio, m_pretxt2 + msg + msg1.Replace("'", "''"));
                        writeConnection.Execute(Cmd, true);
                        return 2;
                    }
                }
                if (Imad != "")
                {
                    Cmd = string.Format("insert into IMAD (cycledate,lterm,seqno,amount,status,acked) values ('{0}', '{1}', {2}, {3}, ' ', 'N');",
                    Imad.Substring(0, 8), Imad.Substring(8, 8), Imad.Substring(16, 6), amt);
                    writeConnection.Execute(Cmd, false);
                }
                // Place the msg into FedReceiveAckQue.
                Cmd = string.Format("insert into FedReceiveAckQue (LineName, Nak, Tag, ErrCode, ErrDesc, MsgText) values('{0}', ' ', ' ', ' ',' ','{1}');", LineName, buffer.Replace("'", "''"));
                writeConnection.Execute(Cmd, true);
            }
            else  // it is non-payment try to create a response
            {
                string msg = ProcessNonAcctns(writeConnection, readConnection, Lterm, CycleDate, Aba, buffer, Msgtype, send_line);
                if (msg.Length != 0)
                {
                    // Insert to the lnk outbound
                    string prio = "0";
                    Cmd = string.Format("insert into {0} (prio,msgcount,qbltext) values ('{1}',1,'{2}')", send_line, prio, msg);
                    writeConnection.Execute(Cmd, true);
                }
                return 2;
            }
            return 1;
        }

        private string pad_spaces(string buf, int len)
        {
            int no_to_add = len - buf.Length;
            string retbuf = buf;
            if (no_to_add < 1)
                return retbuf;
            for (int i = 0; i < no_to_add; i++)
                retbuf += " ";
            return retbuf;
        }

        private string ProcessNonAcctns(DBAccess writeConnection, DBAccess readConnection, string Lterm, string CycleDate, string Aba, string MsgBody, string Msgtype, string LineName)
        {
            string m_Txt;
            int CreditCnt, DebitCnt;
            decimal OpenBal, DebitCap, FundsCol, CreditAmt, DebitAmt, Net, Bal, AvailBal;
            string Cmd = string.Format("select * from FedControl");
            string BankName;
            acktxt.Length = 0;
            using (SqlCommand sqlCommand = new SqlCommand(Cmd, writeConnection.Connection))
            {
                using (SqlDataReader SQLDR = sqlCommand.ExecuteReader())
                {
                    SQLDR.Read();
                    BankName = SQLDR["BankName"].ToString().TrimEnd();
                    OpenBal = SQLDR.GetDecimal(7);
                    DebitCap = SQLDR.GetDecimal(8);
                    FundsCol = SQLDR.GetDecimal(9);
                    CreditAmt = SQLDR.GetDecimal(10);
                    CreditCnt = SQLDR.GetInt32(11);
                    DebitAmt = SQLDR.GetDecimal(12);
                    DebitCnt = SQLDR.GetInt32(13);
                }
            }
            Net = CreditAmt - DebitAmt;
            Bal = Net + OpenBal;
            AvailBal = Bal + DebitCap + FundsCol;
            NumberFormatInfo myNfi = new NumberFormatInfo();
            myNfi.NumberNegativePattern = 3;

            switch (Msgtype)
            {
                case "FTIABAL":	// Request for ABAL report
                    int hl = 23;
                    byte[] hlb = BitConverter.GetBytes(hl);
                    string byte1 = Encoding.ASCII.GetString(hlb, 0, 1);
                    acktxt.Append(byte1);
                    acktxt.Append(m_pretxt3);
                    //  acktxt.Append(pad_spaces("FTNBAL", 79));
                    //                    acktxt.Append(pad_spaces("22000114FTNBAL  01 07925", 79));
                    acktxt.Append("22000114FTNBAL  01 07925");
                    m_Txt = string.Format(
                        //1PAGE   1*  12/28/06 10:38:37  ABMS BALANCE         BAL TYPE: MASTER  12/28/2006
        "1PAGE   1*  {0:MM/dd/yy hh:mm:ss}  ABMS BALANCE        BAL TYPE: MASTER  {1:MM/dd/yyyy}",
                        DateTime.Now, DateTime.Now);
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    m_Txt = string.Format(
                        //Z           12/28/06 CC1  TEST
        "Z           {0:MM/dd/yy} CC1  TEST", DateTime.Now);
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    m_Txt = string.Format(
                        //2INQUIRY ABA: 021000018    REPORTED ABA: 021000018  BANK OF NEW YORK
        "2INQUIRY ABA: {0}    REPORTED ABA: {0}  {1}", Aba, BankName);
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    acktxt.Append(pad_spaces("Z", 80));
                    acktxt.Append(pad_spaces("Z         STATUS            DEBIT               CREDIT               NET", 80));
                    m_Txt = string.Format(
                        //3OPEN BAL: 10:03 F                                                19,026,319.95
        "3OPEN BAL: 10:00 F                                        {0,21}", OpenBal.ToString("N", myNfi));
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    m_Txt = string.Format(
                        //4FNDS ($): 00:00                 0.00       746,860,474.63       746,860,474.63
        "4FNDS ($): 00:00 {0,20} {1,20} {2,21}",
            DebitAmt.ToString("N", myNfi), CreditAmt.ToString("N", myNfi), Net.ToString("N", myNfi));
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    m_Txt = string.Format(
                        //5     (#):                       0                  104"
        "5     (#):                 {0,7}              {1,7}", DebitCnt.ToString("D"), CreditCnt.ToString("D"));
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    acktxt.Append(pad_spaces("8NSS     : 00:00                 0.00                 0.00                 0.00", 80));
                    acktxt.Append(pad_spaces("6SEC  ($): 00:00                 0.00                 0.00                 0.00", 80));
                    acktxt.Append(pad_spaces("7     (#):                       0                    0", 80));
                    acktxt.Append(pad_spaces("AOTHR AVL: 00:00                 0.00                 0.00                 0.00", 80));
                    m_Txt = string.Format(
                        //BDLOD BAL:      --------------------------------------->         765,886,794
        "BDLOD BAL:      --------------------------------------->  {0,21}", Bal.ToString("N", myNfi));
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    acktxt.Append(pad_spaces("CNON  AVL: 00:00                 0.00                 0.00                 0.00", 80));
                    m_Txt = string.Format(
                        //DACCT BAL:      --------------------------------------->         765,886,794.58
        "DACCT BAL:      --------------------------------------->  {0,21}", Bal.ToString("N", myNfi));
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    acktxt.Append(pad_spaces("EMEMOPOST: 00:00                 0.00                 0.00                 0.00", 80));
                    m_Txt = string.Format(
                        //FDEBITCAP: 03/08                         13,384,040,625.00    13,384,040,625.00
        "FDEBITCAP: 03/08                      {0,20} {0:21}", DebitCap.ToString("N", myNfi));
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    m_Txt = string.Format(
                        //GFND COLL: 03/08                          6,615,959,375.00     6,615,959,375.00
        "GFND COLL: 03/08                      {0,20} {0:21}", FundsCol.ToString("N", myNfi));
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    acktxt.Append(pad_spaces("HSEC COLL: 12/12                                      0.00                 0.00", 80));
                    m_Txt = string.Format(
                        //IAVL FNDS: DLOD --------------------------------------->      20,765,886,794.58
        "IAVL FNDS: DLOD --------------------------------------->   {0,21}", AvailBal.ToString("N", myNfi));
                    acktxt.Append(pad_spaces(m_Txt, 80));
                    acktxt.Append(pad_spaces("Z", 80));
                    acktxt.Append(pad_spaces("Z", 80));

                    break;

                case "FTI0042":	// Request for Short Ack    FTI0042 X25000443LTERM123      000001000010
                    return "";
                default:
                    return "";
            }
            string msg = Convert.ToString(acktxt);
            msg = msg.Replace("'", "''");
            return msg;
        }

        private string NakFedMsg(string ApplId, string nakstr)
        {
            string err_cat = nakstr.Substring(0, 1);
            int pos = nakstr.IndexOf("/", 2);
            string err_code = nakstr.Substring(2, 3);
            string err_desc = nakstr.Substring(6);
            string dd = string.Format("{0:MMddhhmm}", DateTime.Now);
            string retstr = "{1100}" +m_pretxt4 + " 3{1110}" + dd + ApplId + "{1130}" + err_cat + err_code + err_desc + "*";
            return retstr;
        }

        public bool WritetoFile(DBAccess m_Connection, StreamWriter sw, string linename)
        {
            string Cmd = string.Format("select MsgText from FedReceiveAckQue where LineName='{0}'", linename);
            //			m_Connection=new DBAccess();
            //			m_Connection.Connect(false,area);
            using (SqlCommand sqlCommand = new SqlCommand(Cmd, m_Connection.Connection))
            {
                using (SqlDataReader SQLDR = sqlCommand.ExecuteReader())
                {
                    while (SQLDR.Read())
                    {
                        string msgbody = SQLDR["Msgtext"].ToString().TrimEnd();
                        msgbody += "\n";
                        sw.Write(msgbody);
                    }
                }
            }
            return true;
        }

        public void MakeFinalMsg(DBAccess m_Connection, DBAccess m_ReadConnection, string linename, string RuleNak, string DoEdits, string ApplId)
        {
            ArrayList ackEntryList = new ArrayList();
            AckNakProcess m_rules = new AckNakProcess();
            DoEdits m_edits = new DoEdits();
            string Cmd = string.Format("select msgtext,nak,tag,ErrCode,ErrDesc from FedReceiveAckQue where linename='{0}'", linename);

            string nakmsg = "";
            using (SqlCommand sqlCommand = new SqlCommand(Cmd, m_Connection.Connection))
            {
                using (SqlDataReader SQLDR = sqlCommand.ExecuteReader())
                {
                    while (SQLDR.Read())
                    {
                        string[] ackEntry = new string[5];
                        ackEntry[0] = SQLDR["Nak"].ToString().TrimEnd();
                        ackEntry[1] = SQLDR["Tag"].ToString().TrimEnd();
                        ackEntry[2] = SQLDR["ErrCode"].ToString().TrimEnd();
                        ackEntry[3] = SQLDR["MsgText"].ToString().TrimEnd();
                        ackEntry[4] = SQLDR["ErrDesc"].ToString().TrimEnd();
                        ackEntryList.Add(ackEntry);
                    }
                }
            }

            int entryCount = ackEntryList.Count;
            for (int index = 0; index < entryCount; index++)
            {
                string[] ackEntry = (string[])ackEntryList[index];
                string nak = ackEntry[0];
                string tag = ackEntry[1];
                string err_code = ackEntry[2];
                string msgbody = ackEntry[3];
                string errdesc = ackEntry[4];

                bool editfailed = false;

                if (DoEdits == "Y")
                {
                    string nakstr = m_edits.Edits(m_ReadConnection, "FED", msgbody);
                    if (nakstr != "")	// failed edit field rules
                    {
                        nakmsg = NakFedMsg(ApplId, nakstr);
                        editfailed = true;
                    }
                }
                if (!editfailed)
                {
                    if (!(RuleNak == "")) //Apply rules that are specified in the table
                    {
                        string rtn = m_rules.CheckAckRules(m_Connection, msgbody, RuleNak, "FED");
                        if (rtn.Length > 0)
                            nakmsg = NakFedMsg(ApplId, rtn);
                    }
                    else
                    {
                        if (nak == "Y")
                        {
                            if (!(tag == ""))
                                errdesc = "TAG " + tag + " " + errdesc;
                            nakmsg = err_code + " " + errdesc + "*";
                        }
                    }
                }

                int pos = msgbody.IndexOf("{2000}");
                decimal amt = 0;
                if (!editfailed)  // update totals ONLY if edits are successful
                {
                    try  // Incase amount is screwed up
                    {
                        if (pos != -1)
                            amt = Convert.ToDecimal(msgbody.Substring(pos + 6, 12)) / 100;
                        Cmd = string.Format("exec FedSndUpd {0}", amt);
                        if (m_Connection.OpenDataReader(Cmd))
                        {
                            m_Connection.SQLDR.Read();
                            decimal Qblid = m_Connection.SQLDR.GetSqlMoney(0).ToDecimal();
                            m_Connection.CloseDataReader();
                        }
                    }
                    catch { }
                }

                string Imad = "";
                pos = msgbody.IndexOf("{1520}");  // must be here
                if (pos != -1)
                    Imad = msgbody.Substring(pos + 6, 22);
                string Stat = "2";
                if (nakmsg.Length > 0)
                    Stat = "3";
                Cmd = "update IMAD set Status='" + Stat + "', Acked= 'N' where CycleDate = '" + Imad.Substring(0, 8) +
                "' and Lterm = '" + Imad.Substring(8, 8) + "' and SeqNo = " + Imad.Substring(16, 6) + ";";
                m_Connection.Execute(Cmd, false);
                if (nakmsg.Length > 0)
                {
                    string prio = "0";
                    string SendLine = linename.Replace("OUT", "IN");
                    pos = msgbody.IndexOf("{1500}");
                    string msg1 = msgbody.Substring(pos, msgbody.Length - pos);
                    Cmd = string.Format("insert into {0} (prio,msgcount,qbltext) values ('{1}',1,'{2}');", SendLine, prio, m_pretxt2 + nakmsg + msg1.Replace("'", "''"));
                    m_Connection.Execute(Cmd, false);
                }
                else  // Ack msg
                {
                    string prio = "0";
                    string SendLine = linename.Replace("OUT", "IN");
                    pos = msgbody.IndexOf("{1500}");  // must be here
                    string s1 = msgbody.Substring(pos + 8, 8);
                    pos = msgbody.IndexOf("{1520}");  // must be here
                    string s2 = msgbody.Substring(pos + 10, 18);
                    string sts = "2";  //Indicates accepted accounting. Possible values: see below.
                    m_ackseq++;
// citiba                    string Ack = "        MIDNAME1 FTFR12" + s1 + s2 + string.Format("{0:MMddhhmm}", DateTime.Now) + ApplId + sts + "Simulated Ack";
		    string s3 = " "+s2.Substring(0,4)+"LTERMOBK"+string.Format("{0:000000}",m_ackseq)+string.Format("{0:MMddhhmm}", DateTime.Now)+ApplId+sts+string.Format("{0:0000000}",m_ackseq);
                    string Ack = m_pretxt2 + s1 + s2 + string.Format("{0:MMddhhmm}", DateTime.Now) + ApplId + sts + s3;
                    Cmd = string.Format("insert into {0} (prio,msgcount,qbltext) values ('{1}',1,'{2}');", SendLine, prio, Ack.Replace("'", "''"));
                    m_Connection.Execute(Cmd, false);
                }
            };

            return;
        }
        /*
        MSG_INTERCEPTED = '0';
        MSG_NOT_RECEIVED = '1';
        MSG_ACCPTED_ACCTG = '2';
        MSG_ACCPTED_NOACCTG = '7';
        MSG_REJECTED = '3';
        MSG_SKIPPED = '4';
        MSG_RETURNED = 'R';
        MSG_INCFXFR = 'N';
        MSG_INCSVCFXFR = 'S';
        MSG_ACCPTED_ZERO_PAYMENT = '8';	//SEC001
        MSG_NULL_STATUS = '~';		//CSF001
        */


        public string FmtMsg(DBAccess m_Connection, ArrayList msgs, string Lterm, string send_line)
        {
            string finalmsg = string.Empty;
            fedmsg.Length = 0;

            string Cmd = string.Format("select * from FedControl");
            string m_Gen_omad = "";
            string m_Change_cycledate = "";
            DateTime m_CycleDate;
            using (SqlCommand sqlCommand = new SqlCommand(Cmd, m_Connection.Connection))
            {
                using (SqlDataReader SQLDR = sqlCommand.ExecuteReader())
                {
                    SQLDR.Read();
                    m_Gen_omad = SQLDR["GenOmad"].ToString().TrimEnd();
                    m_Change_cycledate = SQLDR["ChangeCDate"].ToString().TrimEnd();
                    m_CycleDate = SQLDR.GetDateTime(1);
                }
            }


            for (int i = 0; i < msgs.Count; i++)
            {
                fedmsg.Length = 0;
                msg_array next_msg = (msg_array)msgs[i];
                string Part1 = "", Part2 = "";
                int pos = next_msg.qbltext.ToString().IndexOf("{1510}");
                if (pos == -1)
                    return (finalmsg);  // return null. ALL msgs should have 1510 fields.
                Part2 = next_msg.qbltext.ToString().Substring(pos, next_msg.qbltext.Length - pos);
                Part1 = "{1100}"+m_pretxt4+" N";   // Test msg
                pos = next_msg.qbltext.ToString().IndexOf("{1110}");
                Part1 += next_msg.qbltext.Substring(pos, 18);
                Part1 += "{1120}";
                pos = next_msg.qbltext.ToString().IndexOf("{1120}");
                if (m_Change_cycledate == "Y")
                    Part1 += string.Format("{0:yyyyMMdd}", m_CycleDate);
                else
                    Part1 += next_msg.qbltext.Substring(pos + 6, 8);
                Part1 += Lterm;
                if (m_Gen_omad == "Y")
                {
                    Part1 += "======";  // Link substitutes it with Seq#
                    Part1 += next_msg.qbltext.Substring(pos + 28, 12);
                }
                else
                    Part1 += next_msg.qbltext.Substring(pos + 22, 18);
                pos = Part2.IndexOf("{1520}");	//IMAD. 
                if (pos != -1)
                {
                    string oldImad = Part2.Substring(pos, 28);
                    string newImad = "{1520}" + string.Format("{0:yyyyMMdd}", m_CycleDate) + oldImad.Substring(14, 8) + "======";
                    Part2 = Part2.Replace(oldImad, newImad);
                }
                finalmsg = m_pretxt1 + Part1 + Part2;
                finalmsg = finalmsg.Replace("'", "''");
            }
            return (finalmsg);
        }
        #region IDisposable Members

        public void Dispose()
        {
            // TODO:  Add ChpFormatter.Dispose implementation
            //			m_Connection.Dispose();
        }

        #endregion
    }
}