/*                                                             
 Copyright (c) 1999 - 2012 by EFT Technologies, Inc.
 All rights reserved.

 This Software is confidential and proprietary to 
 EFT Technologies and it is protected by U.S. copyright law, 
 other national copyright laws, and international treaties.
 The Software may not be disclosed or reproduced in whole or in part in any manner to 
 any third party without the express prior written consent of 
 EFT Technologies, Inc.                                      
                                                                
 This Software and its related Documentation are proprietary
 and confidential material of EFT Technologies, Inc.
 * 
 * 
 * 28-Nov-15   JR  Synch code between Jacob and John
 * 
*/
using System;
using System.IO;
using System.Text;
using System.Data;
using System.Collections;
using Simulator.DBLibrary;
using Simulator.Interfaces;
using Simulator.MQClass;
using System.Timers;
using Simulator.QueueInterface;
using System.Data.SqlClient;

namespace Fedlink
{
	class Fedlink
	{
		private DBAccess m_Connection;

		private string m_Area;
		private string m_LineName;
		private string m_QueueName;
		private string m_channel;
		private string m_RcvQueueName;
		private string m_ProcName;
        private enum SndRcv {Send, Receive};
        private SndRcv m_SndRcv;
        private System.Timers.Timer _Timer;
        private int _TimeOut;
        private bool m_SndAwait;
        private bool m_RcvAwait;
        private SynchInterface m_transportConnection;		// interface to mq classes
        private bool m_TimedOut;


		int m_CurrentSequence;// Current link sequence
		int m_OutSeqNo;  // Output sequence #
		int m_NumberofQueueItemstoCache;
		QueueInterface m_QI;

		// MQ specific stuff

		string m_inputQueueName;
        string m_outputQueueName;
        string m_outputQueueName1;
        string m_queueMgrName;
		
		int m_ReadTimeout;
		bool Show;

		[STAThread]
		static void Main(string[] args)
		{
			Fedlink cl=new Fedlink();
			cl.Run(args);
		}

		private void Run(string[] args)
		{
			if(args.Length < 2)
			{
				Console.Write("Correct syntax for invoking this executable is Area LineName Show(Steps Y/N)\r\n");
				return;
			}

			m_QI = null;
			m_Area = args[0];
			m_LineName = args[1];			// as in FedLnknn
			try
			{
				if (args[2] == "Y")
					Show = true;
				else
					Show = false;
			}
			catch
			{
				Show = false;
			}
			m_Connection=new DBAccess();
			m_Connection.Connect(true,m_Area);
			m_NumberofQueueItemstoCache=10;
			m_QueueName="LNK_"+m_LineName;
			m_RcvQueueName = "RCV_"+m_LineName;
			m_ProcName="Fed"+"_"+m_Area+"_"+m_LineName;
            m_SndAwait = false;
            m_RcvAwait = false;
            m_ReadTimeout = 0;
            m_SndRcv = SndRcv.Receive; // Start with Rcv. We'll wait for MTS to wake us up for now till I'll find out the protocol
            _TimeOut = 3000; // 3 sec. Time to rcv or send msgs before switching to another mode
			GetLineContext();
			MsgLoop();
	}


	private void MsgLoop()
	{
		if (Show)
			Console.WriteLine ("Starting");
        _Timer = new System.Timers.Timer();
        _Timer.Elapsed += new ElapsedEventHandler(OnTimerEvent);
        _Timer.Interval = _TimeOut;	 // Set to 3 seconds. Interval to switch between modes while doing heavy Snd/Rcv
        _Timer.AutoReset = false;
        _Timer.Stop();
        for (; ;)
		{
			try
			{
// Init all variables.
				m_transportConnection = new SimMQ(m_Area, m_queueMgrName,m_channel);
				Console.WriteLine("Connecting");
                // m_outputQueueName - is advice queue. We insert only payments there. The rest goes to Name1.
                // Name 1 contains short acks, reports including ABAL. We are going to use Prio field to seperate
                // msgs. Prio - 0 goes to Name1 queue, Prio - 1 to Name queue.
                		if (m_transportConnection.Connect(m_inputQueueName, m_outputQueueName, m_outputQueueName1))
                    			Link_process();
				else
				{
                    			Console.WriteLine(string.Format("Line {0} cannot connect to mq address {0} and {1} or {2}", m_inputQueueName, m_outputQueueName, m_outputQueueName1));
					break;
				}
			}
			catch (Exception ex)
			{
				Console.Write(string.Format("Problem connecting to MQ for line {0},Error {1}",m_LineName,ex));
				break;
			}
            /* Logic of how to start the session is to be determined.
            // The problems:
                1. If we come up and start sending we have no idea if MTS is UP and receiveing.
             *     In this case we can send everything we've got while the other side is down.
             *  2. If we are waiting for a msg from MTS to start a session then we could get into
             *      a situation when MTS must send someting to activate a session. It could be a problem.
             *  So, We need to determine the protocol and how to make sure that MTS wants to talk.
            */
			m_ReadTimeout = 0; // next read sits forever until the other side activates
			m_transportConnection.DisConnect();
		}
	}
	
	private void Link_process()
	{

        bool stat=false;
		for (;;)   //loop until the other side is inactive.
		{
            if (m_ReadTimeout > 0)  // Don't start timer first time before MTS starts to talk.
            {
                _Timer.Start();
                if (Show)
                    Console.WriteLine("Timer Started.");
	    }
            m_TimedOut = false;
            switch (m_SndRcv)
            {
                case SndRcv.Receive:
                    { stat = Rcv_msgs(); }
                    break;
                case SndRcv.Send:
                    { stat = Send_msgs(); }
                    break;
            }
            _Timer.Stop();
            if (m_ReadTimeout == 0) // indicates that line dropped and we need to disconnect
                break;  // back to main loop. Awaiting connection.

            if (stat) // We successfully Snd or Rcv msgs. NOT Timed out while receiving or ran out of msgs to send.
            {
                switch (m_SndRcv)
                {
                    case SndRcv.Receive:
                        { m_RcvAwait = true; }
                        break;
                    case SndRcv.Send:
                        { m_SndAwait = true; }
                        break;
                }
            }
            else
            {
                switch (m_SndRcv)
                {
                    case SndRcv.Receive:
                        {
                            m_RcvAwait = false;
                            if (!m_SndAwait)  // we timedout on receive. If nothing awaiting to be sent then sleep
                                System.Threading.Thread.Sleep(1000);
                        }
                        break;
                    case SndRcv.Send:
                        {
                            m_SndAwait = false;
                            if (!m_RcvAwait)  // we timedout on receive. If nothing awaiting to be received then sleep
                                System.Threading.Thread.Sleep(1000);
                        }
                        break;
                }
            }
            switch (m_SndRcv)
            {
                case SndRcv.Receive:
                    { m_SndRcv = SndRcv.Send; }
                    break;
                case SndRcv.Send:
                    { m_SndRcv = SndRcv.Receive; }
                    break;
            }
            
		}
	}
	
    private bool Rcv_msgs()
    {
        if (Show)
           Console.WriteLine("Receiving msgs.");
       // m_ReadTimeout = 1; // DELETE !!!!!!!!!!!   Test in ct
    	for ( ; ; )
    	{
        string readBuffer = "";
        try
        {
            if (m_transportConnection.Read(ref readBuffer, m_ReadTimeout))	// First time around we wait for MTS to wake us up
            {
                if (Show)
		    Console.WriteLine ("Receiving  - {0}",readBuffer);
		if ( readBuffer.IndexOf("Wake up FED Line") != -1 )  // User wants to send regardless . Up to user to monitor the MQ
		{
			m_ReadTimeout = 1;
		}
		else
		{
	                m_CurrentSequence++;
	                m_Connection.Execute(string.Format("update linkcontrol set NextSeqNo={0} where LineName='{1}'", m_CurrentSequence, m_LineName), false);
	                int pos = readBuffer.IndexOf("FT");
	                string Cmd = string.Format("insert into {0} (qbltext) values ('{1}')", m_RcvQueueName, readBuffer.Substring(pos,readBuffer.Length-pos).Replace("'", "''"));
	                m_Connection.Execute(Cmd, true);
	                m_ReadTimeout = 1; // Set timeout for MQ read until line drops.
                }
            }
            else  // Empty MQ read
            {
                if (Show)
                    Console.WriteLine("Nothing to receive.");
                return false;
            }
        }
        catch (Exception e)
        {
            if (Show)
                    Console.WriteLine("Error received from Rcv_msg. Error- {0}", e.ToString());
            m_Connection.RecordEvent(1, m_ProcName, string.Format("{0}:Read error in link {1}. Error - {2}", DateTime.Now, m_LineName, e.ToString()), m_Area);
            m_ReadTimeout = 0; // indicates that line dropped and we need to disconnect
            return false;
        }
        if (m_TimedOut)
        {
                if (Show)
                    Console.WriteLine("Timed Out on Receive.");
                break;
        }
        }
        return true;
    }

	private bool Send_msgs()
	{
                if (Show)
                    Console.WriteLine("Sending msgs.");
		if(m_QI == null)
			m_QI = new QueueInterface("LNK_"+m_LineName,m_NumberofQueueItemstoCache,m_Area);
		string qblText;
		int qblId=0;
		int qblPriority=0;
		if (Show)
			Console.WriteLine ("Send routine. Step in");
		for(;;)
		{
			for(int index=0;index < m_NumberofQueueItemstoCache;index++)
			{
				QueueItem qi= m_QI.getQueueItem();
				if(qi==null)
				{
					if (Show)
						Console.WriteLine ("Send routine. Nothing to send");
                    return false;
                }
				qblText = qi.Text;
				qblId = qi.Qblid;
                qblPriority = qi.Priority;
                if (qblPriority == 1)  // increment only for advices (aka payments)
                {
                    string Cmd1 = string.Format("NewOutNumber");
                    //int m_OutSeqNo = 0;
                    using (SqlCommand sqlProc = new SqlCommand(Cmd1, m_Connection.Connection))
                    {
                        sqlProc.CommandType = CommandType.StoredProcedure;
                        sqlProc.Parameters.Add(new SqlParameter("@Line", SqlDbType.Char, 20, "Line"));
                        sqlProc.Parameters[0].Value = m_LineName;
                        using (SqlDataReader SQLDR = sqlProc.ExecuteReader())
                        {
                            SQLDR.Read();
                            m_OutSeqNo = SQLDR.GetInt32(0);
                        }
                    }
                }
				qblText = qblText.Replace("======", string.Format("{0:000000}", m_OutSeqNo));
				if(!m_transportConnection.Write(qblText, qblPriority))	// if write fails, flush transaction
				{
					m_Connection.RecordEvent(1,m_ProcName,string.Format("{0}:MQ write error in Fedlink {1}", DateTime.Now,m_LineName), m_Area);
                    m_ReadTimeout = 0; // indicates that line dropped and we need to disconnect
                    return false;			// and reconnect
				}
				if (Show)
					Console.WriteLine ("Sending - {0}",qblText);
				
// add usage of storeproc newosnnumber
                if (qblPriority == 1)
    				m_Connection.Execute(string.Format("update linkcontrol set OutSeqNo={0} where LineName='{1}'",m_OutSeqNo,m_LineName),false);
				m_Connection.Execute(string.Format("delete from {0} where qbl={1} and prio='{2}'",m_QueueName,qblId,qblPriority),true);
			}
		}		
	}
    private void OnTimerEvent(object source, ElapsedEventArgs e)
    {
        _Timer.Stop();
        m_TimedOut = true;
        if (m_SndRcv == SndRcv.Send)
            m_SndAwait = true;
        if (m_SndRcv == SndRcv.Receive)
            m_RcvAwait = true;
    }
#region commonstuff

	private void GetLineContext()
	{
        string Cmd = string.Format("select NextSeqNo, inputMQName,outputMQName,outputMQName1,MQMgrName,ConnChannel,OutSeqNo from LinkControl where linename= '{0}'", m_LineName);
		m_Connection.OpenDataReader(Cmd);
		m_Connection.SQLDR.Read();
		int colNdx=0;
		m_CurrentSequence=m_Connection.SQLDR.GetInt32(colNdx++);
		m_inputQueueName=m_Connection.SQLDR[colNdx++].ToString().TrimEnd().ToUpper();
	        m_outputQueueName = m_Connection.SQLDR[colNdx++].ToString().TrimEnd().ToUpper();
	        m_outputQueueName1 = m_Connection.SQLDR[colNdx++].ToString().TrimEnd().ToUpper();
	        m_queueMgrName = m_Connection.SQLDR[colNdx++].ToString().TrimEnd().ToUpper();
		m_channel=m_Connection.SQLDR[colNdx++].ToString().TrimEnd().ToUpper();
		m_OutSeqNo=m_Connection.SQLDR.GetInt32(colNdx++);
		m_Connection.CloseDataReader();
	}

#endregion
	}
}
