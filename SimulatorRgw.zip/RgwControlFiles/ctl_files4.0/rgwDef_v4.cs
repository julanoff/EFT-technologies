using System;
using System.Collections.Generic;
using System.Text;
using Simulator.dataDefs;
using Simulator.DBLibrary;

/*
 * 
 * 28-Nov-15    JR  Synch code between Jacob and John
 * 
 */

namespace dataDefs
{
    public class rgwDef_v4
    {
        /*
         * MTS 4.0 table definitions.
         */

        string dropMESSAGE = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE]";

        string dropMESSAGE_ACCTG = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_ACCTG]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_ACCTG]";


        string dropMESSAGE_CR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_CR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_CR]";


        string dropMESSAGE_DEST = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_DEST]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_DEST]";


        string dropMESSAGE_DR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_DR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_DR]";


        string dropMESSAGE_HIST = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_HIST]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_HIST]";


        string dropMESSAGE_PR = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR]";


        string dropMESSAGE_PR_MCH = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_MCH]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_MCH]";


        string dropMESSAGE_PR_PRM = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_PRM]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_PRM]";


        string dropMESSAGE_PR_PVL = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_PR_PVL]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_PR_PVL]";


        string dropMESSAGE_QUEUE = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_QUEUE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_QUEUE]";


        string dropMESSAGE_REL_AMT = "if exists (select * from dbo.sysobjects where id = " +
            "object_id(N'[dbo].[MESSAGE_REL_AMT]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
            "drop table [dbo].[MESSAGE_REL_AMT]";


        string dropMESSAGE_TEXT = "if exists (select * from dbo.sysobjects where id = " +
                "object_id(N'[dbo].[MESSAGE_TEXT]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
                "drop table [dbo].[MESSAGE_TEXT]";


        // MTS 4.0 tables.
        string[] MESSAGE = {
        "CREATE TABLE [dbo].[MESSAGE] (",
        "[TRN_DATE] [datetime] NULL ,",
        "[TRN_NUMBER] [int] NOT NULL ,",
        "[TRN_TIMESTAMP] [numeric] (23,0) NOT NULL ,",
        "[PROC_DATE] [datetime] NULL ,",
        "[BANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LOC] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAY_DATE] [datetime] NULL ,",
        "[PAY_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INST_DATE] [datetime] NULL ,",
        "[TRAN_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPETITIVE_ID] [varchar] (48) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SOURCE_CD] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INSTR_ADV_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BASE_AMOUNT] [numeric] (21,3) NULL ,",
        "[TYPE_CD] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SUBTYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IN_TYPE_CD] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IN_SUBTYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CHRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CHRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMMISSION] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_CHARGE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[WIRE_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STRAIGHT_THRU] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NETWORK_SND_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NETWORK_SND_ACC] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_ACC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CAN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_RISK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_AUTO] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_OVER] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CSTMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_DSTMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_LIM] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_RPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_NON_RPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALLBACK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FAIL_TST] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTV_LIM] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTV_CHNG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALL_NOF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MON_INTERCEPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCV_DATE] [datetime] NULL ,",
        "[RCV_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DLV_DATE] [datetime] NULL ,",
        "[DLV_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALLER] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DOC_NUM] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ITEM_NUM] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAN_MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAN_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CAL] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_RATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FX_TOLERANCE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_RATE] [numeric] (29,11) NULL ,",
        "[AMOUNT] [numeric] (21,3) NULL ,",
        "[CURRENCY_CODE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADER_CTRL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDS_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_IMAD] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_OMAD] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_ISN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_OSN] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_SSN_1] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHP_SSN_6] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_IN_MIR] [varchar] (28) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_OUT_MIR] [varchar] (28) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ENTRY_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VERIFY_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPAIR_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCEPT_PERSON] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TOT_AMT] [numeric] (21,3) NULL ,",
        "[CUSIP] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUSIP_DESC] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHECK_SEQ] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NO_PHNADV_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXC_MEMO] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAY_STATE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NOTIFY] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STOP_INTERCEPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELEASE_TIME_HH] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELEASE_TIME_MM] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRE_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FX_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COR_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RTE_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_LAST_NAME] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_FIRST_NAME] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OVER_DRAFT_AMT] [numeric] (21,3) NULL ,",
        "[DBT_CON_BANK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CON_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CON_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_BANK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CON_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SYS_OF_REC] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SYS_OF_REC] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PARENT_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PARENT_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RECEIPT_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FRONTEND_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_DADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AVAIL_BAL] [numeric] (21,3) NULL ,",
        "[LEDGER_BAL] [numeric] (21,3) NULL ,",
        "[OVER_TIMESTAMP] [datetime] NULL ,",
        "[RECORD_EXPIRED] [numeric] (23,0) NULL ,",
        "[RECORD_UPDATED] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_STATE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NEW_TRADE_STATE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_OPERATION] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OPERATION_SCOPE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_CUSTOMER] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BENE_INST4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PARTY_B] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND5] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TERM_COND6] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTACT_INFO4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_METHOD] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_BRANCH_PTYA] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEAL_BRANCH_PTYB] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_ID] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_COMISN] [numeric] (21,3) NULL ,",
        "[COUNTERPARTY_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BROKER_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORIG_MSG_DATE] [datetime] NULL ,",
        "[TRADE_PARTY_SUSP_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OTHER_PARTY_SUSP_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LAST_USED_DATE] [datetime] NULL ,",
        "[ORIG_INST_VAL_DATE] [datetime] NULL ,",
        "[TRADE_TYPE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_SUBTYPE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_BUY_SELL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRADE_UPDATE_PENDING_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORIG_EXCH_RATE] [numeric] (29,11) NULL ,",
        "[RECEIVE_CHAR_COUNT] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INCOMING_FORMAT] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INCOMING_REF] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDS_CATEGORY] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SEGMENT_INDEX] [numeric] (11,0) NULL ,",
        "[SPLIT_CTR] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPR_LEVEL] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[POST_DATE] [datetime] NULL ,",
        "[POST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SEND_DATE] [datetime] NULL ,",
        "[FEDFUND_TYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FED_DAYS] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INTEREST_RATE] [numeric] (7,5) NULL ,",
        "[ANT_TOL_AMT] [numeric] (21,3) NULL ,",
        "[CAL_OVR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PIN_REF_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFC_PIN_REF_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PHN_NOF_ID] [varchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TESTKEY_IN] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_TEXT] [varchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RISKINESS_IND] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMM_MODE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_MODE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADM_LOCK_TEXT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNK_TX_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULT_DBT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULT_CDT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AMT_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUR_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCH_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SERIAL_VFY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PDM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADV_OVR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_REQ_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SITE_OPTION1_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ACCT_VFC_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MULTI_CUR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIORITY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DELIVERY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RTP_INTERCEPT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DELAY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCHED_ANT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPAIR_CHNG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHIPS_RECVRY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NON_ACCTING_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SWF_STMT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHARGE_STATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFY_COUNT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_DBT_AUTH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_DBT_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_CDT_AUTH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_CDT_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TEST_STATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VFC_COUNT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDED_MSG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PMT_CHRG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INT_REROUTE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUR_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OVR_OUT_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FORCE_POST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPTD_SWF_STMT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHECK_FOUND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_DBT_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_CDT_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_BNP_ID] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_SRN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MATCH_SIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[UMBRELLA_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BANK_OPERATION_CODE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ACC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BIC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_DBT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_SBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_OBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ORP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_INS] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CDT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_IB1] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_IBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BBK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BNP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_BBI] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_OBI] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_DTE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_AMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CNF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_REG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_CRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_ADV] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_PRD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PMT_CHAR_CODE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUTOFF_OVERRIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXCHANGE_RATE_STAT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FOREX_BYPASS_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[GLOBAL_DEBIT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_PTY_SIDE_IND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FORCE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEFINITIVE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CANCELLED_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FIN_CPY_SRC_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SUPPR_PMT_CONF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ENTERED_SIDE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE] [datetime] NULL ,",
        "[DUE_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DUE_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE] [datetime] NULL ,",
        "[PRIME_SEND_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PRIME_SEND_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE] [datetime] NULL ,",
        "[SECOND_SEND_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SECOND_SEND_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REG_ID_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REG_ID] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BOPR_TEXT3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AUTH_REF] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MSG_STATE] [varchar] (23) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELATED_TRN_DATE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RELATED_TRN_NUM] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_POST_DATE] [datetime] NULL ,",
        "[CDT_POST_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OPERTNL_RLS_DATE] [datetime] NULL ,",
        "[OPERTNL_RLS_TIME] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RAMET_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NON_RET_VALVE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUTOFF_DONE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FOREX_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FEE_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EUR_BENE_CHRG_ALLOW] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[HIGH_MSG_STATE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMM_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_CHRG_ORG] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FTR_PROC_RULE_STATE] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[POSTAL_CODE_OVR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RPR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[EXC_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IMPOSED_AMOUNT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[GLOBAL_CREDIT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAYMNT_FUNDING_IND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAYMNT_ASYNCH_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PAYMNT_RESP_TIME] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MON_PER_INTERCEPT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MON_PER_LOG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SMPL_WRHS_INDICATOR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ENT_REF_SYS_VEC] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[WRHS_REF_SYS_VEC] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REF_CALL_VECTOR] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SMPL_PYMT_FORMAT] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CONTAINER_REJ_REASON] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[UNIQUE_REF] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SRGW_EXPORT_SERIAL] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MSGTYPE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHILDQ_CREATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FASTER_SENT_IND] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CTR_BTR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DIRECTION_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BLACKLIST_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[MPA_PDM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_IB2] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHG_IB3] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PARTY_3_PIN_REF_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PARTY_3_PIN_CALLER] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PROCESSING_WEIGHT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IMPOSED_CHANNEL] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[GENNED_AUTO_RETURN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ACH_SRC_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BISI_LINK_SRC] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RMSG_ORIG_TRN_DATE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RMSG_ORIG_TRN_REF] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RMSG_ORIG_REF] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RMSG_ORIG_CSTMREF] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RMSG_TRN_DATE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RMSG_TRN_REF] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RMSG_REF] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RMSG_CSTMREF] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ROW_ID] [numeric] (16,0) NULL ,",
        "[MSGSUBTYPE_ONEOF] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PREV_STOP_INTERCEPT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TIMEOUT_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORIG_EXCH_RATE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CALC_RATE_USED_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PSD_OVERRIDDEN_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORIG_BNP_CHG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",

        ") ON [PRIMARY]"};


        string[] MESSAGE_ACCTG = {
        "CREATE TABLE [dbo].[MESSAGE_ACCTG] (",
        "[TRN_DATE] [datetime] NULL ,",
        "[TRN_NUMBER] [int] NOT NULL ,",
        "[ACCTG_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ACCTG_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AMOUNT] [numeric] (21,3) NULL ,",
        "[STS_DBT_CDT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_CROSS_BANK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[STS_PRIMARY] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRN_TIMESTAMP] [numeric] (23,0) NOT NULL ,",
        "[PERIOD] [datetime] NULL ,",
        "[PROC_DATE] [datetime] NULL ,",
        "[BANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LOC] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[VALUE_DATE] [datetime] NULL ,",
        "[INST_DATE] [datetime] NULL ,",
        "[TRAN_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REPETITIVE_ID] [varchar] (48) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SOURCE_CD] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INSTR_ADV_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TYPE_CD] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SUBTYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IN_TYPE_CD] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IN_SUBTYPE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CHRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CHRG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COMMISSION] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CBL_CHARGE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[WIRE_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[TRAN_NAME_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADR_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADR_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ADR_SUBTYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SEC_ACCTG_FLG] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SEC_ACCTG_AMT] [numeric] (21,3) NULL ,",
        "[OFFSET_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OFFSET_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OFFSET_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[FUNDS_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ASC_AMOUNT] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ASC_SEC_AMT] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REC_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[LAST_ADDR] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_AUTH_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RECON_REF] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RECON_REF] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CUR_CODE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RECORD_EXPIRED] [numeric] (23,0) NULL ,",
        "[RECORD_UPDATED] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_CR = {
        "CREATE TABLE [dbo].[MESSAGE_CR] (",
        "[TRN_DATE] [datetime] NULL ,",
        "[TRN_NUMBER] [int] NOT NULL ,",
        "[TRN_TIMESTAMP] [numeric] (23,0) NOT NULL ,",
        "[CDT_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TRAN_NAME_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_SLASH] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACCTG_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DISTRICT] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_OFFICE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_SUBTYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_ACCTG_FLG] [numeric] (10,0) NULL ,",
        "[CDT_SEC_ACCTG_AMT] [numeric] (21,3) NULL ,",
        "[CDT_TER_ACCTG_FLG] [numeric] (10,0) NULL ,",
        "[CDT_TER_ACCTG_AMT] [numeric] (21,3) NULL ,",
        "[CDT_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_AMOUNT] [numeric] (21,3) NULL ,",
        "[CDT_CURRENCY] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SHNAM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RT_CODE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_SUB_ACCT] [varchar] (61) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_PROD_CODE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_DELIVERY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_PARENT] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RECON_REF] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CUSTOMER_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_BNK_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_CHARGE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_IB1_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEN_INF4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RECORD_EXPIRED] [numeric] (23,0) NULL ,",
        "[RECORD_UPDATED] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_CHIPS_UPTO] [numeric] (10,0) NULL ,",
        "[IB1_CHIPS_QUAL] [numeric] (10,0) NULL ,",
        "[IBK_CHIPS_UPTO] [numeric] (10,0) NULL ,",
        "[IBK_CHIPS_QUAL] [numeric] (10,0) NULL ,",
        "[BBK_CHIPS_UPTO] [numeric] (10,0) NULL ,",
        "[BBK_CHIPS_QUAL] [numeric] (10,0) NULL ,",
        "[BNP_CHIPS_UPTO] [numeric] (10,0) NULL ,",
        "[BNP_CHIPS_QUAL] [numeric] (10,0) NULL ,",
        "[CDT_CURRENCY_SUSP_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_EXCH_RATE] [numeric] (29,11) NULL ,",
        "[CDT_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ACC_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_CITY] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADV_TYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ADR_ADV_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_LOCATION] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RT_STATE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_WIR_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_WIR_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PYMNT_ADV_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PYMNT_PHN_TIME] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PYMNT_Q] [varchar] (65) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PAY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SECWIR_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ALT_SWIFT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_ID_CHG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_NOF_LOOKED_UP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PAYSYS_FMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_MAILING_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REGULATORY_REPORT1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REGULATORY_REPORT2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[REGULATORY_REPORT3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_AUTH_REF] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_VALUE_DATE] [datetime] NULL ,",
        "[CDT_VALUE_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_VALUE_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_VALUE_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_BOOK_DATE] [datetime] NULL ,",
        "[CDT_BOOK_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_BOOK_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_BOOK_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CREDITSIDE_RESIDENCY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PROFILE_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PROFILE_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PROFILE_IDACC] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PROFILE_IDADR] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PROFILE_IDPAD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IBK_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB1_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BBK_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_BILAT_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_BILAT_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_BILAT_IDKEY] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_IDKEY] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SEC_ACCTG_CUR] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TER_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TER_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TER_IDKEY] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_TER_ACCTG_CUR] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SPARE_ACC] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SPARE_ADR] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SPARE_PAD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_PROC_RULE_STATE] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SPC_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SPC_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_SPC_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CDT_COMM_CBL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_IB2_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_CHIPS_UPTO] [numeric] (10,0) NULL ,",
        "[IB2_CHIPS_QUAL] [numeric] (10,0) NULL ,",
        "[IB2_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_SECWIR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_IB3_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_ADV_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_ADV_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_ADV_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_CHIPS_UPTO] [numeric] (10,0) NULL ,",
        "[IB3_CHIPS_QUAL] [numeric] (10,0) NULL ,",
        "[IB3_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_ID_ONFILE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BNP_ADV_ID_CDTHOLD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB2_ADR_PTR_OK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IB3_ADR_PTR_OK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PSD_VALUE_DATE_CD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PSD_EXEC_TIME_CD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PSD_TARIF_CD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AUTRV_CHGD_CDT_ADR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_DEST = {
         "CREATE TABLE [dbo].[MESSAGE_DEST] (",
        "[TRN_DATE] [datetime] NULL ,",
        "[TRN_NUMBER] [int] NOT NULL ,",
        "[DST_ORDINAL] [numeric] (5,0) NULL ,",
        "[TRN_TIMESTAMP] [numeric] (23,0) NOT NULL ,",
        "[ALTERNATE_ACCT] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[COST_CENTER] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PARAM_1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[PARAM_2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IDENTIFIER] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_OVR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CARRIER] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_AREA_CODE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_DIAL] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SIGN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_MAC] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_ANS] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CAB2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CAB3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CAB4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CITY] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_QUE_BANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_QUE_LOC] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_QUE_NAME] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_ROUTE_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_DEPARTMENT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_RT_CODE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CHAR_COUNT] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_MULTI_SEQ] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_MULTI_START] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_MULTI_COUNT] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_OUT_TEST] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_PDM_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_STATE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_ATTN] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_TYPE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_AREA_CODE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_DIAL] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_SIGN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_MAC] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_ANS] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_CAB2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_CAB3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SEC_CAB4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_ACK_STATE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_NAK_STATE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_DELIVERY_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_ADR_LOCATION] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_3RD_PARTY_TST] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_FORMAT] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_MSGTYPE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CONN_TIME] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CHARGES] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CARRIER_REF] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_TER_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_TER_ID] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_TERTIARY_DEPT] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_MSG_COND] [numeric] (10,0) NULL ,",
        "[DST_MSG_TYPE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SRC_COND] [numeric] (10,0) NULL ,",
        "[DST_SRC_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_TIME] [datetime] NULL ,",
        "[DST_OUTGOING_REF] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_TEST_DATE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RECORD_EXPIRED] [numeric] (23,0) NULL ,",
        "[RECORD_UPDATED] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_FIN_COPY_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_119_HDR_DATA] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_CASC_NAME] [varchar] (33) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_SRV_MSG_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_INC_HDR_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_COPIES] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_NO_ACCT_STMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_PRECEDENCE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_ORIGIN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_113_HDR_DATA] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_EMAIL_ADDRESS] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DST_TYPE_INDICATOR] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_DR = {
        "CREATE TABLE [dbo].[MESSAGE_DR] (",
        "[TRN_DATE] [datetime] NULL ,",
        "[TRN_NUMBER] [int] NOT NULL ,",
        "[TRN_TIMESTAMP] [numeric] (23,0) NOT NULL ,",
        "[DBT_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_NAME_2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_NAME_3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_NAME_4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_NOF_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C1] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C2] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C3] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C4] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C5] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C6] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C7] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C8] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C9] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TRAN_NAME_C10] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_DEPT] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SERIAL] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_SLASH] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACCTG_ACCOUNT] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_DISTRICT] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_OFFICE] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_SUBTYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_ACCTG_FLG] [numeric] (10,0) NULL ,",
        "[DBT_SEC_ACCTG_AMT] [numeric] (21,3) NULL ,",
        "[DBT_TER_ACCTG_FLG] [numeric] (10,0) NULL ,",
        "[DBT_TER_ACCTG_AMT] [numeric] (21,3) NULL ,",
        "[DBT_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BAL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[CHIPS_LIM_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_GRP_BAL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PRE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_GRP_PRE_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_AMOUNT] [numeric] (21,3) NULL ,",
        "[DBT_CURRENCY] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RT_CODE] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF5] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BNK_INF6] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_SUB_ACCT] [varchar] (61) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_PROD_CODE] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TER_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TER_IDKEY] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_FEE_CODE] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RECON_REF] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ACC_PARENT_CD] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CUSTOMER_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_DRAFT_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_REF_NUM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RECORD_EXPIRED] [numeric] (23,0) NULL ,",
        "[RECORD_UPDATED] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_REL_ID] [numeric] (10,0) NULL ,",
        "[INS_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_REL_ID] [numeric] (10,0) NULL ,",
        "[RCA_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_NAME1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_NAME2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_NAME3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_NAME4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SHORT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_GROUP_SHORT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CROSS_SHORT_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_EXCH_RATE] [numeric] (29,11) NULL ,",
        "[DBT_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_CLASS] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADR_CITY] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ADV_TYP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RT_STATE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_WIR_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_WIR_ID] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_DRAWDOWN_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PS_ELIG_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_ITEM_HOLD_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_NOF_LOOKED_UP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CURRENCY_SUSP_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DDA_BALANCE] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[BALANCE_RISK] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_ADR_BNK_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_REL_ID] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_REF_NUM] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_STATE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_POSTAL_CODE] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_RES_COUNTRY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_AUTH_REF] [varchar] (34) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_VALUE_DATE] [datetime] NULL ,",
        "[DBT_VALUE_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_VALUE_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_VALUE_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BOOK_DATE] [datetime] NULL ,",
        "[DBT_BOOK_DATE_CHG] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BOOK_DATE_ADJ] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BOOK_DATE_SP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_CAMEFROM] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DEBITSIDE_RESIDENCY] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PROFILE_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PROFILE_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PROFILE_IDACC] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PROFILE_IDADR] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PROFILE_IDPAD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_PROFILE_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_PROFILE_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_PROFILE_IDACC] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_PROFILE_IDADR] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_PROFILE_IDPAD] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[OBK_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[INS_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[RCA_BEI_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BILAT_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BILAT_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_BILAT_IDKEY] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_IDTYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_IDKEY] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SEC_ACCTG_CUR] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TER_IDBANK] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_TER_ACCTG_CUR] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_IBAN] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PRULE_COPY] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_PRULE_COPY] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PROC_RULE_STATE] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[SBK_PROC_RULE_STATE] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SPC_INST1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SPC_INST2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_SPC_INST3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_COMM_CBL_FLG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[ORP_BNK] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[DBT_PSD_OSC] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[AUTRV_CHGD_DBT_ADR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[IS_COVER_PAYMENT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",

        ") ON [PRIMARY]"};


        string[] MESSAGE_HIST = {
        "CREATE TABLE [dbo].[MESSAGE_HIST] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Hist_No] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Sub_Hist_No] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Entry_Type] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Bank] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Que_Line_ID] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Date_Time] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Sequence_No] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Details] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Opr_Initials] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Amount] [numeric](21, 3) NULL ,",
        "[Msg_Info] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR = {
        "CREATE TABLE [dbo].[MESSAGE_PR] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Pr_ordinal] [numeric](10, 0) NULL ,",
        "[Pr_level] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_source] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_source_id] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_name] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_type] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_text] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Pr_effective_time] [datetime] NULL ,",
        "[Pr_expiration_time] [datetime] NULL ,",
        "[Pr_subtype] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR_MCH = { 
        "CREATE TABLE [dbo].[MESSAGE_PR_MCH] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prmatch_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Prmatch_cond] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Prmatch_value] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Prmatch_logical] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Prmatch_action] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_PR_PRM = {
        "CREATE TABLE [dbo].[MESSAGE_PR_PRM] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prparm_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_timestamp] [numeric](23, 0) NOT NULL ,",
        "[Prparm_edit] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Prparm_count] [numeric](10, 0) NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};

        string[] MESSAGE_PR_PVL = {
        "CREATE TABLE [dbo].[MESSAGE_PR_PVL] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Pr_seq_num] [numeric](10, 0) NOT NULL ,",
        "[Prparm_id] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Value_seq_num] [numeric](10, 0) NOT NULL ,",
        "[TRN_timestamp] [numeric](23, 0) NOT NULL ,",
        "[Parameter_values] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_QUEUE = {
         "CREATE TABLE [dbo].[MESSAGE_QUEUE] (",
        "[Queue_Prod_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Bank_ID] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Loc] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Cust] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Queue_Name] [varchar] (33) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[TRN_Timestamp] [datetime] NOT NULL ,",
        "[Record_Expired] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Future_date] [datetime] NULL ,",
        "[Rls_action] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_REL_AMT = {
         "CREATE TABLE [dbo].[MESSAGE_REL_AMT] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Sequence_no] [numeric](10, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Amt_Codeword] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Amount] [numeric](21, 3) NULL ,",
        "[Curr] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Memo] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] MESSAGE_TEXT = {
        "CREATE TABLE [dbo].[MESSAGE_TEXT] (",
        "[TRN_Date] [datetime] NOT NULL ,",
        "[TRN_Number] [int] NOT NULL ,",
        "[Text_Type] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,",
        "[Sequence_no] [numeric](10, 0) NOT NULL ,",
        "[Dst_ordinal] [numeric](5, 0) NOT NULL ,",
        "[TRN_Timestamp] [numeric](23, 0) NOT NULL ,",
        "[Message_text] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,",
        "[Record_Expired] [numeric](23, 0) NULL ,",
        "[Record_Updated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ",
        ") ON [PRIMARY]"};


        string[] createIndex = {
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_REL_AMT] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_ACCTG] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_CR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_DEST] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_DR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_HIST] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",	
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_MCH] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_PRM] ([TRN_Date], [TRN_Number]) ON [PRIMARY];	",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_PR_PVL] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_QUEUE] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",
            "create INDEX [TrnIndex] ON [dbo].[MESSAGE_TEXT] ([TRN_Date], [TRN_Number]) ON [PRIMARY];",

            "create  INDEX [Bank] ON [dbo].[MESSAGE]([BANK]) ON [PRIMARY]",
            "create  INDEX [Source_cd] ON [dbo].[MESSAGE]([SOURCE_CD]) ON [PRIMARY]",
            "create  INDEX [Base_Amount] ON [dbo].[MESSAGE]([BASE_AMOUNT]) ON [PRIMARY]",
            "create  INDEX [Amount] ON [dbo].[MESSAGE]([AMOUNT]) ON [PRIMARY]",
            "create  INDEX [ReceiveTime] ON [dbo].[MESSAGE]([RCV_DATE], [RCV_TIME]) ON [PRIMARY]",
            "create  INDEX [TranType] ON [dbo].[MESSAGE]([TRAN_TYPE]) ON [PRIMARY]",
            "create  INDEX [AdviceType] ON [dbo].[MESSAGE]([INSTR_ADV_TYPE]) ON [PRIMARY]",
            "create  INDEX [CurrencyCode] ON [dbo].[MESSAGE]([CURRENCY_CODE]) ON [PRIMARY]",
            "create  INDEX [ValueDate] ON [dbo].[MESSAGE]([PAY_DATE], [PAY_TIME]) ON [PRIMARY]",
            "create  INDEX [InstructionDate] ON [dbo].[MESSAGE]([INST_DATE], [INST_TIME]) ON [PRIMARY]",
            "create  INDEX [DbtChrg] ON [dbo].[MESSAGE]([DBT_CHRG]) ON [PRIMARY]",
            "create  INDEX [CdtChrg] ON [dbo].[MESSAGE]([CDT_CHRG]) ON [PRIMARY]",
            "create  INDEX [Comission] ON [dbo].[MESSAGE]([COMMISSION]) ON [PRIMARY]",
            "create  INDEX [CblCharge] ON [dbo].[MESSAGE]([CBL_CHARGE]) ON [PRIMARY]",
            "create  INDEX [Imad] ON [dbo].[MESSAGE]([FED_IMAD]) ON [PRIMARY]",
            "create  INDEX [ChipSsn] ON [dbo].[MESSAGE]([CHP_SSN_6]) ON [PRIMARY]",
            "create  INDEX [SwiftMir] ON [dbo].[MESSAGE]([SWF_IN_MIR]) ON [PRIMARY]",

            "create  INDEX [qName] ON [dbo].[MESSAGE_HIST]([QUE_LINE_ID]) ON [PRIMARY]"
        };



        public void createAllRgwTables(string area)
        {
            /*
             * This one creates all the rgw tables.
             */
            tableDefs tableDefs = new tableDefs();
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE), true);
            }
            catch 
            {
                string x = tableDefs.buildCreateString(MESSAGE);
                dbWriter.Connect(true, area); 
            }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_ACCTG), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_CR), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_DEST), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_DR), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_HIST), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_MCH), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_PRM), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_PR_PVL), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_QUEUE), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_REL_AMT), true);
            }
            catch { dbWriter.Connect(true, area); }

            try
            {
                dbWriter.Execute(tableDefs.buildCreateString(MESSAGE_TEXT), true);
            }
            catch { dbWriter.Connect(true, area); }

            dbWriter.Dispose();
        }


        public void createAllRgwIndices(string area)
        {
            /*
             * This one adds all the indices to the rgw tables.
             */
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);
            for (int i = 0; i < createIndex.Length; i++)
            {
                try
                {
                    dbWriter.Execute(createIndex[i], true);
                }
                catch { dbWriter.Connect(true, area); }
            }
            dbWriter.Dispose();
        }


        public void dropAllRgwTables(string area)
        {
            /*
             * This one kills all the existing rgw tables.
             */
            DBAccess dbWriter = new DBAccess();
            dbWriter.Connect(true, area);

            try { dbWriter.Execute(dropMESSAGE, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_ACCTG, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_CR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_DEST, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_DR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_HIST, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_MCH, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_PRM, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_PR_PVL, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_QUEUE, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_REL_AMT, true); }
            catch { dbWriter.Connect(true, area); }

            try { dbWriter.Execute(dropMESSAGE_TEXT, true); }
            catch { dbWriter.Connect(true, area); }

            dbWriter.Dispose();
        }

        public void initMessageRepository(string area)
        {
            /*
             * Wipe 'em all out and make 'em again. Add the indices.
             */
            dropAllRgwTables(area);
            createAllRgwTables(area);
            createAllRgwIndices(area);
        }
    }
}

