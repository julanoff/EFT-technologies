#!/usr/bin/bash
#
#	wtx_pdu_diff.sh
#
#   Modification History:
#   =====================
#   09-Aug-2004 Jacob Novak
#	Copied from wtx_manual_pd_update, deleted FTP step.
#
# =============================================================================

#   Define the PD input and report file names

logext=$(date +"%m%d-%H%M%S")
diff_file=$AREA_ROOT_DIR/logs/manual_pd_diff.${logext}.log
err_file=$AREA_ROOT_DIR/logs/manual_pd_errors.${logext}.log

pd_file=$AREA_ROOT_DIR/input/partydict.dat
pd_new_file=$AREA_ROOT_DIR/input/partydict.tmp
pd_report=$AREA_ROOT_DIR/output/wtx0028.prt
pd_err_rpt=$AREA_ROOT_DIR/output/wtxmanpderr.prt

# --------------------------------------------------------------------------

rm -f $pd_new_file

#    Regular update:
#	There must be an existing PD
#	Prepare a report of the old PD for diff
#	Create a new new file
#	Prepare a report of the new PD for diff
#	Run differences, prepare update report
#	Announce

wtx_alarm INFO "%WTX_PD_DIFF-I-START, Party Dictionary difference report starting"

   if [[ ! -f "$AREA_ROOT_DIR/input/partydict.dat" ]]; then
   	 wtx_alarm ERROR "%WTX_PDU_DIFF_NOEXIST, Cannot diff PD; no prior PD"
    exit -1
   fi

# Create a new partydict.dat file 

pdu_dump_entia -ar diff

#   Copy the shm file to the RHS databases

#   wtx_data_currency -p PDPROD -s PDRHS1 -t PDRHS2

#   Create a differences report using the two contents reports.

rm -f $pd_report

diff -C 1 $pd_file $pd_new_file | wtx_pd_diff_rpt | \
	wtx_report_writer -t > $pd_report

#   Make a permanent copy of the differences report.

cp -p $pd_report $diff_file

if [[ $WTX_NY_RPT1_PRT != "" ]]; then
     lpr -P${WTX_NY_RPT1_PRT} $pd_report
     wtx_alarm INFO "%WTX_PD_DIFF-I-DIFFRPT, Differences report sent to WTX_NY_RPT1_PRT printer"
fi

if [[ $WTX_NY_RPT6_PRT != "" ]]; then
     lpr -P${WTX_NY_RPT6_PRT} $pd_report
     wtx_alarm INFO "%WTX_PD_DIFF-I-DIFFRPT, Differences report sent to WTX_NY_RPT6_PRT printer"
fi

if [[ $WTX_CHAR_RPT1_PRT != "" ]]; then
     lpr -P${WTX_CHAR_RPT1_PRT} $pd_report
     wtx_alarm INFO "%WTX_PD_DIFF-I-DIFFRPT, Differences report sent to WTX_CHAR_RPT1_PRT printer"
fi

#  Clean up

rm -f $pd_new_file

wtx_alarm INFO "%WTX_PD_DIFF-I-DONE, Party Dictionary Diff report completed"

exit 0
