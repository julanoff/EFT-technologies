#module	pdu_load_subs
    /*
       J. Richardson	19-Jun-00. The famous or infamous 'intrtl' trap
       where the cpd or pdu function croaks on an accvio. It turns out that
       this code defines (or used to) the same vars that another routine in
       the intrtl also defines. They don't define it the same way.
       So, I tweaked the variable names in here so they're distinct.
       The empirical evidence points to the problem being solved.

       J. Richardson    5-Dec-02. Change the 'short' simplification call
       to allow for 7 words. It used to be 5.

    */
#pragma builtins

#define account_length		16
#define max_length  50
    /* #define DBG			1 */

   char simple_b[max_length], inter_b[max_length];
   long simple_aray[7], inter_aray[6];
   long lenny, lenny1;
   long idx;

   unstring_action (
   char *inrec,
   int  ilen,
   char *action_id,
   short *action_id_len,
   char *acc_id,
   short *acc_id_len,
   char *rte,
   char *action,
   char *eflag
)
{
   int value, i, temp;

       /*
	  Go find the '/' that starts the action-id.
       */
   for ( i = 0; i < ilen; i++)
    {
      if (inrec[i] == '/') break;
    }
   if ( i == ilen) return(-1);	/* Fallen off the end? */

       /*
	  Ok, we're sitting on the start of the match string, so
	  let's go get the rest of it.
       */
   temp = 0;
   i++;
   while ( i < ilen)
    {
      if (inrec[i] == '/') break;
      action_id[temp++] = inrec[i++];
    }
   *action_id_len = temp;
   i++;
   if ( i == ilen) return(-1);	/* Fallen off the end? */

   while ( i < ilen)
    {
      if (inrec[i++] >= 'A') break;
    }
   if ( i == ilen) return(-1);	/* Fallen off the end? */
   i--;
   action[0] = inrec[i++];
   action[1] = inrec[i++];
   action[2] = inrec[i++];


   while ( i < ilen)
    {
      if (inrec[i++] >= 'A') break;
    }
   if ( i == ilen) return(-1);	/* Fallen off the end? */

       /*
	  Scoop up the account id and return it.
	  Not so fast Buster, in rare cases we don't
	  have an account string here; let's check
	  if we're looking at a routing code. Geesh.
       */
   i--;

   if ( (!strncmp( &inrec[i], "VFY", 3)) ||
      (  !strncmp( &inrec[i], "RPR", 3)) ||
      (  !strncmp( &inrec[i], "STP", 3)) )
    {
      i = i;
	  /*      continue; */
    }
   else
    {
      temp = 0;
      while ( i < ilen)
       {
	 if (inrec[i] <= ' ') break;
	 acc_id[temp++] = inrec[i++];
       }
      if ( i == ilen) return(-1);	/* Fallen off the end? */
      *acc_id_len = temp;
    }

       /*
	  The routing code is next. Find the start of the
	  next ascii string and then gobble up the text.
       */
   while ( i < ilen)
    {
      if (inrec[i++] >= 'A') break;
    }
   if ( i == ilen) return(-1);	/* Fallen off the end? */

   i--;
   temp = 0;
   while ( i < ilen)
    {
      if (inrec[i] <= ' ') break;
      rte[temp++] = inrec[i++];
    }
   if ( i == ilen) return(-1);	/* Fallen off the end? */


       /* And now for the enable/disable/sim flag */
       /*
	  Aha, but first comes the 'wild' flag ... so we need to skip
	  over that ... today's bug.
       */
   while ( i < ilen)
    {
      if (inrec[i++] >= 'A') break;
    }
   if ( i == ilen)
    {
	  /* Fallen off the end, default to enabled */
      *eflag = 'E';
    }


   while ( i < ilen)
    {
      if (inrec[i++] >= 'A') break;
    }
   if ( i == ilen)
    {
	  /* Fallen off the end, default to enabled */
      *eflag = 'E';
    }
   else
    {
      i--;
      *eflag = inrec[i];
    }
   return(1);
}

    /*

    */
unstring_primary (
	 char  *inrec,
	 int   inlen,
	 char  *primary_id,
	 short *primary_id_len,
	 char  *primary_key,
	 short *primary_key_len,
	 char  *eflag
	 )
{
   int i, j, eptr;

   eptr = 0;
   i    = 0;
   i    = inlen;

   *eflag = 'E';			/* Assume enabled. */

   for ( i = inlen -1; i >= 0; i--)
    {
      if (inrec[i] != ' ') break;
    }

   if (inrec[i] == '/')
    {
	  /*
	     Hmmm, we're looking at a slash in the input line and
	     this can (should?) only mean that we're sitting on the
	     tail end of an enable/disable/simulate entry. Let's deal
	     it - back up to the first '/', return the char immediately
	     following and then keep backing up in the input string
	     to find the tail of the primary id.
	  */

      i--;

      while ( i >= 0)
       {
	 if ( inrec[i] == '/')
	  {
		/*
		   Ok, we've found the beginning slash.
		*/
	    *eflag = inrec[i+1];
	    i--;
	    break;
	  }
	 i--;
       }


      while ( i >= 0)
       {
	 if ( inrec[i] >= 'A')
	  {
	    break;
	  }
	 i--;
       }
    }

       /*
	  Ok, we've figured out how long the input string is, so
	  let's return that back as the 'primary_id' which will
	  get used mostly for informational purposes.

	  The real 'key' to use will be the 'simplified' version of
	  the primary_id. The cpd simplifies lookup strings before
	  trying to find them in the party dictionary, so we need
	  to do the same thing and return the result as the 'primary_key'
	  to use and the index label.
       */

   for (j = 0; j <= i; j++)
    {
      primary_id[j] = inrec[j];
    }
   lenny = i+1;
   *primary_id_len = lenny;
   lenny1 = lenny;
       /*
	  So, now let's simplify this guy and return that result.
       */
   idx = mtf_cpd_simplify (inrec, &lenny, &simple_b, &inter_b,
	    &simple_aray, &inter_aray, 7);

   lenny = simple_aray[idx];

   for (j = 0; j <= lenny; j++)
    {
      primary_key[j] = simple_b[j];
    }
   *primary_key_len = lenny;

   return(1);
}


    /*

    */
unstring_synonym (
	 char *inrec,
	 int  inlen,
	 char *synonym_id,
	 short *synonym_id_len
	 )
{
   int i, j;

   i = 0;
   i = inlen;

       /*
	  This is pretty much the same thing that we do to pin down
	  a 'primary' id, with the exception that a synonym string
	  starts with a hyphen and we want to throw that away.
       */

   for ( i = inlen -1; i >= 0; i--)
    {
      if (inrec[i] > ' ') break;
    }

   for (j = 0; j < i; j++)
    {
      synonym_id[j] = inrec[j+1];
    }
   *synonym_id_len = i;
   return (1);
}



