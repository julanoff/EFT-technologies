﻿using System;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace SwfClient
{
    public class SwfClient
    {

        // It should look in the current dir from where this app is launched.
        
        [DllImport("Des.dll", EntryPoint = "des_pr", CharSet = CharSet.Auto)]
        public static extern int des_pr([MarshalAs(UnmanagedType.LPArray)] byte[] m_drv, [MarshalAs(UnmanagedType.LPArray)] byte[] m_pass);

        byte[] m_pass = new byte[200];
        byte[] m_drv = new byte[2];

        [STAThread]
        static void Main(string[] args)
        {
            SwfClient cln = new SwfClient();
            cln.dorcv(args);
        }
        private void dorcv(string[] args)
        {

            Console.WriteLine("TESTING DES DLL LOADING.");
            m_pass = System.Text.Encoding.ASCII.GetBytes("marina12345678901234567890123456");

            /*
             * BBT stuff for now, let's see if d:\simulator exists. Use D: as the drive if so...
             */ 

            try
            {
                string fName;
                string[] fList;
                ArrayList fArray = new ArrayList();
                fList = Directory.GetFiles(@"d:\simulator");

                for (int i = 0; i < fList.Length; i++)
                {
                    fName = fList[i];
                    fArray.Add(fName);
                }
                m_drv = System.Text.Encoding.ASCII.GetBytes("d:");
                Console.WriteLine("looking on the D: drive ...");
            }
            catch
            {
                m_drv = System.Text.Encoding.ASCII.GetBytes("c:"); 
                Console.WriteLine("looking on the C: drive ...");
            }

            
            try
            {
                des_pr(m_drv, m_pass);	// pass is a key that is created from LAU data. Do it once per session.
            }
            catch (Exception e)
            {
                string tmp = e.Message;
                Console.WriteLine("Exception: " + tmp);
            }
            Console.WriteLine("\nGood!");
            string hex = BitConverter.ToString(m_pass);
            Console.WriteLine(" pas - " + hex);
            Console.WriteLine("     ");
            Console.WriteLine("     ");

            string serverIP = "localhost";
            Console.WriteLine("TESTING DHS TRANSLATION. NAME - " + serverIP);
            IPHostEntry hostInfo = Dns.GetHostEntry(serverIP);
            string x = Dns.GetHostName();
            IPAddress[] address = hostInfo.AddressList;
            string m_serverIP = address[0].ToString();
            string m_serverIP2 = address[1].ToString();
            Console.WriteLine("address[0]: " + m_serverIP);
            Console.WriteLine("address[1]: " + m_serverIP2);
            Console.WriteLine("");
            //if (m_serverIP != "")
            //{
            //    Console.WriteLine("Good translation " + m_serverIP);
            //   // return;
            //}
            Console.WriteLine("     ");
            serverIP = "QWR-EFTIIS01"; //CHECK IF IT IS FINE!!!
            Console.WriteLine("TESTING DHS TRANSLATION. NAME - " + serverIP);
            try
            {
                hostInfo = Dns.GetHostEntry(serverIP);
                address = hostInfo.AddressList;
                m_serverIP = address[0].ToString();
                m_serverIP2 = address[1].ToString();
                Console.WriteLine("address[0]: " + m_serverIP);
                Console.WriteLine("address[1]: " + m_serverIP2);
                Console.WriteLine("");
            }
            catch (Exception e)
            {
                Console.WriteLine("Failure: " + e.Message);
            }
            //if (m_serverIP != "")
            //{
            //    Console.WriteLine("Good translation " + m_serverIP);
            //   // return;
            //}

        }
    }
}