/* --- The following code comes from c:\lcc\lib\wizard\dll.tpl. */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include "des.h"

/*------------------------------------------------------------------------
 Procedure:     LibMain ID:1
 Purpose:       Dll entry point.Called when a dll is loaded or
                unloaded by a process, and when new threads are
                created or destroyed.
 Input:         LAU file
 Output:        pass for encryption
 Errors:
------------------------------------------------------------------------*/

BOOL WINAPI __declspec(dllexport)  LibMain (HINSTANCE hInst, DWORD Reason, LPVOID Reserved)
//BOOL WINAPI   DllMain(HINSTANCE hInst, DWORD Reason, LPVOID Reserved)
{
	printf("DllMain enter\n");
  if(Reason==DLL_PROCESS_ATTACH)
	{
		printf("DllMain - process attach\n");
  	return   TRUE;
  	}

  if(Reason==DLL_PROCESS_DETACH)
  	{
		printf("DllMain - process detach\n");
  	return   TRUE;
  	}
printf("DllMain - didn't recognize reason %d", Reason);
  return   FALSE;
}


__declspec(dllexport) void __stdcall des_pr(drv, pass)

char *drv;
unsigned char *pass;

{
	 printf ("des_pr enter.\n");
	  typedef struct
	  {
	    des_cblock hi;
	    des_cblock lo;
	  } desKey;
	  des_cblock *KeyIn;
	  des_cblock *KeyOut;

	  des_key_schedule localKeySchedHi;
	  des_key_schedule localKeySchedLo;

	  desKey localKey;
	  char key1[11];
	  int i;
	  int iCount;
	  int iStrCryptLen;
	  size_t szFileLength;
	  char *pxStrCrypt = NULL;
	  char Rec[400];
	  char *px;
	  char *pxszStrCrypt = NULL;
	  char fname[26];
	  printf ("des_pr drive %s.\n", drv);
      sprintf(fname, "%s\\simulator\\laukey.dat", drv);
	  printf ("des_pr laukey file name %s.\n", fname);
	  FILE *iSecretFile = fopen(fname, "r");
        	if (iSecretFile)
        	{	printf ("file here %s\n", fname);
        	}
        	else
			{
				printf ("LAU not found.\n");
				return;
			}
			szFileLength = fread(Rec, sizeof(char), 400, iSecretFile);
  	  		fclose(iSecretFile);
			printf ("des_pr read  %u bytes from secret file.\n", szFileLength);

			for ( px = Rec; px < (Rec + szFileLength); px++ )
    		{
		      if ( !strncmp( px, "Length=", 7 ))
		        pxszStrCrypt = (px + 7);
		      if ( !strncmp( px, "EncryptedData=", 14 ))
		        pxStrCrypt = (px + 14);
		    }
			px = memchr(pxszStrCrypt, '\n', 4);

			if (!(NULL == px))
		    {
		      *px = '\0';
		      iStrCryptLen = atoi( pxszStrCrypt );
		    }
			else
				printf ("error in size.\n");

			strcpy(key1, "MasterKey12");
			des_string_to_2keys(key1, &(localKey.hi), &(localKey.lo));

			if (i = des_set_key(&localKey.lo, localKeySchedLo))
				printf ("1st call to des_set_key failed.\n");


			if (i = des_set_key(&localKey.hi, localKeySchedHi))
				printf ("2nd call to des_set_key failed.\n");

			memset(&localKey, '\0', sizeof(localKey));

			KeyIn = (des_cblock*)pxStrCrypt;
			KeyOut = (des_cblock*)pass;

			for (iCount = 0; iCount < iStrCryptLen; iCount += DES_KEY_SZ)
		    {
		       des_ecb3_encrypt(KeyIn, KeyOut,
                        localKeySchedHi, localKeySchedLo, localKeySchedHi,
                        DES_DECRYPT);
		       KeyIn++;
		       KeyOut++;
		    }

			return ;
}
